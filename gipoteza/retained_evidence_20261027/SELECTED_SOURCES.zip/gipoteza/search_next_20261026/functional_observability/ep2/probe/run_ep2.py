#!/usr/bin/env python3
"""Frozen EP2: complete minimal-separator IUT, VAL-only selection, fresh TEST."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np
from scipy.stats import poisson

HERE=Path(__file__).resolve().parent
EP1=HERE.parents[1]/"probe"
ROOT=HERE.parents[4]
sys.path.insert(0,str(EP1))
import run_probe as ep1
from cut_family import enumerate_minimal_cuts,cut_matrix,verify_exhaustive_4x4,verify_family_minimality
from controls import evaluate_controls,verify_controls

DOSES=[.5,1.,2.,4.]
REPEATS=16
ALPHA=.025
LIMIT=600.
START=None
PRIMARY_ORDER=["ep2_unweighted","ep2_weighted:1","ep2_weighted:0.5","ep2_weighted:2"]
TAU_ORDER=["1","0.5","2"]


def sha(data):return hashlib.sha256(data).hexdigest()


def dump(name,value):
    p=HERE/name;t=p.with_suffix(p.suffix+".tmp")
    t.write_text(json.dumps(value,indent=2,ensure_ascii=False));t.replace(p)


def elapsed():return time.perf_counter()-START


def progress(stage):
    info={"stage":stage,"elapsed_seconds":elapsed(),"complete":False}
    dump("PROGRESS.json",info);print(json.dumps(info),flush=True)
    if elapsed()>LIMIT:raise TimeoutError("Frozen600second EP2limit exceeded")


def identity(mask):return ep1.canonical(mask)


def prepare_geometry():
    oldpath=ROOT/"gipoteza/search_20261026/sem_electrical/PATCHES.npz"
    old=np.load(oldpath);manifest=json.loads((oldpath.parent/"MANIFEST.json").read_text())
    trainkeys=set();valbykey={}
    for i,mask in enumerate(old["Y"]):
        frame=int(old["frame"][i])
        if frame not in range(8):continue
        for qr,qc in itertools.product(range(2),repeat=2):
            patch=mask[6*qr:6*(qr+1),6*qc:6*(qc+1)]
            key=identity(patch)
            if frame<6:trainkeys.add(key);continue
            item={"source":str(oldpath.relative_to(ROOT)),"index":i,"frame":frame,
                  "quadrant":[qr,qc],"y":int(manifest[i]["y"])+6*qr,
                  "x":int(manifest[i]["x"])+6*qc}
            item["id_sha256"]=sha(json.dumps(item,sort_keys=True).encode())
            item["canonical_hex"]=key.hex()
            prev=valbykey.get(key)
            if prev is None or item["id_sha256"]<prev[0]["id_sha256"]:
                valbykey[key]=(item,patch.copy())
    groups=[[],[]]
    for key,(item,mask) in valbykey.items():
        if key in trainkeys:continue
        lab=ep1.lr_bit(mask);item["label"]=lab;groups[lab].append((item,mask))
    for group in groups:group.sort(key=lambda pair:pair[0]["id_sha256"])
    n=min(128,*(len(g) for g in groups))
    if n==0:raise ValueError("No independent VAL geometry available for bothclasses")
    valitems=groups[0][:n]+groups[1][:n]
    selection=json.loads((EP1/"SELECTION.json").read_text())
    testitems=selection["future_cnn_holdout"]
    archive=np.load(EP1/"GEOMETRIES.npz")
    testmasks=archive["future_M"]
    if len(testmasks)!=256 or len(testitems)!=256:
        raise ValueError("Expected pre-reserved256TESTgeometry")
    pilotkeys={identity(m) for m in archive["M"]}
    valkeys={identity(m) for _,m in valitems}
    seen=set()
    for item,m in zip(testitems,testmasks):
        key=identity(m)
        if key.hex()!=item["canonical_hex"] or ep1.lr_bit(m)!=item["label"]:
            raise AssertionError("ReservedTESTmetadata/mask mismatch")
        if key in seen or key in trainkeys or key in valkeys or key in pilotkeys:
            raise AssertionError("Geometry leakage")
        seen.add(key)
    valmasks=np.stack([m for _,m in valitems]);valtruth=np.array([i["label"] for i,_ in valitems])
    valframes=np.array([i["frame"] for i,_ in valitems])
    testtruth=np.array([i["label"] for i in testitems]);testframes=np.array([i["frame"] for i in testitems])
    almost=[]
    for i in np.flatnonzero(testtruth==0):
        for r,c in np.argwhere(~testmasks[i]):
            candidate=testmasks[i].copy();candidate[r,c]=True
            if ep1.lr_bit(candidate):almost.append(int(i));break
    metadata={"VAL":[i for i,_ in valitems],"TEST":testitems,
              "train_unique_hv":len(trainkeys),"val_available_by_class":[len(g) for g in groups],
              "val_selected_per_class":n,"test_selected_per_class":128,
              "almost_connected_test_negative_indices":almost,
              "all_disjointness_checks_passed":True,
              "input_sha256":{str(oldpath.relative_to(ROOT)):sha(oldpath.read_bytes()),
                 str((EP1/"GEOMETRIES.npz").relative_to(ROOT)):sha((EP1/"GEOMETRIES.npz").read_bytes()),
                 str((EP1/"SELECTION.json").relative_to(ROOT)):sha((EP1/"SELECTION.json").read_bytes())}}
    dump("SELECTION.json",metadata)
    np.savez_compressed(HERE/"GEOMETRIES.npz",VAL_M=valmasks,VAL_truth=valtruth,VAL_frame=valframes,
                         TEST_M=testmasks,TEST_truth=testtruth,TEST_frame=testframes)
    return (valmasks,valtruth,valframes),(testmasks,testtruth,testframes),almost


class CutEvaluator:
    def __init__(self,cuts):
        self.matrix=cut_matrix(cuts,6,6).reshape(len(cuts),36)
        self.floatmatrix=self.matrix.astype(float)
        self.lengths=self.matrix.sum(axis=1).astype(int)
        self.indices=np.full((len(cuts),int(self.lengths.max())),36,dtype=int)
        for i,row in enumerate(self.matrix):
            positions=np.flatnonzero(row);self.indices[i,:len(positions)]=positions

    def evaluate(self,b,qa_by_tau,tb):
        """Allcuts evaluated, same completefamily for everyinput/candidate."""
        names=["ep2_unweighted"]+[f"ep2_weighted:{tau:g}" for tau in [.5,1.,2.]]
        output={name:np.zeros(len(b)) for name in names}
        flatb=b.reshape(-1,36)
        maxsum=int(flatb.max())*int(self.lengths.max())
        lengths=np.arange(int(self.lengths.max())+1)
        tail=poisson.sf(np.arange(maxsum+1)[None,:]-1,2*tb*lengths[:,None])
        pixel_tail=poisson.sf(np.arange(int(flatb.max())+1)-1,2*tb)
        for lo in range(0,len(b),128):
            hi=min(lo+128,len(b));data=flatb[lo:hi]
            sums=np.rint(data @ self.floatmatrix.T).astype(np.int32)
            psum=tail[self.lengths[None,:],sums]
            pp=pixel_tail[data]
            for name in names:
                if name=="ep2_unweighted":v=np.ones_like(pp,dtype=float)
                else:v=qa_by_tau[float(name.split(":")[1])][lo:hi].reshape(-1,36)
                sumv=v @ self.floatmatrix.T
                ratio=np.concatenate([pp/v,np.full((len(data),1),np.inf)],axis=1)
                minimum=np.min(ratio[:,self.indices],axis=2)
                patomic=np.minimum(1.,minimum*sumv)
                pk=np.minimum(1.,np.minimum(2*patomic,2*psum))
                output[name][lo:hi]=pk.max(axis=1)
            if lo%1024==0:progress(f"completecuts_batch_{lo}_of{len(b)}")
        return output


def classify(conn,no_conn):
    return np.where(conn&~no_conn,1,np.where(~conn&no_conn,0,-1)).astype(np.int8)


def run_phase(name,data,seeds,evaluator):
    masks,truth,frames=data;n=len(masks)
    ra=np.random.default_rng(seeds[0]);rb=np.random.default_rng(seeds[1])
    predictions=[];allkeys=None;diagnostics=[]
    for dose in DOSES:
        mean=2+6*masks.astype(float)
        a=ra.poisson(.2*dose*mean[:,None],size=(n,REPEATS,6,6)).astype(np.int16)
        b=rb.poisson(.8*dose*mean[:,None],size=(n,REPEATS,6,6)).astype(np.int16)
        fa=a.reshape(-1,6,6);fb=b.reshape(-1,6,6)
        progress(f"{name}_dose{dose:g}_controls")
        scores,conns,no_conn,qa=evaluate_controls(fa,fb,dose)
        progress(f"{name}_dose{dose:g}_cut_scores")
        cut_scores=evaluator.evaluate(fb,qa,.8*dose)
        for key,value in cut_scores.items():scores[key]=value;conns[key]=value<=ALPHA
        # Proven dominance check: max cutlength14 gives2|K|<36.
        if np.any(conns["pixel_bonferroni"]&~conns["ep2_unweighted"]):
            raise AssertionError("UnweightedEP2failedprovenBonfdominance")
        keys=sorted(conns)
        if allkeys is None:allkeys=keys
        elif keys!=allkeys:raise AssertionError("Methods changed acrossdoses")
        pred=np.stack([classify(conns[k],no_conn) for k in keys]).reshape(len(keys),n,REPEATS)
        predictions.append(pred)
        diagnostics.append({"dose":dose,"no_conn_certificates":int(no_conn.sum()),
             "conflicts":{k:int((conns[k]&no_conn).sum()) for k in keys},
             "raw_false_conn":{k:int(conns[k].reshape(n,REPEATS)[truth==0].sum()) for k in keys},
             "raw_false_disc":int(no_conn.reshape(n,REPEATS)[truth==1].sum())})
        save={"A":a,"B":b,"no_conn_cert":no_conn.reshape(n,REPEATS),
              "predictions":pred,"method":np.array(keys)}
        for key in keys:
            save["score__"+key]=np.asarray(scores[key]).reshape(n,REPEATS)
            save["conn__"+key]=conns[key].reshape(n,REPEATS)
        np.savez_compressed(HERE/f"{name}_dose_{dose:g}.npz",**save)
        progress(f"{name}_dose{dose:g}_complete")
    preds=np.stack(predictions)
    counts=np.stack([ep1.counts_metrics(truth,p) for p in preds])
    f1=ep1.f1_from_counts(counts.sum(axis=2))
    metrics={key:{"primary_macro_f1":float(f1[:,i].mean()),"by_dose_macro_f1":f1[:,i].tolist(),
            "coverage":[float((preds[d,i]!=-1).mean()) for d in range(4)]}
             for i,key in enumerate(allkeys)}
    dump(f"{name}_ALL_METRICS.json",{"metrics":metrics,"diagnostics":diagnostics,
         "scope":"allfixedcalibratorsretained; choicebyVALonly"})
    return allkeys,preds,counts,metrics,diagnostics


def select_calibrators(keys,metrics):
    main=max(PRIMARY_ORDER,key=lambda k:metrics[k]["primary_macro_f1"])
    controls={}
    for base in ["selected_iut","local_slrt","full_slrt","ep1_mix_e","weighted_holm"]:
        options=[f"{base}:{t}" for t in TAU_ORDER]
        controls[base]=max(options,key=lambda k:metrics[k]["primary_macro_f1"])
    controls["pixel_bonferroni"]="pixel_bonferroni";controls["holm"]="holm"
    controls["hochberg"]="hochberg"
    if main!="ep2_unweighted":controls["unweighted_ep2_ablation"]="ep2_unweighted"
    return main,controls


def paired_ci(counts,frames,main_index,control_indices,hierarchical):
    rng=np.random.default_rng(261026205 if hierarchical else 261026206)
    fids=np.unique(frames);groups={f:np.flatnonzero(frames==f) for f in fids}
    samples=[]
    for _ in range(1000):
        if hierarchical:
            chosen=rng.choice(fids,len(fids),replace=True)
            idx=np.concatenate([rng.choice(groups[f],len(groups[f]),replace=True) for f in chosen])
        else:idx=rng.integers(0,len(frames),len(frames))
        f1=ep1.f1_from_counts(counts[:,:,idx].sum(axis=2)).mean(axis=0)
        samples.append(f1[main_index]-f1[control_indices])
    arr=np.array(samples)
    return np.quantile(arr,[.025,.975],axis=0).T


def main():
    global START
    START=time.perf_counter()
    frozen=[HERE/"FROZEN_PROTOCOL.md",HERE/"run_ep2.py",HERE/"cut_family.py",HERE/"controls.py",
            EP1/"run_probe.py",EP1/"slrt_oracle.py"]
    dump("RUN_FROZEN.json",{"sha256":{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in frozen},
                           "runtime_limit_seconds":LIMIT})
    progress("completefamily_andgeometry_verification")
    cuts=enumerate_minimal_cuts(6,6)
    verification={"4x4":verify_exhaustive_4x4(enumerate_minimal_cuts(4,4)),
                  "6x6":verify_family_minimality(cuts,6,6),
                  "unknown_f1":ep1.verify_unknown_metric(),"holm":verify_controls()}
    dump("RUN_VERIFICATION.json",verification)
    np.savez_compressed(HERE/"CUT_FAMILY.npz",codes=np.asarray(cuts,dtype=np.uint64),
                         masks=cut_matrix(cuts,6,6))
    val,test,almost=prepare_geometry()
    progress("dataIDs_andfamily_saved_before_scores")
    evaluator=CutEvaluator(cuts)
    valkeys,vpred,vcounts,valmetrics,vdiagnostics=run_phase("VAL",val,(261026201,261026202),evaluator)
    mainkey,controls=select_calibrators(valkeys,valmetrics)
    chosen={"primary":mainkey,"controls":controls,"all_VAL_metrics":valmetrics,
            "selection_rule":"maximumVALavg4doseF1; fixedtieorder; TESTunused",
            "elapsed_seconds":elapsed(),"neural_training":False}
    dump("VAL_SELECTION_BEFORE_TEST.json",chosen)
    progress("VALselection_frozen_before_TESTcounts")
    keys,preds,counts,metrics,diagnostics=run_phase("TEST",test,(261026203,261026204),evaluator)
    names=list(controls);ciidx=[keys.index(controls[n]) for n in names];mi=keys.index(mainkey)
    sourceci=paired_ci(counts,test[2],mi,ciidx,True)
    geoci=paired_ci(counts,test[2],mi,ciidx,False)
    basepoint=metrics[mainkey]["primary_macro_f1"]
    comparisons={}
    for j,name in enumerate(names):
        control=controls[name];diff=basepoint-metrics[control]["primary_macro_f1"]
        comparisons[name]={"calibrator":control,"difference":diff,
          "hierarchical_ci95":sourceci[j].tolist(),"geometry_only_ci95":geoci[j].tolist(),
          "passed":bool(diff>=.02 and sourceci[j,0]>0)}
    success=all(v["passed"] for v in comparisons.values())
    selected_metrics={"primary":metrics[mainkey]}
    for name,key in controls.items():selected_metrics[name]=metrics[key]
    for name,key in [("primary",mainkey)]+list(controls.items()):
        m=keys.index(key)
        selected_metrics[name]["details"]=[]
        for di,d in enumerate(DOSES):
            pred=preds[di,m];truth=test[1]
            selected_metrics[name]["details"].append({"dose":d,
                 "false_connection_final":int((pred[truth==0]==1).sum()),
                 "negative_draws":int((truth==0).sum()*REPEATS),
                 "false_disconnection_final":int((pred[truth==1]==0).sum()),
                 "positive_draws":int((truth==1).sum()*REPEATS),
                 "almost_connected_false_connection_final":int((pred[almost]==1).sum()),
                 "almost_connected_draws":len(almost)*REPEATS})
    result={"complete":True,"gate":"PASS" if success else "FAIL","primary":mainkey,
      "chosen_controls":controls,"selected_metrics":selected_metrics,"comparisons":comparisons,
      "all_TEST_metrics":metrics,"diagnostics":diagnostics,"verification":verification,
      "test_geometry_count":len(test[0]),"VAL_geometry_count":len(val[0]),
      "test_count_draws":len(test[0])*4*REPEATS,"VAL_count_draws":len(val[0])*4*REPEATS,
      "almost_connected_test_negatives":len(almost),"elapsed_seconds":elapsed(),
      "neural_training":False,"scope":"knownindependentintegerPoisson2intensity,zeroPSF,analyticproposal; finitegeometrysameIC; noCNNorrealSEMconfirmation"}
    dump("RESULT.json",result)
    np.savez_compressed(HERE/"TEST_PREDICTIONS.npz",predictions=preds,counts=counts,truth=test[1],
                         frame=test[2],method=np.array(keys),dose=np.array(DOSES))
    progress("allmethods_allcalibrators_complete")
    dump("PROGRESS.json",{"complete":True,"gate":result["gate"],"elapsed_seconds":elapsed()})
    print(json.dumps({"gate":result["gate"],"primary":mainkey,"metrics":selected_metrics,
                      "comparisons":comparisons,"elapsed_seconds":elapsed()},ensure_ascii=False),flush=True)


if __name__=="__main__":
    try:main()
    except BaseException as exc:
        if START is not None:dump("ERROR.json",{"complete":False,"type":type(exc).__name__,
            "message":str(exc),"elapsed_seconds":elapsed()})
        raise
