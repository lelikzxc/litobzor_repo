"""Complete minimal separators of a binary pixel grid (geometry only).

Foreground uses 4-adjacency and left/right terminals.  Its absence is
equivalent, on a rectangular image, to an 8-adjacent background top/bottom
path.  Inclusion-minimal separators are exactly the vertex sets of induced
8-paths with one top and one bottom boundary vertex.

No probability model, counts, images, TRAIN/VAL/TEST data, or metric is read.
The CLI enumerates and verifies tiny families and writes VERIFICATION.json.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np


def neighbor_masks(height: int, width: int, adjacency: int = 8) -> list[int]:
    if height < 1 or width < 1 or adjacency not in (4, 8):
        raise ValueError("positive dimensions and 4/8 adjacency required")
    result = []
    for row in range(height):
        for col in range(width):
            neighbors = 0
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    if (dr == dc == 0) or (adjacency == 4 and abs(dr) + abs(dc) != 1):
                        continue
                    rr, cc = row + dr, col + dc
                    if 0 <= rr < height and 0 <= cc < width:
                        neighbors |= 1 << (rr * width + cc)
            result.append(neighbors)
    return result


def enumerate_minimal_cuts(height: int, width: int, *, time_limit: float = 570.0) -> list[int]:
    """Enumerate ALL minimal 4-LR vertex cuts as induced 8-TB paths.

    Row-major bit i denotes row=i//width, column=i%width.  Paths start on
    one top vertex, never visit another top vertex, and stop at the first
    bottom vertex.  Every extension has no 8-neighbor in the visited path
    except its immediate predecessor, so the final path has no chord.

    A deadline aborts with an error; a partial family is never returned.
    """
    if height < 1 or width < 1:
        raise ValueError("positive dimensions required")
    if height * width > 63:
        raise ValueError("verification helpers support at most 63 vertices")
    started = time.perf_counter()
    neighbors = neighbor_masks(height, width, 8)
    all_bits = (1 << (height * width)) - 1
    top = (1 << width) - 1
    bottom = top << ((height - 1) * width)
    extension_allowed = all_bits ^ top
    paths: list[int] = []
    visited_states = 0

    def visit(current: int, visited: int, forbidden: int) -> None:
        nonlocal visited_states
        visited_states += 1
        if visited_states % 65536 == 0 and time.perf_counter() - started > time_limit:
            raise TimeoutError("complete family enumeration exceeded deadline; no partial output returned")
        if (1 << current) & bottom:
            paths.append(visited)
            return
        # forbidden is the union of neighborhoods of all OLD vertices,
        # excluding current.  This enforces the exact no-chord condition.
        candidates = neighbors[current] & ~visited & ~forbidden & extension_allowed
        next_forbidden = forbidden | neighbors[current]
        while candidates:
            next_bit = candidates & -candidates
            candidates ^= next_bit
            visit(next_bit.bit_length() - 1, visited | next_bit, next_forbidden)

    for col in range(width):
        visit(col, 1 << col, 0)
    family = sorted(set(paths))
    if len(family) != len(paths):
        raise AssertionError("a unique-boundary induced path was enumerated more than once")
    return family


def cut_matrix(cuts: list[int] | np.ndarray, height: int, width: int) -> np.ndarray:
    """Return bool [number_of_cuts,height,width], retaining every cut."""
    codes = np.asarray(cuts, dtype=np.uint64)
    positions = np.arange(height * width, dtype=np.uint64)
    return ((codes[:, None] >> positions) & np.uint64(1)).astype(bool).reshape(-1, height, width)


def has_lr_connection(codes: np.ndarray, height: int, width: int) -> np.ndarray:
    """Vectorized bitboard 4-connectivity, independent of path DFS."""
    codes = np.asarray(codes, dtype=np.uint64)
    count = height * width
    if not (1 <= count <= 63):
        raise ValueError("1..63 pixels supported")
    full = np.uint64((1 << count) - 1)
    left = np.uint64(sum(1 << (row * width) for row in range(height)))
    right = np.uint64(sum(1 << (row * width + width - 1) for row in range(height)))
    reached = codes & left
    for _ in range(count):
        adjacent = (
            ((reached << np.uint64(1)) & ~left)
            | ((reached >> np.uint64(1)) & ~right)
            | (reached << np.uint64(width))
            | (reached >> np.uint64(width))
        ) & full
        updated = reached | (adjacent & codes)
        if np.array_equal(updated, reached):
            break
        reached = updated
    return (reached & right) != 0


def verify_exhaustive_4x4(family: list[int]) -> dict:
    """Compare DFS against EVERY binary mask and EVERY minimal subset cut."""
    height = width = 4
    count = 16
    full = np.uint64((1 << count) - 1)
    all_subsets = np.arange(1 << count, dtype=np.uint64)
    connected_foreground = has_lr_connection(all_subsets, height, width)
    # Here a subset is interpreted as BACKGROUND, not foreground.
    cut_status = ~has_lr_connection(full ^ all_subsets, height, width)
    minimal = cut_status.copy()
    for index in range(count):
        bit = np.uint64(1 << index)
        has_vertex = (all_subsets & bit) != 0
        removed = all_subsets ^ bit
        minimal &= ~has_vertex | ~cut_status[removed.astype(np.int64)]
    exact_family = {int(value) for value in all_subsets[minimal]}
    dfs_family = set(family)
    missing = sorted(exact_family - dfs_family)
    extras = sorted(dfs_family - exact_family)
    if missing or extras:
        raise AssertionError({"missing_count": len(missing), "extra_count": len(extras), "first_missing": missing[:10], "first_extra": extras[:10]})
    contains_cut = np.zeros(len(all_subsets), dtype=bool)
    for value in family:
        cut = np.uint64(value)
        contains_cut |= (all_subsets & cut) == cut
    expected_no_connection = ~has_lr_connection(full ^ all_subsets, height, width)
    disagreements = int(np.count_nonzero(contains_cut != expected_no_connection))
    if disagreements:
        raise AssertionError("background-cut equivalence fails")
    return {
        "all_masks": int(len(all_subsets)),
        "foreground_connected_count": int(connected_foreground.sum()),
        "minimal_cut_family_count": len(family),
        "complete_family_equals_exhaustive_minimal_subsets": True,
        "no_foreground_connection_iff_contains_background_cut_disagreements": disagreements,
        "every_cut_vertex_necessary": True,
        "family_code_sha256": hashlib.sha256(np.asarray(family, dtype="<u8").tobytes()).hexdigest(),
    }


def verify_family_minimality(family: list[int], height: int, width: int) -> dict:
    """Every enumerated cut separates; every constituent vertex is needed."""
    codes = np.asarray(family, dtype=np.uint64)
    full = np.uint64((1 << (height * width)) - 1)
    if np.any(has_lr_connection(full ^ codes, height, width)):
        raise AssertionError("enumerated set fails to separate foreground")
    tested_vertex_removals = 0
    for index in range(height * width):
        bit = np.uint64(1 << index)
        selected = codes[(codes & bit) != 0]
        tested_vertex_removals += len(selected)
        foreground_after_removal = (full ^ selected) | bit
        if np.any(~has_lr_connection(foreground_after_removal, height, width)):
            raise AssertionError("enumerated cut contains a redundant vertex")
    lengths = [value.bit_count() for value in family]
    return {
        "minimal_cut_family_count": len(family),
        "max_cut_length": max(lengths),
        "min_cut_length": min(lengths),
        "every_cut_separates_4LR_foreground": True,
        "every_cut_vertex_necessary": True,
        "vertex_removal_checks": int(tested_vertex_removals),
        "family_code_sha256": hashlib.sha256(np.asarray(family, dtype="<u8").tobytes()).hexdigest(),
    }


def main(output: Path) -> None:
    started = time.perf_counter()
    stage = time.perf_counter()
    family4 = enumerate_minimal_cuts(4, 4)
    enumerate4_seconds = time.perf_counter() - stage
    stage = time.perf_counter()
    verify4 = verify_exhaustive_4x4(family4)
    verify4_seconds = time.perf_counter() - stage
    stage = time.perf_counter()
    family6 = enumerate_minimal_cuts(6, 6)
    enumerate6_seconds = time.perf_counter() - stage
    stage = time.perf_counter()
    verify6 = verify_family_minimality(family6, 6, 6)
    verify6_seconds = time.perf_counter() - stage
    result = {
        "status": "PASS",
        "scope": "geometry and completeness preflight only; no images, counts, or experiment metrics read",
        "foreground_adjacency": 4,
        "cut_adjacency": 8,
        "algorithm": "complete induced8-TB-path DFS, one top and bottom vertex, no chords",
        "4x4": verify4,
        "6x6": verify6,
        "timing_seconds": {
            "enumeration_4x4": enumerate4_seconds,
            "exhaustive_verification_4x4": verify4_seconds,
            "enumeration_6x6": enumerate6_seconds,
            "minimality_verification_6x6": verify6_seconds,
            "total": time.perf_counter() - started,
        },
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(json.dumps(result, indent=2) + "\n")
    temporary.replace(output)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("VERIFICATION.json"))
    args = parser.parse_args()
    main(args.output)
