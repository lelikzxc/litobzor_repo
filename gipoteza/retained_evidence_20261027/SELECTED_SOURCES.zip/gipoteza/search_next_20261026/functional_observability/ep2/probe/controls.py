"""Frozen EP2 comparison methods; importing this module reads no dataset.

All evidence uses independent B counts; q_A, selected paths, corridors and
Holm weights use A only.  This is restricted to the known independent
two-intensity Poisson count model from FROZEN_PROTOCOL.md.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import binary_dilation
from scipy.special import expit
from scipy.stats import poisson


HERE = Path(__file__).resolve().parent
EP1 = HERE.parent.parent / "probe"
if str(EP1) not in sys.path:
    sys.path.insert(0, str(EP1))
_spec = importlib.util.spec_from_file_location("_frozen_ep1_run_probe", EP1 / "run_probe.py")
if _spec is None or _spec.loader is None:
    raise ImportError("cannot load frozen EP1 helpers")
_ep1 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_ep1)
_oracle = importlib.import_module("slrt_oracle")

ALPHA = 0.025
LOG_THRESHOLD = float(np.log(1 / ALPHA))
TAUS = (0.5, 1.0, 2.0)
STRUCTURE_4 = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)


def holm_adjusted(pvalues: np.ndarray, weights: np.ndarray | None = None) -> np.ndarray:
    """Exact ordinary/weighted Holm adjusted p-values, arbitrary dependence.

    Sort p_i/v_i, test sequentially at alpha*v_i/sum(remaining v).
    Weights need not be normalized; a common scale cancels.  Cumulative
    maxima implement the stop-after-first-failure rule for every alpha.
    The final axis indexes hypotheses; all preceding axes are batch axes.
    """
    pvalues = np.asarray(pvalues, dtype=np.float64)
    if pvalues.ndim < 1 or pvalues.shape[-1] < 1:
        raise ValueError("at least one p-value is required")
    if not np.all(np.isfinite(pvalues)) or np.any((pvalues < 0) | (pvalues > 1)):
        raise ValueError("p-values must be finite and in [0,1]")
    if weights is None:
        weights = np.ones_like(pvalues)
    else:
        weights = np.broadcast_to(np.asarray(weights, dtype=np.float64), pvalues.shape)
        if not np.all(np.isfinite(weights)) or np.any(weights <= 0):
            raise ValueError("weights must be finite and strictly positive")
    order = np.argsort(pvalues / weights, axis=-1, kind="stable")
    ordered_p = np.take_along_axis(pvalues, order, axis=-1)
    ordered_w = np.take_along_axis(weights, order, axis=-1)
    remaining = np.flip(np.cumsum(np.flip(ordered_w, axis=-1), axis=-1), axis=-1)
    adjusted_ordered = np.minimum(
        1.0, np.maximum.accumulate(ordered_p * remaining / ordered_w, axis=-1)
    )
    adjusted = np.empty_like(adjusted_ordered)
    np.put_along_axis(adjusted, order, adjusted_ordered, axis=-1)
    return adjusted


def hochberg_adjusted(pvalues: np.ndarray) -> np.ndarray:
    """Ordinary Hochberg step-up adjusted p-values, independent B pixels.

    For ordered p_(j), the adjusted value is min_{k>=j}(m-k+1)*p_(k).
    This uses the true conditional pixel independence of the frozen count
    model; it is not asserted under arbitrary dependence or real SEM blur.
    """
    pvalues = np.asarray(pvalues, dtype=np.float64)
    if pvalues.ndim < 1 or pvalues.shape[-1] < 1:
        raise ValueError("at least one p-value is required")
    if not np.all(np.isfinite(pvalues)) or np.any((pvalues < 0) | (pvalues > 1)):
        raise ValueError("p-values must be finite and in [0,1]")
    count = pvalues.shape[-1]
    order = np.argsort(pvalues, axis=-1, kind="stable")
    ordered = np.take_along_axis(pvalues, order, axis=-1)
    scaled = ordered * np.arange(count, 0, -1, dtype=np.float64)
    adjusted_ordered = np.minimum(
        1.0, np.flip(np.minimum.accumulate(np.flip(scaled, axis=-1), axis=-1), axis=-1)
    )
    adjusted = np.empty_like(adjusted_ordered)
    np.put_along_axis(adjusted, order, adjusted_ordered, axis=-1)
    return adjusted


def connectivity_level(pixel_levels: np.ndarray) -> np.ndarray:
    """Smallest threshold admitting a 4-connected left/right pixel path.

    A fixed Bellman-Ford bottleneck iteration computes min_path max_i score_i
    simultaneously for a batch.  Hence score<=alpha exactly equals checking
    4-connectivity of pixel_levels<=alpha; diagonals are never introduced.
    """
    pixel_levels = np.asarray(pixel_levels, dtype=np.float64)
    if pixel_levels.ndim != 3 or min(pixel_levels.shape[1:]) < 1:
        raise ValueError("expected batch,height,width pixel-level scores")
    n, height, width = pixel_levels.shape
    distance = np.full_like(pixel_levels, np.inf)
    distance[:, :, 0] = pixel_levels[:, :, 0]
    for _ in range(height * width - 1):
        neighbor = np.full_like(distance, np.inf)
        neighbor[:, 1:, :] = np.minimum(neighbor[:, 1:, :], distance[:, :-1, :])
        neighbor[:, :-1, :] = np.minimum(neighbor[:, :-1, :], distance[:, 1:, :])
        neighbor[:, :, 1:] = np.minimum(neighbor[:, :, 1:], distance[:, :, :-1])
        neighbor[:, :, :-1] = np.minimum(neighbor[:, :, :-1], distance[:, :, 1:])
        updated = np.minimum(distance, np.maximum(pixel_levels, neighbor))
        if np.array_equal(updated, distance):
            break
        distance = updated
    return distance[:, :, -1].min(axis=1)


def _validate_counts(A: np.ndarray, B: np.ndarray, dose: float):
    A, B = np.asarray(A), np.asarray(B)
    if A.ndim != 3 or A.shape[1:] != (6, 6) or B.shape != A.shape or not len(A):
        raise ValueError("A and B must have identical nonempty batch,6,6 shape")
    if not np.isfinite(dose) or dose <= 0:
        raise ValueError("dose must be positive and finite")
    for value in (A, B):
        if not np.all(np.isfinite(value)) or np.any(value < 0) or np.any(value != np.floor(value)):
            raise ValueError("A and B must be nonnegative integer counts")
    return A.astype(np.float64), B.astype(np.float64)


def _predictive_relative(ell: np.ndarray, qa: np.ndarray) -> np.ndarray:
    return np.logaddexp(np.log1p(-qa), np.log(qa) + ell)


def evaluate_controls(A: np.ndarray, B: np.ndarray, dose: float):
    """Return (scores, connection_flags, common_no_connection, q_A_by_tau).

    Arrays in scores/flags have shape (batch,).  Method keys ending in a
    colon use tau formatted with ``:g``.  Scores are p-values for IUT,
    Bonferroni and Holm; log e-values for splitLR; and e-values for EP1.
    ``SCORE_KINDS`` records those conventions.  Flags already apply each
    method's correct alpha=0.025 threshold.
    """
    A, B = _validate_counts(A, B, dose)
    tb = 0.8 * float(dose)
    ell_a = A * np.log(4.0) - 1.2 * float(dose)
    ell_b = B * np.log(4.0) - 6.0 * tb
    qa_by_tau = {
        tau: np.clip(expit(ell_a / tau), 1e-8, 1 - 1e-8) for tau in TAUS
    }
    p_bg = poisson.sf(B - 1, 2 * tb)
    p_fg = poisson.cdf(B, 8 * tb)
    qa_one = qa_by_tau[1.0]
    column = np.log1p(-qa_one).sum(axis=1).argmax(axis=1)
    selected_column_p = p_fg[
        np.arange(len(A))[:, None], np.arange(6)[None, :], column[:, None]
    ].max(axis=1)
    common_no_conn = selected_column_p <= ALPHA

    scores: dict[str, np.ndarray] = {}
    connections: dict[str, np.ndarray] = {}

    # The constrained denominator depends on B alone and is reused over the
    # three independent q_A calibrators.  All calculations remain in log units.
    full_denominator = np.maximum(ell_b, 0).sum(axis=(1, 2)) - np.fromiter(
        (_oracle.positive_vertex_cut(value) for value in ell_b),
        dtype=np.float64, count=len(B),
    )

    for tau in TAUS:
        suffix = f":{tau:g}"
        qa = qa_by_tau[tau]
        start, transition = _ep1.make_prior(qa)
        selected, _, _ = _ep1.viterbi_paths(start, transition)
        if not all(_oracle.has_lr_connection(path) for path in selected):
            raise AssertionError("selected path is not genuinely 4-connected")
        path_p = np.where(selected, p_bg, 0.0).max(axis=(1, 2))
        scores["selected_iut" + suffix] = path_p
        connections["selected_iut" + suffix] = path_p <= ALPHA

        corridor = np.stack([
            binary_dilation(path, structure=STRUCTURE_4, iterations=1) for path in selected
        ])
        local_score = np.fromiter(
            (_oracle.log_slrt_corridor(ell_b[j], qa[j], corridor[j]) for j in range(len(B))),
            dtype=np.float64, count=len(B),
        )
        full_score = _predictive_relative(ell_b, qa).sum(axis=(1, 2)) - full_denominator
        scores["local_slrt" + suffix] = local_score
        scores["full_slrt" + suffix] = full_score
        connections["local_slrt" + suffix] = local_score >= LOG_THRESHOLD
        connections["full_slrt" + suffix] = full_score >= LOG_THRESHOLD

        mixture, _ = _ep1.path_scores(start, transition, B.astype(np.int64), tb)
        scores["ep1_mix_e" + suffix] = mixture
        connections["ep1_mix_e" + suffix] = mixture >= 1 / ALPHA

        adjusted_weighted = holm_adjusted(
            p_bg.reshape(len(B), -1), qa.reshape(len(B), -1)
        ).reshape(B.shape)
        weighted_level = connectivity_level(adjusted_weighted)
        scores["weighted_holm" + suffix] = weighted_level
        connections["weighted_holm" + suffix] = weighted_level <= ALPHA

    bonferroni_level = connectivity_level(np.minimum(1, 36 * p_bg))
    ordinary_holm_level = connectivity_level(
        holm_adjusted(p_bg.reshape(len(B), -1)).reshape(B.shape)
    )
    ordinary_hochberg_level = connectivity_level(
        hochberg_adjusted(p_bg.reshape(len(B), -1)).reshape(B.shape)
    )
    scores["pixel_bonferroni"] = bonferroni_level
    scores["holm"] = ordinary_holm_level
    scores["hochberg"] = ordinary_hochberg_level
    connections["pixel_bonferroni"] = bonferroni_level <= ALPHA
    connections["holm"] = ordinary_holm_level <= ALPHA
    connections["hochberg"] = ordinary_hochberg_level <= ALPHA
    return scores, connections, common_no_conn, qa_by_tau


SCORE_KINDS = {
    "selected_iut": "p_value: lower is stronger; reject <=0.025",
    "local_slrt": "log_e_value: higher is stronger; reject >=log(40)",
    "full_slrt": "log_e_value: higher is stronger; reject >=log(40)",
    "ep1_mix_e": "e_value: higher is stronger; reject >=40",
    "weighted_holm": "connectivity adjusted_p_value: reject <=0.025",
    "pixel_bonferroni": "connectivity adjusted_p_value: reject <=0.025",
    "holm": "connectivity adjusted_p_value: reject <=0.025",
    "hochberg": "independent-pixel step-up connectivity adjusted_p_value: reject <=0.025",
}


def verify_controls() -> dict:
    """Algorithmic fixtures only; no count-generation or dataset outcomes."""
    rng = np.random.default_rng(261026208)
    fixed = [
        (np.array([0.001, 0.02, 0.03]), np.ones(3), np.array([True, True, True])),
        (np.array([0.001, 0.03, 0.04]), np.ones(3), np.array([True, False, False])),
        (np.array([0.02, 0.04, 0.02]), np.array([0.6, 0.3, 0.1]), np.array([True, False, False])),
    ]
    for pvalue, weight, expected in fixed:
        if not np.array_equal(holm_adjusted(pvalue, weight) <= 0.05, expected):
            raise AssertionError("fixed weighted Holm fixture failed")
    for _ in range(200):
        pvalue = rng.uniform(0, 0.2, 12)
        weight = rng.uniform(0.01, 1.0, 12)
        alpha = float(rng.uniform(0.01, 0.2))
        order = np.argsort(pvalue / weight, kind="stable")
        expected = np.zeros(12, dtype=bool)
        for rank, index in enumerate(order):
            if pvalue[index] <= alpha * weight[index] / weight[order[rank:]].sum():
                expected[index] = True
            else:
                break
        if not np.array_equal(holm_adjusted(pvalue, weight) <= alpha, expected):
            raise AssertionError("vector and literal weighted Holm disagree")
    fixed_hochberg = [
        (np.array([0.01, 0.04, 0.049]), np.array([True, True, True])),
        (np.array([0.01, 0.03, 0.2]), np.array([True, False, False])),
        (np.array([0.02, 0.03, 0.06]), np.array([False, False, False])),
    ]
    for pvalue, expected in fixed_hochberg:
        if not np.array_equal(hochberg_adjusted(pvalue) <= 0.05, expected):
            raise AssertionError("fixed Hochberg fixture failed")
    for _ in range(200):
        pvalue = rng.uniform(0, 0.2, 12)
        alpha = float(rng.uniform(0.01, 0.2))
        order = np.argsort(pvalue, kind="stable")
        expected = np.zeros(12, dtype=bool)
        for rank in range(11, -1, -1):
            if pvalue[order[rank]] <= alpha / (12 - rank):
                expected[order[:rank + 1]] = True
                break
        if not np.array_equal(hochberg_adjusted(pvalue) <= alpha, expected):
            raise AssertionError("vector and literal Hochberg step-up disagree")
    pixel_levels = rng.uniform(0, 1, (20, 4, 4))
    levels = connectivity_level(pixel_levels)
    checks = 0
    for sample, level in zip(pixel_levels, levels):
        for threshold in np.r_[np.unique(sample), 0, 1]:
            actual = _oracle.has_lr_connection(sample <= threshold)
            if actual != bool(level <= threshold):
                raise AssertionError("bottleneck score and binary 4-connectivity disagree")
            checks += 1
    return {
        "status": "PASS", "fixed_holm_fixtures": len(fixed),
        "weighted_holm_literal_loop_cases": 200,
        "fixed_hochberg_fixtures": len(fixed_hochberg),
        "hochberg_literal_stepup_cases": 200,
        "hommel": "not implemented; statsmodels not installed, outside requested controls",
        "connectivity_threshold_checks": checks,
        "scope": "algorithmic fixture verification only; no generated counts or dataset read",
    }


if __name__ == "__main__":
    import json
    print(json.dumps(verify_controls(), indent=2))
