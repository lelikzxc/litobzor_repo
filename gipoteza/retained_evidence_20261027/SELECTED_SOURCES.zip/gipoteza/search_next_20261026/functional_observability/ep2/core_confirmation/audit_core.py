#!/usr/bin/env python3
"""Independent read-only numerical audit of the frozen EP2-Core experiment.

Writes only INDEPENDENT_AUDIT_DESIGN_CONTEXT.json and matching .md next to this
file. Does not edit experiment inputs, protocols, code, or result files.
No model training or new predictive experiment is performed.
"""
from __future__ import annotations

import hashlib
import importlib.util
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np
from scipy.special import expit
from scipy.stats import poisson
from sklearn.metrics import confusion_matrix, f1_score

HERE = Path(__file__).resolve().parent
EP2 = HERE.parent / "probe"
EP1 = HERE.parents[1] / "probe"
ROOT = HERE.parents[4]
DOSES = [0.5, 1.0, 2.0, 4.0]
ALPHA = 0.025


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name, folder=HERE):
    return json.loads((folder / name).read_text())


def canonical(mask):
    # Independent spelling of the four permitted reflection orbit members.
    variants = [np.flip(mask, axis=axes) if axes else mask
                for axes in [(), (0,), (1,), (0, 1)]]
    return min(np.packbits(x.flatten(), bitorder="little").tobytes() for x in variants)


def connected(mask):
    # Ordinary coordinate BFS, independent of the experiment's bitboard code.
    h, w = mask.shape
    reached = {(r, 0) for r in range(h) if mask[r, 0]}
    queue = list(reached)
    for r, c in queue:
        if c == w - 1:
            return True
        for rr, cc in [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]:
            if 0 <= rr < h and 0 <= cc < w and mask[rr, cc] and (rr, cc) not in reached:
                reached.add((rr, cc))
                queue.append((rr, cc))
    return False


def own_counts(truth, pred):
    # pred [dose,method,geometry,repeat] -> [dose,method,geometry,6].
    out = np.zeros(pred.shape[:-1] + (6,), dtype=np.int64)
    for k in (0, 1):
        target = truth[None, None, :, None] == k
        called = pred == k
        out[..., 3*k] = np.sum(target & called, axis=-1)
        out[..., 3*k+1] = np.sum(~target & called, axis=-1)
        out[..., 3*k+2] = np.sum(target & ~called, axis=-1)
    return out


def own_f1(c):
    pieces = []
    for j in (0, 3):
        den = 2*c[..., j] + c[..., j+1] + c[..., j+2]
        pieces.append(np.divide(2*c[..., j], den, out=np.zeros_like(den, dtype=float), where=den != 0))
    return (pieces[0] + pieces[1]) / 2


def confidence_intervals(counts, frames, hierarchical):
    # Separately implemented from run_core.bootstrap. Exactly reproduces
    # the frozen resampling law/seed so every published endpoint is auditable.
    seed = 261026303 if hierarchical else 261026304
    rng = np.random.default_rng(seed)
    unique = np.unique(frames)
    membership = {f: np.where(frames == f)[0] for f in unique}
    average = np.empty((4000, 9))
    highest = np.empty((4000, 9))
    ablation = np.empty(4000)
    for b in range(4000):
        if hierarchical:
            sampled_frames = rng.choice(unique, size=len(unique), replace=True)
            ix = np.concatenate([rng.choice(membership[f], size=len(membership[f]), replace=True)
                                 for f in sampled_frames])
        else:
            ix = rng.integers(0, len(frames), size=len(frames))
        pooled = counts[:, :, ix, :].sum(axis=2)
        f1 = own_f1(pooled)
        average[b] = f1[:, 0].mean() - f1[:, 1:10].mean(axis=0)
        highest[b] = f1[-1, 0] - f1[-1, 1:10]
        ablation[b] = f1[:, 0].mean() - f1[:, -1].mean()
    return {"average": np.quantile(average, [.025, .975], axis=0).T,
            "dose4": np.quantile(highest, [.025, .975], axis=0).T,
            "ablation": np.quantile(ablation, [.025, .975]),
            "seed": seed, "replicates": 4000}


def audit():
    started = time.perf_counter()
    result = read("RESULT.json")
    frozen = read("RUN_FROZEN.json")
    selection = read("SELECTION_BEFORE_COUNTS.json")
    fixed = read("FIXED_IMPLEMENTATION_BEFORE_COUNTS.json")
    val = read("VAL_SELECTION_BEFORE_TEST.json", EP2)
    progress = read("PROGRESS.json")
    assert result["complete"] and progress["complete"]
    assert not (HERE / "ERROR.json").exists()
    assert result["elapsed_seconds"] <= 600 and progress["elapsed_seconds"] <= 600
    checked_hashes = {}
    for folder, name in [(HERE, "RUN_FROZEN.json"), (EP2, "RUN_FROZEN.json"), (EP1, "RUN_FROZEN.json")]:
        for rel, expected in read(name, folder)["sha256"].items():
            resolved = ROOT / rel if (ROOT / rel).exists() else folder / rel
            actual = sha(resolved)
            assert actual == expected, (rel, expected, actual)
            checked_hashes[str(resolved.relative_to(ROOT))] = actual
    for rel, expected in selection["input_sha256"].items():
        assert sha(ROOT / rel) == expected
        checked_hashes[rel] = expected
    assert fixed["source_VAL_selection_sha256"] == sha(EP2 / "VAL_SELECTION_BEFORE_TEST.json")
    assert fixed["primary"] == val["primary"] == "ep2_weighted:0.5"
    assert fixed["no_core_tuning"] is True
    for name in fixed["methods"][1:9]:
        assert val["controls"][name.split(":")[0]] == name
    assert read("RESULT.json", EP2)["gate"] == "FAIL"
    assert result["old_EP2_gate"] == "FAIL unchanged"

    geometry = np.load(HERE / "GEOMETRIES.npz")
    masks, truth, frames = geometry["M"], geometry["truth"], geometry["frame"]
    assert masks.shape == (242, 6, 6) and masks.dtype == bool
    assert [int(np.sum(truth == k)) for k in [0, 1]] == [121, 121]
    assert np.array_equal([int(connected(m)) for m in masks], truth)
    keys = [canonical(m) for m in masks]
    assert len(set(keys)) == 242
    assert len(np.unique(frames)) == 12
    oldpath = ROOT / "gipoteza/search_20261026/sem_electrical/PATCHES.npz"
    newpath = ROOT / "gipoteza/longer_20261026/holdout/PATCHES.npz"
    old, raw = np.load(oldpath), np.load(newpath)
    manifest = read("MANIFEST.json", newpath.parent)
    excluded = set()
    for i, m in enumerate(old["Y"]):
        if int(old["frame"][i]) in range(8):
            excluded.update(canonical(m[r:r+6, c:c+6]) for r, c in itertools.product([0, 6], repeat=2))
    old1, old2 = np.load(EP1 / "GEOMETRIES.npz"), np.load(EP2 / "GEOMETRIES.npz")
    pilot1 = {canonical(m) for m in old1["M"]}
    pilot2 = {canonical(m) for m in old1["future_M"]}
    assert len(pilot1) == len(pilot2) == 256 and not pilot1 & pilot2
    assert np.array_equal(old1["future_M"], old2["TEST_M"])
    assert not set(keys) & (excluded | pilot1 | pilot2)
    assert not set(keys) & {canonical(m) for m in old2["VAL_M"]}
    full_pool = {}
    for i, parent in enumerate(raw["Y"]):
        for qr, qc in itertools.product(range(2), repeat=2):
            child = parent[qr*6:(qr+1)*6, qc*6:(qc+1)*6]
            key = canonical(child)
            if key in excluded:
                continue
            item = {"source": str(newpath.relative_to(ROOT)), "index": i,
                    "frame": int(raw["frame"][i]), "quadrant": [qr, qc],
                    "y": int(manifest[i]["y"]) + 6*qr,
                    "x": int(manifest[i]["x"]) + 6*qc}
            item["id_sha256"] = hashlib.sha256(json.dumps(item, sort_keys=True).encode()).hexdigest()
            item["canonical_hex"] = key.hex()
            if key not in full_pool or item["id_sha256"] < full_pool[key][0]["id_sha256"]:
                full_pool[key] = (item, child.copy())
    groups = [[], []]
    for item, m in full_pool.values():
        k = int(connected(m))
        item["label"] = k
        groups[k].append((item, m))
    for group in groups:
        group.sort(key=lambda x: x[0]["id_sha256"])
    assert [len(g) for g in groups] == [419, 377]
    assert {canonical(m) for g in groups for _, m in g[:128]} == pilot1
    assert {canonical(m) for g in groups for _, m in g[128:256]} == pilot2
    remaining = [[pair for pair in g if canonical(pair[1]) not in pilot1 | pilot2] for g in groups]
    assert [len(g) for g in remaining] == [163, 121]
    expected = remaining[0][:121] + remaining[1][:121]
    assert [x[0] for x in expected] == selection["selected"]
    assert np.array_equal(np.stack([x[1] for x in expected]), masks)
    assert np.array_equal(frames, [x[0]["frame"] for x in expected])
    almost = []
    for i in np.flatnonzero(truth == 0):
        for r, c in np.argwhere(~masks[i]):
            x = masks[i].copy()
            x[r, c] = True
            if connected(x):
                almost.append(int(i)); break
    assert almost == selection["almost_connected_negative_indices"] and len(almost) == 49

    archive = np.load(HERE / "PREDICTIONS.npz")
    pred = archive["predictions"]
    methods = archive["method"].tolist()
    assert methods == fixed["methods"] and len(methods) == 11
    assert pred.shape == (4, 11, 242, 32)
    assert np.array_equal(archive["truth"], truth) and np.array_equal(archive["frame"], frames)
    assert np.array_equal(archive["dose"], DOSES)
    counts = own_counts(truth, pred)
    assert np.array_equal(counts, archive["counts"])
    f1 = own_f1(counts.sum(axis=2))
    sklearn_max_error = 0.0
    matrices = {}
    risks = []
    all_doses = []
    ra, rb = np.random.default_rng(261026301), np.random.default_rng(261026302)
    rng_counts_verified = 0
    for d, dose in enumerate(DOSES):
        z = np.load(HERE / f"dose_{dose:g}.npz")
        all_doses.append(z)
        mean = 2 + 6*masks.astype(float)
        for stream, key, fraction in [(ra, "A", .2), (rb, "B", .8)]:
            actual = z[key]
            assert np.issubdtype(actual.dtype, np.integer) and np.min(actual) >= 0
            regenerated = stream.poisson(fraction*dose*mean[:, None], size=(242, 32, 6, 6))
            assert np.array_equal(actual, regenerated), (dose, key)
            rng_counts_verified += int(actual.size)
        assert np.array_equal(z["predictions"], pred[d]) and z["method"].tolist() == methods
        A, B = z["A"], z["B"]
        q1 = np.clip(expit(A*np.log(4)-1.2*dose), 1e-8, 1-1e-8)
        selected_column = np.argmax(np.log1p(-q1).sum(axis=2), axis=-1)
        pfg = poisson.cdf(B, 6.4*dose)
        column_p = np.take_along_axis(pfg, selected_column[:, :, None, None], axis=-1).max(axis=2)[..., 0]
        negative = column_p <= ALPHA
        assert np.array_equal(negative, z["no_conn_cert"])
        for j, name in enumerate(methods):
            score = z["score__" + name]
            positive = z["conn__" + name]
            if name.startswith(("local_slrt", "full_slrt")):
                threshold_flags = score >= np.log(40)
            elif name.startswith("ep1_mix_e"):
                threshold_flags = score >= 40
            else:
                threshold_flags = score <= ALPHA
            assert np.array_equal(positive, threshold_flags)
            called = np.where(positive & ~negative, 1, np.where(~positive & negative, 0, -1))
            assert np.array_equal(called, pred[d, j])
            yt = np.repeat(truth, 32)
            yp = pred[d, j].reshape(-1)
            sk = f1_score(yt, yp, labels=[0, 1], average="macro", zero_division=0)
            sklearn_max_error = max(sklearn_max_error, abs(sk - f1[d, j]))
            assert abs(sk - f1[d, j]) < 1e-14
            matrices[f"dose{dose:g}__{name}"] = confusion_matrix(yt, yp, labels=[-1, 0, 1]).tolist()
            assert np.allclose(result["metrics"][name]["by_dose_macro_f1"][d], sk, atol=1e-14)
            assert np.allclose(result["metrics"][name]["coverage"][d], np.mean(yp != -1), atol=1e-14)
            raw_fp = int(positive[truth == 0].sum())
            conflict = int((positive & negative).sum())
            assert result["diagnostics"][d]["raw_false_conn"][name] == raw_fp
            assert result["diagnostics"][d]["conflicts"][name] == conflict
        false_conn = int(z["conn__"+methods[0]][truth == 0].sum())
        false_disc = int(negative[truth == 1].sum())
        n0 = int(np.sum(truth == 0)*32); n1 = int(np.sum(truth == 1)*32)
        own_risk = {"dose": dose, "false_conn": false_conn, "false_disc": false_disc,
                    "n0": n0, "n1": n1, "false_conn_rate": false_conn/n0,
                    "false_disc_rate": false_disc/n1,
                    "conditional_fixed_geometry_Hoeffding_upper95_false_conn": min(1, false_conn/n0+np.sqrt(np.log(20)/(2*n0))),
                    "conditional_fixed_geometry_Hoeffding_upper95_false_disc": min(1, false_disc/n1+np.sqrt(np.log(20)/(2*n1))),
                    "empirical_guard_passed": bool(false_conn/n0 <= ALPHA and false_disc/n1 <= ALPHA)}
        assert own_risk == result["risk"][d]
        assert false_disc == result["diagnostics"][d]["raw_false_disc"]
        own_risk["final_false_conn"] = int(np.sum(pred[d, 0][truth == 0] == 1))
        own_risk["final_false_disc"] = int(np.sum(pred[d, 0][truth == 1] == 0))
        risks.append(own_risk)
    point = f1.mean(axis=0)
    for j, name in enumerate(methods):
        assert abs(point[j] - result["metrics"][name]["average_macro_f1"]) < 1e-14

    ci = confidence_intervals(counts, frames, True)
    gci = confidence_intervals(counts, frames, False)
    ci_error = 0.0
    comparisons = {}
    for j, name in enumerate(methods[1:10]):
        old_comparison = result["comparisons"][name]
        for old_value, fresh in [(old_comparison["average_ci95"], ci["average"][j]),
                                 (old_comparison["geometry_only_average_ci95"], gci["average"][j]),
                                 (old_comparison["dose4_ci95"], ci["dose4"][j])]:
            error = float(np.max(np.abs(np.asarray(old_value)-fresh)))
            ci_error = max(ci_error, error)
            assert error < 1e-14
        assert abs((point[0]-point[j+1])-old_comparison["average_difference"]) < 1e-14
        assert abs((f1[-1,0]-f1[-1,j+1])-old_comparison["dose4_difference"]) < 1e-14
        assert old_comparison["core_passed"] == bool(ci["average"][j,0] > .01)
        assert old_comparison["dose4_guard_passed"] == bool(ci["dose4"][j,0] >= -.01)
        comparisons[name] = {"mean_difference": float(point[0]-point[j+1]),
                             "hierarchical_ci95": ci["average"][j].tolist(),
                             "geometry_ci95": gci["average"][j].tolist(),
                             "dose4_hierarchical_ci95": ci["dose4"][j].tolist(),
                             "dose4_geometry_ci95": gci["dose4"][j].tolist()}
    assert np.allclose(ci["ablation"], result["unweighted_descriptive"]["ci95"], atol=1e-14)

    # Literal cut-by-cut reference, separate from the original matrix/gather
    # implementation. Sample draws chosen only by fixed ordinal positions.
    sys.path.insert(0, str(HERE)); sys.path.insert(0, str(EP2)); sys.path.insert(0, str(EP1))
    spec = importlib.util.spec_from_file_location("_audit_core_original", HERE / "run_core.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.progress = lambda stage: None  # suppress audit-time experiment writes
    cuts = mod.enumerate_minimal_cuts(6, 6)
    assert len(cuts) == 4286
    indices = [[i for i in range(36) if code & (1 << i)] for code in cuts]
    cut_hash = hashlib.sha256(np.asarray(cuts, dtype="<u8").tobytes()).hexdigest()
    assert cut_hash == result["verification"]["6x6"]["family_code_sha256"]
    helper = mod.CutEvaluator(cuts)
    max_literal_error = 0.0; max_helper_error = 0.0; flag_mismatch = 0
    sample_records = []
    for d, dose in enumerate(DOSES):
        chosen = np.linspace(0, 242*32-1, 64, dtype=int)
        A = all_doses[d]["A"].reshape(-1, 36)[chosen]
        B = all_doses[d]["B"].reshape(-1, 36)[chosen]
        weights = np.clip(expit((A*np.log(4)-1.2*dose)/.5), 1e-8, 1-1e-8)
        pixel_p = poisson.sf(B-1, 1.6*dose)
        reference = np.zeros((2, 64))
        for ix in indices:
            # Every cut is evaluated; no selection by the inference data.
            psum = poisson.sf(B[:, ix].sum(axis=1)-1, len(ix)*1.6*dose)
            weighted_atom = np.minimum(1, (pixel_p[:, ix]/weights[:, ix]).min(axis=1)*weights[:, ix].sum(axis=1))
            plain_atom = np.minimum(1, len(ix)*pixel_p[:, ix].min(axis=1))
            reference[0] = np.maximum(reference[0], np.minimum(1, np.minimum(2*weighted_atom, 2*psum)))
            reference[1] = np.maximum(reference[1], np.minimum(1, np.minimum(2*plain_atom, 2*psum)))
        calculated = helper.evaluate(B.reshape(-1,6,6), weights.reshape(-1,6,6), .8*dose)
        stored = np.stack([all_doses[d]["score__"+methods[0]].ravel()[chosen],
                           all_doses[d]["score__"+methods[-1]].ravel()[chosen]])
        max_literal_error = max(max_literal_error, float(np.max(np.abs(reference-stored))))
        max_helper_error = max(max_helper_error, float(np.max(np.abs(reference-calculated))))
        assert np.allclose(reference, stored, atol=2e-13, rtol=2e-13)
        assert np.allclose(reference, calculated, atol=2e-13, rtol=2e-13)
        flag_mismatch += int(np.count_nonzero((reference<=ALPHA) != (stored<=ALPHA)))
        sample_records.append({"dose": dose, "flattened_geometry_repeat_indices": chosen.tolist()})
    assert flag_mismatch == 0

    # Artifact chronology is supporting evidence only; code ordering and
    # pre-count frozen records are the substantive reproducible safeguards.
    selection_mtime = (HERE/"SELECTION_BEFORE_COUNTS.json").stat().st_mtime_ns
    fixed_mtime = (HERE/"FIXED_IMPLEMENTATION_BEFORE_COUNTS.json").stat().st_mtime_ns
    first_dose_mtime = (HERE/"dose_0.5.npz").stat().st_mtime_ns
    assert selection_mtime <= first_dose_mtime and fixed_mtime <= first_dose_mtime
    gate = (all(v["hierarchical_ci95"][0] > .01 and v["dose4_hierarchical_ci95"][0] >= -.01
                for v in comparisons.values()) and all(x["empirical_guard_passed"] for x in risks))
    assert gate and result["gate"] == "PASS"
    # Catch any concurrent mutation of frozen source during the audit.
    for rel, expected_hash in checked_hashes.items():
        assert sha(ROOT / rel) == expected_hash
    return {"status":"PASS", "scope":"independent reconstruction and read-only numerical audit; no new model or predictive experiment",
            "core_gate_recomputed":"PASS", "old_EP2_gate":"FAIL unchanged",
            "all_frozen_and_source_hashes_match":True, "checked_sha256":checked_hashes,
            "geometry":{"count":242,"per_class":[121,121],"source_frame_count":12,
                        "source_frame_distribution":selection["sourceframes"],
                        "full_unique_pool_per_class":[419,377],"remaining_after_two_old_tests":[163,121],
                        "both_old_tests_and_trainval_HV_overlap":0,"within_core_HV_duplicates":0,
                        "selection_exactly_reproduced_from_original_sources":True,
                        "old_first_128_and_next_128_sets_exactly_reproduced":True,
                        "new_source_frames_disjoint_from_old_TEST":False,
                        "reason":"fresh H/V geometries, same source-frame pool and same IC; not unseen-wafer or new-device evidence",
                        "almost_connected_negative_count":49},
            "counts":{"integer_nonnegative":True,"exact_seed_regeneration_matches":True,
                      "scalar_counts_verified":rng_counts_verified,"seeds_A_B":[261026301,261026302],
                      "mean_model":"A=Pois(.2*d*(2+6M)), B=Pois(.8*d*(2+6M)); independent generators",
                      "shape_per_stream_per_dose":[242,32,6,6],"doses":DOSES},
            "precount_safeguards":{"VAL_primary":"ep2_weighted:0.5","all_prior_VAL_control_choices_unchanged":True,
                                   "selection_and_implementation_files_before_first_saved_dose":True,
                                   "timestamps_are_supporting_not_cryptographic_proof_of_chronology":True},
            "metrics":{"method_count":11,"sklearn_macro_f1_cases":44,
                       "sklearn_maximum_absolute_error":sklearn_max_error,
                       "per_geometry_confusion_counts_match":True,"unknown_is_FN":True,
                       "primary_average_macro_f1":float(point[0]),"primary_by_dose_macro_f1":f1[:,0].tolist(),
                       "primary_coverage":result["metrics"][methods[0]]["coverage"],
                       "confusion_matrix_label_order":[-1,0,1],"confusion_matrices":matrices},
            "bootstrap":{"hierarchical_and_geometry_replicates_each":4000,"seeds":[ci["seed"],gci["seed"]],
                         "published_endpoint_maximum_absolute_error":ci_error,"comparisons":comparisons,
                         "unweighted_ablation_mean_difference":float(point[0]-point[-1]),
                         "unweighted_ablation_hierarchical_ci95":ci["ablation"].tolist(),
                         "individual_95_intervals_not_a_claim_of_joint_simultaneous_95_coverage":True},
            "literal_cut_check":{"fixed_sample_draw_count":256,"all_minimal_cuts_per_draw":4286,
                                 "weighted_and_unweighted_channels_checked":True,"cut_family_sha256":cut_hash,
                                 "literal_vs_saved_maximum_absolute_error":max_literal_error,
                                 "literal_vs_rerun_batched_helper_maximum_absolute_error":max_helper_error,
                                 "threshold_flag_disagreements":flag_mismatch,"sample_ordinals":sample_records},
            "risks":risks,
            "interpretation":{"false_certificate_guarantee":"model-conditional error per true mask and one decision; not accepted-decision precision",
                              "known_independent_two_intensity_integer_Poisson":True,"PSF":False,
                              "neural_training":False,"same_IC_finite_geometry_benchmark":True,
                              "large_extra_gain_from_weights_confirmed":False,
                              "Q1_level_or_world_priority_confirmed":False},
            "core_runtime_seconds":progress["elapsed_seconds"],"audit_runtime_seconds":time.perf_counter()-started,
            "audit_script_sha256":sha(HERE/"audit_core.py")}


if __name__ == "__main__":
    try:
        findings = audit()
    except BaseException as exc:
        findings = {"status":"FAIL","error_type":type(exc).__name__,"message":str(exc),
                    "scope":"independent audit failed; do not silently interpret original gate as audited"}
        (HERE/"INDEPENDENT_AUDIT_DESIGN_CONTEXT.json").write_text(json.dumps(findings,indent=2,ensure_ascii=False)+"\n")
        raise
    (HERE/"INDEPENDENT_AUDIT_DESIGN_CONTEXT.json").write_text(json.dumps(findings,indent=2,ensure_ascii=False)+"\n")
    note = """# Независимая проверка EP2-Core

Численная проверка **PASS**. Отбор242 новых H/V-геометрий (121/класс,
12 исходных полей), все A/B counts,44 Macro-F1 против sklearn,
11 методов с unknown как FN, обе4000-кратные bootstrap-процедуры,
все9 основных сравнений и guard дозы4 воспроизведены. На256 заранее
заданных порядковых наблюдениях literal loop по всем4286cut совпал
с сохранёнными p и повторным batched helper. Хэши frozen-кода и старых
inputs совпадают; старый EP2 gate остаётся FAIL.

Среднее Macro-F1 основного теста44.266%; ближайший внешний контроль
weighted Holm41.325%, разность2.941п.п., иерархический95%CI
[2.040;3.824]п.п. Дополнительный выигрыш от весов против unweighted
составил0.552п.п. [0.286;0.841]; большой эффект весов не подтверждён.

Это положительный результат основного структурного теста в конечной
модели independent integer Poisson без PSF. Он не подтверждает обучение
CNN, перенос на другую пластину, real-SEM калибровку, мировой приоритет
или готовность Q1. FPR относится к ложному сертификату при истинном
классе; он не означает точность среди принятых решений. На малых дозах
метод часто отказывается: coverage0.258% и6.792% при d0.5 и1.

Полные числа, confusion matrices, ошибки raw/final, хэши и границы
проверки находятся в INDEPENDENT_AUDIT_DESIGN_CONTEXT.json; audit_core.py воспроизводит
аудит, не меняя исходный опыт.
"""
    (HERE/"INDEPENDENT_AUDIT_DESIGN_CONTEXT.md").write_text(note)
    print(json.dumps({k:findings[k] for k in ["status","core_gate_recomputed","old_EP2_gate","core_runtime_seconds","audit_runtime_seconds"]},indent=2))
