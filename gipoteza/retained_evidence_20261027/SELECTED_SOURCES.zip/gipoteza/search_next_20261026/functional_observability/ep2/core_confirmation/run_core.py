#!/usr/bin/env python3
"""Fresh EP2-Core confirmation; preserves both failed pilot records."""
from __future__ import annotations
import hashlib,itertools,json,sys,time
from pathlib import Path
import numpy as np
from scipy.stats import poisson

HERE=Path(__file__).resolve().parent
EP2=HERE.parent/"probe";EP1=HERE.parents[1]/"probe";ROOT=HERE.parents[4]
sys.path.insert(0,str(EP2));sys.path.insert(0,str(EP1))
import run_probe as ep1
from controls import evaluate_controls,verify_controls,connectivity_level
from cut_family import enumerate_minimal_cuts,cut_matrix,verify_exhaustive_4x4,verify_family_minimality
from hommel import hommel_adjusted,verify_hommel

DOSES=[.5,1.,2.,4.];REPEATS=32;ALPHA=.025;LIMIT=600.;START=None
METHODS=["ep2_fixed_weighted_tau0.5","selected_iut:0.5","local_slrt:1","full_slrt:1",
         "ep1_mix_e:0.5","weighted_holm:0.5","pixel_bonferroni","holm","hochberg",
         "hommel","ep2_unweighted_descriptive"]
KNOWN=METHODS[1:10]

def sha(data):return hashlib.sha256(data).hexdigest()
def dump(name,v):
    p=HERE/name;t=p.with_suffix(p.suffix+".tmp");t.write_text(json.dumps(v,indent=2,ensure_ascii=False));t.replace(p)
def elapsed():return time.perf_counter()-START
def progress(stage):
    v={"stage":stage,"elapsed_seconds":elapsed(),"complete":False};dump("PROGRESS.json",v);print(json.dumps(v),flush=True)
    if elapsed()>LIMIT:raise TimeoutError("Core frozen600second limit exceeded")

def prepare():
    oldpath=ROOT/"gipoteza/search_20261026/sem_electrical/PATCHES.npz"
    newpath=ROOT/"gipoteza/longer_20261026/holdout/PATCHES.npz"
    old=np.load(oldpath);z=np.load(newpath);mf=json.loads((newpath.parent/"MANIFEST.json").read_text())
    prior=set()
    for i,m in enumerate(old["Y"]):
        if int(old["frame"][i]) not in range(8):continue
        for qr,qc in itertools.product(range(2),repeat=2):prior.add(ep1.canonical(m[qr*6:(qr+1)*6,qc*6:(qc+1)*6]))
    previous=np.load(EP1/"GEOMETRIES.npz")
    used={ep1.canonical(m) for m in previous["M"]}|{ep1.canonical(m) for m in previous["future_M"]}
    if len(used)!=512:raise AssertionError("Expected512distinctpreviousTESTgeometries")
    pool={}
    for i,m in enumerate(z["Y"]):
        for qr,qc in itertools.product(range(2),repeat=2):
            patch=m[qr*6:(qr+1)*6,qc*6:(qc+1)*6];key=ep1.canonical(patch)
            if key in prior or key in used:continue
            item={"source":str(newpath.relative_to(ROOT)),"index":i,"frame":int(z["frame"][i]),
                  "quadrant":[qr,qc],"y":int(mf[i]["y"])+6*qr,"x":int(mf[i]["x"])+6*qc}
            item["id_sha256"]=sha(json.dumps(item,sort_keys=True).encode());item["canonical_hex"]=key.hex()
            prev=pool.get(key)
            if prev is None or item["id_sha256"]<prev[0]["id_sha256"]:pool[key]=(item,patch.copy())
    groups=[[],[]]
    for item,m in pool.values():
        label=ep1.lr_bit(m);item["label"]=label;groups[label].append((item,m))
    for g in groups:g.sort(key=lambda p:p[0]["id_sha256"])
    if [len(g) for g in groups]!=[163,121]:raise AssertionError("Frozenpoolavailabilitychanged")
    chosen=groups[0][:121]+groups[1][:121]
    masks=np.stack([m for _,m in chosen]);truth=np.array([i["label"] for i,_ in chosen]);frames=np.array([i["frame"] for i,_ in chosen])
    almost=[]
    for i in np.flatnonzero(truth==0):
        for r,c in np.argwhere(~masks[i]):
            alt=masks[i].copy();alt[r,c]=True
            if ep1.lr_bit(alt):almost.append(int(i));break
    dump("SELECTION_BEFORE_COUNTS.json",{"selected":[i for i,_ in chosen],"remaining_pool_classes":[163,121],
        "selected_per_class":121,"sourceframes":{str(f):int((frames==f).sum()) for f in np.unique(frames)},
        "almost_connected_negative_indices":almost,"all_old_trainval_and_TEST_HV_excluded":True,
        "input_sha256":{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [oldpath,newpath,EP1/"GEOMETRIES.npz",EP2/"VAL_SELECTION_BEFORE_TEST.json"]}})
    np.savez_compressed(HERE/"GEOMETRIES.npz",M=masks,truth=truth,frame=frames)
    return masks,truth,frames,almost

class CutEvaluator:
    def __init__(self,cuts):
        self.matrix=cut_matrix(cuts,6,6).reshape(len(cuts),36).astype(float)
        self.length=self.matrix.sum(axis=1).astype(int)
        self.idx=np.full((len(cuts),int(self.length.max())),36,int)
        for j,m in enumerate(self.matrix):
            pos=np.flatnonzero(m);self.idx[j,:len(pos)]=pos
    def evaluate(self,b,qa,tb):
        counts=b.reshape(-1,36);out=np.zeros((2,len(b)))
        tail=poisson.sf(np.arange(int(counts.max())*14+1)[None,:]-1,
                        2*tb*np.arange(15)[:,None])
        pixel=poisson.sf(np.arange(int(counts.max())+1)-1,2*tb)
        for lo in range(0,len(b),128):
            hi=min(lo+128,len(b));bb=counts[lo:hi]
            sums=np.rint(bb@self.matrix.T).astype(int);ps=tail[self.length[None,:],sums];pp=pixel[bb]
            for j in [0,1]:
                v=qa[lo:hi].reshape(-1,36) if j==0 else np.ones_like(pp,float)
                vs=v@self.matrix.T
                ratio=np.concatenate([pp/v,np.full((len(bb),1),np.inf)],axis=1)
                minimum=np.min(ratio[:,self.idx],axis=2)
                out[j,lo:hi]=np.minimum(1.,np.minimum(2*vs*minimum,2*ps)).max(axis=1)
            if lo%2048==0:progress(f"all4286cuts_batch{lo}_of{len(b)}")
        return out

def classify(conn,no_conn):return np.where(conn&~no_conn,1,np.where(~conn&no_conn,0,-1)).astype(np.int8)

def bootstrap(counts,frames,hierarchy):
    rng=np.random.default_rng(261026303 if hierarchy else 261026304)
    fids=np.unique(frames);groups={f:np.flatnonzero(frames==f) for f in fids}
    avg=[];high=[];ablation=[]
    for _ in range(4000):
        if hierarchy:
            ff=rng.choice(fids,len(fids),replace=True)
            idx=np.concatenate([rng.choice(groups[f],len(groups[f]),replace=True) for f in ff])
        else:idx=rng.integers(0,len(frames),len(frames))
        values=ep1.f1_from_counts(counts[:,:,idx].sum(axis=2))
        avg.append(values[:,0].mean()-values[:,1:10].mean(axis=0))
        high.append(values[-1,0]-values[-1,1:10])
        ablation.append(values[:,0].mean()-values[:,-1].mean())
    return {"average":np.quantile(avg,[.025,.975],axis=0).T,
            "dose4":np.quantile(high,[.025,.975],axis=0).T,
            "ablation":np.quantile(ablation,[.025,.975])}

def main():
    global START
    START=time.perf_counter()
    sources=[HERE/"FROZEN_PROTOCOL.md",HERE/"run_core.py",HERE/"hommel.py",EP2/"controls.py",
             EP2/"cut_family.py",EP1/"run_probe.py",EP1/"slrt_oracle.py"]
    dump("RUN_FROZEN.json",{"sha256":{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sources},"limit_seconds":LIMIT})
    progress("freshgeometry_and_knowncontrols_verification")
    cuts=enumerate_minimal_cuts(6,6)
    verification={"4x4":verify_exhaustive_4x4(enumerate_minimal_cuts(4,4)),
        "6x6":verify_family_minimality(cuts,6,6),"unknown":ep1.verify_unknown_metric(),
        "controls":verify_controls(),"hommel":verify_hommel()}
    dump("VERIFICATION.json",verification)
    masks,truth,frames,almost=prepare();n=len(masks)
    progress("fresh242IDs_saved_before_counts")
    # Assert primary/control calibrators are unchanged from the previousVAL.
    val=json.loads((EP2/"VAL_SELECTION_BEFORE_TEST.json").read_text())
    if val["primary"]!="ep2_weighted:0.5":raise AssertionError("VALprimarychanged")
    for k in METHODS[1:9]:
        base=k.split(":")[0]
        if val["controls"][base]!=k:raise AssertionError("VALcontrolchanged")
    dump("FIXED_IMPLEMENTATION_BEFORE_COUNTS.json",{"primary":"ep2_weighted:0.5",
        "methods":METHODS,"source_VAL_selection_sha256":sha((EP2/"VAL_SELECTION_BEFORE_TEST.json").read_bytes()),
        "no_core_tuning":True,"new_method":"Hommel, frozenbeforeCorecounts"})
    evaluator=CutEvaluator(cuts);ra=np.random.default_rng(261026301);rb=np.random.default_rng(261026302)
    predictions=[];diagnostics=[]
    for dose in DOSES:
        mean=2+6*masks.astype(float)
        a=ra.poisson(.2*dose*mean[:,None],size=(n,REPEATS,6,6)).astype(np.int16)
        b=rb.poisson(.8*dose*mean[:,None],size=(n,REPEATS,6,6)).astype(np.int16)
        aa=a.reshape(-1,6,6);bb=b.reshape(-1,6,6)
        progress(f"dose{dose:g}_knowncontrols")
        scores,flags,no_conn,qa=evaluate_controls(aa,bb,dose)
        hommel_p=hommel_adjusted(poisson.sf(bb.reshape(-1,36)-1,1.6*dose)).reshape(bb.shape)
        scores["hommel"]=connectivity_level(hommel_p);flags["hommel"]=scores["hommel"]<=ALPHA
        progress(f"dose{dose:g}_fixedprimary")
        cut_scores=evaluator.evaluate(bb,qa[.5],.8*dose)
        scores[METHODS[0]]=cut_scores[0];flags[METHODS[0]]=cut_scores[0]<=ALPHA
        scores[METHODS[-1]]=cut_scores[1];flags[METHODS[-1]]=cut_scores[1]<=ALPHA
        if np.any(flags["pixel_bonferroni"]&~flags[METHODS[-1]]):raise AssertionError("Bonfdominancefailed")
        pred=np.stack([classify(flags[m],no_conn) for m in METHODS]).reshape(len(METHODS),n,REPEATS)
        predictions.append(pred)
        diag={"dose":dose,"conflicts":{},"raw_false_conn":{},"raw_false_disc":int(no_conn.reshape(n,REPEATS)[truth==1].sum()),
              "negative_draws":int((truth==0).sum()*REPEATS),"positive_draws":int((truth==1).sum()*REPEATS)}
        save={"A":a,"B":b,"method":np.array(METHODS),"predictions":pred,"no_conn_cert":no_conn.reshape(n,REPEATS)}
        for m in METHODS:
            diag["raw_false_conn"][m]=int(flags[m].reshape(n,REPEATS)[truth==0].sum())
            diag["conflicts"][m]=int((flags[m]&no_conn).sum())
            save["score__"+m]=scores[m].reshape(n,REPEATS);save["conn__"+m]=flags[m].reshape(n,REPEATS)
        diagnostics.append(diag);np.savez_compressed(HERE/f"dose_{dose:g}.npz",**save)
        progress(f"dose{dose:g}_complete")
    pred=np.stack(predictions);counts=np.stack([ep1.counts_metrics(truth,p) for p in pred])
    by_dose=ep1.f1_from_counts(counts.sum(axis=2));point=by_dose.mean(axis=0)
    ci=bootstrap(counts,frames,True);gci=bootstrap(counts,frames,False)
    comparisons={}
    for j,m in enumerate(KNOWN):
        comparisons[m]={"average_difference":float(point[0]-point[j+1]),"average_ci95":ci["average"][j].tolist(),
              "geometry_only_average_ci95":gci["average"][j].tolist(),
              "dose4_difference":float(by_dose[-1,0]-by_dose[-1,j+1]),"dose4_ci95":ci["dose4"][j].tolist(),
              "core_passed":bool(ci["average"][j,0]>.01),"dose4_guard_passed":bool(ci["dose4"][j,0]>=-.01)}
    risk=[]
    for d in diagnostics:
        fc=d["raw_false_conn"][METHODS[0]];fd=d["raw_false_disc"];n0=d["negative_draws"];n1=d["positive_draws"]
        r0=fc/n0;r1=fd/n1
        risk.append({"dose":d["dose"],"false_conn":fc,"false_disc":fd,"n0":n0,"n1":n1,
            "false_conn_rate":r0,"false_disc_rate":r1,
            "conditional_fixed_geometry_Hoeffding_upper95_false_conn":min(1,r0+np.sqrt(np.log(20)/(2*n0))),
            "conditional_fixed_geometry_Hoeffding_upper95_false_disc":min(1,r1+np.sqrt(np.log(20)/(2*n1))),
            "empirical_guard_passed":bool(r0<=ALPHA and r1<=ALPHA)})
    success=all(v["core_passed"] and v["dose4_guard_passed"] for v in comparisons.values()) and all(v["empirical_guard_passed"] for v in risk)
    metrics={m:{"average_macro_f1":float(point[j]),"by_dose_macro_f1":by_dose[:,j].tolist(),
             "coverage":[float((pred[d,j]!=-1).mean()) for d in range(4)]} for j,m in enumerate(METHODS)}
    result={"complete":True,"gate":"PASS" if success else "FAIL","claim":"fixedcoreminimal-separatortest; notlargeimageweightbenefit",
         "primary":METHODS[0],"metrics":metrics,"comparisons":comparisons,"risk":risk,"diagnostics":diagnostics,
         "unweighted_descriptive":{"difference":float(point[0]-point[-1]),"ci95":ci["ablation"].tolist(),"not_part_of_core_gate":True},
         "geometry_count":n,"repeats":REPEATS,"count_draws":n*4*REPEATS,"almost_connected_negative_count":len(almost),
         "verification":verification,"elapsed_seconds":elapsed(),"neural_training":False,
         "old_EP2_gate":"FAIL unchanged","scope":"fresh6x6geometryfinitebenchmark,sameICsource,knownindependentPoissoncounts,zeroPSF,analyticproposal"}
    dump("RESULT.json",result)
    np.savez_compressed(HERE/"PREDICTIONS.npz",predictions=pred,counts=counts,truth=truth,frame=frames,method=np.array(METHODS),dose=DOSES)
    progress("strict_core_comparison_and_guards_complete")
    dump("PROGRESS.json",{"complete":True,"gate":result["gate"],"elapsed_seconds":elapsed()})
    print(json.dumps({"gate":result["gate"],"metrics":metrics,"comparisons":comparisons,"risk":risk,
                      "unweighted_descriptive":result["unweighted_descriptive"],"elapsed_seconds":elapsed()},ensure_ascii=False),flush=True)

if __name__=="__main__":
    try:main()
    except BaseException as e:
        if START is not None:dump("ERROR.json",{"complete":False,"type":type(e).__name__,"message":str(e),"elapsed_seconds":elapsed()})
        raise
