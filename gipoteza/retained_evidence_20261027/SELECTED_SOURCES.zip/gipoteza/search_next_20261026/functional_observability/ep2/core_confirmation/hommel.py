"""Batched Hommel adjusted p-values for the restricted independent-count test.

The short Hommel recurrence is adapted to NumPy batches from the official
statsmodels implementation, by Josef Perktold, reviewed 2026-10-26:
https://raw.githubusercontent.com/statsmodels/statsmodels/main/statsmodels/stats/multitest.py
Hommel branch, lines 253--261 at the time of review.

No statsmodels package is installed or imported.  Independence of the B
pixel counts makes Simes intersection tests valid in the frozen model.
No claim is made for arbitrary dependent p-values or physical SEM images.
The independent verifier below literally enumerates closed Simes testing.

Statsmodels attribution and BSD-3 license, retained for this adaptation:
https://raw.githubusercontent.com/statsmodels/statsmodels/main/LICENSE.txt

Copyright (C) 2006, Jonathan E. Taylor
All rights reserved.

Copyright (c) 2006-2008 Scipy Developers.
All rights reserved.

Copyright (c) 2009-2018 statsmodels Developers.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
  a. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.
  b. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  c. Neither the name of statsmodels nor the names of its contributors
     may be used to endorse or promote products derived from this software
     without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL STATSMODELS OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.
"""

from __future__ import annotations

import itertools
import json
import time

import numpy as np


OFFICIAL_SOURCE_URL = (
    "https://raw.githubusercontent.com/statsmodels/statsmodels/main/"
    "statsmodels/stats/multitest.py"
)
LICENSE_SOURCE_URL = "https://raw.githubusercontent.com/statsmodels/statsmodels/main/LICENSE.txt"


def hommel_adjusted(pvalues: np.ndarray) -> np.ndarray:
    """Return Hommel adjusted p-values along the final axis, batchwise.

    The output has exactly the input shape and original hypothesis order.
    Reject at adjusted<=alpha.  Inputs must be finite p-values in [0,1]
    with a nonempty last axis.  Complexity is O(batch*m^2), appropriate
    here for m=36 pixels, with no exponential subset enumeration.
    """
    pvalues = np.asarray(pvalues, dtype=np.float64)
    if pvalues.ndim < 1 or pvalues.shape[-1] == 0:
        raise ValueError("p-values need a nonempty hypothesis axis")
    if not np.all(np.isfinite(pvalues)) or np.any((pvalues < 0) | (pvalues > 1)):
        raise ValueError("p-values must be finite and lie in [0,1]")
    count = pvalues.shape[-1]
    order = np.argsort(pvalues, axis=-1, kind="stable")
    ordered = np.take_along_axis(pvalues, order, axis=-1)
    adjusted_ordered = ordered.copy()
    for subset_size in range(count, 1, -1):
        ranks = np.arange(1, subset_size + 1, dtype=np.float64)
        tail_simes = np.min(
            subset_size * ordered[..., -subset_size:] / ranks,
            axis=-1, keepdims=True,
        )
        adjusted_ordered[..., -subset_size:] = np.maximum(
            adjusted_ordered[..., -subset_size:], tail_simes
        )
        adjusted_ordered[..., :-subset_size] = np.maximum(
            adjusted_ordered[..., :-subset_size],
            np.minimum(subset_size * ordered[..., :-subset_size], tail_simes),
        )
    adjusted_ordered = np.minimum(adjusted_ordered, 1.0)
    result = np.empty_like(adjusted_ordered)
    np.put_along_axis(result, order, adjusted_ordered, axis=-1)
    return result


def _literal_closed_simes(pvalues: np.ndarray) -> tuple[np.ndarray, int]:
    """Independent exponential oracle: enumerate ALL intersection subsets.

    For every I, compute its Simes p-value, then assign its value to each
    member.  The adjusted singleton p-value is the maximum over containing
    intersections.  This shares neither recurrence nor ordering shortcut
    with the implementation above.  Tiny fixture use only, m<=8.
    """
    values = np.asarray(pvalues, dtype=np.float64)
    if values.ndim != 1 or not 1 <= len(values) <= 8:
        raise ValueError("oracle is limited to 1..8 hypotheses")
    result = np.zeros(len(values), dtype=np.float64)
    subset_count = 0
    for size in range(1, len(values) + 1):
        for members in itertools.combinations(range(len(values)), size):
            subset_count += 1
            ordered_subset = np.sort(values[list(members)])
            simes = min(
                1.0,
                min(size * float(value) / rank
                    for rank, value in enumerate(ordered_subset, 1)),
            )
            for member in members:
                result[member] = max(result[member], simes)
    return result, subset_count


def verify_hommel(seed: int = 261026302) -> dict:
    """Algorithmic p-value fixtures only; no dataset or count-generation."""
    started = time.perf_counter()
    rng = np.random.default_rng(seed)
    maximum_error = 0.0
    fixture_count = 0
    subset_count = 0
    for count in range(1, 9):
        fixtures = [
            np.zeros(count), np.ones(count), np.full(count, 0.017),
            np.linspace(0.001, 0.19, count),
            np.linspace(0.19, 0.001, count),
            np.resize(np.array([0, 0.002, 0.01, 0.01, 0.025, 0.05, 1, 1]), count),
        ]
        fixtures.extend(rng.uniform(0, 1, (20, count)))
        fixtures.extend(rng.uniform(0, 0.1, (20, count)))
        fixtures.extend(10 ** rng.uniform(-6, 0, (20, count)))
        values = np.stack(fixtures)
        batched = hommel_adjusted(values)
        for row, adjusted in zip(values, batched):
            expected, intersections = _literal_closed_simes(row)
            subset_count += intersections
            fixture_count += 1
            error = float(np.max(np.abs(adjusted - expected)))
            maximum_error = max(maximum_error, error)
            if not np.allclose(adjusted, expected, atol=2e-14, rtol=2e-13):
                raise AssertionError({"p": row.tolist(), "got": adjusted.tolist(), "expected": expected.tolist()})
            if not np.array_equal(adjusted <= 0.025, expected <= 0.025):
                raise AssertionError("closed Simes and Hommel rejection flags differ")
            if np.any(adjusted < row - 2e-14):
                raise AssertionError("adjusted p-value below singleton intersection")
            if not np.allclose(hommel_adjusted(row), adjusted, atol=2e-14):
                raise AssertionError("single-row and batched recurrence differ")
    multi_batch = rng.uniform(size=(2, 3, 8))
    multi_result = hommel_adjusted(multi_batch)
    if not np.allclose(multi_result.reshape(-1, 8), hommel_adjusted(multi_batch.reshape(-1, 8))):
        raise AssertionError("multiple batch axes change results")
    for invalid in (np.array([]), np.array([np.nan]), np.array([-0.1]), np.array([1.1])):
        try:
            hommel_adjusted(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid input was not rejected")
    return {
        "status": "PASS",
        "seed": seed,
        "hypothesis_counts": list(range(1, 9)),
        "fixture_rows": fixture_count,
        "all_subset_simes_evaluations": subset_count,
        "maximum_absolute_error": maximum_error,
        "multiple_batch_axes": True,
        "scope": "algorithmic fixtures only; no dataset or synthetic count outcomes",
        "source": OFFICIAL_SOURCE_URL,
        "license": "BSD-3, attribution and full notice retained in this file",
        "elapsed_seconds": time.perf_counter() - started,
    }


if __name__ == "__main__":
    print(json.dumps(verify_hommel(), indent=2))
