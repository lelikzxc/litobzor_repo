"""Read-only audit of stored Core results; writes only INDEPENDENT_AUDIT.json.

This does not tune, rerun, or modify any experimental implementation.
Independent literal formulas check fixed hash-selected stored observations.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path
import sys
import time

import numpy as np
from scipy.stats import poisson
from sklearn.metrics import f1_score

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
EP2 = HERE.parent / "probe"
EP1 = HERE.parents[1] / "probe"
sys.path.insert(0, str(EP2))
from cut_family import enumerate_minimal_cuts


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(mask):
    return min(np.packbits(view.ravel(), bitorder="little").tobytes()
               for view in (mask, mask[::-1], mask[:, ::-1], mask[::-1, ::-1]))


def connected(mask):
    seen = set()
    stack = [(row, 0) for row in range(6) if mask[row, 0]]
    while stack:
        row, col = stack.pop()
        if (row, col) in seen:
            continue
        seen.add((row, col))
        if col == 5:
            return 1
        for rr, cc in ((row - 1, col), (row + 1, col), (row, col - 1), (row, col + 1)):
            if 0 <= rr < 6 and 0 <= cc < 6 and mask[rr, cc] and (rr, cc) not in seen:
                stack.append((rr, cc))
    return 0


def sufficient_counts(truth, predicted):
    pieces = []
    for label in (0, 1):
        actual = truth[None, :, None] == label
        guessed = predicted == label
        pieces.extend(((actual & guessed).sum(axis=-1),
                       (~actual & guessed).sum(axis=-1),
                       (actual & ~guessed).sum(axis=-1)))
    return np.stack(pieces, axis=-1)


def macro_from_sufficient(value):
    parts = []
    for offset in (0, 3):
        numerator = 2 * value[..., offset]
        denominator = numerator + value[..., offset + 1] + value[..., offset + 2]
        parts.append(np.divide(numerator, denominator, out=np.zeros_like(numerator, dtype=float), where=denominator != 0))
    return (parts[0] + parts[1]) / 2


def main():
    started = time.perf_counter()
    result = json.loads((HERE / "RESULT.json").read_text())
    selection = json.loads((HERE / "SELECTION_BEFORE_COUNTS.json").read_text())
    implementation = json.loads((HERE / "FIXED_IMPLEMENTATION_BEFORE_COUNTS.json").read_text())
    geometries = np.load(HERE / "GEOMETRIES.npz")
    predictions = np.load(HERE / "PREDICTIONS.npz")
    M, truth, frames = geometries["M"], geometries["truth"], geometries["frame"]
    methods = predictions["method"].tolist()
    doses = predictions["dose"].tolist()
    pred = predictions["predictions"]
    assert M.shape == (242, 6, 6) and len(selection["selected"]) == 242
    assert np.array_equal(truth, predictions["truth"])
    assert np.array_equal(frames, predictions["frame"])
    assert np.array_equal(truth, [connected(mask) for mask in M])
    assert np.bincount(truth).tolist() == [121, 121]

    # Freeze the audit sample by identifiers alone, before opening count NPZs.
    sample_keys = []
    for geometry, item in enumerate(selection["selected"]):
        for repeat in range(32):
            identifier = f"core-independent-audit/{item['id_sha256']}/{repeat}"
            sample_keys.append((hashlib.sha256(identifier.encode()).hexdigest(), geometry, repeat))
    audited_observations = sorted(sample_keys)[:16]

    hashes = []
    for folder in (EP1, EP2, HERE):
        frozen = json.loads((folder / "RUN_FROZEN.json").read_text())
        for name, expected in frozen["sha256"].items():
            path = ROOT / name if "/" in name else folder / name
            actual = sha(path)
            assert actual == expected, ("changed frozen file", str(path), actual, expected)
            hashes.append({"record": str((folder / "RUN_FROZEN.json").relative_to(ROOT)),
                           "file": str(path.relative_to(ROOT)), "sha256": actual})
    for name, expected in selection["input_sha256"].items():
        assert sha(ROOT / name) == expected, ("changed selection input", name)
    val_file = EP2 / "VAL_SELECTION_BEFORE_TEST.json"
    assert sha(val_file) == implementation["source_VAL_selection_sha256"]
    val = json.loads(val_file.read_text())
    assert val["primary"] == implementation["primary"] == "ep2_weighted:0.5"
    for name in methods[1:9]:
        assert val["controls"][name.split(":")[0]] == name
    old_result = json.loads((EP2 / "RESULT.json").read_text())
    assert old_result["gate"] == "FAIL"

    old = np.load(ROOT / "gipoteza/search_20261026/sem_electrical/PATCHES.npz")
    old_keys = set()
    for index, mask in enumerate(old["Y"]):
        if int(old["frame"][index]) in range(8):
            for qr, qc in itertools.product(range(2), repeat=2):
                old_keys.add(canonical(mask[6 * qr:6 * (qr + 1), 6 * qc:6 * (qc + 1)]))
    previous = np.load(EP1 / "GEOMETRIES.npz")
    previous_keys = {canonical(mask) for name in ("M", "future_M") for mask in previous[name]}
    assert len(previous_keys) == 512
    core_keys = {canonical(mask) for mask in M}
    assert len(core_keys) == 242 and not (core_keys & old_keys) and not (core_keys & previous_keys)
    source = ROOT / "gipoteza/longer_20261026/holdout/PATCHES.npz"
    z = np.load(source)
    manifest = json.loads((source.parent / "MANIFEST.json").read_text())
    pool = {}
    for index, mask in enumerate(z["Y"]):
        for qr, qc in itertools.product(range(2), repeat=2):
            patch = mask[6 * qr:6 * (qr + 1), 6 * qc:6 * (qc + 1)]
            key = canonical(patch)
            if key in old_keys or key in previous_keys:
                continue
            item = {"source": str(source.relative_to(ROOT)), "index": index,
                    "frame": int(z["frame"][index]), "quadrant": [qr, qc],
                    "y": int(manifest[index]["y"]) + 6 * qr,
                    "x": int(manifest[index]["x"]) + 6 * qc}
            identity = hashlib.sha256(json.dumps(item, sort_keys=True).encode()).hexdigest()
            if key not in pool or identity < pool[key][0]:
                pool[key] = (identity, patch.copy())
    groups = [[], []]
    for identity, patch in pool.values():
        groups[connected(patch)].append((identity, patch))
    for group in groups:
        group.sort(key=lambda pair: pair[0])
    assert [len(group) for group in groups] == [163, 121]
    reconstructed = groups[0][:121] + groups[1][:121]
    assert [item["id_sha256"] for item in selection["selected"]] == [identity for identity, _ in reconstructed]
    assert np.array_equal(M, np.stack([mask for _, mask in reconstructed]))
    assert not (set(map(int, frames)) & set(map(int, old["frame"])))

    cuts = enumerate_minimal_cuts(6, 6)
    cut_array = np.array([[(cut >> bit) & 1 for bit in range(36)] for cut in cuts], dtype=bool)
    lengths = cut_array.sum(axis=1)
    assert len(cuts) == 4286
    random_A = np.random.default_rng(261026301)
    random_B = np.random.default_rng(261026302)
    literal_errors = []
    all_metric_errors = []
    raw_risk = []
    threshold_disagreements = 0
    for di, dose in enumerate(doses):
        stored = np.load(HERE / f"dose_{dose:g}.npz")
        A, B = stored["A"], stored["B"]
        mean = 2 + 6 * M.astype(float)
        assert np.array_equal(A, random_A.poisson(0.2 * dose * mean[:, None], size=A.shape).astype(np.int16))
        assert np.array_equal(B, random_B.poisson(0.8 * dose * mean[:, None], size=B.shape).astype(np.int16))
        assert np.array_equal(stored["predictions"], pred[di])
        # Recompute the common negative certificate from A/B without labels.
        qa_one = np.clip(1 / (1 + np.exp(-(A * np.log(4) - 1.2 * dose))), 1e-8, 1 - 1e-8)
        flat_q = qa_one.reshape(-1, 6, 6)
        flat_B = B.reshape(-1, 6, 6)
        column = np.log1p(-flat_q).sum(axis=1).argmax(axis=1)
        lower_p = poisson.cdf(flat_B, 6.4 * dose)
        negative = lower_p[np.arange(len(flat_B))[:, None], np.arange(6)[None, :], column[:, None]].max(axis=1) <= 0.025
        assert np.array_equal(negative.reshape(242, 32), stored["no_conn_cert"])
        for _, geometry, repeat in audited_observations:
            a = A[geometry, repeat].ravel()
            b = B[geometry, repeat].ravel()
            qa = np.clip(1 / (1 + np.exp(-2 * (a * np.log(4) - 1.2 * dose))), 1e-8, 1 - 1e-8)
            pixel = poisson.sf(b - 1, 1.6 * dose)
            sum_p = poisson.sf((cut_array * b).sum(axis=1) - 1, lengths * 1.6 * dose)
            for name, weights in ((methods[0], qa), (methods[-1], np.ones(36))):
                weighted_atomic = (cut_array * weights).sum(axis=1) * np.where(
                    cut_array, pixel[None, :] / weights[None, :], np.inf
                ).min(axis=1)
                cut_p = np.minimum(1, np.minimum(2 * weighted_atomic, 2 * sum_p))
                literal = float(cut_p.max())
                actual = float(stored["score__" + name][geometry, repeat])
                error = abs(literal - actual)
                literal_errors.append(error)
                assert np.isclose(literal, actual, atol=2e-12, rtol=2e-12), (dose, geometry, repeat, literal, actual)
        for mi, name in enumerate(methods):
            score, flag = stored["score__" + name], stored["conn__" + name]
            if name.startswith(("local_slrt", "full_slrt")):
                derived = score >= np.log(40)
            elif name.startswith("ep1_mix_e"):
                derived = score >= 40
            else:
                derived = score <= 0.025
            threshold_disagreements += int(np.count_nonzero(derived != flag))
            assert np.array_equal(derived, flag)
            expected_pred = np.where(flag & ~stored["no_conn_cert"], 1,
                                     np.where(~flag & stored["no_conn_cert"], 0, -1))
            assert np.array_equal(expected_pred, pred[di, mi])
            actual = f1_score(np.repeat(truth, 32), pred[di, mi].ravel(), labels=[0, 1], average="macro", zero_division=0)
            expected = result["metrics"][name]["by_dose_macro_f1"][di]
            all_metric_errors.append(abs(actual - expected))
            assert abs(actual - expected) < 2e-14
            assert abs((pred[di, mi] != -1).mean() - result["metrics"][name]["coverage"][di]) < 2e-14
        raw_false_conn = int(stored["conn__" + methods[0]][truth == 0].sum())
        raw_false_disc = int(stored["no_conn_cert"][truth == 1].sum())
        risk = result["risk"][di]
        assert (raw_false_conn, raw_false_disc) == (risk["false_conn"], risk["false_disc"])
        for label, errors in ((0, raw_false_conn), (1, raw_false_disc)):
            denominator = int(np.sum(truth == label) * 32)
            field = "conditional_fixed_geometry_Hoeffding_upper95_false_conn" if label == 0 else "conditional_fixed_geometry_Hoeffding_upper95_false_disc"
            upper = min(1, errors / denominator + np.sqrt(np.log(20) / (2 * denominator)))
            assert abs(upper - risk[field]) < 2e-14
        raw_risk.append({"dose": dose, "false_conn": raw_false_conn, "false_disc": raw_false_disc})

    counts = np.stack([sufficient_counts(truth, p) for p in pred])
    assert np.array_equal(counts, predictions["counts"])
    bootstrap_errors = []
    for hierarchy, seed in ((True, 261026303), (False, 261026304)):
        rng = np.random.default_rng(seed)
        unique_frames = np.unique(frames)
        groups_by_frame = {frame: np.flatnonzero(frames == frame) for frame in unique_frames}
        differences, high_dose = [], []
        for _ in range(4000):
            if hierarchy:
                sampled_frames = rng.choice(unique_frames, len(unique_frames), replace=True)
                indices = np.concatenate([rng.choice(groups_by_frame[frame], len(groups_by_frame[frame]), replace=True) for frame in sampled_frames])
            else:
                indices = rng.integers(0, len(frames), len(frames))
            values = macro_from_sufficient(counts[:, :, indices].sum(axis=2))
            differences.append(values[:, 0].mean() - values[:, 1:10].mean(axis=0))
            high_dose.append(values[-1, 0] - values[-1, 1:10])
        average_ci = np.quantile(differences, [0.025, 0.975], axis=0).T
        dose4_ci = np.quantile(high_dose, [0.025, 0.975], axis=0).T
        for mi, name in enumerate(methods[1:10]):
            field = "average_ci95" if hierarchy else "geometry_only_average_ci95"
            err = float(np.max(np.abs(average_ci[mi] - result["comparisons"][name][field])))
            bootstrap_errors.append(err)
            assert err < 2e-14
            if hierarchy:
                assert np.allclose(dose4_ci[mi], result["comparisons"][name]["dose4_ci95"], atol=2e-14, rtol=0)
    primary_gate = all(value["average_ci95"][0] > 0.01 and value["dose4_ci95"][0] >= -0.01 for value in result["comparisons"].values())
    risk_gate = all(item["false_conn_rate"] <= 0.025 and item["false_disc_rate"] <= 0.025 for item in result["risk"])
    assert primary_gate and risk_gate and result["gate"] == "PASS"

    audit = {
        "status": "PASS",
        "read_only_algorithm_audit": True,
        "all_frozen_hashes_unchanged": True,
        "frozen_hash_entries_checked": len(hashes),
        "hash_records": hashes,
        "selection": {"geometry_count": 242, "class_counts": [121, 121], "unique_HV": 242,
                      "previous_TEST_unique_excluded": 512, "trainval_disjoint": True,
                      "sourceframe_ids_disjoint_from_old_source": True,
                      "new_core_SOURCEframes_reuse_previous_holdout_SOURCEframes": True,
                      "new_core_geometries_disjoint_from_previous_TESTs": True,
                      "remaining_pool_reconstructed": [163, 121], "first121_by_SHA_per_class_confirmed": True},
        "literal_score_audit": {"fixed_rule": "first16 SHA256(core-independent-audit/geometryID/repeat), same observations each dose",
                                "sample": [{"sha256": h, "geometry": g, "repeat": r} for h, g, r in audited_observations],
                                "doses": doses, "all_cuts_per_observation": 4286, "weighted_and_unweighted_checks": len(literal_errors),
                                "maximum_absolute_error": max(literal_errors), "no_true_M_or_class_in_score_recomputation": True,
                                "tau": 0.5, "two_channels_and_factor2_confirmed": True},
        "stored_counts_reproduced_from_frozen_separate_seeds": True,
        "all_method_metrics_sklearn_checks": len(all_metric_errors),
        "all_method_macro_f1_maximum_error": max(all_metric_errors),
        "unknown_retained_as_FN": True,
        "score_to_flag_threshold_disagreements": threshold_disagreements,
        "bootstrap": {"hierarchical_and_geometry_only_replicates_each": 4000,
                      "all_primary_CIs_match": True, "maximum_error": max(bootstrap_errors),
                      "dose4_guard_CIs_match": True},
        "risk": {"raw_counts": raw_risk, "individual_Hoeffding_upper95_formula_confirmed": True,
                 "interpretation": "each bound separately; not a simultaneous95percent statement over all doses/errors"},
        "guards_and_strict_core_gate_reproduced": True,
        "old_EP2_gate_remains_FAIL": True,
        "mathematical_assessment": {
            "validity": "Under no4LRconnection there exists all-background minimal8TBcut K. Weighted atomic Bonferroni and independent Poisson sum are each valid for that all-background cut null conditional on A. Factor2 merges two channels. max over the COMPLETE cut family is an intersection-union p-value for no connection.",
            "negative_certificate": "A-selected straight column exact lower-tail IUT is valid against any true foreground4LRconnection; A and B separate.",
            "scope": "Known independent integer Poisson two-intensity model, zeroPSF, fixed sameIC geometry benchmark, analytical proposal; no CNN benefit or realSEM calibration shown.",
            "CI_limit": "Percentile hierarchical bootstrap over12 sourceframes is approximate; no independentwafer or newproduction distribution represented.",
            "ablation_limit": "Weighted-versus-unweighted effect is descriptive; old large-weight-benefit pilotFAIL is not changed.",
        },
        "elapsed_seconds": time.perf_counter() - started,
    }
    (HERE / "INDEPENDENT_AUDIT.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({key: audit[key] for key in ("status", "selection", "all_method_macro_f1_maximum_error", "guards_and_strict_core_gate_reproduced", "elapsed_seconds")}, indent=2))


if __name__ == "__main__":
    main()
