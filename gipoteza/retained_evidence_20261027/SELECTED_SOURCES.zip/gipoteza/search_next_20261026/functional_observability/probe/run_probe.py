#!/usr/bin/env python3
"""Restricted independent-count connectivity probe. See FROZEN_PROTOCOL.md.

No original SEM intensity is used as a Poisson count. No neural model is
trained by this script. Every result, including failed controls, is saved.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
from scipy.ndimage import binary_dilation
from scipy.special import expit
from scipy.stats import beta, poisson

from slrt_oracle import (
    has_lr_connection, log_slrt_corridor, log_slrt_full, verify_oracle,
)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
METHODS = ["epath", "selected_min_e", "selected_exact_iut", "local_slrt",
           "full_slrt", "pixel_bonferroni", "max_weighted_path_e"]
DOSES = np.array([.5, 1., 2., 4.])
REPEATS = 16
ALPHA = .025
THRESHOLD = 40.
BUDGET = 600.
START = None


def dump(name, value):
    path = HERE / name
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False))
    temp.replace(path)


def elapsed():
    return time.perf_counter() - START


def deadline(stage):
    dump("PROGRESS.json", {"stage": stage, "elapsed_seconds": elapsed(), "complete": False})
    print(json.dumps({"stage": stage, "elapsed_seconds": round(elapsed(), 3)}), flush=True)
    if elapsed() > BUDGET:
        raise TimeoutError("Frozen 600-second computation limit exceeded")


def sha(value):
    return hashlib.sha256(value).hexdigest()


def canonical(mask):
    return min(np.packbits(view.ravel(), bitorder="little").tobytes()
               for view in (mask, mask[::-1], mask[:, ::-1], mask[::-1, ::-1]))


def lr_bit(mask):
    h, w = mask.shape
    value = int.from_bytes(np.packbits(mask.ravel(), bitorder="little").tobytes(), "little")
    left = sum(1 << (r*w) for r in range(h))
    right = left << (w-1)
    full = (1 << (h*w)) - 1
    reached = value & left
    while True:
        adjacent = (((reached << 1) & ~left) | ((reached >> 1) & ~right)
                    | (reached << w) | (reached >> w)) & full
        new = reached | (adjacent & value)
        if new == reached:
            return int(bool(reached & right))
        reached = new


def select_data():
    old_path = ROOT / "gipoteza/search_20261026/sem_electrical/PATCHES.npz"
    new_path = ROOT / "gipoteza/longer_20261026/holdout/PATCHES.npz"
    old = np.load(old_path)
    prior_keys = set()
    train_unique = {}
    old_counts = {}
    for i, mask in enumerate(old["Y"]):
        frame = int(old["frame"][i])
        if frame not in range(8):
            continue
        old_counts[str(frame)] = old_counts.get(str(frame), 0) + 1
        for qr, qc in itertools.product(range(2), repeat=2):
            patch = mask[qr*6:(qr+1)*6, qc*6:(qc+1)*6]
            key = canonical(patch)
            prior_keys.add(key)
            if frame < 6:
                train_unique.setdefault(key, patch.copy())
    z = np.load(new_path)
    manifest = json.loads((new_path.parent / "MANIFEST.json").read_text())
    unique = {}
    duplicates_prior = 0
    for i, mask in enumerate(z["Y"]):
        for qr, qc in itertools.product(range(2), repeat=2):
            patch = mask[qr*6:(qr+1)*6, qc*6:(qc+1)*6]
            key = canonical(patch)
            if key in prior_keys:
                duplicates_prior += 1
                continue
            item = {"source": str(new_path.relative_to(ROOT)), "index": i,
                    "frame": int(z["frame"][i]), "quadrant": [qr, qc],
                    "y": int(manifest[i]["y"]) + 6*qr,
                    "x": int(manifest[i]["x"]) + 6*qc}
            item["id_sha256"] = sha(json.dumps(item, sort_keys=True).encode())
            item["canonical_hex"] = key.hex()
            old_item = unique.get(key)
            if old_item is None or item["id_sha256"] < old_item[0]["id_sha256"]:
                unique[key] = (item, patch.copy())
    by_class = [[], []]
    for item, patch in unique.values():
        label = lr_bit(patch)
        item["label"] = label
        by_class[label].append((item, patch))
    for group in by_class:
        group.sort(key=lambda pair: pair[0]["id_sha256"])
    n = min(128, *(len(x) for x in by_class))
    chosen = by_class[0][:n] + by_class[1][:n]
    n_future = min(128, *(max(0, len(x)-n) for x in by_class))
    future = by_class[0][n:n+n_future] + by_class[1][n:n+n_future]
    masks = np.stack([p for _, p in chosen])
    labels = np.array([d["label"] for d, _ in chosen], dtype=np.int8)
    frames = np.array([d["frame"] for d, _ in chosen])
    almost = []
    for i in np.flatnonzero(labels == 0):
        mask = masks[i]
        one_away = False
        for r, c in np.argwhere(~mask):
            modified = mask.copy()
            modified[r, c] = True
            if lr_bit(modified):
                one_away = True
                break
        if one_away:
            almost.append(int(i))
    dump("SELECTION.json", {"selected": [d for d, _ in chosen],
         "future_cnn_holdout": [d for d, _ in future],
         "almost_connected_negative_indices": almost,
         "input_sha256": {str(old_path.relative_to(ROOT)): sha(old_path.read_bytes()),
                          str(new_path.relative_to(ROOT)): sha(new_path.read_bytes())},
         "counts": {"trainval_quadrant_unique_hv": len(prior_keys),
                    "train_unique_hv": len(train_unique),
                    "old_frame_parent_patches": old_counts,
                    "test_parent_patches": len(z["Y"]),
                    "excluded_prior_duplicate_quadrants": duplicates_prior,
                    "test_unique_available_by_class": [len(x) for x in by_class],
                    "selected_per_class": n, "reserved_future_per_class": n_future,
                    "selected_frames": {str(f): int((frames == f).sum()) for f in np.unique(frames)},
                    "almost_connected_negative_count": len(almost)}})
    np.savez_compressed(HERE/"GEOMETRIES.npz", M=masks, truth=labels, frame=frames,
                        future_M=np.stack([p for _, p in future]) if future else np.zeros((0,6,6), bool),
                        train_M=np.stack(list(train_unique.values())))
    return masks, labels, frames, almost


def make_prior(q):
    """q: batch,height,width; transitions enter destination-column segments."""
    n, h, w = q.shape
    logq = np.log(q)
    start = q[:, :, 0] / q[:, :, 0].sum(axis=1, keepdims=True)
    logt = np.empty((n, w-1, h, h))
    for c in range(1, w):
        for r in range(h):
            for s in range(h):
                logt[:, c-1, r, s] = (-.25*abs(r-s)
                    + logq[:, min(r,s):max(r,s)+1, c].sum(axis=1))
    maximum = logt.max(axis=3, keepdims=True)
    t = np.exp(logt-maximum)
    t /= t.sum(axis=3, keepdims=True)
    return start, t


def segment_min(values):
    n, h, w = values.shape
    answer = np.empty((n, w-1, h, h), dtype=values.dtype)
    for c in range(1, w):
        for r in range(h):
            for s in range(h):
                answer[:, c-1, r, s] = values[:, min(r,s):max(r,s)+1, c].min(axis=1)
    return answer


def path_scores(start, transitions, counts, tb):
    """Exact sum and max of weighted bottleneck, threshold integral DP."""
    seg = segment_min(counts)
    max_k = int(counts.max())
    loglevels = np.minimum(1.*np.arange(max_k+1)*np.log(4)-6*tb, np.log(1e12))
    levels = np.exp(loglevels)
    total = np.zeros(len(counts))
    max_weighted = np.zeros(len(counts))
    previous = 0.
    logt = np.log(transitions)
    for k, level in enumerate(levels):
        if level == previous:
            continue
        alive0 = counts[:, :, 0] >= k
        prob = start * alive0
        best = np.where(alive0, np.log(start), -np.inf)
        for c in range(counts.shape[2]-1):
            alive = seg[:, c] >= k
            prob = np.einsum("nr,nrs->ns", prob, transitions[:,c]*alive, optimize=False)
            best = np.max(np.where(alive, best[:,:,None]+logt[:,c], -np.inf), axis=1)
        total += (level-previous) * prob.sum(axis=1)
        max_weighted = np.maximum(max_weighted, level*np.exp(best.max(axis=1)))
        previous = level
    return total, max_weighted


def viterbi_paths(start, transitions):
    n, wc, h, _ = transitions.shape
    best = np.log(start)
    back = []
    for c in range(wc):
        score = best[:, :, None]+np.log(transitions[:,c])
        back.append(score.argmax(axis=1))
        best = score.max(axis=1)
    rows = np.empty((n, wc+1), dtype=int)
    rows[:,-1] = best.argmax(axis=1)
    for c in range(wc-1, -1, -1):
        rows[:,c] = back[c][np.arange(n), rows[:,c+1]]
    supports = np.zeros((n,h,wc+1), dtype=bool)
    supports[np.arange(n), rows[:,0], 0] = True
    for j in range(n):
        for c in range(1,wc+1):
            r,s = rows[j,c-1:c+1]
            supports[j,min(r,s):max(r,s)+1,c] = True
    return supports, rows, np.exp(best.max(axis=1))


def enumerate_path_values(start, transitions, evalues):
    h,w = evalues.shape
    total=0.; maximum=0.; vprob=-1.; vrows=None
    for rows in itertools.product(range(h),repeat=w):
        prob=start[rows[0]]
        bottleneck=evalues[rows[0],0]
        for c in range(1,w):
            r,s=rows[c-1:c+1]
            prob*=transitions[c-1,r,s]
            bottleneck=min(bottleneck,evalues[min(r,s):max(r,s)+1,c].min())
        total+=prob*bottleneck
        maximum=max(maximum,prob*bottleneck)
        if prob>vprob:
            vprob=prob;vrows=rows
    return total,maximum,vprob,vrows


def verify_dp():
    rng=np.random.default_rng(261026099)
    errors=[]
    for d in [.5,2.,4.]:
        qa=rng.uniform(.01,.99,(5,4,4))
        counts=rng.poisson(5,(5,4,4))
        start,t=make_prior(qa)
        got,gotmax=path_scores(start,t,counts,.8*d)
        supports,rows,prob=viterbi_paths(start,t)
        for j in range(5):
            ev=np.exp(np.minimum(counts[j]*np.log(4)-6*.8*d,np.log(1e12)))
            exact,emax,vp,vr=enumerate_path_values(start[j],t[j],ev)
            errors.append(max(abs(got[j]-exact),abs(gotmax[j]-emax)))
            if not np.isclose(got[j],exact,rtol=1e-10,atol=1e-10):
                raise AssertionError((got[j],exact))
            if not np.isclose(gotmax[j],emax,rtol=1e-10,atol=1e-10):
                raise AssertionError((gotmax[j],emax))
            if not np.isclose(prob[j],vp,rtol=1e-10):
                raise AssertionError("Viterbi probability mismatch")
            if not has_lr_connection(supports[j]):
                raise AssertionError("Selected path lacks real4connectivity")
            coords=[(int(rows[j,0]),0)]
            for c in range(1,4):
                r,s=rows[j,c-1:c+1]
                coords.extend((int(v),c) for v in range(r,s+(1 if s>=r else -1),1 if s>=r else -1))
            if any(abs(r1-r2)+abs(c1-c2)!=1 for (r1,c1),(r2,c2) in zip(coords,coords[1:])):
                raise AssertionError("non4adjacent path jump")
    return {"path_cases":15,"enumerated_paths_each":256,
            "maximum_absolute_error":float(max(errors)),"passed":True}


def counts_metrics(labels,predictions):
    # predictions: method,geometry,repeat, or dose,method,geometry,repeat.
    result=[]
    for klass in [0,1]:
        truth=labels[None,:,None]==klass
        guessed=predictions==klass
        result.extend([(truth & guessed).sum(axis=-1),
                       (~truth & guessed).sum(axis=-1),
                       (truth & ~guessed).sum(axis=-1)])
    return np.stack(result,axis=-1)


def f1_from_counts(counts):
    first=2*counts[...,0]/np.maximum(2*counts[...,0]+counts[...,1]+counts[...,2],1)
    second=2*counts[...,3]/np.maximum(2*counts[...,3]+counts[...,4]+counts[...,5],1)
    return (first+second)/2


def verify_unknown_metric():
    from sklearn.metrics import f1_score
    truth=np.array([0,0,1,1,0,1],dtype=np.int8)
    fixtures=[np.array([0,-1,1,-1,1,0]),np.full(6,-1),truth.copy()]
    for pred in fixtures:
        actual=float(f1_from_counts(counts_metrics(truth,pred[None,:,None]).sum(axis=1))[0])
        expected=float(f1_score(truth,pred,labels=[0,1],average="macro",zero_division=0))
        if not np.isclose(actual,expected,atol=1e-14):
            raise AssertionError(("unknownF1",actual,expected))
    return {"passed":True,"fixture_count":len(fixtures),"unknown_kept_as_false_negative":True}


def bootstrap(allcounts,frames,hierarchical):
    rng=np.random.default_rng(261026103 if hierarchical else 261026104)
    frameids=np.unique(frames)
    groups={f:np.flatnonzero(frames==f) for f in frameids}
    out=[]
    for _ in range(1000):
        if hierarchical:
            ff=rng.choice(frameids,len(frameids),replace=True)
            idx=np.concatenate([rng.choice(groups[f],len(groups[f]),replace=True) for f in ff])
        else:
            idx=rng.integers(0,len(frames),len(frames))
        met=f1_from_counts(allcounts[:,:,idx].sum(axis=2)).mean(axis=0)
        out.append(met[0]-met[1:])
    array=np.array(out)
    return {name:{"lower":float(np.quantile(array[:,i],.025)),
                  "upper":float(np.quantile(array[:,i],.975))}
            for i,name in enumerate(METHODS[1:])}


def main():
    global START
    START=time.perf_counter()
    hashes={name:sha((HERE/name).read_bytes()) for name in
            ["FROZEN_PROTOCOL.md","run_probe.py","slrt_oracle.py"]}
    dump("RUN_FROZEN.json",{"sha256":hashes,"numpy_version":np.__version__,
                           "runtime_limit_seconds":BUDGET})
    deadline("selecting_geometry_before_scores")
    masks,labels,frames,almost=select_data()
    deadline("selection_saved_before_noise")
    verification={"path_dp":verify_dp(),"slrt":verify_oracle(),"unknown_metric":verify_unknown_metric()}
    dump("VERIFICATION.json",verification)
    deadline("oracles_verified")
    n=len(masks)
    rng_a=np.random.default_rng(261026101)
    rng_b=np.random.default_rng(261026102)
    pred_all=[]; scores_all=[]; selected_all=[]; raw_a=[];raw_b=[]
    diagnostics=[]
    for dose in DOSES:
        ta,tb=.2*dose,.8*dose
        mean=2+6*masks.astype(float)
        a=rng_a.poisson(ta*mean[:,None,:,:],size=(n,REPEATS,6,6)).astype(np.int16)
        b=rng_b.poisson(tb*mean[:,None,:,:],size=(n,REPEATS,6,6)).astype(np.int16)
        flat_a=a.reshape(-1,6,6);flat_b=b.reshape(-1,6,6)
        qa=np.clip(expit(flat_a*np.log(4)-6*ta),1e-8,1-1e-8)
        start,t=make_prior(qa)
        mixture,maxweighted=path_scores(start,t,flat_b,tb)
        supports,rows,pathprior=viterbi_paths(start,t)
        if not all(has_lr_connection(p) for p in supports):
            raise AssertionError("A selected6x6path not4connected")
        ell=flat_b*np.log(4)-6*tb
        local_e=np.exp(np.minimum(ell,np.log(1e12)))
        min_e=np.where(supports,local_e,np.inf).min(axis=(1,2))
        p_bg=poisson.sf(flat_b-1,2*tb)
        path_p=np.where(supports,p_bg,0).max(axis=(1,2))
        selected_column=np.log1p(-qa).sum(axis=1).argmax(axis=1)
        p_fg=poisson.cdf(flat_b,8*tb)
        column_p=p_fg[np.arange(len(qa))[:,None],np.arange(6)[None,:],selected_column[:,None]].max(axis=1)
        no_connection=column_p<=ALPHA
        region=np.stack([binary_dilation(p,structure=np.array([[0,1,0],[1,1,1],[0,1,0]],bool)) for p in supports])
        slrt_local=np.empty(len(qa));slrt_full=np.empty(len(qa))
        for j in range(len(qa)):
            slrt_local[j]=log_slrt_corridor(ell[j],qa[j],region[j])
            slrt_full[j]=log_slrt_full(ell[j],qa[j])
            if j%1024==0:
                deadline(f"dose{dose:g}_slrt_{j}_of{len(qa)}")
        pixel_confirmed=p_bg<=ALPHA/36
        bonf=np.array([has_lr_connection(p) for p in pixel_confirmed])
        conn=np.stack([mixture>=THRESHOLD,min_e>=THRESHOLD,path_p<=ALPHA,
                       slrt_local>=np.log(THRESHOLD),slrt_full>=np.log(THRESHOLD),
                       bonf,maxweighted>=THRESHOLD])
        predicted=np.where(conn & ~no_connection[None,:],1,
                           np.where(~conn & no_connection[None,:],0,-1)).astype(np.int8)
        if not np.all(maxweighted<=mixture+1e-6*np.maximum(mixture,1)):
            raise AssertionError("maxweighted exceeds sum mixture")
        np.savez_compressed(HERE/f"dose_{dose:g}.npz",A=a,B=b,qA=qa.reshape(n,REPEATS,6,6),
            selected_path=supports.reshape(n,REPEATS,6,6),selected_column=selected_column.reshape(n,REPEATS),
            path_prior=pathprior.reshape(n,REPEATS),mixture=mixture.reshape(n,REPEATS),
            maxweighted=maxweighted.reshape(n,REPEATS),selected_min_e=min_e.reshape(n,REPEATS),
            selected_p=path_p.reshape(n,REPEATS),column_p=column_p.reshape(n,REPEATS),
            local_log_slrt=slrt_local.reshape(n,REPEATS),full_log_slrt=slrt_full.reshape(n,REPEATS),
            conn_cert=conn.reshape(len(METHODS),n,REPEATS),no_conn_cert=no_connection.reshape(n,REPEATS),
            predicted=predicted.reshape(len(METHODS),n,REPEATS))
        pred_all.append(predicted.reshape(len(METHODS),n,REPEATS))
        diagnostics.append({"dose":float(dose),"connections_certified":{method:int(v.sum()) for method,v in zip(METHODS,conn)},
             "no_connections_certified":int(no_connection.sum()),
             "conflicts":{method:int((v&no_connection).sum()) for method,v in zip(METHODS,conn)}})
        deadline(f"dose{dose:g}_complete")
    predictions=np.stack(pred_all)
    allcounts=np.stack([counts_metrics(labels,p) for p in predictions])
    point_by_dose=f1_from_counts(allcounts.sum(axis=2))
    point=point_by_dose.mean(axis=0)
    ci=bootstrap(allcounts,frames,True)
    geometry_ci=bootstrap(allcounts,frames,False)
    metrics={}
    for mi,method in enumerate(METHODS):
        per_dose=[]
        for di,dose in enumerate(DOSES):
            p=predictions[di,mi]
            negative=(labels==0)
            positive=(labels==1)
            false_conn=int((p[negative]==1).sum());n0=int(negative.sum()*REPEATS)
            false_disc=int((p[positive]==0).sum());n1=int(positive.sum()*REPEATS)
            upper_fc=float(beta.ppf(.95,false_conn+1,n0-false_conn)) if false_conn<n0 else 1.
            per_dose.append({"dose":float(dose),"macro_f1":float(point_by_dose[di,mi]),
             "coverage":float((p!=-1).mean()),"false_connection_count":false_conn,
             "negative_draws":n0,"false_connection_rate":false_conn/n0,
             "false_connection_binomial_upper95_descriptive_only":upper_fc,
             "false_disconnection_count":false_disc,"positive_draws":n1,
             "false_disconnection_rate":false_disc/n1,
             "almost_connected_false_connection_count":int((p[almost]==1).sum()),
             "almost_connected_draws":len(almost)*REPEATS})
        metrics[method]={"primary_macro_f1":float(point[mi]),"by_dose":per_dose}
    comparisons={method:{"difference":float(point[0]-point[i]),
                     "hierarchical_ci95":ci[method],"geometry_only_ci95":geometry_ci[method],
                     "passed":bool(point[0]-point[i]>=.02 and ci[method]["lower"]>0)}
                 for i,method in enumerate(METHODS[1:],1)}
    passed=all(v["passed"] for v in comparisons.values())
    result={"complete":True,"gate":"PASS" if passed else "FAIL", "cnn_triggered":False,
            "methods":METHODS,"geometry_count":n,"dose_count":4,"repeats":16,
            "count_draws":int(n*4*REPEATS),"frames":np.unique(frames).tolist(),
            "metrics":metrics,"comparisons":comparisons,"diagnostics":diagnostics,
            "verification":verification,"elapsed_seconds":elapsed(),
            "scope":"Analytical proposal; independent known2intensity integerPoisson counts; noPSF; finitegeometrysameIC; not CNN or realSEM validation.",
            "gate_requires":{"difference":.02,"lower_ci_above":0,"against":"every6controls"}}
    dump("RESULT.json",result)
    np.savez_compressed(HERE/"PREDICTIONS.npz",predictions=predictions,truth=labels,frame=frames,
                        dose=DOSES,method=np.array(METHODS),counts=allcounts)
    deadline("finished_all_controls_bootstrap")
    dump("PROGRESS.json",{"stage":"complete","elapsed_seconds":elapsed(),"complete":True,"gate":result["gate"]})
    print(json.dumps({"gate":result["gate"],"metrics":{m:round(v["primary_macro_f1"],6) for m,v in metrics.items()},
                      "comparisons":comparisons,"elapsed_seconds":elapsed()},ensure_ascii=False),flush=True)


if __name__=="__main__":
    try:
        main()
    except BaseException as exc:
        if START is not None:
            dump("ERROR.json",{"type":type(exc).__name__,"message":str(exc),"elapsed_seconds":elapsed(),
                  "complete":False})
        raise
