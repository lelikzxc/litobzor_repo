"""Exact split-likelihood-ratio controls for the restricted count-image probe.

Only known two-intensity, independent-count models are covered.  ``ell`` is
log p_1(count) / p_0(count), e.g. k*log(4)-6*t for means 8*t versus 2*t.
``q_a`` is a selection-split-measurable, normalized per-pixel predictive
foreground probability.  No image from the inference split may choose it.

No SEM calibration, blur handling, or real benchmark is performed here.
Running this file only checks the oracle against exhaustive tiny problems.
"""

from __future__ import annotations

import json
import math
import time
from collections import deque

import networkx as nx
import numpy as np


def _validate(ell: np.ndarray, q_a: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    ell = np.asarray(ell, dtype=np.float64)
    q_a = np.asarray(q_a, dtype=np.float64)
    if ell.ndim != 2 or q_a.shape != ell.shape:
        raise ValueError("ell and q_a must have the same two-dimensional shape")
    if not np.all(np.isfinite(ell)):
        raise ValueError("log likelihood ratios must be finite")
    if not np.all(np.isfinite(q_a)) or np.any((q_a < 0) | (q_a > 1)):
        raise ValueError("predictive probabilities must lie in [0,1]")
    return ell, q_a


def has_lr_connection(mask: np.ndarray) -> bool:
    """Foreground 4-connectivity from any left pixel to any right pixel."""
    mask = np.asarray(mask, dtype=bool)
    if mask.ndim != 2:
        raise ValueError("mask must be two-dimensional")
    height, width = mask.shape
    seen = np.zeros_like(mask)
    queue = deque()
    for row in range(height):
        if mask[row, 0]:
            seen[row, 0] = True
            queue.append((row, 0))
    while queue:
        row, col = queue.popleft()
        if col == width - 1:
            return True
        for rr, cc in ((row - 1, col), (row + 1, col), (row, col - 1), (row, col + 1)):
            if 0 <= rr < height and 0 <= cc < width and mask[rr, cc] and not seen[rr, cc]:
                seen[rr, cc] = True
                queue.append((rr, cc))
    return False


def positive_vertex_cut(ell: np.ndarray) -> float:
    """Minimum cost of changing the unconstrained MAP to disconnected.

    The zero/negative-ell sites have zero deletion cost.  Deleting positive
    sites costs their positive log-likelihood advantage.  Adding foreground
    at any negative site cannot help disconnect, so an optimum always has
    this deletion-only form.  A node-split directed graph computes the exact
    weighted vertex cut; no integer rounding of capacities is used.
    """
    ell = np.asarray(ell, dtype=np.float64)
    if ell.ndim != 2 or not np.all(np.isfinite(ell)):
        raise ValueError("ell must be a finite two-dimensional array")
    positive = np.maximum(ell, 0.0)
    if not has_lr_connection(positive > 0):
        return 0.0
    height, width = ell.shape
    count = height * width
    source, sink = 2 * count, 2 * count + 1
    total = float(positive.sum())
    infinity = total + max(1.0, abs(total) * 0.01)
    graph = nx.DiGraph()
    graph.add_nodes_from(range(2 * count + 2))
    for row in range(height):
        for col in range(width):
            index = row * width + col
            graph.add_edge(2 * index, 2 * index + 1, capacity=float(positive[row, col]))
            if col == 0:
                graph.add_edge(source, 2 * index, capacity=infinity)
            if col == width - 1:
                graph.add_edge(2 * index + 1, sink, capacity=infinity)
            for rr, cc in ((row - 1, col), (row + 1, col), (row, col - 1), (row, col + 1)):
                if 0 <= rr < height and 0 <= cc < width:
                    neighbor = rr * width + cc
                    graph.add_edge(2 * index + 1, 2 * neighbor, capacity=infinity)
    cut, _ = nx.minimum_cut(
        graph, source, sink, capacity="capacity",
        flow_func=nx.algorithms.flow.shortest_augmenting_path,
    )
    if cut < -1e-9 or cut > total + 1e-8:
        raise ArithmeticError("invalid min-cut value")
    return max(0.0, float(cut))


def _log_predictive_relative(ell: np.ndarray, q_a: np.ndarray) -> np.ndarray:
    """Log of [(1-q)p0 + q*p1] / p0, including q=0 or 1 exactly."""
    with np.errstate(divide="ignore"):
        return np.logaddexp(np.log1p(-q_a), np.log(q_a) + ell)


def log_slrt_full(ell: np.ndarray, q_a: np.ndarray, region: np.ndarray | None = None) -> float:
    """Full-image universal splitLR against no foreground LR connection.

    All p0(count) factors cancel between numerator and denominator.  The
    constrained maximum relative log likelihood is sum(max(ell,0))-cut.
    This function returns log E; thresholding at log(1/alpha) is valid.
    """
    if region is not None:
        return log_slrt_corridor(ell, q_a, region)
    ell, q_a = _validate(ell, q_a)
    log_numerator = float(_log_predictive_relative(ell, q_a).sum())
    log_denominator = float(np.maximum(ell, 0).sum()) - positive_vertex_cut(ell)
    return log_numerator - log_denominator


def _path_indices(path, shape: tuple[int, int]) -> tuple[np.ndarray, np.ndarray]:
    """Accept unique (row,col) pairs or a boolean support mask.

    Connectivity of the path is checked independently of row-major order.
    A support is admissible if it contains a genuine LR-connected 4-path;
    under the no-connection null it must then contain a background site.
    Repeated coordinates never create repeated observations.
    """
    value = np.asarray(path)
    if value.dtype == bool and value.shape == shape:
        support = value.copy()
    elif value.ndim == 2 and value.shape[1] == 2:
        coordinates = value.astype(np.int64)
        if np.any(coordinates != value):
            raise ValueError("path coordinates must be integers")
        if np.any(coordinates < 0) or np.any(coordinates[:, 0] >= shape[0]) or np.any(coordinates[:, 1] >= shape[1]):
            raise ValueError("path coordinate outside image")
        support = np.zeros(shape, dtype=bool)
        support[coordinates[:, 0], coordinates[:, 1]] = True
    else:
        raise ValueError("path must be a support mask or list of row,col pairs")
    if not has_lr_connection(support):
        raise ValueError("selected support does not contain a real 4-connected LR path")
    return np.nonzero(support)


def log_slrt_path(ell: np.ndarray, q_a: np.ndarray, path) -> float:
    """Local splitLR against at least one background site on a fixed path.

    This uses the union null, not a plug-in mask.  An all-foreground
    unconstrained MAP is made non-all-foreground by its cheapest one-site
    flip; if a MAP background site exists no correction is needed.  It is
    conservative but valid for the global disconnected null.
    """
    ell, q_a = _validate(ell, q_a)
    rr, cc = _path_indices(path, ell.shape)
    local_ell, local_q = ell[rr, cc], q_a[rr, cc]
    log_numerator = float(_log_predictive_relative(local_ell, local_q).sum())
    log_denominator = float(np.maximum(local_ell, 0).sum())
    if np.all(local_ell > 0):
        log_denominator -= float(local_ell.min())
    return log_numerator - log_denominator


def log_slrt_corridor(ell: np.ndarray, q_a: np.ndarray, observed: np.ndarray) -> float:
    """Localized universal splitLR observing only an independent corridor.

    The observed-region null is no LR connection contained IN the region;
    global no-connection implies it.  Sites outside carry zero score.
    Maximizing the global no-connection likelihood over unobserved labels
    is equivalent: every region-disconnected configuration can be extended
    with all-background outside.  This implementation keeps zero-capacity
    exterior nodes rather than rebuilding a distinct regional graph.
    """
    ell, q_a = _validate(ell, q_a)
    observed = np.asarray(observed, dtype=bool)
    if observed.shape != ell.shape:
        raise ValueError("corridor support must have image shape")
    if not np.any(observed):
        return 0.0
    log_numerator = float(_log_predictive_relative(ell[observed], q_a[observed]).sum())
    effective_ell = np.where(observed, ell, 0.0)
    log_denominator = float(np.maximum(effective_ell, 0).sum()) - positive_vertex_cut(effective_ell)
    return log_numerator - log_denominator


def _all_mask_classification(height: int, width: int):
    """Vectorized exhaustive ground truth, independent of graph-cut code."""
    count = height * width
    if count > 20:
        raise ValueError("tiny verification only")
    code = np.arange(1 << count, dtype=np.uint32)
    full_bits = np.uint32((1 << count) - 1)
    left_bits = np.uint32(sum(1 << (row * width) for row in range(height)))
    right_bits = np.uint32(sum(1 << (row * width + width - 1) for row in range(height)))
    reached = code & left_bits
    for _ in range(count):
        adjacent = (
            ((reached << np.uint32(1)) & ~left_bits)
            | ((reached >> np.uint32(1)) & ~right_bits)
            | (reached << np.uint32(width))
            | (reached >> np.uint32(width))
        ) & full_bits
        updated = reached | (adjacent & code)
        if np.array_equal(reached, updated):
            break
        reached = updated
    connected = (reached & right_bits) != 0
    masks = ((code[:, None] >> np.arange(count, dtype=np.uint32)) & 1).astype(np.float64)
    return masks, connected


def verify_oracle(seed: int = 2026102603) -> dict:
    """Exhaustive 4x4 mask checks; no real dataset or count images are read."""
    started = time.perf_counter()
    rng = np.random.default_rng(seed)
    masks, connected = _all_mask_classification(4, 4)
    # An independent ordinary BFS verifies the bitboard truth on random masks.
    for index in rng.integers(0, len(masks), 100):
        if has_lr_connection(masks[index].reshape(4, 4)) != bool(connected[index]):
            raise AssertionError("bitboard and BFS disagree")
    test_ell = [
        np.ones((4, 4)), -np.ones((4, 4)), np.zeros((4, 4)),
        np.arange(16, dtype=float).reshape(4, 4) / 7 - 1,
    ]
    test_ell.extend(rng.normal(0, 3, (4, 4)) for _ in range(12))
    test_ell.extend(rng.uniform(0.01, 10, (4, 4)) for _ in range(4))
    maximum_error = 0.0
    for ell in test_ell:
        exact = float(np.max(masks[~connected] @ ell.ravel()))
        calculated = float(np.maximum(ell, 0).sum()) - positive_vertex_cut(ell)
        maximum_error = max(maximum_error, abs(exact - calculated))
        if not math.isclose(exact, calculated, abs_tol=1e-9, rel_tol=1e-11):
            raise AssertionError((exact, calculated))
        # Localized null optimizes all 16 labels, with no information outside.
        support = rng.uniform(size=(4, 4)) > 0.35
        effective = np.where(support, ell, 0)
        exact_local = float(np.max(masks[~connected] @ effective.ravel()))
        calculated_local = float(np.maximum(effective, 0).sum()) - positive_vertex_cut(effective)
        maximum_error = max(maximum_error, abs(exact_local - calculated_local))
        if not math.isclose(exact_local, calculated_local, abs_tol=1e-9, rel_tol=1e-11):
            raise AssertionError((exact_local, calculated_local))
    # Union-null path denominator versus every binary labeling of five sites.
    small_masks, _ = _all_mask_classification(1, 5)
    not_all_foreground = small_masks.sum(axis=1) < 5
    path_error = 0.0
    for _ in range(20):
        ell = rng.normal(1, 2, 5)
        exact = float(np.max(small_masks[not_all_foreground] @ ell))
        calculated = float(np.maximum(ell, 0).sum())
        if np.all(ell > 0):
            calculated -= float(ell.min())
        path_error = max(path_error, abs(exact - calculated))
        if not math.isclose(exact, calculated, abs_tol=1e-10):
            raise AssertionError((exact, calculated))
    return {
        "status": "PASS",
        "seed": seed,
        "all_4x4_masks": len(masks),
        "unary_cases": len(test_ell),
        "full_and_local_denominator_cases": 2 * len(test_ell),
        "maximum_abs_error": maximum_error,
        "path_union_cases": 20,
        "path_maximum_abs_error": path_error,
        "elapsed_seconds": time.perf_counter() - started,
        "scope": "oracle verification only; no dataset or experiment outcomes",
    }


if __name__ == "__main__":
    print(json.dumps(verify_oracle(), indent=2))
