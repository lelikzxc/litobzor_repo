"""Read saved outcomes; separate raw certificates and resolved decisions."""
from pathlib import Path
import json
import numpy as np

base = Path(__file__).resolve().parent
result = json.loads((base / "RESULT.json").read_text())
truth = np.load(base / "GEOMETRIES.npz")["truth"]
audit = {}
for dose in [.5, 1, 2, 4]:
    saved = np.load(base / f"dose_{dose:g}.npz")
    audit[str(dose)] = {}
    for method_index, name in enumerate(result["methods"]):
        raw = saved["conn_cert"][method_index]
        predicted = saved["predicted"][method_index]
        no_connection = saved["no_conn_cert"]
        audit[str(dose)][name] = {
            "raw_false_conn": int(raw[truth == 0].sum()),
            "decision_false_conn": int((predicted[truth == 0] == 1).sum()),
            "raw_false_disc": int(no_connection[truth == 1].sum()),
            "decision_false_disc": int((predicted[truth == 1] == 0).sum()),
            "conflicts": int((raw & no_connection).sum()),
        }
(base / "CERTIFICATE_AUDIT.json").write_text(json.dumps(audit, indent=2))
