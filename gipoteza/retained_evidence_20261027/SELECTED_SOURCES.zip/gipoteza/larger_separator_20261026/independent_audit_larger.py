#!/usr/bin/env python3
"""Read-only independent audit, runnable only after the complete larger run.

No frozen experiment file is edited. Output is restricted to the two
INDEPENDENT_RESULT_AUDIT_DESIGN_CONTEXT files next to this script.
The fixed audit sampling rule does not use predictions or count values.
"""
from __future__ import annotations

import hashlib
import heapq
import json
from pathlib import Path
import time

import numpy as np
from scipy.special import expit, logsumexp
from scipy.stats import beta, poisson
from sklearn.metrics import confusion_matrix, f1_score

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
SIGMAS = [0., .5, .8]
DOSES = [.5, 1., 2., 4., 8., 16.]
ALPHA = .025
REPEATS = {6: 32, 4: 16}
BOOT = 4000
EXTERNAL = ['pixel_bonferroni', 'holm', 'hochberg', 'hommel',
            'weighted_holm_fixed', 'selected_global_path_fixed',
            'weighted_holm_ml', 'selected_global_path_ml']
PREFIX = 'INDEPENDENT_RESULT_AUDIT_DESIGN_CONTEXT'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def same(actual, expected, tolerance=1e-11):
    actual, expected = np.asarray(actual), np.asarray(expected)
    error = float(np.max(np.abs(actual-expected))) if actual.size else 0.
    assert error <= tolerance, {'maximum_error': error, 'tolerance': tolerance}
    return error


def bfs(mask):
    h, w = mask.shape
    visited = {(r, 0) for r in range(h) if mask[r, 0]}
    queue = list(visited)
    for r, c in queue:
        if c == w-1:
            return True
        for rr, cc in [(r-1,c), (r+1,c), (r,c-1), (r,c+1)]:
            if 0 <= rr < h and 0 <= cc < w and mask[rr,cc] and (rr,cc) not in visited:
                visited.add((rr,cc)); queue.append((rr,cc))
    return False


def all_masks4():
    codes = np.arange(65536, dtype=np.uint32)
    masks = ((codes[:,None] >> np.arange(16, dtype=np.uint32)) & 1).astype(bool).reshape(-1,4,4)
    reached = np.zeros_like(masks)
    reached[:,:,0] = masks[:,:,0]
    for _ in range(15):
        near = np.zeros_like(reached)
        near[:,1:,:] |= reached[:,:-1,:]
        near[:,:-1,:] |= reached[:,1:,:]
        near[:,:,1:] |= reached[:,:,:-1]
        near[:,:,:-1] |= reached[:,:,1:]
        new = reached | (near & masks)
        if np.array_equal(new, reached):
            break
        reached = new
    connected = reached[:,:,-1].any(axis=1)
    assert int(connected.sum()) == 22193
    return masks.reshape(-1,16).astype(float), connected


def counts_from_calls(truth, pred):
    out = np.zeros(pred.shape[:-1] + (6,), dtype=np.int64)
    for k in (0,1):
        actual = truth[None,None,:,None] == k
        called = pred == k
        out[...,3*k] = (actual & called).sum(axis=-1)
        out[...,3*k+1] = (~actual & called).sum(axis=-1)
        out[...,3*k+2] = (actual & ~called).sum(axis=-1)
    return out


def macro(counts):
    parts = []
    for j in (0,3):
        den = 2*counts[...,j]+counts[...,j+1]+counts[...,j+2]
        parts.append(np.divide(2*counts[...,j], den, out=np.zeros_like(den,dtype=float), where=den!=0))
    return (parts[0]+parts[1])/2


def own_weights(frames, seed):
    """Literal multinomial frame multiplicities, then within-frame counts."""
    rng = np.random.default_rng(seed)
    ids = sorted(set(map(int, frames)))
    members = {f: np.array([j for j,x in enumerate(frames) if x == f]) for f in ids}
    out = np.zeros((BOOT, len(frames)), dtype=np.float64)
    for b in range(BOOT):
        frequency = rng.multinomial(len(ids), [1/len(ids)]*len(ids))
        for f, copies in zip(ids, frequency):
            if copies:
                ix = members[f]
                out[b,ix] = rng.multinomial(int(copies)*len(ix), [1/len(ix)]*len(ix))
    return out


def bootstrap(counts, frames, h):
    weights = own_weights(frames, 261027600+h)
    pooled = np.einsum('bg,cmgs->bcms', weights, counts, optimize=True)
    hvalues = macro(pooled)
    rng = np.random.default_rng(261027700+h)
    gweights = rng.multinomial(len(frames), np.full(len(frames),1/len(frames)), size=BOOT).astype(float)
    gvalues = macro(np.einsum('bg,cmgs->bcms', gweights, counts, optimize=True))
    return hvalues, gvalues


def sample_plan(h, selection):
    """First16 SHA-defined observations per sigma; no outcome in the key."""
    plans = {}
    for sigma in SIGMAS:
        def candidates():
            for g, item in enumerate(selection['selected']):
                for r in range(REPEATS[h]):
                    for d in DOSES:
                        key = f'larger-independent-audit-v1/{h}/{sigma:g}/{d:g}/{item["id_sha256"]}/{r}'
                        yield (hashlib.sha256(key.encode()).hexdigest(),g,r,d)
        plans[sigma] = heapq.nsmallest(16, candidates())
    return plans


def negative_p(a,b,dose,H,h):
    q = np.clip(expit(a*np.log(4)-1.2*dose),1e-8,1-1e-8)
    col = np.argmax(np.log1p(-q).reshape(-1,h,h).sum(axis=1),axis=1)
    p = poisson.cdf(b,.8*dose*(2+6*np.diag(H))).reshape(-1,h,h)
    return np.array([p[n,:,c].max() for n,c in enumerate(col)])


def literal_cut(a,b,dose,H,K,indices):
    """No gather/DP cache: direct caps and a literal loop over every cut."""
    q = np.clip(expit((a*np.log(4)-1.2*dose)/.5),1e-8,1-1e-8)
    caps = np.array([2+6*H[:,row==0].sum(axis=1) for row in K])
    tails = poisson.sf(b[None,:]-1,.8*dose*caps)
    sums = poisson.sf(K@b-1,.8*dose*(caps*K).sum(axis=1))
    combined = plain = atom_only = 0.
    for k, ix in enumerate(indices):
        atom = min(1., float(np.min(tails[k,ix]/q[ix])*q[ix].sum()))
        unweighted = min(1., float(len(ix)*np.min(tails[k,ix])))
        combined = max(combined,min(1.,2*atom,2*sums[k]))
        plain = max(plain,min(1.,2*unweighted,2*sums[k]))
        atom_only = max(atom_only,atom)
    return np.array([combined,plain,float(sums.max()),atom_only])


def literal_exact(a,b,dose,H,allm,connected):
    """All65536 masks, direct per-mask likelihood, independent of runner."""
    rate = 2+6*(allm@H.T)
    mu_a, mu_b = .2*dose*rate, .8*dose*rate
    la = (a[None,:]*np.log(mu_a)-mu_a).sum(axis=1)
    lb = (b[None,:]*np.log(mu_b)-mu_b).sum(axis=1)
    return float(logsumexp(la+lb)-logsumexp(la)-lb[~connected].max())


def audit_grid(h, allm, connected4):
    expected = read(HERE/f'RESULT_{h}.json')
    data = np.load(HERE/'data'/f'GEOMETRIES_{h}.npz')
    selection = read(HERE/'data'/f'SELECTION_{h}.json')
    M = data['M'].astype(float); truth = data['truth']; frames = data['frame']
    assert sha(HERE/'data'/f'GEOMETRIES_{h}.npz') == selection['geometry_npz_sha256']
    assert np.array_equal([int(bfs(m.astype(bool))) for m in M],truth)
    assert selection['predictive_scores_created'] is False
    z = np.load(HERE/f'PREDICTIONS_{h}.npz')
    pred = z['predictions']; names = z['method'].tolist()
    assert np.array_equal(z['truth'],truth) and np.array_equal(z['frame'],frames)
    assert pred.shape == (18,len(names),len(M),REPEATS[h])
    assert set(np.unique(pred)).issubset({-1,0,1})
    counts = counts_from_calls(truth,pred)
    assert np.array_equal(counts,z['counts'])
    cell_points = macro(counts.sum(axis=2))
    plans = sample_plan(h,selection)
    risk_map = {(r['sigma'],r['dose'],r['method']):r for r in expected['risk']}
    rng_a = np.random.default_rng(261027100+h)
    rng_b = np.random.default_rng(261027200+h)
    scalar_counts = 0; sk_cases = 0; score_cases = 0; exact_cases = 0
    sk_error = cut_error = exact_error = 0.
    all_risks = []; sample_records = []; confusion = {}; allcells=[]
    for s,sigma in enumerate(SIGMAS):
        model = np.load(HERE/f'MODEL_{h}_sigma{sigma:g}.npz')
        H,K = model['H'],model['K']
        assert H.shape == (h*h,h*h) and np.all(H>=0)
        same(H.sum(axis=1),np.ones(h*h),1e-14)
        assert len(K) == (4286 if h==6 else 78)
        assert np.all((K==0)|(K==1))
        cap = np.array([2+6*H[:,row==0].sum(axis=1) for row in K])
        same(cap,model['cap_per_exposure'],1e-12)
        same((cap*K).sum(axis=1),model['sum_cap_per_exposure'],1e-11)
        indices = [np.where(row==1)[0] for row in K]
        rate = 2+6*(M.reshape(-1,h*h)@H.T)
        for j,dose in enumerate(DOSES):
            ci=s*6+j; allcells.append({'sigma':sigma,'dose':dose})
            saved=np.load(HERE/f'grid{h}'/f'sigma{sigma:g}_dose{dose:g}.npz')
            a,b=saved['A'],saved['B']
            assert a.shape==b.shape==(len(M),REPEATS[h],h*h)
            for rng,key,observed,fraction in [(rng_a,'A',a,.2),(rng_b,'B',b,.8)]:
                assert np.issubdtype(observed.dtype,np.integer) and observed.min()>=0
                recreated=rng.poisson(fraction*dose*rate[:,None,:],size=observed.shape)
                assert np.array_equal(recreated,observed), (h,sigma,dose,key)
                scalar_counts += int(observed.size)
            assert saved['method'].tolist()==names and np.array_equal(saved['predictions'],pred[ci])
            dp=negative_p(a.reshape(-1,h*h),b.reshape(-1,h*h),dose,H,h)
            same(dp,saved['disc_p'].ravel(),1e-13)
            negative=dp.reshape(len(M),REPEATS[h])<=ALPHA
            for m,name in enumerate(names):
                score=saved['score__'+name]
                positive=score>=np.log(40) if name=='exact_bayes_slrt' else score<=ALPHA
                called=np.where(positive&~negative,1,np.where(negative&~positive,0,-1))
                assert np.array_equal(called,pred[ci,m]), (h,sigma,dose,name)
                yt=np.repeat(truth,REPEATS[h]); yp=called.ravel()
                sf=f1_score(yt,yp,labels=[0,1],average='macro',zero_division=0)
                sk_error=max(sk_error,abs(sf-cell_points[ci,m])); sk_cases+=1
                assert abs(sf-cell_points[ci,m])<1e-14
                same(sf,expected['methods'][name]['cell_macro_f1'][ci],1e-14)
                same(np.mean(yp!=-1),expected['methods'][name]['cell_coverage'][ci],1e-14)
                cm=confusion_matrix(yt,yp,labels=[-1,0,1])[1:,:]
                assert cm.tolist()==expected['methods'][name]['cell_confusion_true_0_1_pred_unknown_0_1'][ci]
                recall=[float((called[truth==k]==k).mean()) for k in (0,1)]
                same(recall,expected['methods'][name]['cell_class_recall'][ci],1e-14)
                confusion[f'sigma{sigma:g}/dose{dose:g}/{name}']=cm.tolist()
                row=risk_map[(sigma,dose,name)]
                n0=int((truth==0).sum()*REPEATS[h]); n1=int((truth==1).sum()*REPEATS[h])
                fc=int(positive[truth==0].sum()); fd=int(negative[truth==1].sum())
                actual={'false_conn':fc,'false_disc':fd,'n0':n0,'n1':n1,
                        'conflicts':int((positive&negative).sum()),
                        'final_false_conn':int((called[truth==0]==1).sum()),
                        'final_false_disc':int((called[truth==1]==0).sum())}
                for key,value in actual.items(): assert row[key]==value, (h,sigma,dose,name,key)
                same([fc/n0,fd/n1],[row['false_conn_rate'],row['false_disc_rate']],1e-14)
                for kind,k,n in [('false_conn',fc,n0),('false_disc',fd,n1)]:
                    cp=1. if k==n else beta.ppf(.95,k+1,n-k)
                    same(cp,row[kind+'_binomial_CP_reference95'],1e-13)
                    same(min(1.,k/n+np.sqrt(np.log(20)/(2*n))),row[kind+'_Hoeffding_upper95'],1e-13)
                if m==0: all_risks.append(dict(sigma=sigma,dose=dose,**actual))
            for sample in [x for x in plans[sigma] if x[3]==dose]:
                digest,g,r,_=sample
                actual=literal_cut(a[g,r],b[g,r],dose,H,K,indices)
                target=np.array([saved['score__'+name][g,r] for name in
                     ['joint_cut_fixed','joint_cut_unweighted','joint_sum_only','joint_atomic_only']])
                cut_error=max(cut_error,same(actual,target,1e-9)); score_cases+=1
                assert np.array_equal(actual<=ALPHA,target<=ALPHA)
                exact_checked=False
                if h==4 and sigma>0 and sample in plans[sigma][:4]:
                    le=literal_exact(a[g,r],b[g,r],dose,H,allm,connected4)
                    exact_error=max(exact_error,same(le,saved['score__exact_bayes_slrt'][g,r],1e-8))
                    assert bool(le>=np.log(40))==bool(saved['score__exact_bayes_slrt'][g,r]>=np.log(40))
                    exact_cases+=1; exact_checked=True
                sample_records.append(dict(sha256=digest,h=h,sigma=sigma,dose=dose,
                                           geometry=g,repeat=r,exact_full65536_checked=exact_checked))
    assert allcells==expected['cells']
    blur=np.array([c['sigma']>0 for c in allcells]); average=cell_points[blur].mean(axis=0)
    for j,name in enumerate(names):
        same(average[j],expected['methods'][name]['blur_average_macro_f1'],1e-14)
        for s,sigma in enumerate(SIGMAS):
            same(cell_points[s*6:s*6+6,j].mean(),expected['methods'][name]['sigma_average_macro_f1'][str(sigma)],1e-14)
    hv,gv=bootstrap(counts,frames,h)
    hmean=hv[:,blur,:].mean(axis=1); gmean=gv[:,blur,:].mean(axis=1)
    max_ci_error=0.; comparison_checks={}
    for j,name in enumerate(names[1:],1):
        recorded=expected['comparisons'][name]
        ci=np.quantile(hmean[:,0]-hmean[:,j],[.025,.975])
        gci=np.quantile(gmean[:,0]-gmean[:,j],[.025,.975])
        max_ci_error=max(max_ci_error,same(ci,recorded['ci95'],1e-12),same(gci,recorded['geometry_only_ci95'],1e-12))
        same(average[0]-average[j],recorded['difference_blur_average'],1e-14)
        assert recorded['lower_gt_1pp']==bool(ci[0]>.01)
        assert recorded['lower_gt_0']==bool(ci[0]>0)
        guards={}
        for s,sigma in enumerate(SIGMAS):
            idx=s*6+5
            g=np.quantile(hv[:,idx,0]-hv[:,idx,j],[.025,.975])
            savedg=recorded['dose16_guards'][str(sigma)]
            max_ci_error=max(max_ci_error,same(g,savedg['ci95'],1e-12))
            same(cell_points[idx,0]-cell_points[idx,j],savedg['difference'],1e-14)
            assert savedg['passed']==bool(g[0]>=-.01)
            guards[str(sigma)]=bool(g[0]>=-.01)
        comparison_checks[name]=dict(ci95=ci.tolist(),geometry_ci95=gci.tolist(),
                                    lower_gt_1pp=bool(ci[0]>.01),lower_gt_0=bool(ci[0]>0),guards=guards)
    empirical=all(x['false_conn']/x['n0']<=ALPHA and x['false_disc']/x['n1']<=ALPHA for x in all_risks)
    if h==6:
        cgate=all(comparison_checks[x]['lower_gt_1pp'] and all(comparison_checks[x]['guards'].values()) for x in EXTERNAL)
    else:
        e=comparison_checks['exact_bayes_slrt']; cgate=e['lower_gt_0'] and all(e['guards'].values())
    gate='PASS' if empirical and cgate else 'FAIL'
    assert gate==expected['gate']
    assert empirical==expected['empirical_risk_gate'] and cgate==expected['comparison_gate']
    return dict(h=h,audit_status='PASS',recomputed_experiment_gate=gate,
                geometry_count=len(M),class_counts=[int((truth==k).sum()) for k in (0,1)],
                source_frame_count=len(np.unique(frames)),selection_mode=selection['mode'],
                old_shape_overlap_count=selection['old_shape_overlap_count'],
                exact_regenerated_scalar_counts=scalar_counts,
                sklearn_cases=sk_cases,sklearn_maximum_error=sk_error,
                all_confusion_counts_and_unknown_match=True,confusion_matrices=confusion,
                primary_raw_and_final_risks=all_risks,
                bootstrap_replicates_each=BOOT,bootstrap_maximum_endpoint_error=max_ci_error,
                comparisons=comparison_checks,literal_primary_draws=score_cases,
                all_cuts_per_literal_draw=(4286 if h==6 else 78),
                literal_four_channel_maximum_error=cut_error,
                literal_exact_full65536_cases=exact_cases,literal_exact_maximum_error=exact_error,
                fixed_SHA_sample_records=sample_records)


def audit_mismatch():
    data=np.load(HERE/'data/GEOMETRIES_6.npz'); M=data['M'].reshape(-1,36).astype(float); truth=data['truth']
    expected=read(HERE/'MISMATCH.json'); records=[]; scalar=0
    assert expected['diagnostic_only'] is True and expected['outside_model_guarantee'] is True
    rng_a=np.random.default_rng(261027901); rng_b=np.random.default_rng(261027902)
    for assumed in [.5,.8]:
        rc=np.indices((6,6)).reshape(2,-1).T
        diff=rc[:,None]-rc[None,:]
        w=np.exp(-(diff*diff).sum(axis=-1)/(2*(1.2*assumed)**2))
        w[np.abs(diff).max(axis=-1)>1]=0
        Htrue=w/w.sum(axis=1,keepdims=True)
        Hassumed=np.load(HERE/f'MODEL_6_sigma{assumed:g}.npz')['H']
        rate=2+6*(M@Htrue.T)
        for dose in [4.,16.]:
            z=np.load(HERE/f'mismatch_assumed{assumed:g}_dose{dose:g}.npz')
            for rng,key,fraction in [(rng_a,'A',.2),(rng_b,'B',.8)]:
                observed=z[key]
                assert np.issubdtype(observed.dtype,np.integer) and observed.min()>=0
                assert np.array_equal(rng.poisson(fraction*dose*rate[:,None,:],size=observed.shape),observed)
                scalar+=observed.size
            dp=negative_p(z['A'].reshape(-1,36),z['B'].reshape(-1,36),dose,Hassumed,6)
            same(dp,z['disc_p'].ravel(),1e-13)
            pos=z['score'].reshape(len(M),16)<=ALPHA
            neg=dp.reshape(len(M),16)<=ALPHA
            row=next(r for r in expected['rows'] if r['assumed_sigma']==assumed and r['dose']==dose)
            fc=int(pos[truth==0].sum()); fd=int(neg[truth==1].sum())
            n0=int((truth==0).sum()*16); n1=int((truth==1).sum()*16)
            facts={'false_conn':fc,'false_disc':fd,'n0':n0,'n1':n1,
                   'final_false_conn':int((pos[truth==0]&~neg[truth==0]).sum()),
                   'final_false_disc':int((neg[truth==1]&~pos[truth==1]).sum()),
                   'conflicts':int((pos&neg).sum())}
            for k,v in facts.items(): assert row[k]==v
            same([fc/n0,fd/n1],[row['false_conn_rate'],row['false_disc_rate']],1e-14)
            same(min(1.,fc/n0+np.sqrt(np.log(20)/(2*n0))),row['false_conn_Hoeffding_upper95'],1e-13)
            same(min(1.,fd/n1+np.sqrt(np.log(20)/(2*n1))),row['false_disc_Hoeffding_upper95'],1e-13)
            assert row['validity_guarantee'] is False
            records.append(dict(assumed_sigma=assumed,true_sigma=1.2*assumed,dose=dose,**facts))
    return dict(status='PASS',scalar_counts_recreated=int(scalar),records=records,
                included_in_primary_gate=False,PSF_mismatch_guarantee_claimed=False)


def audit():
    started=time.perf_counter()
    final=read(HERE/'RESULT.json'); progress=read(HERE/'PROGRESS.json')
    assert final['complete'] and progress['complete']
    assert not (HERE/'ERROR.json').exists(), 'current run has ERROR.json'
    frozen=read(HERE/'RUN_FROZEN.json')
    for rel,expected in frozen['sha256'].items():
        assert sha(ROOT/rel)==expected, ('frozen hash changed',rel)
    allm,connected4=all_masks4()
    r6=audit_grid(6,allm,connected4)
    r4=audit_grid(4,allm,connected4)
    mismatch=audit_mismatch()
    gate='PASS' if r6['recomputed_experiment_gate']=='PASS' and r4['recomputed_experiment_gate']=='PASS' else 'FAIL'
    assert final['gate']==gate
    assert final['grid6_gate']==r6['recomputed_experiment_gate']
    assert final['grid4_exact_control_gate']==r4['recomputed_experiment_gate']
    for rel,expected in frozen['sha256'].items(): assert sha(ROOT/rel)==expected
    return dict(audit_status='PASS',recomputed_experiment_gate=gate,
                scope='read-only independent result reproduction; no new hypothesis test, training, or changes to frozen results',
                frozen_hash_entries_verified=len(frozen['sha256']),all_frozen_hashes_unchanged=True,
                frozen_record_sha256=sha(HERE/'RUN_FROZEN.json'),
                experiment_RESULT_sha256=sha(HERE/'RESULT.json'),
                audit_script_sha256=sha(Path(__file__)),grid6=r6,grid4=r4,mismatch=mismatch,
                failed_attempt_preserved=(HERE/'failed_attempt_1').is_dir(),
                context_limits=['known synthetic Poisson counts and finite-scene operator',
                                'same IC; source frames can physically overlap',
                                'source-fresh4 challenge may reuse old shapes',
                                'no trained CV model or real electrical-function labels',
                                'CP numbers are descriptive binomial references; Hoeffding separate',
                                'individual approximate bootstrap CIs; no independent-wafer evidence'],
                experiment_elapsed_seconds=final['elapsed_seconds'],
                audit_elapsed_seconds=time.perf_counter()-started)


if __name__=='__main__':
    if not (HERE/'RESULT.json').exists():
        raise SystemExit('Audit not run: complete RESULT.json is not available yet; no output written.')
    try:
        result=audit()
    except BaseException as exc:
        result={'audit_status':'FAIL','error_type':type(exc).__name__,'message':str(exc),
                'scope':'independent audit failed; no experiment file edited'}
        (HERE/(PREFIX+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        raise
    (HERE/(PREFIX+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    lines=['# Независимый аудит расширенной проверки','',
           '**Численный аудит: PASS.** Все frozen-хэши совпали; исходный gate воспроизведён: **'+result['recomputed_experiment_gate']+'**.','',
           'Проверены все counts из независимых seeds, все cells/методы против sklearn, unknown как FN, сырые и конечные ошибки, обе4000-кратные bootstrap-процедуры и все guards.',
           '',f"6×6: {result['grid6']['geometry_count']} геометрий, gate {result['grid6']['recomputed_experiment_gate']}; 4×4: {result['grid4']['geometry_count']} геометрий, gate {result['grid4']['recomputed_experiment_gate']}.",
           'Проверены96 SHA-заданных наблюдений: по16 на каждую sigma и размер, все4286/78cut. Exact4SLRT независимо пересчитан по всем65536маскам для4 наблюдений при каждой ненулевойsigma.',
           '', 'Успешный аудит означает корректное воспроизведение результата, включая возможный FAIL гипотезы. Он не подтверждает CNN, физическую SEM-калибровку или Q1. Полные числа и ограничения сохранены в '+PREFIX+'.json.']
    (HERE/(PREFIX+'.md')).write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:result[k] for k in ['audit_status','recomputed_experiment_gate','frozen_hash_entries_verified','audit_elapsed_seconds']},indent=2))
