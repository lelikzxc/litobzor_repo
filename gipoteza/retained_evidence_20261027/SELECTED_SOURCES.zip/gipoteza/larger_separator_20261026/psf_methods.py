"""Finite-scene Poisson separator tests. No data are read on import.

H is an explicitly defined forward operator, not a calibrated SEM PSF.
All choices depending on data use independent A; evidence uses B only.
"""
from __future__ import annotations

import sys
from collections import deque
from pathlib import Path

import numpy as np
from scipy.special import expit, logsumexp
from scipy.stats import poisson

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'search_next_20261026/functional_observability'
sys.path.insert(0, str(OLD / 'ep2/probe'))
sys.path.insert(0, str(OLD / 'ep2/core_confirmation'))
from cut_family import enumerate_minimal_cuts, cut_matrix, has_lr_connection
from controls import holm_adjusted, hochberg_adjusted, connectivity_level
from hommel import hommel_adjusted

ALPHA = .025


def operator(h: int, sigma: float) -> np.ndarray:
    """Radius-one Gaussian, renormalized inside the finite scene."""
    if sigma == 0:
        return np.eye(h*h)
    rc = np.indices((h, h)).reshape(2, -1).T
    diff = rc[:, None] - rc[None, :]
    weights = np.exp(-(diff*diff).sum(-1)/(2*sigma*sigma))
    weights[np.abs(diff).max(-1) > 1] = 0
    return weights / weights.sum(1, keepdims=True)


def proposal(a: np.ndarray, dose: float, H: np.ndarray):
    """Old analytic A score and a fixed 40-step projected Poisson MLE.

    Under blur the sigmoid is a heuristic score, not a posterior.
    The MLE is a continuous [0,1] estimate; no labels/tuning are used.
    """
    n, p = a.shape
    q = np.clip(expit((a*np.log(4)-1.2*dose)/.5), 1e-8, 1-1e-8)
    q_one = np.clip(expit(a*np.log(4)-1.2*dose), 1e-8, 1-1e-8)
    exposure = .2*dose
    observed = a/exposure
    estimate = np.clip((observed-2)/6, 0, 1)
    # A global Hessian upper bound over the full box makes this a fixed,
    # conservative projected-gradient algorithm rather than an optimizer
    # whose convergence or score influences the experimental protocol.
    lipschitz = np.maximum(1., 9*observed.max(1)*np.linalg.norm(H, 2)**2)
    for _ in range(40):
        rate = 2+6*(estimate@H.T)
        gradient = 6*((1-observed/rate)@H)
        estimate = np.clip(estimate-gradient/lipschitz[:, None], 0, 1)
    return q, q_one, .02+.96*estimate, estimate


def selected_paths(q: np.ndarray, h: int) -> np.ndarray:
    """Global 4-connected maximum-bottleneck A path, deterministic ties."""
    levels = connectivity_level((1-q).reshape(-1,h,h))
    allowed = (1-q).reshape(-1,h,h) <= levels[:,None,None]+1e-14
    paths = np.zeros_like(allowed)
    for index, mask in enumerate(allowed):
        previous = {}
        queue = deque()
        for row in range(h):
            if mask[row,0]:
                previous[(row,0)] = None
                queue.append((row,0))
        end = None
        while queue:
            r,c = queue.popleft()
            if c == h-1:
                end = (r,c)
                break
            for rr,cc in ((r-1,c),(r+1,c),(r,c-1),(r,c+1)):
                if 0<=rr<h and 0<=cc<h and mask[rr,cc] and (rr,cc) not in previous:
                    previous[(rr,cc)] = (r,c)
                    queue.append((rr,cc))
        if end is None:
            raise AssertionError('bottleneck path reconstruction failed')
        while end is not None:
            paths[index,end[0],end[1]] = True
            end = previous[end]
    return paths.reshape(-1,h*h)


class CutTest:
    def __init__(self, h: int, H: np.ndarray, dose: float):
        self.h = h
        self.H = H
        self.exposure = .8*dose
        self.family = enumerate_minimal_cuts(h,h)
        self.K = cut_matrix(self.family,h,h).reshape(-1,h*h).astype(float)
        self.length = self.K.sum(1).astype(int)
        self.indices = np.full((len(self.K),self.length.max()), h*h, int)
        for j, row in enumerate(self.K):
            selected = np.flatnonzero(row)
            self.indices[j,:len(selected)] = selected
        # rows are detector positions, columns latent object positions.
        self.cap = self.exposure*(2+6*((1-self.K)@H.T))
        self.sum_cap = (self.cap*self.K).sum(1)
        # Group equal caps without downward rounding: each class uses its
        # maximum original value, a conservative machine-precision envelope.
        flatcap = np.take_along_axis(
            np.concatenate([self.cap,np.zeros((len(self.K),1))],1), self.indices,1)
        rounded = np.round(flatcap,12)
        _, self.capindex = np.unique(rounded, return_inverse=True)
        self.capindex = self.capindex.reshape(flatcap.shape)
        self.unique_cap = np.zeros(self.capindex.max()+1)
        np.maximum.at(self.unique_cap,self.capindex.ravel(),flatcap.ravel())

    def evaluate(self, b: np.ndarray, weights: np.ndarray, batch: int=96):
        """All cuts retained. Return weighted, unweighted, sum, atomic p."""
        maximum = int(b.max())
        tail_atom = poisson.sf(np.arange(maximum+1)[None,:]-1,
                               self.unique_cap[:,None])
        tail_sum = poisson.sf(np.arange(maximum*int(self.length.max())+1)[None,:]-1,
                              self.sum_cap[:,None])
        out = np.zeros((4,len(b)))
        padding = self.h*self.h
        for lo in range(0,len(b),batch):
            hi = min(lo+batch,len(b))
            bb = b[lo:hi]
            padded = np.concatenate([bb,np.zeros((len(bb),1),dtype=bb.dtype)],1)
            chosen = padded[:,self.indices]
            pp = tail_atom[self.capindex[None,:,:],chosen]
            valid = self.indices != padding
            pp = np.where(valid[None,:,:],pp,np.inf)
            sums = np.rint(bb@self.K.T).astype(int)
            ps = tail_sum[np.arange(len(self.K))[None,:],sums]
            for j, ww in enumerate((weights[lo:hi],np.ones_like(weights[lo:hi]))):
                wp = np.concatenate([ww,np.ones((len(bb),1))],1)
                minimum = (pp/wp[:,self.indices]).min(2)
                atomic = np.minimum(1, minimum*(ww@self.K.T))
                out[j,lo:hi] = np.minimum(1,np.minimum(2*atomic,2*ps)).max(1)
                if j == 0:
                    out[3,lo:hi] = atomic.max(1)
            out[2,lo:hi] = ps.max(1)
        return out


METHODS = ['joint_cut_fixed','pixel_bonferroni','holm','hochberg','hommel',
           'weighted_holm_fixed','selected_global_path_fixed',
           'weighted_holm_ml','selected_global_path_ml',
           'joint_cut_unweighted','joint_sum_only','joint_atomic_only']
CONTROLS = METHODS[1:9]


def scores(a: np.ndarray, b: np.ndarray, dose: float, H: np.ndarray, h: int):
    q, q_one, q_ml, m_ml = proposal(a,dose,H)
    tb = .8*dose
    mu0 = tb*(2+6*(H.sum(1)-np.diag(H)))
    pp = poisson.sf(b-1,mu0)
    result = {}
    level = lambda x: connectivity_level(x.reshape(-1,h,h))
    result['pixel_bonferroni'] = level(np.minimum(1,h*h*pp))
    result['holm'] = level(holm_adjusted(pp))
    result['hochberg'] = level(hochberg_adjusted(pp))
    result['hommel'] = level(hommel_adjusted(pp))
    for suffix, weights in [('fixed',q),('ml',q_ml)]:
        result['weighted_holm_'+suffix] = level(holm_adjusted(pp,weights))
        path = selected_paths(weights,h)
        result['selected_global_path_'+suffix] = np.where(path,pp,0).max(1)
    cut = CutTest(h,H,dose)
    values = cut.evaluate(b,q)
    for key,value in zip(['joint_cut_fixed','joint_cut_unweighted',
                          'joint_sum_only','joint_atomic_only'],values):
        result[key] = value
    # A-only column; every connected object crosses it at an object site.
    column = np.log1p(-q_one).reshape(-1,h,h).sum(1).argmax(1)
    lower = tb*(2+6*np.diag(H))
    lowp = poisson.cdf(b,lower).reshape(-1,h,h)
    pd = lowp[np.arange(len(b))[:,None],np.arange(h)[None,:],column[:,None]].max(1)
    return result,pd,m_ml


class ExhaustiveSLRT:
    """Exact 4x4 null MLE and uniform-binary-prior predictive numerator."""
    def __init__(self,h: int,H: np.ndarray,dose: float):
        if h>4:
            raise ValueError('explicit enumeration restricted to h<=4')
        codes = np.arange(1<<(h*h),dtype=np.uint64)
        masks = ((codes[:,None]>>np.arange(h*h,dtype=np.uint64))&1).astype(float)
        self.connected = has_lr_connection(codes,h,h)
        self.rate = 2+6*(masks@H.T)
        self.a_mu = .2*dose*self.rate
        self.b_mu = .8*dose*self.rate
        self.la = np.log(self.a_mu).T.copy()
        self.lb = np.log(self.b_mu).T.copy()
        self.sa = self.a_mu.sum(1)
        self.sb = self.b_mu.sum(1)

    def evaluate(self,a: np.ndarray,b: np.ndarray,batch: int=32):
        out = np.empty(len(a))
        for lo in range(0,len(a),batch):
            hi = min(lo+batch,len(a))
            aa = a[lo:hi]@self.la-self.sa
            bb = b[lo:hi]@self.lb-self.sb
            log_predictive = logsumexp(aa+bb,axis=1)-logsumexp(aa,axis=1)
            denominator = bb[:,~self.connected].max(1)
            out[lo:hi] = log_predictive-denominator
        return out


def classify(conn: np.ndarray, disc: np.ndarray):
    return np.where(conn&~disc,1,np.where(disc&~conn,0,-1)).astype(np.int8)
