#!/usr/bin/env python3
"""Describe the frozen larger experiment; never changes its criteria."""
from __future__ import annotations
import json
import os
from pathlib import Path

HERE=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(HERE/'.matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def pp(v):return f'{100*v:+.3f}'
def ci(v):return f'[{pp(v[0])}; {pp(v[1])}]'


def main():
    final=json.loads((HERE/'RESULT.json').read_text())
    r6=json.loads((HERE/'RESULT_6.json').read_text())
    r4=json.loads((HERE/'RESULT_4.json').read_text())
    mismatch=json.loads((HERE/'MISMATCH.json').read_text())
    ready=json.loads((HERE/'data/READY.json').read_text())
    diagnostic=json.loads((HERE/'GEOMETRY_DIAGNOSTICS_6.json').read_text())
    controls=['pixel_bonferroni','holm','hochberg','hommel','weighted_holm_fixed',
              'selected_global_path_fixed','weighted_holm_ml','selected_global_path_ml']
    closest=r6['comparisons']['selected_global_path_fixed']
    exact_guard=r4['comparisons']['exact_bayes_slrt']['dose16_guards']['0.8']
    lines=['# Более крупная проверка теста минимальных разделителей',
           '',f"**Общий заранее зафиксированный критерий: {final['gate']}.**",
           f"Основная сетка 6×6: {r6['gate']}; отдельный точный контроль 4×4: {r4['gate']}.",
           '', 'Причины:', '',
           f"1. На 6×6 средний выигрыш над сильнейшим контролем положителен: "
           f"{pp(closest['difference_blur_average'])} п.п., 95% интервал {ci(closest['ci95'])}. "
           'Нижняя граница не превысила заданный до опыта практический порог +1 п.п.',
           f"2. На 4×4 при σ=0,8 и дозе 16 метод уступил точному контролю: "
           f"{pp(exact_guard['difference'])} п.п., 95% интервал {ci(exact_guard['ci95'])}. "
           'Критерий сохранения качества ≥−1 п.п. нарушен.',
           '', 'Метод даёт измеримый средний эффект, но заявленное преимущество '
           'с сохранением качества во всех зарегистрированных режимах не подтверждено. '
           'Положительный прежний опыт без размытия остаётся историческим результатом.',
           '', '## Что проверялось', '',
           'Новые исходные поля и уникальные геометрии того же открытого слоя M2 одного ИС. '
           'Входные отсчёты синтезированы по известному положительному оператору; '
           'это не новые реальные SEM-измерения. Связность геометрии не равна измеренной проводимости.',
           '',f"6×6: {r6['geometry_count']} геометрий из {r6['sourceframe_count']} кадров, "
           f"{r6['repeats']} шумовых повторов, {r6['observation_count']:,} наблюдений.",
           f"4×4: {r4['geometry_count']} геометрий из {r4['sourceframe_count']} кадров, "
           f"{r4['repeats']} повторов, {r4['observation_count']:,} наблюдений.",
           '', f"Для 6×6 режим отбора — `{ready['6']['mode']}`: совпадений "
           f"с прежними H/V-геометриями нет. Для 4×4 — `{ready['4']['mode']}`: "
           f"{ready['4']['old_shape_overlap_count']} из {r4['geometry_count']} форм уже встречались "
           'в старых данных, хотя исходные кадры новые. Поэтому точный 4×4 опыт '
           'проверяет механизм на новых измерениях и источниках, а не обобщение на новые формы.',
           '', 'Шесть доз × три уровня размытия. Основная метрика усредняет только '
           '12 условий с ненулевым размытием. Отказы от ответа остаются ошибками '
           'истинного класса. По дозам и режимам равные веса.',
           '', '## Основное сравнение 6×6', '',
           '| Метод | Macro-F1 при размытии, % | Новый тест минус контроль, п.п. | 95% интервал | Нижняя граница >1 п.п. |',
           '|---|---:|---:|---|---|',
           f"| **joint_cut_fixed** | **{100*r6['methods']['joint_cut_fixed']['blur_average_macro_f1']:.3f}** | — | — | — |"]
    for name in controls:
        comp=r6['comparisons'][name]
        lines.append(f"| {name} | {100*r6['methods'][name]['blur_average_macro_f1']:.3f} | "
                     f"{pp(comp['difference_blur_average'])} | {ci(comp['ci95'])} | "
                     f"{'PASS' if comp['lower_gt_1pp'] else 'FAIL'} |")
    lines+=['','Дополнительные абляции:','',
            '| Метод | Macro-F1 при размытии, % |','|---|---:|']
    for name in ['joint_cut_unweighted','joint_sum_only','joint_atomic_only']:
        lines.append(f"| {name} | {100*r6['methods'][name]['blur_average_macro_f1']:.3f} |")
    lines+=['','## Геометрический предел мощности','',
            'До генерации отсчётов рассчитан наихудший запас по всем разделителям '
            'для каждой связанной геометрии. Неположительный запас означает, что '
            'нет обещания надёжного подтверждения даже при росте дозы. Такие '
            'геометрии сохранены в оценке.','',
            '| σ | Положительный запас / все связанные геометрии |',
            '|---|---:|']
    for row in diagnostic['records']:
        lines.append(f"| {row['sigma']:g} | {row['positive_margin_count']}/{row['positive_count']} |")
    lines+=['','## Все режимы и отказы','',
            '| Размытие σ | Доза | Новый тест: Macro-F1, % | Доля определённых ответов, % |',
            '|---|---:|---:|---:|']
    for i,cell in enumerate(r6['cells']):
        mm=r6['methods']['joint_cut_fixed']
        lines.append(f"| {cell['sigma']:g} | {cell['dose']:g} | {100*mm['cell_macro_f1'][i]:.3f} | "
                     f"{100*mm['cell_coverage'][i]:.3f} |")
    lines+=['','## Сохранение качества при максимальной дозе','',
            'Требовалась нижняя граница разности ≥−1 п.п. отдельно при каждом σ, '
            'включая контроль без размытия.','',
            '| Контроль | σ | Разность, п.п. | 95% интервал | Критерий |',
            '|---|---:|---:|---|---|']
    for name in controls:
        for sigma,guard in r6['comparisons'][name]['dose16_guards'].items():
            lines.append(f"| {name} | {sigma} | {pp(guard['difference'])} | {ci(guard['ci95'])} | "
                         f"{'PASS' if guard['passed'] else 'FAIL'} |")
    exact=r4['comparisons']['exact_bayes_slrt']
    lines+=['','## Точный структурный контроль 4×4','',
            'Нормированный байесовский предиктивный числитель по A и точный максимум '
            'правдоподобия под нулём отсутствия связи по всем 65 536 маскам. '
            'Оператор размытия совпадает с генератором; прежний простой min-cut здесь не используется.',
            '',f"Новый тест: **{100*r4['methods']['joint_cut_fixed']['blur_average_macro_f1']:.3f}%**, "
            f"точный SLRT: **{100*r4['methods']['exact_bayes_slrt']['blur_average_macro_f1']:.3f}%**. "
            f"Разность **{pp(exact['difference_blur_average'])} п.п.**, "
            f"95% интервал **{ci(exact['ci95'])} п.п.**. "
            f"Требование положительной нижней границы: {'PASS' if exact['lower_gt_0'] else 'FAIL'}.",
            '', 'Однако обязательное сохранение качества при дозе 16 также '
            'проверялось отдельно при каждом σ:', '',
            '| σ | Новый тест минус точный SLRT, п.п. | 95% интервал | Критерий ≥−1 п.п. |',
            '|---|---:|---|---|']
    for sigma,guard in exact['dose16_guards'].items():
        lines.append(f"| {sigma} | {pp(guard['difference'])} | {ci(guard['ci95'])} | "
                     f"{'PASS' if guard['passed'] else 'FAIL'} |")
    lines+=[
            '', '## Вероятности ложных утверждений','',
            'Ниже сырые сертификаты основного метода до разрешения конфликтов. '
            'Конфликт двух сертификатов сохраняется как отказ. В JSON сохранены '
            'отдельные односторонние 95% границы Hoeffding для независимых шумовых '
            'реализаций при фиксированных геометриях. Вероятности разных геометрий '
            'могут различаться; биномиальные Clopper–Pearson числа в JSON приведены '
            'только справочно, без заявления покрытия для такой смеси. '
            'Теоретическая граница 2,5% относится '
            'к верной модели и одному истинному состоянию.',
            '', '| Сетка | σ | Доза | Ложное соединение / число | Ложный разрыв / число |',
            '|---|---:|---:|---:|---:|']
    for h,result in [(6,r6),(4,r4)]:
        for row in result['risk']:
            if row['method']=='joint_cut_fixed':
                lines.append(f"| {h}×{h} | {row['sigma']:g} | {row['dose']:g} | "
                             f"{row['false_conn']}/{row['n0']} | {row['false_disc']}/{row['n1']} |")
    lines+=['','## Ошибка знания размытия','',
            'Диагностический опыт: истинная σ на 20% больше принятой в тесте. '
            'Он не участвует в основном критерии; прежняя теоретическая гарантия '
            'на неверный оператор автоматически не переносится.','',
            '| Принятая σ | Истинная σ | Доза | Ложные соединения, % | Ложные разрывы, % |',
            '|---|---:|---:|---:|---:|']
    for row in mismatch['rows']:
        lines.append(f"| {row['assumed_sigma']:g} | {row['true_sigma']:g} | {row['dose']:g} | "
                     f"{100*row['false_conn_rate']:.3f} | {100*row['false_disc_rate']:.3f} |")
    lines+=['','## Ограничения и воспроизведение','',
            'Сцена конечная: Gaussian radius=1 с нормировкой строк внутри поля. '
            'Это явно заданная искусственная граница, не модель неизвестного окружения '
            'реального SEM. Контраст, фон и PSF известны. Все данные — один ИС; '
            'новые поля не заменяют независимые изделия/партии. Нейросеть не обучалась.',
            '',f"Численное время основного запуска: {final['elapsed_seconds']/60:.2f} мин. "
            'Подготовка данных, программирование и аудит в это число не включены.',
            '', 'Первый запуск остановился из-за ошибки передачи p-значения в '
            'булев классификатор до сохранения предсказаний и итоговых метрик. '
            'Он сохранён отдельно; исправление реализует прежний протокол с теми же seeds '
            'и прошло две интеграционные проверки. '
            '[Описание исправления](BUGFIX_BEFORE_RESULTS.md), [архив попытки](failed_attempt_1/run.log).',
            '', '[Зафиксированный протокол](FROZEN_PROTOCOL.md), '
            '[подготовка данных](data/README.md), [методы](psf_methods.py), '
            '[запуск](run_larger.py), [независимые фикстуры](VERIFICATION.json), '
            '[полные числа 6×6](RESULT_6.json), [полные числа 4×4](RESULT_4.json).',
            '', '[Независимый пересчёт итогового опыта](INDEPENDENT_RESULT_AUDIT_DESIGN_CONTEXT.md), '
            '[скрипт пересчёта](independent_audit_larger.py). '
            'Численный аудит пройден; отрицательный итог воспроизведён.',
            '', 'Групповые интервалы построены 4000 парными иерархическими '
            'пересэмплированиями «кадр → геометрия», со всеми повторами геометрии вместе. '
            'Это приближённые интервалы, не доказательство межиздельного переноса.']
    (HERE/'RESULT.md').write_text('\n'.join(lines)+'\n')
    fig,axes=plt.subplots(1,3,figsize=(14,4.2),sharey=True)
    selected=['joint_cut_fixed','selected_global_path_fixed','weighted_holm_ml','hommel']
    labels=['Тест разделителей','Выбранный путь, IUT','Holm с восстановлением по A','Hommel']
    for ax,sigma in zip(axes,[0.,.5,.8]):
        idx=[i for i,c in enumerate(r6['cells']) if c['sigma']==sigma]
        doses=[r6['cells'][i]['dose'] for i in idx]
        for key,label in zip(selected,labels):
            values=r6['methods'][key]['cell_macro_f1']
            ax.plot(doses,[100*values[i] for i in idx],marker='o',label=label)
        ax.set_xscale('log',base=2);ax.set_xticks(doses,[f'{v:g}' for v in doses])
        ax.set_title(f'σ = {sigma:g}');ax.set_xlabel('Относительная доза');ax.grid(alpha=.25)
        ax.set_ylim(-1,101)
    axes[0].set_ylabel('Macro-F1 с отказами, %');axes[0].legend(fontsize=8)
    fig.suptitle('Новые геометрии одного ИС; известный конечный оператор; синтетические отсчёты')
    fig.tight_layout()
    (HERE/'figures').mkdir(exist_ok=True)
    fig.savefig(HERE/'figures/larger_dose_curves.png',dpi=180)
    fig.savefig(HERE/'figures/larger_dose_curves.svg')
    fig4,axes4=plt.subplots(1,3,figsize=(14,4.2),sharey=True)
    for ax,sigma in zip(axes4,[0.,.5,.8]):
        idx=[i for i,c in enumerate(r4['cells']) if c['sigma']==sigma]
        doses=[r4['cells'][i]['dose'] for i in idx]
        for key,label in [('joint_cut_fixed','Тест разделителей'),('exact_bayes_slrt','Точный структурный SLRT')]:
            values=r4['methods'][key]['cell_macro_f1']
            ax.plot(doses,[100*values[i] for i in idx],marker='o',label=label)
        ax.set_xscale('log',base=2);ax.set_xticks(doses,[f'{v:g}' for v in doses])
        ax.set_title(f'σ = {sigma:g}');ax.set_xlabel('Относительная доза')
        ax.grid(alpha=.25);ax.set_ylim(-1,101)
    axes4[0].set_ylabel('Macro-F1 с отказами, %');axes4[0].legend(fontsize=8)
    fig4.suptitle('4×4: новые исходные кадры, ранее встречавшиеся формы; точный контроль по 65 536 маскам')
    fig4.tight_layout()
    fig4.savefig(HERE/'figures/exact4_dose_curves.png',dpi=180)
    fig4.savefig(HERE/'figures/exact4_dose_curves.svg')
    print(json.dumps({'report':str(HERE/'RESULT.md'),'gate':final['gate']}))


if __name__=='__main__':main()
