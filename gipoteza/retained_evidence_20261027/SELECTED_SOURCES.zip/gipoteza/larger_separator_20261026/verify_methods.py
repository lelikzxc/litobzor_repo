#!/usr/bin/env python3
"""Independent algorithmic fixtures; reads no real experiment/data files.

Writes only VERIFICATION.json beside this script. Fixed fictional count
vectors are implementation fixtures, not a predictive benchmark.
"""
from __future__ import annotations

import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import time

import numpy as np
from scipy.special import expit, gammaln, logsumexp
from scipy.stats import poisson

import psf_methods as tested

HERE = Path(__file__).resolve().parent


def connected(mask):
    h, w = mask.shape
    visited = {(r, 0) for r in range(h) if mask[r, 0]}
    queue = list(visited)
    for r, c in queue:
        if c == w-1:
            return True
        for rr, cc in [(r-1,c), (r+1,c), (r,c-1), (r,c+1)]:
            if 0 <= rr < h and 0 <= cc < w and mask[rr,cc] and (rr,cc) not in visited:
                visited.add((rr,cc))
                queue.append((rr,cc))
    return False


def masks(h):
    # Deliberately independent spelling from the tested bitboard code.
    return np.array(list(itertools.product((0,1), repeat=h*h)), dtype=np.int8)


def fictional_counts(n, p):
    index = np.arange(n*p).reshape(n,p)
    return ((index*7 + index//p*3 + 5) % 21).astype(np.int16)


def literal_cut_values(b, weights, H, dose, cut_masks):
    answer = np.zeros((4,len(b)))
    for cut in cut_masks:
        indices = np.flatnonzero(cut)
        # Explicit sums make H's detector/object direction unambiguous.
        cap = np.array([.8*dose*(2+6*sum(float(H[j,i]) for i in range(H.shape[1]) if not cut[i]))
                        for j in indices])
        pp = poisson.sf(b[:,indices]-1, cap[None,:])
        sums = b[:,indices].sum(1)
        ps = poisson.sf(sums-1, float(cap.sum()))
        atom = np.minimum(1, (pp/weights[:,indices]).min(1)*weights[:,indices].sum(1))
        atom_unweighted = np.minimum(1,pp.min(1)*len(indices))
        answer[0] = np.maximum(answer[0],np.minimum(1,np.minimum(2*atom,2*ps)))
        answer[1] = np.maximum(answer[1],np.minimum(1,np.minimum(2*atom_unweighted,2*ps)))
        answer[2] = np.maximum(answer[2],ps)
        answer[3] = np.maximum(answer[3],atom)
    return answer


def check_identity():
    h, dose = 6, 2.
    b = fictional_counts(16,h*h)
    weights = .001+.998*expit(np.sin(np.arange(16*h*h).reshape(16,h*h)))
    new = tested.CutTest(h,np.eye(h*h),dose).evaluate(b,weights)
    oldfile = (HERE.parent/'search_next_20261026/functional_observability/ep2/core_confirmation/run_core.py')
    spec = importlib.util.spec_from_file_location('_old_core_fixture_only',oldfile)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    old.progress = lambda stage: None  # Do not write old progress/results.
    family = tested.enumerate_minimal_cuts(h,h)
    prior = old.CutEvaluator(family).evaluate(b.reshape(16,h,h),weights.reshape(16,h,h),.8*dose)
    error = float(np.max(np.abs(new[:2]-prior)))
    assert error < 2e-13, error
    assert np.array_equal(tested.operator(6,0),np.eye(36))
    return {'draws':16,'cuts':len(family),'old_EP2_absolute_error':error,
            'old_module_import_writes':False}


def check_caps_and_tails():
    h, sigma, dose = 4, .6, 2.
    H = tested.operator(h,sigma)
    cut = tested.CutTest(h,H,dose)
    all_masks = masks(h)
    rates = .8*dose*(2+6*(all_masks@H.T))
    maximum_error = 0.
    maximum_violation = 0.
    independent_cap = []
    for k, K in enumerate(cut.K.astype(bool)):
        feasible = np.all(all_masks[:,K] == 0,axis=1)
        attained = rates[feasible].max(0)
        maximum_error = max(maximum_error,float(np.max(np.abs(attained-cut.cap[k]))))
        maximum_violation = max(maximum_violation,float(np.max(rates[feasible]-cut.cap[k])))
        all_outside = .8*dose*(2+6*(H@(~K).astype(float)))
        maximum_error = max(maximum_error,float(np.max(np.abs(all_outside-cut.cap[k]))))
        independent_cap.append(float(sum(cut.cap[k,j] for j in np.flatnonzero(K))))
    sum_error = float(np.max(np.abs(independent_cap-cut.sum_cap)))
    for i in range(h*h):
        conditional = all_masks[:,i] == 0
        upper = .8*dose*(2+6*(H[i].sum()-H[i,i]))
        maximum_error = max(maximum_error,abs(float(rates[conditional,i].max())-upper))
        lower = .8*dose*(2+6*H[i,i])
        maximum_error = max(maximum_error,abs(float(rates[~conditional,i].min())-lower))
    assert maximum_error < 1e-12
    assert maximum_violation < 1e-12
    assert sum_error < 1e-12
    assert np.max(np.abs(H-H.T)) > .01, 'fixture must detect transpose errors'
    assert np.max(np.abs(H.sum(1)-1)) < 1e-14
    b = fictional_counts(16,h*h)
    weights = .001+.998*expit(np.cos(np.arange(16*h*h).reshape(16,h*h)))
    batch = cut.evaluate(b,weights,batch=5)
    literal = literal_cut_values(b,weights,H,dose,cut.K.astype(bool))
    cut_error = float(np.max(np.abs(batch-literal)))
    assert cut_error < 1e-12, cut_error
    # Direct PMF summation catches off-by-one/sign errors in sf(k-1).
    tail_error = 0.
    for mu in [.1,2.,8.,12.8]:
        for k in [0,1,2,9,21]:
            lower = sum(math.exp(-mu)*mu**j/math.factorial(j) for j in range(k+1))
            upper = 1-sum(math.exp(-mu)*mu**j/math.factorial(j) for j in range(k))
            tail_error = max(tail_error,abs(lower-float(poisson.cdf(k,mu))),
                             abs(upper-float(poisson.sf(k-1,mu))))
    assert tail_error < 2e-14
    return {'all_binary_masks':len(all_masks),'all_cuts':len(cut.K),'sigma':sigma,
            'maximum_cap_or_attainment_error':maximum_error,'maximum_cap_violation':maximum_violation,
            'sum_cap_error':sum_error,'literal_cut_score_error':cut_error,'tail_direct_sum_error':tail_error,
            'operator_asymmetry':float(np.max(np.abs(H-H.T)))}


def check_paths_and_negative():
    h, dose = 6, 2.
    a = fictional_counts(16,h*h)
    b = fictional_counts(16,h*h)[:,::-1].copy()
    H = tested.operator(h,.7)
    q = .001+.998*expit(np.sin(np.arange(16*h*h).reshape(16,h*h)*.7))
    path = tested.selected_paths(q,h)
    for i in range(len(path)):
        assert connected(path[i].reshape(h,h))
        threshold = float(q[i,path[i]].min())
        # No strictly better bottleneck threshold may have a connection.
        better = (q[i] > threshold+1e-13).reshape(h,h)
        assert not connected(better)
    result,pd,_ = tested.scores(a,b,dose,H,h)
    q1 = expit(a*math.log(4)-1.2*dose)
    columns = np.log1p(-q1).reshape(-1,h,h).sum(1).argmax(1)
    manual = []
    for n,col in enumerate(columns):
        values = []
        for row in range(h):
            j = row*h+col
            lower = .8*dose*(2+6*H[j,j])
            values.append(float(poisson.cdf(int(b[n,j]),lower)))
        manual.append(max(values))
    error = float(np.max(np.abs(pd-manual)))
    assert error < 1e-12
    assert set(result) == set(tested.METHODS)
    assert all(np.all((p>=0)&(p<=1)) for p in result.values())
    # Explicit conflict/unknown fixture.
    called = tested.classify(np.array([False,False,True,True]),np.array([False,True,False,True]))
    assert np.array_equal(called,[-1,0,1,-1])
    return {'global_paths_checked':len(path),'all_paths_actual_4_connected':True,
            'all_paths_bottleneck_optimal':True,'negative_certificate_error':error,
            'score_names_match':True,'conflicts_remain_unknown':True}


def check_slrt():
    h, sigma, dose = 3, .6, 1.
    H = tested.operator(h,sigma)
    ex = tested.ExhaustiveSLRT(h,H,dose)
    m = masks(h)
    conn = np.array([connected(x.reshape(h,h)) for x in m])
    # Lexicographic order differs from tested bit-order enumeration.
    rates = np.array([[2+6*sum(float(H[j,i])*int(mask[i]) for i in range(h*h))
                       for j in range(h*h)] for mask in m])
    a = fictional_counts(8,h*h)%4
    b = fictional_counts(8,h*h)%7
    batch = ex.evaluate(a,b,batch=3)
    manual = []
    numerator_error = 0.
    denom_margin = float('inf')
    for aa,bb in zip(a,b):
        log_a = np.array([sum(int(aa[j])*math.log(.2*dose*r[j])-.2*dose*r[j]
                            for j in range(h*h)) for r in rates])
        log_b = np.array([sum(int(bb[j])*math.log(.8*dose*r[j])-.8*dose*r[j]
                            for j in range(h*h)) for r in rates])
        # Independent posterior weights, then weighted predictive density.
        posterior = np.exp(log_a-logsumexp(log_a))
        shift = float(log_b.max())
        predictive = math.log(float(np.dot(posterior,np.exp(log_b-shift))))+shift
        stable_predictive = float(logsumexp(log_a+log_b)-logsumexp(log_a))
        numerator_error = max(numerator_error,abs(predictive-stable_predictive))
        denominator = float(log_b[~conn].max())
        denom_margin = min(denom_margin,float(np.min(denominator-log_b[~conn])))
        manual.append(predictive-denominator)
    error = float(np.max(np.abs(batch-manual)))
    assert error < 1e-11
    assert numerator_error < 1e-11
    assert denom_margin >= -1e-12

    # Exact finite-state integration on a tiny grid. This is not a predictive
    # benchmark: it checks the normalized conditional density/e-value proof.
    tiny_h, tiny_dose = 2,.25
    tiny_H = tested.operator(tiny_h,.6)
    tiny = tested.ExhaustiveSLRT(tiny_h,tiny_H,tiny_dose)
    mm = masks(tiny_h)
    cc = np.array([connected(x.reshape(2,2)) for x in mm])
    mu = .8*tiny_dose*(2+6*(mm@tiny_H.T))
    b_vectors = np.array(list(itertools.product(range(13),repeat=4)),dtype=np.int16)
    factorial = gammaln(b_vectors+1).sum(1)
    loglik = b_vectors@np.log(mu).T-mu.sum(1)-factorial[:,None]
    denominator = loglik[:,~cc].max(1)
    max_expectation = 0.
    max_reject_probability = 0.
    maximum_tail_bound = 0.
    for aa in [np.array([0,0,0,0]),np.array([0,1,2,3]),np.array([3,0,3,0])]:
        a_mu = .2*tiny_dose*(2+6*(mm@tiny_H.T))
        wa = aa@np.log(a_mu).T-a_mu.sum(1)
        wa -= logsumexp(wa)
        log_predictive = logsumexp(loglik+wa[None,:],axis=1)
        log_e = log_predictive-denominator
        for j in np.flatnonzero(~cc):
            truth_mass = np.exp(loglik[:,j])
            expectation = float(np.dot(truth_mass,np.exp(log_e)))
            risk = float(truth_mass[log_e>=math.log(1/tested.ALPHA)].sum())
            remainder = float(poisson.sf(12,mu[j]).sum())
            max_expectation = max(max_expectation,expectation)
            max_reject_probability = max(max_reject_probability,risk+remainder)
            maximum_tail_bound = max(maximum_tail_bound,remainder)
        # The same truncation law must agree with the tested implementation.
        chosen = np.array([0,1,500,10000,len(b_vectors)-1])
        tested_log_e = tiny.evaluate(np.repeat(aa[None,:],len(chosen),axis=0),b_vectors[chosen])
        assert np.max(np.abs(tested_log_e-log_e[chosen])) < 1e-11
    assert max_expectation <= 1+1e-12
    assert max_reject_probability <= tested.ALPHA+1e-12
    return {'manual_grid':h,'manual_masks':len(m),'manual_count_vectors':len(a),
            'scalar_vs_batch_log_e_error':error,'Bayesian_predictive_numerator_error':numerator_error,
            'null_denominator_minimum_margin':denom_margin,'integrated_grid':tiny_h,
            'integrated_count_vectors':len(b_vectors),'integrated_A_vectors':3,
            'max_truncated_e_expectation_under_null':max_expectation,
            'max_rejection_probability_plus_tail_bound':max_reject_probability,
            'maximum_omitted_probability_bound':maximum_tail_bound}


def main():
    start = time.perf_counter()
    result = {'scope':'fixed fictional implementation fixtures; no predictive benchmark or real data',
              'status':'RUNNING',
              'source_sha256':hashlib.sha256((HERE/'psf_methods.py').read_bytes()).hexdigest(),
              'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    try:
        result['identity_EP2'] = check_identity()
        result['caps_and_tails'] = check_caps_and_tails()
        result['paths_and_negative'] = check_paths_and_negative()
        result['SLRT_and_predictive_density'] = check_slrt()
        result['status'] = 'PASS'
    except BaseException as exc:
        result.update(status='FAIL',error_type=type(exc).__name__,message=str(exc))
        raise
    finally:
        result['elapsed_seconds'] = time.perf_counter()-start
        (HERE/'VERIFICATION.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
        print(json.dumps(result,indent=2,ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
