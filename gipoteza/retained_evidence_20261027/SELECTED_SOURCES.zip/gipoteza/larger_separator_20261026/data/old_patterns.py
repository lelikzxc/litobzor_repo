"""Canonical ALL sliding subpatterns of previously used realSEM masks."""
from pathlib import Path
import hashlib,json,time
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
SOURCES=[ROOT/f"gipoteza/search_20261026/{n}/PATCHES.npz" for n in ["sem_electrical","sem_replication","sem_graded_test"]]
SOURCES+=[ROOT/"gipoteza/longer_20261026/holdout/PATCHES.npz"]

def encode(windows):
    a=np.asarray(windows,dtype=bool);side=a.shape[-1]
    assert a.shape[-2]==side and side*side<=63
    powers=np.left_shift(np.uint64(1),np.arange(side*side,dtype=np.uint64))
    return np.sum(a.reshape(-1,side*side).astype(np.uint64)*powers,axis=1,dtype=np.uint64).reshape(a.shape[:-2])

def canonical_codes(windows):
    a=np.asarray(windows,dtype=bool)
    views=(a,a[...,::-1,:],a[...,:,::-1],a[...,::-1,::-1])
    return np.minimum.reduce([encode(v) for v in views])

def decode(code,side):
    return ((np.uint64(code)>>np.arange(side*side,dtype=np.uint64))&np.uint64(1)).astype(bool).reshape(side,side)

def connectivity_codes(codes,side):
    codes=np.asarray(codes,dtype=np.uint64)
    full=np.uint64((1<<(side*side))-1)
    left=np.uint64(sum(1<<(r*side) for r in range(side)));right=left<<np.uint64(side-1)
    reached=codes&left
    for _ in range(side*side):
        adj=(((reached<<np.uint64(1))&~left)|((reached>>np.uint64(1))&~right)
             |(reached<<np.uint64(side))|(reached>>np.uint64(side)))&full
        update=reached|(adj&codes)
        if np.array_equal(update,reached):break
        reached=update
    return ((reached&right)!=0).astype(np.int8)

def main():
    start=time.monotonic();seen={4:set(),6:set()};records=[]
    for path in SOURCES:
        z=np.load(path);masks=z['Y'];assert masks.dtype==bool and masks.shape[1:]==(12,12)
        for lo in range(0,len(masks),256):
            batch=masks[lo:lo+256]
            for side in [4,6]:
                windows=np.lib.stride_tricks.sliding_window_view(batch,(side,side),axis=(-2,-1))
                codes=canonical_codes(windows)
                seen[side].update(np.unique(codes).tolist())
        records.append({'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
             'mask_shape':list(masks.shape),'frames':np.unique(z['frame']).tolist(),
             'cumulative_unique4':len(seen[4]),'cumulative_unique6':len(seen[6])})
        print(json.dumps(records[-1]),flush=True)
    arrays={f'codes{s}':np.asarray(sorted(seen[s]),dtype=np.uint64) for s in [4,6]}
    np.savez_compressed(HERE/'OLD_PATTERN_CODES.npz',**arrays)
    result={'complete':True,'sources':records,'encoding':'row-majorLSB,uint64;minoverI,H,V,HV',
            'scope':'ALLsliding4x4and6x6insideALLpreviousrealSEM12x12Y;strongerthanquadrants',
            'unique_counts':{str(s):len(seen[s]) for s in [4,6]},
            'codes_sha256':{str(s):hashlib.sha256(arrays[f'codes{s}'].astype('<u8').tobytes()).hexdigest() for s in [4,6]},
            'seconds':time.monotonic()-start,'statistical_scores_created':False}
    (HERE/'OLD_PATTERN_INVENTORY.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)

if __name__=='__main__':main()
