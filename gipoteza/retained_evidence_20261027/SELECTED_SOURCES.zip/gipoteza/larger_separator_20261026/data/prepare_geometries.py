"""SVG geometry/class preparation only. Never creates predictive scores."""
from pathlib import Path
import hashlib,json,re,time,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw
from old_patterns import encode,canonical_codes,decode,connectivity_codes

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,v):
    p=HERE/name;t=p.with_suffix(p.suffix+".tmp");t.write_text(json.dumps(v,indent=2,ensure_ascii=False));t.replace(p)

def rasterize(path):
    root=ET.parse(path);attrs=root.getroot().attrib
    assert attrs.get('width')=='4096' and attrs.get('height')=='3536'
    canvas=Image.new('L',(4096,3536));draw=ImageDraw.Draw(canvas);paths=0
    for element in root.iter():
        assert 'transform' not in element.attrib
        if not element.tag.endswith('}path'):continue
        data=element.attrib['d'];assert set(re.findall('[A-Za-z]',data))<={'M','L','Z','z'} and data.count('M')==1
        points=[(int(x),int(y)) for x,y in re.findall(r'[ML](-?\d+),(-?\d+) ',data)]
        assert len(points)>=3
        draw.polygon(points,fill=1);paths+=1
    mask=np.asarray(canvas)[512:-512,512:-512]
    h,w=mask.shape;assert(h,w)==(2512,3072)
    reduced=mask.reshape(h//4,4,w//4,4).mean(axis=(1,3))>=.5
    assert reduced.shape==(628,768)
    return reduced,paths

def tiles(mask,side):
    nr,nc=mask.shape[0]//side,mask.shape[1]//side
    value=mask[:nr*side,:nc*side].reshape(nr,side,nc,side).transpose(0,2,1,3).reshape(-1,side,side)
    return value,nc

def audit_old_pipeline():
    path=ROOT/'gipoteza/longer_20261026/holdout/newdata/dataset/labels/m2/label0198.svg'
    mask,_=rasterize(path)
    olddir=ROOT/'gipoteza/longer_20261026/holdout';old=np.load(olddir/'PATCHES.npz')
    mf=json.loads((olddir/'MANIFEST.json').read_text());checked=0
    for i,item in enumerate(mf):
        if item['frame']!=198:continue
        y=(item['y']-512)//4;x=(item['x']-512)//4
        assert np.array_equal(mask[y:y+12,x:x+12],old['Y'][i])
        checked+=1
    assert checked>0
    # Encoding has an independent packbits check and H/V label invariance.
    rng=np.random.default_rng(261026401)
    for side in [4,6]:
        x=rng.integers(0,2,(32,side,side)).astype(bool);codes=encode(x)
        for a,c in zip(x,codes):
            assert int(c)==int.from_bytes(np.packbits(a.ravel(),bitorder='little').tobytes(),'little')
            assert np.array_equal(decode(c,side),a)
        assert np.array_equal(connectivity_codes(codes,side),connectivity_codes(canonical_codes(x),side))
    return {'status':'PASS','old_frame':198,'exact_old_Y12_patches_matched':checked,
            'encoding_packbits_roundtrip_cases':64,'canonical_HV_class_invariance_cases':64,
            'pipeline':'rasterMLZ;crop512;block4mean>=.5','no_new_predictive_scores':True}

def selection_id(frame,side,y,x):
    item={'source_frame':int(frame),'phase':'M2','side':int(side),'down_y':int(y),'down_x':int(x)}
    return hashlib.sha256(json.dumps(item,sort_keys=True).encode()).hexdigest()

def choose(queues,per_class):
    order=sorted(queues,key=lambda f:hashlib.sha256(f'larger_separator_20261026/frame/{f}'.encode()).hexdigest())
    selected=[];used=set()
    for label in [0,1]:
        positions={f:0 for f in order};picked=0
        while picked<per_class:
            progress=False
            for frame in order:
                q=queues[frame][label]
                while positions[frame]<len(q) and q[positions[frame]]['canonical_code'] in used:positions[frame]+=1
                if positions[frame]==len(q):continue
                record=q[positions[frame]];positions[frame]+=1
                selected.append(record);used.add(record['canonical_code']);picked+=1;progress=True
                if picked==per_class:break
            if not progress:raise AssertionError('Pool count and roundrobin availability disagree')
    return selected

def write_dataset(side,selected,oldcodes,mode,available):
    masks=np.stack([decode(r['raw_code'],side) for r in selected]) if selected else np.zeros((0,side,side),bool)
    truth=np.asarray([r['label'] for r in selected],dtype=np.int8);frames=np.asarray([r['frame'] for r in selected],dtype=int)
    canonical=canonical_codes(masks) if len(masks) else np.array([],dtype=np.uint64)
    assert len(np.unique(canonical))==len(masks)
    assert np.array_equal(connectivity_codes(encode(masks),side),truth)
    overlap=int(sum(int(c) in oldcodes for c in canonical))
    if mode=='strict_shape_fresh':assert overlap==0
    np.savez_compressed(HERE/f'GEOMETRIES_{side}.npz',M=masks,truth=truth,frame=frames,canonical_code=canonical)
    result={'status':'READY' if len(selected)>0 else 'DATA_NOT_READY','side':side,'mode':mode,
          'geometry_count':len(selected),'class_counts':np.bincount(truth,minlength=2).tolist(),
          'unique_HV':len(np.unique(canonical)),'old_shape_overlap_count':overlap,
          'strict_fresh_pool_by_class':available,'selected':selected,
          'selected_sourceframes':{str(f):int((frames==f).sum()) for f in np.unique(frames)},
          'sourceframes_new_vs_all_used_authorframes':True,'new_IC':False,
          'SVG_derived_geometry_not_new_raw_SEM_measurements':True,'predictive_scores_created':False,
          'geometry_npz_sha256':sha(HERE/f'GEOMETRIES_{side}.npz')}
    save(f'SELECTION_{side}.json',result);return result

def main():
    start=time.monotonic()
    assert not(HERE/'GEOMETRIES_6.npz').exists(),'Refuse to overwrite prepared geometry selection'
    remote=json.loads((HERE/'REMOTE_SELECTION.json').read_text());download=json.loads((HERE/'DOWNLOAD.json').read_text())
    assert download['complete'] and download['frames']==remote['frames']
    assert not set(remote['frames'])&set(remote['excluded_frames'])
    for r in download['files']:assert sha(HERE/'sources'/r['name'])==r['sha256']
    frozen=[Path(__file__),HERE/'DATA_PROTOCOL.md',HERE/'old_patterns.py',HERE/'OLD_PATTERN_CODES.npz',
            HERE/'OLD_PATTERN_INVENTORY.json',HERE/'REMOTE_SELECTION.json',HERE/'DOWNLOAD.json']
    frozenhash={str(p.relative_to(ROOT)):sha(p) for p in frozen};save('PREPARE_FROZEN.json',frozenhash)
    verification=audit_old_pipeline();save('PIPELINE_VERIFICATION.json',verification)
    old=np.load(HERE/'OLD_PATTERN_CODES.npz');oldsets={s:set(old[f'codes{s}'].tolist()) for s in [4,6]}
    queues={s:{} for s in [4,6]};strict={s:{} for s in [4,6]};global_all={s:set() for s in [4,6]};global_new={s:set() for s in [4,6]}
    per_frame={}
    for frame in remote['frames']:
        svg=HERE/f'sources/dataset/labels/m2/label{frame:04}.svg';mask,path_count=rasterize(svg)
        stats={'svg_paths':path_count}
        for side in [4,6]:
            array,nc=tiles(mask,side);raw=encode(array);canonical=canonical_codes(array)
            unique,idx=np.unique(canonical,return_index=True);labels=connectivity_codes(unique,side)
            groups=[[],[]];newgroups=[[],[]]
            for code,index,label in zip(unique,idx,labels):
                y=(int(index)//nc)*side;x=(int(index)%nc)*side
                record={'frame':int(frame),'phase':'M2','side':side,'down_y':y,'down_x':x,
                   'native_y':512+4*y,'native_x':512+4*x,'native_patch_side':4*side,
                   'source_svg':str(svg.relative_to(HERE)),'id_sha256':selection_id(frame,side,y,x),
                   'raw_code':int(raw[index]),'canonical_code':int(code),'label':int(label),
                   'shape_seen_in_old_subpatterns':int(code) in oldsets[side]}
                groups[int(label)].append(record);global_all[side].add(int(code))
                if int(code) not in oldsets[side]:newgroups[int(label)].append(record);global_new[side].add(int(code))
            for group in groups+newgroups:group.sort(key=lambda r:r['id_sha256'])
            queues[side][frame]=groups;strict[side][frame]=newgroups
            stats[str(side)]={'frame_unique_total':len(unique),'frame_unique_by_class':np.bincount(labels,minlength=2).tolist(),
                              'strict_new_by_class':[len(g) for g in newgroups]}
        per_frame[str(frame)]=stats
        if len(per_frame)%25==0:
            summary={'completed_frames':len(per_frame),'total_frames':len(remote['frames']),
                     'strict_new_unique6':len(global_new[6]),'strict_new_unique4':len(global_new[4]),'seconds':time.monotonic()-start}
            save('PREPARE_PROGRESS.json',summary);print(json.dumps(summary),flush=True)
    availability={s:np.bincount(connectivity_codes(np.asarray(sorted(global_new[s]),dtype=np.uint64),s),minlength=2).tolist() for s in [4,6]}
    all_availability={s:np.bincount(connectivity_codes(np.asarray(sorted(global_all[s]),dtype=np.uint64),s),minlength=2).tolist() for s in [4,6]}
    save('POOL_BEFORE_SELECTION.json',{'strict_new_pool_by_class':availability,'all_new_source_pattern_pool_by_class':all_availability,
        'per_frame':per_frame,'no_predictive_scores':True,'all275sourceframes_used_for_inventory':True})
    n6=min(512,*availability[6]);chosen6=choose(strict[6],n6) if n6>=256 else []
    result6=write_dataset(6,chosen6,oldsets[6],'strict_shape_fresh',availability[6])
    n4=min(64,*availability[4])
    if n4>=32:chosen4=choose(strict[4],n4);mode4='strict_shape_fresh'
    else:
        n4=min(64,*all_availability[4]);chosen4=choose(queues[4],n4) if n4>=32 else []
        mode4='source_fresh_shape_not_necessarily_new'
    result4=write_dataset(4,chosen4,oldsets[4],mode4,availability[4])
    assert all(sha(ROOT/p)==h for p,h in frozenhash.items())
    result={'complete':True,'stage':'GEOMETRY_ONLY','new_source_frame_count':len(remote['frames']),
       'old_source_frames_excluded':remote['excluded_frames'],'strict_new_pool_by_class':availability,
       'all_new_source_pattern_pool_by_class':all_availability,
       '6':{k:v for k,v in result6.items() if k not in ['selected','selected_sourceframes']},
       '4':{k:v for k,v in result4.items() if k not in ['selected','selected_sourceframes']},
       'source_is_one_original_IC_M2':True,'new_real_SEM_intensities_downloaded':False,
       'new_Poisson_counts_or_predictive_scores_created':False,'pipeline_verification':verification,
       'seconds':time.monotonic()-start}
    save('READY.json',result);print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
