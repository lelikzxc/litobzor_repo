"""Freeze unused author M2 frame IDs and download SVG labels only."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from urllib.request import Request,urlopen
import io,json,hashlib,re,struct,time,zipfile,zlib

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
URL="https://edmond.mpg.de/api/access/datafile/223856";SIZE=6396523974
OLD=ROOT/"gipoteza/search_20261026"
MANIFESTS=[OLD/n/"MANIFEST.json" for n in ["sem_electrical","sem_replication","sem_graded_test"]]
MANIFESTS+=[ROOT/"gipoteza/longer_20261026/holdout/MANIFEST.json"]

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):
    p=HERE/name;t=p.with_suffix(p.suffix+".tmp");t.write_text(json.dumps(v,indent=2,ensure_ascii=False));t.replace(p)

class RemoteZip(io.RawIOBase):
    def __init__(self):self.pos=0
    def seekable(self):return True
    def readable(self):return True
    def tell(self):return self.pos
    def seek(self,offset,whence=0):
        self.pos=offset if whence==0 else self.pos+offset if whence==1 else SIZE+offset
        if self.pos<0:raise ValueError("negative offset")
        return self.pos
    def read(self,n=-1):
        if n<0:n=SIZE-self.pos
        n=min(n,SIZE-self.pos)
        if n<=0:return b""
        assert n<=25_000_000
        req=Request(URL,headers={"Range":f"bytes={self.pos}-{self.pos+n-1}"})
        with urlopen(req,timeout=90) as response:
            cr=response.headers.get("Content-Range","")
            assert response.status==206 and cr==f"bytes {self.pos}-{self.pos+n-1}/{SIZE}",(response.status,cr)
            raw=response.read(n+1)
        assert len(raw)==n
        self.pos+=n;return raw

def freeze():
    listingpath=OLD/"sem_zip_listing.json";listing=json.loads(listingpath.read_text());byname={r["name"]:r for r in listing}
    used=set(range(10))
    for p in MANIFESTS:used.update(int(r["frame"]) for r in json.loads(p.read_text()))
    available=[]
    for name in byname:
        match=re.fullmatch(r"dataset/sems/m2/sem(\d+)\.png",name)
        if match and f"dataset/labels/m2/label{int(match.group(1)):04}.svg" in byname:
            available.append(int(match.group(1)))
    frames=sorted(set(available)-used)
    assert len(available)==321 and len(used)==46 and len(frames)==275
    names=[f"dataset/labels/m2/label{f:04}.svg" for f in frames]+["dataset/README"]
    rows=[byname[n] for n in names]
    assert sum(r["size"] for r in rows)<41_000_000
    selection={"source_url":URL,"persistent_id":"doi:10.17617/3.HY5SYN","license":"CC-BY4.0",
       "phase":"M2","available_pair_count":len(available),"excluded_frames":sorted(used),"frames":frames,
       "rule":"ALLunusedM2SEM/SVGpairs; noselectionbyimagesorstatisticaloutcomes",
       "download_kind":"SVGlabelsandREADMEonly; SEMPNGsnotdownloaded","members":rows,
       "selected_total_bytes":sum(r["size"] for r in rows)}
    if (HERE/"REMOTE_SELECTION.json").exists():assert json.loads((HERE/"REMOTE_SELECTION.json").read_text())==selection
    else:save("REMOTE_SELECTION.json",selection)
    files=[Path(__file__),HERE/"DATA_PROTOCOL.md",listingpath,*MANIFESTS,HERE/"REMOTE_SELECTION.json"]
    frozen={str(p.relative_to(ROOT)):digest(p) for p in files}
    if (HERE/"REMOTE_FROZEN.json").exists():assert json.loads((HERE/"REMOTE_FROZEN.json").read_text())==frozen
    else:save("REMOTE_FROZEN.json",frozen)
    print(json.dumps({"stage":"275NEW_SOURCE_IDS_FROZEN","download_bytes":selection["selected_total_bytes"]}),flush=True)
    return selection,frozen

def fetch(info):
    assert info.compress_type==0,"ExpectedstoredZIPmember"
    path=Path(info.filename);assert not path.is_absolute() and ".." not in path.parts
    dest=HERE/"sources"/path
    if dest.exists():raw=dest.read_bytes()
    else:
        for attempt in range(3):
            try:
                remote=RemoteZip();remote.seek(info.header_offset)
                size=min(30+len(info.filename.encode())+2048+info.file_size,SIZE-info.header_offset)
                block=remote.read(size);header=struct.unpack("<4s5H3L2H",block[:30]);assert header[0]==b"PK\x03\x04"
                nn,ne=header[-2:];assert block[30:30+nn].decode()==info.filename
                raw=block[30+nn+ne:30+nn+ne+info.file_size]
                assert len(raw)==info.file_size and zlib.crc32(raw)==info.CRC
                break
            except Exception:
                if attempt==2:raise
        dest.parent.mkdir(parents=True,exist_ok=True);tmp=dest.with_suffix(dest.suffix+".part");tmp.write_bytes(raw);tmp.replace(dest)
    assert len(raw)==info.file_size and zlib.crc32(raw)==info.CRC
    return {"name":info.filename,"bytes":len(raw),"crc32":info.CRC,"sha256":hashlib.sha256(raw).hexdigest()}

def main():
    start=time.monotonic();chosen,frozen=freeze()
    with zipfile.ZipFile(RemoteZip()) as archive:
        infos=[archive.getinfo(r["name"]) for r in chosen["members"]]
    for row,info in zip(chosen["members"],infos):assert row["offset"]==info.header_offset and row["size"]==info.file_size
    records=[]
    try:
        with ThreadPoolExecutor(max_workers=6) as pool:
            futures=[pool.submit(fetch,i) for i in infos]
            for f in as_completed(futures):
                records.append(f.result())
                save("DOWNLOAD_PROGRESS.json",{"completed":len(records),"total":len(infos),"seconds":time.monotonic()-start})
                if len(records)%25==0:print(json.dumps({"completed":len(records),"total":len(infos),"seconds":time.monotonic()-start}),flush=True)
    except Exception as e:
        save("DOWNLOAD_ERROR.json",{"error":repr(e),"downloaded":records,"seconds":time.monotonic()-start});raise
    assert all(digest(ROOT/p)==h for p,h in frozen.items())
    result={"complete":True,"files":sorted(records,key=lambda r:r["name"]),"frames":chosen["frames"],"source_url":URL,
       "source_id":"doi:10.17617/3.HY5SYN","license":"CC-BY4.0","total_bytes":sum(r["bytes"] for r in records),
       "SEM_images_downloaded":False,"new_statistical_scores":False,"seconds":time.monotonic()-start}
    save("DOWNLOAD.json",result);print(json.dumps({k:v for k,v in result.items() if k not in ["files","frames"]}),flush=True)

if __name__=="__main__":main()
