#!/usr/bin/env python3
"""Integration-only verification of p_disc -> bool conversion; no dataset."""
import hashlib
import json
from pathlib import Path
import time

import numpy as np

import psf_methods as methods
import run_larger as runner

HERE = Path(__file__).resolve().parent


def main():
    started = time.perf_counter()
    cases = []
    for h in (4, 6):
        # Manually specified detector count fixtures; no true class or M,
        # no fitted model, no generated experiment outcomes, no F1 scores.
        positions = np.arange(4*h*h).reshape(4, h*h)
        a = (positions % 11).astype(np.int16)
        b = ((positions*3+1) % 19).astype(np.int16)
        H = methods.operator(h, .5)
        scores, disc_p, _ = methods.scores(a, b, 2., H, h)
        assert disc_p.dtype.kind == 'f' and np.all((disc_p >= 0) & (disc_p <= 1))
        disc = disc_p <= runner.ALPHA
        assert disc.dtype == bool
        for name, score in scores.items():
            conn = score <= runner.ALPHA
            calls = methods.classify(conn, disc)
            expected = np.array([1 if c and not d else 0 if d and not c else -1
                                 for c, d in zip(conn, disc)], dtype=np.int8)
            assert np.array_equal(calls, expected)
        if h == 4:
            log_e = methods.ExhaustiveSLRT(h, H, 2.).evaluate(a, b)
            calls = methods.classify(log_e >= np.log(40), disc)
            assert calls.dtype == np.int8 and set(calls).issubset({-1, 0, 1})
        cases.append({'h': h, 'fixture_count_vectors': 4,
                      'all_method_classification_paths_execute': True,
                      'disc_p_retained_as_float': True, 'disc_certificate_is_bool': True})
    boundary = np.array([0, .025, .0250000001, 1.])
    assert np.array_equal(boundary <= runner.ALPHA, [True, True, False, False])
    conn = np.array([False, False, True, True])
    disc = np.array([False, True, False, True])
    assert np.array_equal(methods.classify(conn, disc), [-1, 0, 1, -1])
    result = {'status': 'PASS', 'scope': 'deterministic integration fixtures only; no dataset, true class, predictive metric, or training',
              'bugfix': 'disc=disc_p<=0.025; saved field retains original float p_disc',
              'cases': cases, 'threshold_boundary_fixture': True,
              'all_four_certificate_combinations': True,
              'sha256': {f: hashlib.sha256((HERE/f).read_bytes()).hexdigest()
                         for f in ['run_larger.py', 'psf_methods.py', 'FROZEN_PROTOCOL.md', Path(__file__).name]},
              'elapsed_seconds': time.perf_counter()-started}
    (HERE/'BUGFIX_INTEGRATION_REVIEW.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
