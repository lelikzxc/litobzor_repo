#!/usr/bin/env python3
"""Exercise runner wiring with stubbed p-values, not a predictive study."""
import hashlib
import json
import tempfile
import time
from pathlib import Path

import numpy as np
import run_larger as runner


def main():
    root=Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='integration_fixture_',dir=root) as name:
        folder=Path(name)
        data=folder/'data';data.mkdir()
        masks=np.zeros((2,6,6),dtype=bool);masks[1,2,:]=True
        np.savez(data/'GEOMETRIES_6.npz',M=masks,truth=np.array([0,1]),frame=np.array([901,902]))
        runner.HERE=folder;runner.DATA=data;runner.REPEATS={6:1}
        runner.SIGMAS=[0.];runner.DOSES=[1.];runner.START=time.monotonic()
        def stub_scores(a,b,dose,H,h):
            # Both certs for first scene => unknown; only connection for
            # second scene => class1. p_disc must remain float in storage.
            return {key:np.full(2,.01) for key in runner.methods.METHODS},np.array([.01,.8]),np.zeros_like(a)
        runner.methods.scores=stub_scores
        def assert_summary(h,counts,pred,names,truth,frames,cells,risk):
            assert pred.shape==(1,12,2,1)
            assert np.all(pred[0,:,0,0]==-1)
            assert np.all(pred[0,:,1,0]==1)
            assert all(row['conflicts']==1 for row in risk)
            assert np.allclose(runner.f1(counts.sum(2)),.5)
            return {'gate':'FIXTURE_ONLY','not_predictive':True}
        runner.summarize=assert_summary
        result=runner.run_grid(6)
        saved=np.load(folder/'grid6/sigma0_dose1.npz')
        assert np.array_equal(saved['disc_p'],np.array([[.01],[.8]]))
        assert saved['disc_p'].dtype.kind=='f'
        assert result['not_predictive']
    out={'status':'PASS','scope':'stub p-value integration; no actual predictive outcomes',
         'checks':['negative threshold applied before classify','conflicts remain unknown',
                   'actual p_disc stored without thresholding','unknown metric included'],
         'run_larger_sha256':hashlib.sha256((root/'run_larger.py').read_bytes()).hexdigest()}
    (root/'INTEGRATION_VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))


if __name__=='__main__':main()
