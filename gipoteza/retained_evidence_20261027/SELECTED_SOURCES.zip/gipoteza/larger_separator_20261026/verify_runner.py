#!/usr/bin/env python3
"""Geometry, unknown-aware metric, bootstrap tensor fixtures; no real data.

Writes RUNNER_VERIFICATION.json only. Importing run_larger does not run it.
"""
from __future__ import annotations

import hashlib
import inspect
import json
from pathlib import Path
import time

import numpy as np
from sklearn.metrics import f1_score

import run_larger as tested
from cut_family import (enumerate_minimal_cuts, verify_exhaustive_4x4,
                        verify_family_minimality)

HERE = Path(__file__).resolve().parent


def check_metrics():
    truth = np.array([0,1]*8,dtype=np.int8)
    index = np.arange(5*16*9).reshape(5,16,9)
    pred = ((index*7+index//9)%3-1).astype(np.int8)
    pred[0] = -1
    pred[1] = truth[:,None]
    pred[2] = 1-truth[:,None]
    counts = tested.metric_counts(truth,pred)
    own = np.zeros_like(counts)
    for method in range(len(pred)):
        for geometry,y in enumerate(truth):
            for call in pred[method,geometry]:
                for label in (0,1):
                    if y == label and call == label:
                        own[method,geometry,3*label] += 1
                    elif y != label and call == label:
                        own[method,geometry,3*label+1] += 1
                    elif y == label and call != label:
                        own[method,geometry,3*label+2] += 1
    assert np.array_equal(counts,own)
    values = tested.f1(counts.sum(1))
    reference = np.array([f1_score(np.repeat(truth,9),p.ravel(),labels=[0,1],
                                   average='macro',zero_division=0) for p in pred])
    error = float(np.max(np.abs(values-reference)))
    assert error < 1e-14
    assert values[0] == 0 and values[1] == 1 and values[2] == 0
    return counts, {'geometry_count':16,'fixed_methods':5,'repeats':9,
                    'literal_TP_FP_FN_match':True,'sklearn_macro_F1_max_error':error,
                    'all_unknown_F1':float(values[0]),'all_correct_F1':float(values[1]),
                    'all_wrong_F1':float(values[2])}


def check_bootstrap(counts):
    frames = np.array([3,3,7,9,9,9,12,12,15,18,18,18,20,20,20,20])
    seed = 261027606
    weights = tested.bootstrap_weights(frames,seed)
    repeat = tested.bootstrap_weights(frames,seed)
    assert np.array_equal(weights,repeat)
    rng = np.random.default_rng(seed)
    frame_ids = sorted(set(map(int,frames)))
    literal = np.zeros_like(weights)
    for b in range(tested.BOOTSTRAPS):
        frequency = rng.multinomial(len(frame_ids),[1/len(frame_ids)]*len(frame_ids))
        for frame,n in zip(frame_ids,frequency):
            rows = np.array([j for j,f in enumerate(frames) if f == frame])
            if n:
                sample = rng.multinomial(int(n)*len(rows),[1/len(rows)]*len(rows))
                literal[b,rows] = sample
    assert np.array_equal(weights,literal)
    assert np.all(weights>=0) and np.all(weights==np.floor(weights))
    # Three fictional cells with deliberately different method counts.
    cell_counts = np.stack([counts,counts[:,::-1],counts*2])
    batched = np.tensordot(weights,cell_counts,axes=(1,2))
    assert batched.shape == (tested.BOOTSTRAPS,3,5,6)
    error = 0.
    f1_error = 0.
    for i in [0,1,10,63,tested.BOOTSTRAPS-1]:
        selected = np.repeat(np.arange(len(frames)),weights[i].astype(int))
        manual = cell_counts[:,:,selected,:].sum(2)
        error = max(error,float(np.max(np.abs(batched[i]-manual))))
        expected = []
        for c in range(3):
            v=[]
            for m in range(5):
                pieces=[]
                for offset in (0,3):
                    tp,fp,fn=map(float,manual[c,m,offset:offset+3])
                    pieces.append(2*tp/(2*tp+fp+fn) if (2*tp+fp+fn) else 0.)
                v.append(sum(pieces)/2)
            expected.append(v)
        f1_error=max(f1_error,float(np.max(np.abs(tested.f1(batched[i])-expected))))
    assert error == 0 and f1_error < 1e-14
    return {'repeats':tested.BOOTSTRAPS,'seed':seed,'frame_groups':len(frame_ids),
            'fixed_geometry_count':len(frames),'deterministic_seed_match':True,
            'independent_multinomial_weight_match':True,
            'tensor_shape':list(batched.shape),'literal_resampling_tensor_error':error,
            'literal_resampling_F1_error':f1_error,
            'interpretation':'frame resampling then within-frame geometry; all noise repeats remain grouped',
            'caveat':'approximate group bootstrap, no independent-device or simultaneous-CI guarantee'}


def main():
    start=time.perf_counter()
    result={'status':'RUNNING','passed':False,
            'scope':'algorithmic fixtures and exhaustive tiny-grid geometry; no real data/outcomes',
            'runner_sha256_at_fixture':hashlib.sha256((HERE/'run_larger.py').read_bytes()).hexdigest(),
            'tested_function_sha256':{name:hashlib.sha256(inspect.getsource(getattr(tested,name)).encode()).hexdigest()
                                     for name in ['metric_counts','f1','bootstrap_weights']},
            'verification_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    try:
        result['complete4x4']=verify_exhaustive_4x4(enumerate_minimal_cuts(4,4))
        result['minimality6x6']=verify_family_minimality(enumerate_minimal_cuts(6,6),6,6)
        counts,result['unknown_aware_metrics']=check_metrics()
        result['bootstrap_tensor']=check_bootstrap(counts)
        result.update(status='PASS',passed=True)
    except BaseException as exc:
        result.update(status='FAIL',passed=False,error_type=type(exc).__name__,message=str(exc))
        raise
    finally:
        result['elapsed_seconds']=time.perf_counter()-start
        (HERE/'RUNNER_VERIFICATION.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
        print(json.dumps(result,indent=2,ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
