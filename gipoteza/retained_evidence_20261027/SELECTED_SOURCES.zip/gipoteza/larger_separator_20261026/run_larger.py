#!/usr/bin/env python3
"""Frozen larger PSF-aware finite-scene check, preserving all older studies."""
from __future__ import annotations

import hashlib
import json
import platform
import time
from pathlib import Path

import numpy as np
import scipy
from scipy.stats import beta

import psf_methods as methods

HERE = Path(__file__).resolve().parent
DATA = HERE/'data'
SIGMAS = [0.,.5,.8]
DOSES = [.5,1.,2.,4.,8.,16.]
ALPHA = .025
REPEATS = {6:32,4:16}
BOOTSTRAPS = 4000
START = None


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    dest = HERE/name
    temp = dest.with_suffix(dest.suffix+'.tmp')
    temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    temp.replace(dest)


def progress(stage, **extra):
    row = dict(stage=stage,elapsed_seconds=time.monotonic()-START,complete=False,**extra)
    save('PROGRESS.json',row)
    print(json.dumps(row,ensure_ascii=False),flush=True)


def metric_counts(truth,pred):
    # pred [method,geometry,repeat]; abstention is FN for its true class.
    out = np.zeros(pred.shape[:2]+(6,),dtype=np.int32)
    for label in (0,1):
        actual = truth[None,:,None]==label
        called = pred==label
        out[:,:,3*label] = (actual&called).sum(-1)
        out[:,:,3*label+1] = (~actual&called).sum(-1)
        out[:,:,3*label+2] = (actual&~called).sum(-1)
    return out


def f1(counts):
    pieces=[]
    for j in (0,3):
        den=2*counts[...,j]+counts[...,j+1]+counts[...,j+2]
        pieces.append(np.divide(2*counts[...,j],den,
                      out=np.zeros_like(den,dtype=float),where=den!=0))
    return (pieces[0]+pieces[1])/2


def cp_upper(k,n):
    return 1. if k==n else float(beta.ppf(.95,k+1,n-k))


def geometry_diagnostics(h):
    """Asymptotic margins, computed before counts; never filter scenes."""
    data=np.load(DATA/f'GEOMETRIES_{h}.npz')
    masks=data['M'].reshape(-1,h*h).astype(float)
    truth=data['truth']
    positive=masks[truth==1]
    records=[];stored={}
    for sigma in SIGMAS:
        model=np.load(HERE/f'MODEL_{h}_sigma{sigma:g}.npz')
        H=model['H'];K=model['K'];length=K.sum(1)
        cap=(model['cap_per_exposure']-2)/6
        indices=np.full((len(K),int(length.max())),h*h,int)
        for j,row in enumerate(K):
            selected=np.flatnonzero(row)
            indices[j,:len(selected)]=selected
        cap_pad=np.concatenate([cap,np.zeros((len(K),1))],axis=1)
        selected_cap=np.take_along_axis(cap_pad,indices,axis=1)
        all_gamma=[];all_sum=[]
        for lo in range(0,len(positive),32):
            z=positive[lo:lo+32]@H.T
            zpad=np.concatenate([z,np.zeros((len(z),1))],axis=1)
            difference=zpad[:,indices]-selected_cap[None,:,:]
            difference=np.where(indices[None,:,:]!=h*h,difference,-np.inf)
            atomic=difference.max(2)
            summation=(z@K.T-(cap*K).sum(1))/length
            all_gamma.extend(np.minimum.reduce(np.maximum(atomic,summation),axis=1).tolist())
            all_sum.extend(summation.min(1).tolist())
        gamma=np.array(all_gamma)
        stored[f'gamma_sigma{sigma:g}']=gamma
        stored[f'sum_margin_sigma{sigma:g}']=np.array(all_sum)
        records.append(dict(sigma=sigma,positive_count=len(gamma),
                            positive_margin_count=int((gamma>1e-12).sum()),
                            fraction_positive_margin=float((gamma>1e-12).mean()),
                            quantiles=np.quantile(gamma,[0,.1,.5,.9,1]).tolist()))
    bits=np.left_shift(np.uint64(1),np.arange(h*h,dtype=np.uint64))
    negative=masks[truth==0].astype(np.uint64)
    codes=(negative*bits).sum(1,dtype=np.uint64)
    added=codes[:,None]|bits[None,:]
    almost=methods.has_lr_connection(added.ravel(),h,h).reshape(len(negative),h*h).any(1)
    np.savez_compressed(HERE/f'GEOMETRY_DIAGNOSTICS_{h}.npz',positive_indices=np.flatnonzero(truth==1),**stored)
    save(f'GEOMETRY_DIAGNOSTICS_{h}.json',dict(h=h,before_counts=True,not_used_for_filtering=True,
         positive_count=int((truth==1).sum()),negative_count=int((truth==0).sum()),
         one_pixel_from_connection_negative_count=int(almost.sum()),records=records))


def bootstrap_weights(frames,seed):
    rng = np.random.default_rng(seed)
    unique = np.unique(frames)
    groups = [np.flatnonzero(frames==frame) for frame in unique]
    result = np.zeros((BOOTSTRAPS,len(frames)),dtype=np.float64)
    for b in range(BOOTSTRAPS):
        frame_mult = rng.multinomial(len(unique),np.full(len(unique),1/len(unique)))
        for n,indices in zip(frame_mult,groups):
            if n:
                draws = rng.multinomial(int(n)*len(indices),np.full(len(indices),1/len(indices)))
                result[b,indices] = draws
    return result


def summarize(h,counts,pred,names,truth,frames,cells,risk):
    point = f1(counts.sum(2))
    primary_cells = np.array([c['sigma']>0 for c in cells])
    mean = point[primary_cells].mean(0)
    weights = bootstrap_weights(frames,261027600+h)
    sampled = np.tensordot(weights,counts,axes=(1,2)) # boot,cell,method,6
    boot_values = f1(sampled)
    boot_mean = boot_values[:,primary_cells,:].mean(1)
    comparisons={}
    for j,name in enumerate(names[1:],1):
        delta = boot_mean[:,0]-boot_mean[:,j]
        ci = np.quantile(delta,[.025,.975])
        guards={}
        for sigma in SIGMAS:
            idx=next(i for i,c in enumerate(cells) if c['sigma']==sigma and c['dose']==16)
            interval=np.quantile(boot_values[:,idx,0]-boot_values[:,idx,j],[.025,.975])
            guards[str(sigma)]={'difference':float(point[idx,0]-point[idx,j]),
                                'ci95':interval.tolist(),'passed':bool(interval[0]>=-.01)}
        comparisons[name]={'difference_blur_average':float(mean[0]-mean[j]),
                           'ci95':ci.tolist(),'lower_gt_1pp':bool(ci[0]>.01),
                           'lower_gt_0':bool(ci[0]>0),'dose16_guards':guards}
    # Descriptive sensitivity analysis: geometry-only resampling does not
    # turn correlated source fields into independent devices.
    grng=np.random.default_rng(261027700+h)
    gweights=grng.multinomial(len(frames),np.full(len(frames),1/len(frames)),size=BOOTSTRAPS).astype(float)
    gvalues=f1(np.tensordot(gweights,counts,axes=(1,2)))[:,primary_cells,:].mean(1)
    for j,name in enumerate(names[1:],1):
        comparisons[name]['geometry_only_ci95']=np.quantile(gvalues[:,0]-gvalues[:,j],[.025,.975]).tolist()
    primary_risk=[v for v in risk if v['method']=='joint_cut_fixed']
    risk_pass=all(v['false_conn_rate']<=ALPHA and v['false_disc_rate']<=ALPHA for v in primary_risk)
    if h==6:
        comp_pass=all(comparisons[m]['lower_gt_1pp'] and
                      all(g['passed'] for g in comparisons[m]['dose16_guards'].values())
                      for m in methods.CONTROLS)
    else:
        entry=comparisons['exact_bayes_slrt']
        comp_pass=entry['lower_gt_0'] and all(g['passed'] for g in entry['dose16_guards'].values())
    # This is approximate, paired, frame/geometry hierarchical bootstrap;
    # the source IC is singular and acquisition overlap is not a lot split.
    return dict(h=h,gate='PASS' if comp_pass and risk_pass else 'FAIL',
                comparison_gate=bool(comp_pass),empirical_risk_gate=bool(risk_pass),
                geometry_count=len(truth),sourceframe_count=len(np.unique(frames)),
                repeats=REPEATS[h],observation_count=len(cells)*len(truth)*REPEATS[h],
                primary_cells='12 sigma>0 cells; equal weight; sigma0 reference only',
                methods={name:{'blur_average_macro_f1':float(mean[j]),
                         'cell_macro_f1':point[:,j].tolist(),
                         'sigma_average_macro_f1':{str(sigma):float(point[[i for i,c in enumerate(cells) if c['sigma']==sigma],j].mean()) for sigma in SIGMAS},
                         'cell_coverage':[(pred[i,j]!=-1).mean().item() for i in range(len(cells))],
                         'cell_class_recall':[[float((pred[i,j,truth==label]==label).mean()) for label in (0,1)] for i in range(len(cells))],
                         'cell_confusion_true_0_1_pred_unknown_0_1':[[[int((pred[i,j,truth==label]==called).sum()) for called in (-1,0,1)] for label in (0,1)] for i in range(len(cells))]}
                         for j,name in enumerate(names)},
                comparisons=comparisons,cells=cells,risk=risk,
                bootstrap={'repeats':BOOTSTRAPS,'seed':261027600+h,
                           'secondary_geometry_only_seed':261027700+h,
                           'unit':'sourceframe then geometry; all noise repeats stay together',
                           'coverage':'approximate individual intervals, not independent-device evidence'})


def run_grid(h):
    data=np.load(DATA/f'GEOMETRIES_{h}.npz')
    M=data['M'].astype(float);truth=data['truth'];frames=data['frame']
    names=methods.METHODS+(['exact_bayes_slrt'] if h==4 else [])
    preds=[];all_counts=[];risk=[];cells=[]
    ra=np.random.default_rng(261027100+h)
    rb=np.random.default_rng(261027200+h)
    for sigma in SIGMAS:
        H=methods.operator(h,sigma)
        rate=2+6*(M.reshape(-1,h*h)@H.T)
        for dose in DOSES:
            cell={'sigma':sigma,'dose':dose}
            cell_index=len(cells)
            progress(f'{h}x{h}_sigma{sigma:g}_dose{dose:g}_counts',cell=cell_index,total_cells=18)
            a=ra.poisson(.2*dose*rate[:,None,:],size=(len(M),REPEATS[h],h*h)).astype(np.int16)
            b=rb.poisson(.8*dose*rate[:,None,:],size=(len(M),REPEATS[h],h*h)).astype(np.int16)
            aa=a.reshape(-1,h*h);bb=b.reshape(-1,h*h)
            progress(f'{h}x{h}_sigma{sigma:g}_dose{dose:g}_methods',cell=cell_index,total_cells=18)
            scores,disc_p,_=methods.scores(aa,bb,dose,H,h)
            disc=disc_p<=ALPHA
            conn={key:score<=ALPHA for key,score in scores.items()}
            if h==4:
                progress(f'4x4_sigma{sigma:g}_dose{dose:g}_exact65536_SLRT',cell=cell_index,total_cells=18)
                loge=methods.ExhaustiveSLRT(h,H,dose).evaluate(aa,bb)
                conn['exact_bayes_slrt']=loge>=np.log(1/ALPHA)
                scores['exact_bayes_slrt']=loge
            pred=np.stack([methods.classify(conn[name],disc) for name in names]).reshape(len(names),len(M),REPEATS[h])
            preds.append(pred);all_counts.append(metric_counts(truth,pred));cells.append(cell)
            disc_by=disc.reshape(len(M),REPEATS[h])
            for j,name in enumerate(names):
                con=conn[name].reshape(len(M),REPEATS[h])
                n0=int((truth==0).sum()*REPEATS[h]);n1=int((truth==1).sum()*REPEATS[h])
                fc=int(con[truth==0].sum());fd=int(disc_by[truth==1].sum())
                risk.append(dict(**cell,method=name,false_conn=fc,false_disc=fd,n0=n0,n1=n1,
                       false_conn_rate=fc/n0,false_disc_rate=fd/n1,
                       false_conn_binomial_CP_reference95=cp_upper(fc,n0),
                       false_disc_binomial_CP_reference95=cp_upper(fd,n1),
                       false_conn_Hoeffding_upper95=min(1.,fc/n0+np.sqrt(np.log(20)/(2*n0))),
                       false_disc_Hoeffding_upper95=min(1.,fd/n1+np.sqrt(np.log(20)/(2*n1))),
                       final_false_conn=int((pred[j,truth==0]==1).sum()),
                       final_false_disc=int((pred[j,truth==1]==0).sum()),
                       conflicts=int((con&disc_by).sum())))
            savepath=HERE/f'grid{h}'
            savepath.mkdir(exist_ok=True)
            np.savez_compressed(savepath/f'sigma{sigma:g}_dose{dose:g}.npz',
                    A=a,B=b,predictions=pred,disc_p=disc_p.reshape(len(M),REPEATS[h]),
                    method=np.array(names),**{'score__'+name:scores[name].reshape(len(M),REPEATS[h]) for name in names})
            progress(f'{h}x{h}_sigma{sigma:g}_dose{dose:g}_saved',cell=cell_index+1,total_cells=18)
    pred=np.stack(preds);counts=np.stack(all_counts)
    np.savez_compressed(HERE/f'PREDICTIONS_{h}.npz',predictions=pred,counts=counts,
                        truth=truth,frame=frames,method=np.array(names))
    progress(f'{h}x{h}_hierarchical_bootstrap')
    result=summarize(h,counts,pred,names,truth,frames,cells,risk)
    save(f'RESULT_{h}.json',result)
    progress(f'{h}x{h}_complete',gate=result['gate'])
    return result


def run_mismatch():
    data=np.load(DATA/'GEOMETRIES_6.npz');M=data['M'].astype(float);truth=data['truth']
    ra=np.random.default_rng(261027901);rb=np.random.default_rng(261027902)
    rows=[]
    for assumed in [.5,.8]:
        H_assumed=methods.operator(6,assumed);H_true=methods.operator(6,1.2*assumed)
        rate=2+6*(M.reshape(-1,36)@H_true.T)
        for dose in [4.,16.]:
            progress(f'mismatch_true{1.2*assumed:g}_assumed{assumed:g}_dose{dose:g}')
            a=ra.poisson(.2*dose*rate[:,None,:],size=(len(M),16,36)).astype(np.int16)
            b=rb.poisson(.8*dose*rate[:,None,:],size=(len(M),16,36)).astype(np.int16)
            # Only the frozen primary is needed for this diagnostic, not
            # predictive re-selection or another primary hypothesis test.
            q,q_one,_,_=methods.proposal(a.reshape(-1,36),dose,H_assumed)
            score=methods.CutTest(6,H_assumed,dose).evaluate(b.reshape(-1,36),q)[0]
            raw=score.reshape(len(M),16)<=ALPHA
            fc=int(raw[truth==0].sum());n0=int((truth==0).sum()*16)
            column=np.log1p(-q_one).reshape(-1,6,6).sum(1).argmax(1)
            lower=.8*dose*(2+6*np.diag(H_assumed))
            lowp=methods.poisson.cdf(b.reshape(-1,36),lower).reshape(-1,6,6)
            pd=lowp[np.arange(len(q))[:,None],np.arange(6)[None,:],column[:,None]].max(1)
            disc=pd.reshape(len(M),16)<=ALPHA
            fd=int(disc[truth==1].sum());n1=int((truth==1).sum()*16)
            rows.append(dict(assumed_sigma=assumed,true_sigma=1.2*assumed,dose=dose,
                             false_conn=fc,n0=n0,false_conn_rate=fc/n0,
                             false_conn_Hoeffding_upper95=min(1.,fc/n0+np.sqrt(np.log(20)/(2*n0))),
                             false_disc=fd,n1=n1,false_disc_rate=fd/n1,
                             false_disc_Hoeffding_upper95=min(1.,fd/n1+np.sqrt(np.log(20)/(2*n1))),
                             final_false_conn=int((raw[truth==0]&~disc[truth==0]).sum()),
                             final_false_disc=int((disc[truth==1]&~raw[truth==1]).sum()),
                             conflicts=int((raw&disc).sum()),
                             validity_guarantee=False))
            np.savez_compressed(HERE/f'mismatch_assumed{assumed:g}_dose{dose:g}.npz',
                                A=a,B=b,score=score,disc_p=pd)
    save('MISMATCH.json',{'diagnostic_only':True,'outside_model_guarantee':True,'rows':rows})


def main():
    global START
    START=time.monotonic()
    if (HERE/'RESULT.json').exists():
        raise FileExistsError('preserve the completed result; use independent audit for verification')
    verification=json.loads((HERE/'VERIFICATION.json').read_text())
    if verification.get('status')!='PASS':
        raise AssertionError('independent method fixtures have not passed')
    if verification['source_sha256']!=sha(HERE/'psf_methods.py'):
        raise AssertionError('method implementation changed after fixtures')
    if json.loads((HERE/'RUNNER_VERIFICATION.json').read_text()).get('status')!='PASS':
        raise AssertionError('runner/family/metric fixtures have not passed')
    if json.loads((HERE/'INTEGRATION_VERIFICATION.json').read_text()).get('status')!='PASS':
        raise AssertionError('p-value/boolean runner integration has not passed')
    required=[HERE/'FROZEN_PROTOCOL.md',HERE/'psf_methods.py',Path(__file__),HERE/'VERIFICATION.json',
              HERE/'verify_methods.py',HERE/'verify_runner.py',HERE/'RUNNER_VERIFICATION.json',
              HERE/'verify_integration.py',HERE/'INTEGRATION_VERIFICATION.json',
              HERE/'BUGFIX_BEFORE_RESULTS.md',
              DATA/'GEOMETRIES_6.npz',DATA/'GEOMETRIES_4.npz']
    # Include all frozen selection/preparation metadata and old input code.
    required+=sorted(DATA.glob('*.json'))+sorted(DATA.glob('*.py'))
    required+=[methods.OLD/'ep2/probe'/p for p in ['controls.py','cut_family.py']]
    required+=[methods.OLD/'ep2/core_confirmation/hommel.py']
    required+=[methods.OLD/'probe'/p for p in ['run_probe.py','slrt_oracle.py']]
    for h in [6,4]:
        for sigma in SIGMAS:
            H=methods.operator(h,sigma)
            unit=methods.CutTest(h,H,1.25) # t_B=1: caps scale by actual exposure.
            dest=HERE/f'MODEL_{h}_sigma{sigma:g}.npz'
            np.savez_compressed(dest,H=H,K=unit.K,cap_per_exposure=unit.cap,
                                sum_cap_per_exposure=unit.sum_cap)
            required.append(dest)
        geometry_diagnostics(h)
        required+=[HERE/f'GEOMETRY_DIAGNOSTICS_{h}.json',HERE/f'GEOMETRY_DIAGNOSTICS_{h}.npz']
    frozen={str(p.relative_to(HERE.parent.parent)):sha(p) for p in required}
    save('RUN_FROZEN.json',{'sha256':frozen,'written_before_counts':True,
                          'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    save('ENVIRONMENT.json',dict(python=platform.python_version(),numpy=np.__version__,
                               scipy=scipy.__version__,platform=platform.platform(),backend='CPU',
                               neural_training=False))
    progress('frozen_before_counts')
    r6=run_grid(6)
    r4=run_grid(4)
    run_mismatch()
    for path,value in frozen.items():
        if sha(HERE.parent.parent/path)!=value:
            raise AssertionError(f'frozen input changed: {path}')
    result=dict(complete=True,gate='PASS' if r6['gate']=='PASS' and r4['gate']=='PASS' else 'FAIL',
                grid6_gate=r6['gate'],grid4_exact_control_gate=r4['gate'],
                elapsed_seconds=time.monotonic()-START,
                neural_training=False,real_raw_SEM_measurements=False,
                scope='known finite-scene Poisson forward operator; new same-IC SVG geometry; no device transfer')
    save('RESULT.json',result)
    save('PROGRESS.json',dict(result,stage='complete'))
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    try:
        main()
    except BaseException as exc:
        if START is not None:
            save('ERROR.json',dict(type=type(exc).__name__,message=str(exc),elapsed_seconds=time.monotonic()-START))
        raise
