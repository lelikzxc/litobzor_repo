"""Independent CPU audit of completed longer-E14 results; never trains/infers.

All classification scores are recomputed from stored class predictions; every
stored IoU is recomputed from all144bits of the saved segmentation. A fixed
deterministic subset additionally checks electrical classes with the frozen
binary solver. No evaluation starts before both COMPLETE and RESULT exist.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time

import numpy as np
from sklearn.metrics import f1_score
import torch

HERE = Path(__file__).resolve().parent
OLD = HERE.parent/'search_20261026'
VALIDATION = HERE.parent/'validation_20261026'
sys.path.insert(0, str(OLD))
import sem_joint_development as dev

METHODS = ['base', 'replay', 'strong_soft', 'connectivity', 'joint']
TRAIN_METHODS = METHODS[1:]
SEEDS = [611, 683, 751, 823, 907, 977, 1061, 1151]
STAGES = ['fixed400', 'fixed2000', 'val_selected']
SOURCES = dict(fresh=HERE/'holdout/PATCHES.npz', old_E14=OLD/'sem_graded_test/PATCHES.npz',
               refics=VALIDATION/'transfer_result/PATCHES.npz')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(actual, expected, name):
    np.testing.assert_allclose(actual, expected, atol=1e-12, rtol=0, err_msg=name)


def macro(cm):
    values = []
    for c in range(9):
        tp = cm[..., c, c]
        den = cm[..., c, :].sum(-1)+cm[..., :, c].sum(-1)
        values.append(np.divide(2*tp, den, out=np.zeros_like(tp, dtype=float), where=den>0))
    return np.stack(values, axis=-1).mean(-1)


def independent_confusion(truth, pred, group):
    groups = np.unique(group)
    cm = np.zeros((5, 8, len(groups), 9, 9), np.int64)
    for j in range(5):
        for s in range(8):
            for k, g in enumerate(groups):
                ids = group==g
                cm[j, s, k] = np.bincount(9*truth[ids]+pred[j,s,ids], minlength=81).reshape(9,9)
    return cm


def independent_bootstrap(cm):
    """Group multiplicities and seed multiplicities, no advanced-index reuse."""
    rng = np.random.default_rng(260026)
    ng = cm.shape[2]
    seeds = np.empty((4000,8), np.int64); groups = np.empty((4000,ng), np.int64)
    for b in range(4000):
        seeds[b] = np.bincount(rng.integers(0,8,8), minlength=8)
        groups[b] = np.bincount(rng.integers(0,ng,ng), minlength=ng)
    samples = []
    for start in range(0,4000,250):
        pooled = np.einsum('msgab,tg->tmsab', cm, groups[start:start+250], optimize=True)
        per_seed = macro(pooled)
        samples.append(np.einsum('tms,ts->tm', per_seed, seeds[start:start+250])/8)
    return np.concatenate(samples)


def checkpoint_stage(method, seed, stage, selected):
    if method=='base':
        return HERE/f'training/final_base_{seed}.pt'
    step = 400 if stage=='fixed400' else 2000 if stage=='fixed2000' else selected[method]
    return HERE/f'training/final_{method}_{seed}_{step}.pt'


def verify_selection():
    rows = read(HERE/'training/VAL_ROWS.json')
    selection = read(HERE/'training/SELECTION.json')
    assert selection['primary_step']==2000
    selected = {}
    for method in TRAIN_METHODS:
        choices = []
        for step in [400,1000,2000]:
            rr = [r for r in rows if r['phase']=='development' and r['method']==method and r['step']==step]
            assert sorted(r['seed'] for r in rr)==[17,41]
            choices.append(dict(method=method, step=step, f1=float(np.mean([r['f1'] for r in rr])),
                                iou=float(np.mean([r['iou'] for r in rr]))))
        expected = min(choices, key=lambda r:(-r['f1'],-r['iou'],r['step']))
        assert selection['selected'][method]==expected
        selected[method]=expected['step']
    return selected


def verify_frozen():
    paths = ['training/FROZEN.json','training/MODEL_HASHES.json','evaluation/FROZEN.json',
             'holdout/PREPARE_FROZEN.json','holdout/REMOTE_FROZEN.json','holdout/FROZEN.json']
    seen = {}; counts = {}
    for rel in paths:
        record = read(HERE/rel)
        for name, expected in record.items():
            p = Path(name)
            if name not in seen:
                seen[name] = sha(p)
            assert seen[name]==expected, (rel,name)
        counts[rel] = len(record)
    return counts, seen


def check_physics(packed, predictions, sample_ids, cache):
    new = {}
    for encoded in packed[sample_ids]:
        key = encoded.tobytes()
        if key not in cache:
            new[key] = encoded
    if new:
        keys = list(new)
        masks = np.unpackbits(np.array([new[k] for k in keys]), axis=-1, count=144).reshape(-1,12,12).astype(bool)
        labels = dev.classes(masks)
        cache.update({k:int(c) for k,c in zip(keys,labels)})
    actual = np.array([cache[row.tobytes()] for row in packed[sample_ids]], dtype=np.int8)
    assert np.array_equal(actual,predictions[sample_ids])


def audit():
    started = time.monotonic()
    assert (HERE/'training/COMPLETE.json').exists()
    assert (HERE/'evaluation/RESULT.json').exists()
    torch.set_num_threads(2)
    complete = read(HERE/'training/COMPLETE.json')
    assert complete['final_seeds']==SEEDS and complete['primary_steps']==2000
    assert complete['methods']==TRAIN_METHODS and complete['total_steps']==83200
    result = read(HERE/'evaluation/RESULT.json')
    assert result['seeds']==SEEDS and result['methods']==METHODS
    assert result['primary_dataset']=='fresh' and result['primary_stage']=='fixed2000'
    assert result['bootstrap_draws']==4000 and result['bootstrap_seed']==260026
    frozen_counts, frozen = verify_frozen()
    selected = verify_selection()
    assert selected==result['secondary_steps']
    model_hashes = read(HERE/'training/MODEL_HASHES.json')
    assert len(model_hashes)==complete['checkpoints']==130
    for phase, phase_seeds in [('development',[17,41]),('final',SEEDS)]:
        for seed in phase_seeds:
            expected = [HERE/f'training/{phase}_base_{seed}.pt']
            expected.extend(HERE/f'training/{phase}_{m}_{seed}_{step}.pt' for m in TRAIN_METHODS for step in [400,1000,2000])
            assert all(str(p) in model_hashes for p in expected)
    checkpoint_routes = {}
    for stage in STAGES:
        checkpoint_routes[stage] = {}
        for method in METHODS:
            files = [checkpoint_stage(method,s,stage,selected) for s in SEEDS]
            assert all(str(p) in model_hashes for p in files)
            checkpoint_routes[stage][method] = [p.name for p in files]
    output_inputs = [HERE/'evaluation/RESULT.json', *[HERE/f'evaluation/{d}_{s}.npz' for d in SOURCES for s in STAGES]]
    own_frozen = {str(p):sha(p) for p in [Path(__file__),*output_inputs]}
    physics_cache = {}; physics_examples = 0; metrics_checked = 0; datasets = {}; all_boots = {}
    for dataset, source in SOURCES.items():
        z = np.load(source); truth = z['truth']; y = z['Y'].astype(bool)
        group = z['uid_index'] if dataset=='refics' else z['frame']
        assert np.array_equal(dev.classes(y),truth)
        domains = dict(pooled=np.ones(len(y),bool))
        if dataset=='fresh':
            diag = np.load(HERE/'holdout/D4_DIAGNOSTIC.npz')
            assert np.array_equal(diag['truth'],truth) and np.array_equal(diag['frame'],group)
            domains['no_old_D4'] = ~diag['old_related']
        if dataset=='refics':
            domains.update({str(n):z['node_nm']==n for n in [32,90]})
        all_boots[dataset] = {}; datasets[dataset] = {}
        stage_arrays = {}
        for stage in STAGES:
            saved = np.load(HERE/f'evaluation/{dataset}_{stage}.npz')
            pred, stored_iou, packed = saved['prediction'], saved['iou'], saved['masks_packed']
            assert pred.shape==(5,8,len(y)) and stored_iou.shape==pred.shape
            assert packed.shape==(5,8,len(y),18) and packed.dtype==np.uint8
            assert np.array_equal(saved['truth'],truth) and np.array_equal(saved['group'],group)
            assert saved['methods'].tolist()==METHODS and saved['seeds'].tolist()==SEEDS
            assert ((pred>=0)&(pred<9)).all()
            sample_n = 384 if dataset=='fresh' and stage=='fixed2000' else 64
            sample_ids = np.linspace(0,len(y)-1,min(sample_n,len(y)),dtype=int)
            for j in range(5):
                for s in range(8):
                    hard = np.unpackbits(packed[j,s],axis=-1,count=144).reshape(-1,12,12).astype(bool)
                    inter = (hard&y).sum((1,2)); union = (hard|y).sum((1,2))
                    actual_iou = np.divide(inter,union,out=np.ones(len(y)),where=union>0)
                    assert np.array_equal(actual_iou,stored_iou[j,s])
                    check_physics(packed[j,s],pred[j,s],sample_ids,physics_cache)
                    physics_examples += len(sample_ids)
            all_boots[dataset][stage] = {}; datasets[dataset][stage] = {}
            for domain, ids in domains.items():
                actual_cm = independent_confusion(truth[ids],pred[:,:,ids],group[ids])
                assert np.array_equal(actual_cm,saved['confusion_'+domain])
                report = result['results'][dataset][stage][domain]
                assert report['examples']==int(ids.sum()) and report['groups']==len(np.unique(group[ids]))
                assert report['class_counts']==np.bincount(truth[ids],minlength=9).tolist()
                per_seed = macro(actual_cm.sum(2)); values = {}
                blank = ids&~y.any((1,2)); nonblank = ids&y.any((1,2))
                for j,method in enumerate(METHODS):
                    m = report['metrics'][method]
                    sklearn = [f1_score(truth[ids],pred[j,s,ids],labels=range(9),average='macro',zero_division=0) for s in range(8)]
                    close(per_seed[j],sklearn,'sklearn F1')
                    close(m['per_seed_f1'],per_seed[j],'perseed F1'); close(m['macro_f1'],per_seed[j].mean(),'mean F1')
                    close(m['per_seed_iou'],stored_iou[j][:,ids].mean(1),'perseed IoU')
                    close(m['iou'],stored_iou[j][:,ids].mean(),'mean IoU')
                    if nonblank.any():close(m['nonblank_iou'],stored_iou[j][:,nonblank].mean(),'nonblank IoU')
                    else:assert m['nonblank_iou'] is None
                    assert m['blank_examples']==int(blank.sum())
                    if blank.any():
                        hard_blank = np.unpackbits(packed[j][:,blank],axis=-1,count=144).astype(bool)
                        close(m['blank_any_foreground_rate'],hard_blank.any(-1).mean(),'blank foreground')
                        close(m['blank_foreground_pixel_fraction'],hard_blank.mean(),'blank fraction')
                        close(m['blank_false_connection_rate'],(pred[j][:,blank]!=0).mean(),'blank conduction')
                    values[method] = dict(f1=float(per_seed[j].mean()),iou=float(stored_iou[j][:,ids].mean()))
                    metrics_checked += 1
                boot = independent_bootstrap(actual_cm); all_boots[dataset][stage][domain] = boot
                gates = []
                for j,method in enumerate(METHODS):
                    if method=='joint':continue
                    comp = report['comparisons'][method]
                    delta = values['joint']['f1']-values[method]['f1']
                    ci = np.quantile(boot[:,4]-boot[:,j],[.025,.975])
                    iou_delta = values['joint']['iou']-values[method]['iou']
                    close(comp['delta'],delta,'comparison delta'); close(comp['ci95'],ci,'comparison CI')
                    close(comp['iou_delta'],iou_delta,'comparison IoU')
                    if method in TRAIN_METHODS:
                        gates.append(delta>=.01 and ci[0]>0 and iou_delta>=-.02)
                assert report['gate']==bool(all(gates))
                datasets[dataset][stage][domain] = dict(examples=int(ids.sum()),gate=report['gate'],all_metrics_exact=True)
            stage_arrays[stage] = (pred.copy(),stored_iou.copy(),packed.copy())
            print('AUDITED',dataset,stage,flush=True)
        # The same selected checkpoint must produce byte-identical predictions.
        for j,method in enumerate(METHODS):
            expected_stage = 'fixed400' if method=='base' or selected[method]==400 else 'fixed2000' if selected[method]==2000 else None
            if expected_stage is not None:
                for which in range(3):
                    assert np.array_equal(stage_arrays['val_selected'][which][j],stage_arrays[expected_stage][which][j])
        for domain in domains:
            for j,method in enumerate(METHODS):
                long = result['results'][dataset]['fixed2000'][domain]['metrics'][method]
                short = result['results'][dataset]['fixed400'][domain]['metrics'][method]
                expected = result['long_minus_short'][dataset][domain][method]
                delta = long['macro_f1']-short['macro_f1']
                samples = all_boots[dataset]['fixed2000'][domain][:,j]-all_boots[dataset]['fixed400'][domain][:,j]
                close(expected['delta'],delta,'growth delta')
                close(expected['ci95'],np.quantile(samples,[.025,.975]),'paired growth CI')
                close(expected['iou_delta'],long['iou']-short['iou'],'growth IoU')
        del stage_arrays
    preparation = read(HERE/'holdout/PREPARE_RESULT.json')
    fresh = np.load(SOURCES['fresh']); truth,frame = fresh['truth'],fresh['frame']
    counts = np.bincount(truth,minlength=9)
    support = np.array([[(truth[frame==g]==c).any() for c in range(9)] for g in np.unique(frame)]).sum(0)
    data_gate = bool(counts.min()>=32 and support.min()>=8 and len(np.unique(frame))==12)
    assert data_gate==preparation['data_gate']==result['data_gate']
    assert result['primary_gate']==bool(data_gate and datasets['fresh']['fixed2000']['pooled']['gate'])
    for name,expected in own_frozen.items():assert sha(Path(name))==expected
    # Re-check all current shared inputs after decoding and CPU computations.
    for name,expected in frozen.items():assert sha(Path(name))==expected
    report = dict(status='PASS',scope='Independent CPU verification of completed stored results; no training or model inference',
        seconds=time.monotonic()-started,frozen_record_counts=frozen_counts,unique_frozen_files=len(frozen),
        audited_result_files=9,method_domain_metric_rows=metrics_checked,
        electrical_class_sample_checks=physics_examples,unique_sample_masks=len(physics_cache),
        fresh_primary_class_checks_per_method_seed=384,all_packed_masks_iou_exact=True,
        all_confusions_exact=True,all_f1_sklearn_match=True,all_bootstrap_ci_match=True,
        paired_long_minus_short_match=True,checkpoint_stage_identity_match=True,
        independent_val_selection_match=True,primary_gate=result['primary_gate'],
        primary_gate_note='This audit PASS means numerical correctness, not a scientific positive result',
        selected_steps=selected,checkpoint_routes=checkpoint_routes,datasets=datasets,
        audited_artifact_hashes=own_frozen)
    temp = HERE/'RESULT_AUDIT.json.tmp'
    temp.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');temp.replace(HERE/'RESULT_AUDIT.json')
    print(json.dumps({k:v for k,v in report.items() if k not in ['checkpoint_routes','datasets','audited_artifact_hashes']},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--wait-seconds',type=int,default=0);args=parser.parse_args()
    deadline=time.monotonic()+args.wait_seconds
    while not (HERE/'evaluation/RESULT.json').exists():
        if time.monotonic()>=deadline:raise SystemExit('Evaluation RESULT.json not present; no audit performed')
        time.sleep(min(30,max(0,deadline-time.monotonic())))
    audit()
