"""Export transparent training/test summaries after the locked evaluation."""
from pathlib import Path
import json
import os

import numpy as np

HERE=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(HERE/'.matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

LABELS={'replay':'BCE replay','strong_soft':'Мягкая физика','connectivity':'Связность','joint':'Интервальная потеря'}
COLORS={'replay':'#6b7280','strong_soft':'#2563eb','connectivity':'#b45309','joint':'#047857'}


def main():
    out=HERE/'figures';out.mkdir(exist_ok=True)
    rows=json.loads((HERE/'training/VAL_ROWS.json').read_text())
    result=json.loads((HERE/'evaluation/RESULT.json').read_text())
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for method,label in LABELS.items():
        means=[np.mean([r['f1'] for r in rows if r['phase']=='development' and r['method']==method and r['step']==s])*100 for s in [400,1000,2000]]
        axes[0].plot([400,1000,2000],means,'o-',label=label,color=COLORS[method])
    axes[0].set(xlabel='Шаги дообучения',ylabel='Macro-F1, %',title='Прежняя VAL: среднее двух seeds')
    axes[0].set_xticks([400,1000,2000]);axes[0].grid(alpha=.2);axes[0].legend(fontsize=8)
    for method,label in LABELS.items():
        values=[]
        for step in [400,2000]:
            metric=result['results']['fresh'][f'fixed{step}']['pooled']['metrics'][method]
            values.append(metric['macro_f1']*100)
        axes[1].plot([400,2000],values,'o-',label=label,color=COLORS[method])
    axes[1].set(xlabel='Шаги дообучения',ylabel='Macro-F1, %',title='Новые кадры: среднее восьми seeds')
    axes[1].set_xticks([400,2000]);axes[1].grid(alpha=.2);axes[1].legend(fontsize=8)
    fig.suptitle('Тот же ИС, девять модельных электрических классов',fontsize=12)
    for ext in ['png','svg']:
        fig.savefig(out/f'training_extension.{ext}',dpi=180)
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,4.4),layout='constrained')
    controls=['replay','strong_soft','connectivity']
    for offset,step,color in [(-.12,400,'#2563eb'),(.12,2000,'#047857')]:
        comps=result['results']['fresh'][f'fixed{step}']['pooled']['comparisons']
        mean=np.array([comps[m]['delta']*100 for m in controls])
        intervals=np.array([comps[m]['ci95'] for m in controls])*100
        for i,(value,ci) in enumerate(zip(mean,intervals)):
            ax.plot(ci,[i+offset]*2,color=color,lw=2)
            ax.plot(value,i+offset,'o',color=color,label=f'{step} шагов' if i==0 else None)
    ax.axvline(0,color='#555',lw=1);ax.axvline(1,color='#aaa',lw=1,ls='--')
    ax.set_yticks(range(3),[LABELS[m] for m in controls]);ax.invert_yaxis()
    ax.set(xlabel='Macro-F1 предложения минус контроль, п.п.',title='Новые кадры: парные 95% bootstrap-интервалы')
    ax.grid(axis='x',alpha=.2);ax.legend()
    fig.text(.5,-.02,'Пересэмплирование кадров и training seeds; это один реальный ИС.',ha='center',fontsize=9)
    for ext in ['png','svg']:
        fig.savefig(out/f'paired_comparisons.{ext}',dpi=180,bbox_inches='tight')
    plt.close(fig)


if __name__=='__main__':
    main()
