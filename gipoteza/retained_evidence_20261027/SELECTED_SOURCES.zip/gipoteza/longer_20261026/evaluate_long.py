"""Locked evaluation of the longer E14 experiment. Never trains models."""
from pathlib import Path
import json
import time

import numpy as np
import torch
from sklearn.metrics import f1_score

import long_training as run

HERE = Path(__file__).resolve().parent
OUT = HERE/'evaluation'
METHODS = ['base', *run.METHODS]
SEEDS = run.SEEDS
STAGES = ['fixed400', 'fixed2000', 'val_selected']
START = time.monotonic()


def save(name, value):
    run.save(OUT/name, value)


def log(s):
    print(f'{time.monotonic()-START:.1f}s {s}', flush=True)


def path(method, seed, step):
    return HERE/'training'/(f'final_base_{seed}.pt' if method=='base' else f'final_{method}_{seed}_{step}.pt')


def predict(checkpoint, x, y):
    net = run.e6.network()
    net.load_state_dict(torch.load(checkpoint, weights_only=True))
    net = net.to('mps').eval(); hard = []
    with torch.inference_mode():
        for start in range(0, len(x), 256):
            batch = torch.tensor(5*(x[start:start+256, None]-.2), device='mps')
            hard.append((net(batch)[:, 0]>=0).cpu().numpy())
    hard = np.concatenate(hard)
    pred = run.dev.classes(hard).astype(np.int8)
    inter = (hard & y).sum((1,2)); union = (hard | y).sum((1,2))
    iou = np.divide(inter, union, out=np.ones(len(union)), where=union>0)
    packed = np.packbits(hard.reshape(-1,144), axis=-1)
    return pred, iou, packed


def confusion(truth, prediction, group):
    groups = np.unique(group)
    cm = np.zeros((*prediction.shape[:2], len(groups), 9, 9), np.int64)
    for j in range(len(METHODS)):
        for s in range(len(SEEDS)):
            for k, g in enumerate(groups):
                ids = group==g
                np.add.at(cm[j,s,k], (truth[ids], prediction[j,s,ids]), 1)
    return cm


def score(cm):
    tp = np.diagonal(cm, axis1=-2, axis2=-1)
    den = cm.sum(-1)+cm.sum(-2)
    return np.divide(2*tp,den,out=np.zeros_like(tp,dtype=float),where=den>0).mean(-1)


def bootstrap(cm):
    rng = np.random.default_rng(260026); values = []
    for _ in range(4000):
        si = rng.integers(0,len(SEEDS),len(SEEDS))
        gi = rng.integers(0,cm.shape[2],cm.shape[2])
        values.append(score(cm[:,si][:,:,gi].sum(2)).mean(1))
    return np.array(values)


def assess(pred, ii, packed, truth, group, y):
    cm = confusion(truth,pred,group)
    metrics = {}; nonblank=y.any((1,2)); blank=~nonblank
    for j, method in enumerate(METHODS):
        per_seed = score(cm[j].sum(1))
        reference = [f1_score(truth,pred[j,s],labels=range(9),average='macro',zero_division=0) for s in range(len(SEEDS))]
        assert np.allclose(per_seed, reference, atol=1e-14, rtol=0)
        m = dict(macro_f1=float(per_seed.mean()), per_seed_f1=per_seed.tolist(),
            iou=float(ii[j].mean()), per_seed_iou=ii[j].mean(1).tolist(),
            nonblank_iou=float(ii[j][:,nonblank].mean()) if nonblank.any() else None,
            blank_examples=int(blank.sum()))
        if blank.any():
            binary = np.unpackbits(packed[j][:,blank],axis=-1,count=144).astype(bool)
            m.update(blank_any_foreground_rate=float(binary.any(-1).mean()),
                blank_foreground_pixel_fraction=float(binary.mean()),
                blank_false_connection_rate=float((pred[j][:,blank]!=0).mean()))
        metrics[method]=m
    boot=bootstrap(cm); joint=METHODS.index('joint'); comparisons={}
    for j, method in enumerate(METHODS):
        if method=='joint':continue
        comparisons[method]=dict(delta=metrics['joint']['macro_f1']-metrics[method]['macro_f1'],
            ci95=np.quantile(boot[:,joint]-boot[:,j],[.025,.975]).tolist(),
            iou_delta=metrics['joint']['iou']-metrics[method]['iou'])
    gate=all(comparisons[m]['delta']>=.01 and comparisons[m]['ci95'][0]>0 and comparisons[m]['iou_delta']>=-.02 for m in run.METHODS if m!='joint')
    result=dict(examples=len(truth),groups=len(np.unique(group)),
        class_counts=np.bincount(truth,minlength=9).tolist(),metrics=metrics,
        comparisons=comparisons,gate=bool(gate))
    return result,cm,boot


def main():
    OUT.mkdir(exist_ok=False)
    assert torch.backends.mps.is_available();torch.set_num_threads(2)
    complete=json.loads((HERE/'training/COMPLETE.json').read_text())
    assert complete['final_seeds']==SEEDS and complete['primary_steps']==2000
    selection=json.loads((HERE/'training/SELECTION.json').read_text())['selected']
    selected={m:r['step'] for m,r in selection.items()}
    assert set(selected)==set(run.METHODS)
    assert all(s in run.CHECKPOINTS for s in selected.values())
    model_hashes=json.loads((HERE/'training/MODEL_HASHES.json').read_text())
    for name,h in model_hashes.items():assert run.sha(Path(name))==h
    sources=dict(fresh=HERE/'holdout/PATCHES.npz',
        old_E14=run.OLD/'sem_graded_test/PATCHES.npz',
        refics=run.VALIDATION/'transfer_result/PATCHES.npz')
    files=[Path(__file__),HERE/'continue_evaluation.py',HERE/'long_training.py',HERE/'PROTOCOL.md',HERE/'EVALUATION_PROTOCOL.md',
        HERE/'training/COMPLETE.json',HERE/'training/SELECTION.json',HERE/'training/FROZEN.json',
        HERE/'training/MODEL_HASHES.json',HERE/'holdout/PREPARE_RESULT.json',
        HERE/'holdout/MANIFEST.json',HERE/'holdout/REMOTE_SELECTION.json',
        HERE/'holdout/D4_DIAGNOSTIC.npz',HERE/'holdout/DATA_AUDIT.json',
        run.VALIDATION/'baselines/soft_grid.py',
        run.OLD/'structured12_learning.py',run.OLD/'structured12_prepare.py',run.OLD/'sem_joint_development.py',
        *sources.values()]
    frozen={str(p):run.sha(p) for p in files};frozen.update(model_hashes);save('FROZEN.json',frozen)
    results={}; growth={}
    for dataset,source in sources.items():
        data=np.load(source);x,y,truth=data['X'],data['Y'],data['truth']
        group=data['uid_index'] if dataset=='refics' else data['frame']
        assert np.array_equal(run.dev.classes(y),truth)
        cache={};results[dataset]={};stage_boot={}
        for stage in STAGES:
            predictions=[];ious=[];masks=[]
            for method in METHODS:
                step=0 if method=='base' else 400 if stage=='fixed400' else 2000 if stage=='fixed2000' else selected[method]
                for seed in SEEDS:
                    key=(method,seed,step)
                    if key not in cache:
                        cache[key]=predict(path(method,seed,step),x,y)
                        log(f'{dataset} {stage} {method} seed={seed} step={step}')
                predictions.append([cache[(method,s,step)][0] for s in SEEDS])
                ious.append([cache[(method,s,step)][1] for s in SEEDS])
                masks.append([cache[(method,s,step)][2] for s in SEEDS])
            pred=np.array(predictions);ii=np.array(ious);packed=np.array(masks)
            domains=dict(pooled=np.ones(len(x),bool))
            if dataset=='fresh':
                rotation=np.load(HERE/'holdout/D4_DIAGNOSTIC.npz')
                assert np.array_equal(rotation['truth'],truth)
                assert np.array_equal(rotation['frame'],group)
                domains['no_old_D4']=~rotation['old_related']
            if dataset=='refics':domains.update({str(n):data['node_nm']==n for n in [32,90]})
            stage_result={};confusions={};boots={}
            for domain,ids in domains.items():
                report,cm,boot=assess(pred[:,:,ids],ii[:,:,ids],packed[:,:,ids],truth[ids],group[ids],y[ids])
                stage_result[domain]=report;confusions[domain]=cm;boots[domain]=boot
            results[dataset][stage]=stage_result;stage_boot[stage]=boots
            np.savez_compressed(OUT/f'{dataset}_{stage}.npz',prediction=pred,iou=ii,masks_packed=packed,
                truth=truth,group=group,methods=np.array(METHODS),seeds=np.array(SEEDS),
                **{'confusion_'+k:v for k,v in confusions.items()})
            save('PROGRESS.json',dict(dataset=dataset,stage=stage,seconds=time.monotonic()-START))
            save('PARTIAL_RESULT.json',results)
        growth[dataset]={}
        for domain in stage_boot['fixed2000']:
            change={}
            for j,method in enumerate(METHODS):
                long=results[dataset]['fixed2000'][domain]['metrics'][method]
                short=results[dataset]['fixed400'][domain]['metrics'][method]
                samples=stage_boot['fixed2000'][domain][:,j]-stage_boot['fixed400'][domain][:,j]
                change[method]=dict(delta=long['macro_f1']-short['macro_f1'],
                    ci95=np.quantile(samples,[.025,.975]).tolist(),iou_delta=long['iou']-short['iou'])
            growth[dataset][domain]=change
        del cache
    assert all(run.sha(Path(p))==h for p,h in frozen.items())
    data_gate=json.loads((HERE/'holdout/PREPARE_RESULT.json').read_text())['data_gate']
    primary=results['fresh']['fixed2000']['pooled']
    result=dict(scope='Same E14 hypothesis; new frames of same realIC, 8newseeds, fivefold fine-tuning',
        seeds=SEEDS,methods=METHODS,primary_dataset='fresh',primary_stage='fixed2000',
        primary_gate=bool(data_gate and primary['gate']),data_gate=data_gate,
        secondary_steps=selected,results=results,long_minus_short=growth,
        bootstrap_draws=4000,bootstrap_seed=260026,seconds=time.monotonic()-START,
        limitations=['Single real IC; proxy electrical labels, no measured G',
            'Old E14/REFICS reused for secondary analysis, no independent external replication',
            'Longer training does not establish mathematical novelty'])
    save('RESULT.json',result);log(f'COMPLETE primary_gate={result["primary_gate"]}')


if __name__=='__main__':
    main()
