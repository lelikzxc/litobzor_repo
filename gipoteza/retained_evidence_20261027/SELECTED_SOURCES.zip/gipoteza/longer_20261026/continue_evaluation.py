"""Wait for the complete training artifact, then execute the locked evaluator."""
from pathlib import Path
import time

HERE=Path(__file__).resolve().parent


if __name__=='__main__':
    start=time.monotonic()
    while not (HERE/'training/COMPLETE.json').exists():
        if time.monotonic()-start>3600:
            raise TimeoutError('Training completion artifact did not appear; no TEST evaluated')
        time.sleep(2)
    import evaluate_long
    evaluate_long.main()
