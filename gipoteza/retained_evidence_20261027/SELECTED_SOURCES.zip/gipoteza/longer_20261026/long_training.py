"""Fivefold training extension of E14; TRAIN/VAL only, no test scoring."""
from pathlib import Path
import hashlib
import json
import sys
import time

import numpy as np
from scipy import ndimage as ndi
import torch
from torch.nn import functional as F

HERE = Path(__file__).resolve().parent
OLD = HERE.parent/'search_20261026'
VALIDATION = HERE.parent/'validation_20261026'
sys.path.insert(0, str(VALIDATION/'baselines'))
import soft_grid as grid
dev = grid.joint
e6 = grid.e6

OUT = HERE/'training'
METHODS = ['replay', 'strong_soft', 'connectivity', 'joint']
DEV_SEEDS = [17, 41]
SEEDS = [611, 683, 751, 823, 907, 977, 1061, 1151]
CHECKPOINTS = [400, 1000, 2000]
CONFIG = dict(family='log', a=4., b=40., kappa=4., weight=.4, kernel='min', id='c15')
START = time.monotonic()


def save(path, value):
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')
    temp.replace(path)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def log(message):
    print(f'{time.monotonic()-START:.1f}s {message}', flush=True)


def connected(masks):
    values = []
    for im in masks:
        labs, _ = ndi.label(im)
        left = np.unique(labs[:, 0]); right = np.unique(labs[:, -1])
        values.append(bool(len(np.intersect1d(left[left > 0], right[right > 0]))))
    return np.array(values)


def critical(prob, finite=True):
    ordered, order = prob.reshape(-1, 144).sort(1, descending=True)
    o = order.detach().cpu().numpy()
    rank = np.empty_like(o); rank[np.arange(len(o))[:, None], o] = np.arange(144)
    critical_values = []
    for target in ([1, 2] if finite else [1]):
        low = np.zeros(len(o), int); high = np.full(len(o), 144, int)
        while np.any(high-low > 1):
            ids = np.flatnonzero(high-low > 1); mid = (low[ids]+high[ids])//2
            masks = (rank[ids] < mid[:, None]).reshape(-1, 12, 12)
            yes = connected(masks) if target == 1 else e6.label(e6.binary_response(masks)) >= 2
            high[ids[yes]] = mid[yes]; low[ids[~yes]] = mid[~yes]
        indices = torch.tensor(high-1, device=prob.device, dtype=torch.long)
        critical_values.append(ordered.gather(1, indices[:, None])[:, 0])
    return critical_values


def probabilities(prob):
    q = []
    for p in [prob, prob.transpose(-1, -2)]:
        t1, t2 = critical(p)
        q.append(torch.stack([1-t1, t1-t2, t2], 1))
    return torch.stack(q, 1)


def auxiliary(logits, targets, method):
    if method == 'strong_soft':
        return grid.auxiliary(logits, targets, CONFIG)
    p = logits.sigmoid()
    if method == 'connectivity':
        t1 = torch.stack([critical(p, False)[0], critical(p.transpose(-1, -2), False)[0]], 1)
        return F.binary_cross_entropy(t1.clamp(1e-7, 1-1e-7), (targets > 0).float())
    q = probabilities(p)
    lower, upper = dev.interval_bounds(q, targets)
    lower = lower.max(1).values; upper = upper.min(1).values
    return -.5*(upper.clamp_min(1e-7).log() + (1-lower).clamp_min(1e-7).log()).mean()


def verify():
    rng = np.random.default_rng(260026)
    raw = rng.uniform(.01, .99, (64, 1, 12, 12))
    p = torch.tensor(raw, dtype=torch.float64, requires_grad=True)
    reference = dev.probabilities(p); fast = probabilities(p)
    error = float((reference-fast).detach().abs().max())
    assert error == 0
    coeff = torch.tensor(rng.normal(size=reference.shape), dtype=torch.float64)
    old_grad = torch.autograd.grad((reference*coeff).sum(), p)[0]
    new_grad = torch.autograd.grad((fast*coeff).sum(), p)[0]
    gradient_error = float((old_grad-new_grad).abs().max())
    assert gradient_error == 0
    t1 = torch.stack([critical(p, False)[0], critical(p.transpose(-1,-2), False)[0]], 1)
    assert torch.allclose(t1, 1-reference[:,:,0], atol=1e-15, rtol=0)
    return dict(vectors=64, max_probability_error=error, max_gradient_error=gradient_error,
                strong_soft_solver=grid.verify())


def evaluate(net, data):
    net.eval()
    result = dev.evaluate(net, data['x'], data['y'], data['truth'])
    net.train()
    return result


def main():
    OUT.mkdir(exist_ok=False)
    assert torch.backends.mps.is_available(), 'MPS required; no CPU fallback'
    torch.set_num_threads(2)
    checks = verify(); save(OUT/'VERIFICATION.json', checks)
    files = [Path(__file__), HERE/'PROTOCOL.md', VALIDATION/'baselines/soft_grid.py',
        OLD/'structured12_learning.py', OLD/'structured12_prepare.py', OLD/'sem_joint_development.py',
        OLD/'sem_electrical/PATCHES.npz', OLD/'sem_joint_development/SELECTION.json',
        *[OLD/f'sem_joint_development/base_{s}.pt' for s in DEV_SEEDS]]
    frozen = {str(p):sha(p) for p in files}; save(OUT/'FROZEN.json', frozen)
    save(OUT/'SETTINGS.json', dict(methods=METHODS, dev_seeds=DEV_SEEDS, seeds=SEEDS,
        checkpoints=CHECKPOINTS, strong_soft=CONFIG, steps=2000, weak_loss_weight=.4))
    data = grid.load_data('mps'); a, w, v = data['anchor'], data['weak'], data['val']
    targets = torch.stack([w['target']//3, w['target']%3], 1)
    rows = []; completed_steps = 0; total_steps = (len(DEV_SEEDS)+len(SEEDS))*len(METHODS)*2000 + len(SEEDS)*400
    selected = None
    for phase, seeds in [('development', DEV_SEEDS), ('final', SEEDS)]:
        for seed in seeds:
            torch.manual_seed(seed)
            base = e6.network().to('mps')
            if phase == 'development':
                base.load_state_dict(torch.load(OLD/f'sem_joint_development/base_{seed}.pt', weights_only=True))
            else:
                opt = torch.optim.AdamW(base.parameters(), lr=.003, weight_decay=.0001)
                rng = np.random.default_rng(seed)
                for step in range(400):
                    ids = torch.tensor(rng.integers(0, len(a['x']), 16), device='mps')
                    opt.zero_grad(set_to_none=True)
                    loss = F.binary_cross_entropy_with_logits(base(a['x'][ids]), a['y'][ids])
                    loss.backward(); opt.step(); completed_steps += 1
            weights = {k:t.detach().cpu().clone() for k,t in base.state_dict().items()}
            torch.save(weights, OUT/f'{phase}_base_{seed}.pt')
            rows.append(dict(phase=phase, seed=seed, method='base', step=0, **evaluate(base, v)))
            del base
            for method in METHODS:
                net = e6.network().to('mps'); net.load_state_dict(weights)
                opt = torch.optim.AdamW(net.parameters(), lr=.001, weight_decay=.0001)
                rng = np.random.default_rng(seed+10)
                method_start = time.monotonic()
                for step in range(1, 2001):
                    ai = torch.tensor(rng.integers(0, len(a['x']), 16), device='mps')
                    wi = torch.tensor(rng.integers(0, len(w['x']), 16), device='mps')
                    opt.zero_grad(set_to_none=True)
                    loss = F.binary_cross_entropy_with_logits(net(a['x'][ai]), a['y'][ai])
                    if method != 'replay':
                        loss = loss + .4*auxiliary(net(w['x'][wi]), targets[wi], method)
                    assert torch.isfinite(loss), (phase, seed, method, step)
                    loss.backward(); opt.step(); completed_steps += 1
                    if step in CHECKPOINTS:
                        metrics = evaluate(net, v)
                        rows.append(dict(phase=phase, seed=seed, method=method, step=step, **metrics))
                        torch.save({k:t.detach().cpu().clone() for k,t in net.state_dict().items()}, OUT/f'{phase}_{method}_{seed}_{step}.pt')
                        save(OUT/'VAL_ROWS.json', rows)
                        log(f'{phase} seed={seed} {method} step={step} VAL_F1={metrics["f1"]:.6f} IoU={metrics["iou"]:.6f}')
                    if step % 100 == 0:
                        elapsed = time.monotonic()-START
                        progress = dict(phase=phase, seed=seed, method=method, step=step,
                            completed_steps=completed_steps, total_steps=total_steps,
                            seconds=elapsed, method_steps_per_second=step/(time.monotonic()-method_start))
                        save(OUT/'PROGRESS.json', progress)
                        log(f'progress {completed_steps}/{total_steps} {phase} seed={seed} {method} {step}/2000')
                del net, opt
        if phase == 'development':
            aggregate = []
            for method in METHODS:
                for step in CHECKPOINTS:
                    rr = [r for r in rows if r['phase']=='development' and r['method']==method and r['step']==step]
                    aggregate.append(dict(method=method, step=step, f1=float(np.mean([r['f1'] for r in rr])),
                        iou=float(np.mean([r['iou'] for r in rr]))))
            selected = {m:sorted([r for r in aggregate if r['method']==m], key=lambda r:(-r['f1'], -r['iou'], r['step']))[0]
                        for m in METHODS}
            save(OUT/'SELECTION.json', dict(scope='Secondary duration selection: development VAL only',
                primary_step=2000, selected=selected, aggregate=aggregate))
            log(f'VAL-only duration selection frozen: {selected}')
    assert all(sha(Path(p)) == h for p,h in frozen.items())
    checkpoints = sorted(OUT.glob('*.pt'))
    save(OUT/'MODEL_HASHES.json', {str(p):sha(p) for p in checkpoints})
    save(OUT/'COMPLETE.json', dict(scope='TRAIN/VAL only; no test evaluation', seconds=time.monotonic()-START,
        total_steps=completed_steps, final_seeds=SEEDS, methods=METHODS, primary_steps=2000,
        secondary_selection=selected, checkpoints=len(checkpoints)))
    log('TRAINING COMPLETE; TEST remains unevaluated')


if __name__ == '__main__':
    main()
