"""Prepare the twelve preselected fresh realSEM frames, without model scoring."""
from pathlib import Path
import hashlib
import json
import re
import sys
import time
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
OLD = HERE.parents[1] / 'search_20261026'
sys.path.insert(0, str(OLD))
from structured12_prepare import canonical
import sem_joint_development as dev


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')


def rasterize(svg_path, shape):
    svg = ET.parse(svg_path)
    canvas = Image.new('L', (shape[1], shape[0])); draw = ImageDraw.Draw(canvas)
    paths = 0
    for element in svg.iter():
        assert 'transform' not in element.attrib, svg_path
        if not element.tag.endswith('}path'):
            continue
        data = element.attrib['d']
        assert set(re.findall('[A-Za-z]', data)) <= {'M', 'L', 'Z', 'z'}
        assert data.count('M') == 1
        points = [(int(x), int(y)) for x,y in re.findall(r'[ML](\d+),(\d+) ', data)]
        assert len(points) >= 3
        draw.polygon(points, fill=1); paths += 1
    return np.array(canvas), paths


def main():
    start = time.monotonic()
    assert not (HERE/'PATCHES.npz').exists(), 'Refuse to overwrite prepared holdout'
    selected = json.loads((HERE/'REMOTE_SELECTION.json').read_text())
    download = json.loads((HERE/'DOWNLOAD.json').read_text())
    assert download['frames'] == selected['frames'] and len(download['frames']) == 12
    prior_paths = [OLD/name/'MANIFEST.json' for name in
                   ['sem_electrical', 'sem_replication', 'sem_graded_test']]
    prior = [row for path in prior_paths for row in json.loads(path.read_text())]
    old_seen = {bytes.fromhex(row['canonical']) for row in prior}
    assert all(len(key) == 18 for key in old_seen)
    assert not set(selected['frames']) & {int(row['frame']) for row in prior}
    files = [Path(__file__), HERE/'REMOTE_PROTOCOL.md', HERE/'REMOTE_SELECTION.json',
             HERE/'DOWNLOAD.json', OLD/'structured12_prepare.py',
             OLD/'structured12_learning.py', OLD/'sem_joint_development.py', *prior_paths]
    for row in download['files']:
        path = HERE/'newdata'/row['name']; assert sha(path) == row['sha256']
        files.append(path)
    frozen = {str(path): sha(path) for path in files}
    save(HERE/'PREPARE_FROZEN.json', frozen)
    seen = old_seen.copy(); xx_all = []; yy_all = []; records = []; stats = {}
    for frame in selected['frames']:
        sem_path = HERE/f'newdata/dataset/sems/m2/sem{frame:04}.png'
        svg_path = HERE/f'newdata/dataset/labels/m2/label{frame:04}.svg'
        image = np.array(Image.open(sem_path)); assert image.shape == (3536, 4096)
        mask, path_count = rasterize(svg_path, image.shape)
        xx = image[512:-512,512:-512]; yy = mask[512:-512,512:-512]
        h,w = xx.shape; h=h//4*4; w=w//4*4
        xx = xx[:h,:w].reshape(h//4,4,w//4,4).mean((1,3)).astype(np.float32)/255
        yy = yy[:h,:w].reshape(h//4,4,w//4,4).mean((1,3)) >= .5
        pool = {}; skipped_old_or_prior = 0; skipped_current_duplicates = 0
        for y in range(0,len(yy)-11,6):
            for x in range(0,yy.shape[1]-11,6):
                patch = yy[y:y+12,x:x+12]
                if patch.sum() in [0,144]:
                    continue
                key = canonical(patch)
                if key in seen:
                    skipped_old_or_prior += 1; continue
                if key in pool:
                    skipped_current_duplicates += 1; continue
                pool[key] = (xx[y:y+12,x:x+12].copy(), patch.copy(), y*4+512,x*4+512)
        keys = sorted(pool); seen.update(keys)
        images = np.array([pool[key][1] for key in keys]); labels = dev.classes(images)
        counts = np.bincount(labels,minlength=9).tolist()
        stats[str(frame)] = dict(examples=len(keys), class_counts=counts, svg_paths=path_count,
                                skipped_old_or_prior=skipped_old_or_prior,
                                skipped_current_duplicates=skipped_current_duplicates)
        for key, cls in zip(keys, labels):
            image, mask, y, x = pool[key]
            xx_all.append(image); yy_all.append(mask)
            records.append(dict(frame=frame, y=y, x=x, canonical=key.hex(),label=int(cls)))
        save(HERE/'PREPARE_PROGRESS.json', dict(frame=frame, completed_frames=len(stats), total_frames=12,
            examples=len(records), seconds=time.monotonic()-start))
        print(json.dumps(dict(frame=frame, **stats[str(frame)])),flush=True)
    truth = np.array([row['label'] for row in records]); frames = np.array([row['frame'] for row in records])
    total = np.bincount(truth,minlength=9)
    support = (np.array([row['class_counts'] for row in stats.values()])>0).sum(0)
    gate = np.min(total) >= 32 and np.min(support) >= 8
    canonical_new = {bytes.fromhex(row['canonical']) for row in records}
    assert not canonical_new & old_seen and len(canonical_new)==len(records)
    np.savez_compressed(HERE/'PATCHES.npz', X=np.array(xx_all), Y=np.array(yy_all), truth=truth, frame=frames)
    save(HERE/'MANIFEST.json', records)
    assert all(sha(Path(path)) == expected for path,expected in frozen.items())
    outputs = {name:sha(HERE/name) for name in ['PATCHES.npz','MANIFEST.json']}
    result = dict(status='READY' if gate else 'DATA_GATE_FAILED', data_gate=bool(gate),
        frames=selected['frames'], examples=len(records), class_counts=total.tolist(),
        class_frame_support=support.tolist(), per_frame=stats,
        old_unique_canonical_motifs=len(old_seen), no_old_or_new_HV_duplicates=True,
        scope='Fresh frames of same single realIC; nine proxy electrical classes',
        source_node_nm=128, native_pixel_nm=14.65,
        source_metadata='Author dataset README, not independent measurement',
        new_model_predictions_computed=False, frozen_inputs_verified=len(frozen),
        output_sha256=outputs, seconds=time.monotonic()-start)
    save(HERE/'PREPARE_RESULT.json', result)
    print(json.dumps({k:v for k,v in result.items() if k!='per_frame'},indent=2),flush=True)


if __name__=='__main__':
    main()
