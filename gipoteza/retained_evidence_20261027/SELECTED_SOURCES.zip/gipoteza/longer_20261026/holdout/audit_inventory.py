"""Read-only inventory of local SEM source frames against prior data manifests.

No predictions, model checkpoints, or metric files are opened. All output is
under this script's directory. No download is performed.
"""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
OLD = HERE.parents[1] / 'search_20261026'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest_paths = [OLD / name / 'MANIFEST.json' for name in
                      ['sem_electrical', 'sem_replication', 'sem_graded_test']]
    prior = {}
    for path in manifest_paths:
        records = json.loads(path.read_text())
        prior[path.parent.name] = sorted({int(row['frame']) for row in records})
    sem_sources = [
        (OLD/'sem_author/dataset/sems', OLD/'sem_author/dataset/labels',
         ['sem_electrical']),
        (OLD/'sem_full/dataset/sems/m2', OLD/'sem_full/dataset/labels/m2',
         ['sem_replication', 'sem_graded_test'])]
    files = [Path(__file__), *manifest_paths]
    inventory = []
    for sem_dir, label_dir, source_groups in sem_sources:
        used = set().union(*(set(prior[group]) for group in source_groups))
        for image in sorted(sem_dir.glob('sem*.png')):
            match = re.fullmatch(r'sem(\d+)\.png', image.name)
            assert match, image
            frame = int(match.group(1))
            label = label_dir / f'label{frame:04}.svg'
            assert label.is_file(), label
            files.extend([image, label])
            groups = [name for name in source_groups if frame in prior[name]]
            inventory.append(dict(frame=frame, image=str(image), label=str(label),
                                  prior_data_groups=groups,
                                  image_sha256=sha(image), label_sha256=sha(label),
                                  fresh=frame not in used))
    fresh = [row for row in inventory if row['fresh']]
    frozen = {str(path): sha(path) for path in files}
    result = dict(status='NO_UNSEEN_LOCAL_FRAMES' if not fresh else 'FRESH_LOCAL_FRAMES_FOUND',
                  local_image_label_pairs=len(inventory), fresh_pairs=len(fresh),
                  sufficient_for_minimum_four=len(fresh) >= 4,
                  prior_manifest_frames=prior, inventory=inventory,
                  scope='Same single real IC; source-image/data-use inventory only',
                  no_predictions_or_model_checkpoints_read=True,
                  no_new_holdout_prepared=not bool(fresh))
    (HERE/'FROZEN.json').write_text(json.dumps(frozen, indent=2)+'\n')
    (HERE/'INVENTORY.json').write_text(json.dumps(result, indent=2)+'\n')
    assert all(sha(Path(path)) == expected for path, expected in frozen.items())
    print(json.dumps({key:value for key,value in result.items() if key!='inventory'}, indent=2))


if __name__ == '__main__':
    main()
