"""Independent numerical audit of prepared holdout; no model predictions."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import sys
import time
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
OLD = HERE.parents[1]/'search_20261026'
sys.path.insert(0, str(OLD))
import sem_joint_development as dev


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_hv(image):
    # Standalone implementation; no call to preparation's canonical function.
    return min(np.packbits(image[::-1 if flip_y else 1,
                                 ::-1 if flip_x else 1]).tobytes()
               for flip_y in [False, True] for flip_x in [False, True])


def svg_from_tokens(path, shape):
    """Reparse M/L/Z token stream, independently of prepare.py's point regex."""
    root = ET.parse(path).getroot()
    result = Image.new('1', (shape[1], shape[0]))
    painter = ImageDraw.Draw(result)
    count = 0
    for element in root.iter():
        assert 'transform' not in element.attrib
        if element.tag.split('}')[-1] != 'path':
            continue
        stream = re.findall(r'[A-Za-z]|[-+]?\d+(?:\.\d+)?', element.attrib['d'])
        points = []; index = 0; command = None
        while index < len(stream):
            token = stream[index]
            if token.isalpha():
                command = token; index += 1
                assert command in ['M', 'L', 'Z', 'z']
                if command in ['Z', 'z']:
                    assert index == len(stream)
                    break
            assert command in ['M', 'L']
            x, y = float(stream[index]), float(stream[index+1])
            assert x == int(x) and y == int(y)
            points.append((int(x),int(y)))
            index += 2
            if command == 'M':
                command = 'L'
        assert len(points) >= 3
        painter.polygon(points, fill=1); count += 1
    return np.asarray(result, dtype=bool), count


def main():
    start = time.monotonic()
    checks = {}; verified = {}
    for name in ['FROZEN.json','REMOTE_FROZEN.json','PREPARE_FROZEN.json']:
        frozen = json.loads((HERE/name).read_text())
        for path, expected in frozen.items():
            assert sha(Path(path)) == expected, (name,path)
        verified[name] = len(frozen)
    download = json.loads((HERE/'DOWNLOAD.json').read_text())
    for row in download['files']:
        assert sha(HERE/'newdata'/row['name']) == row['sha256']
    prepared = json.loads((HERE/'PREPARE_RESULT.json').read_text())
    for name, expected in prepared['output_sha256'].items():
        assert sha(HERE/name) == expected
    files = [Path(__file__),HERE/'MANIFEST.json',HERE/'PATCHES.npz',HERE/'PREPARE_RESULT.json',
             HERE/'REMOTE_SELECTION.json',HERE/'DOWNLOAD.json',OLD/'sem_full/dataset/README']
    prior_paths = [OLD/name/'MANIFEST.json' for name in
                   ['sem_electrical','sem_replication','sem_graded_test']]
    files += prior_paths
    audit_frozen = {str(path):sha(path) for path in files}
    old = [row for path in prior_paths for row in json.loads(path.read_text())]
    old_frames = {int(row['frame']) for row in old}
    old_keys = {bytes.fromhex(row['canonical']) for row in old}
    selection = json.loads((HERE/'REMOTE_SELECTION.json').read_text())
    selected = selection['frames']
    assert not old_frames & set(selected) and len(selected)==12
    pool = [frame for frame in range(321) if frame not in old_frames and frame not in range(10)]
    chosen = sorted(pool,key=lambda frame:hashlib.sha256(f'longer_20261026/{frame}'.encode()).hexdigest())[:12]
    assert selected == chosen
    manifest = json.loads((HERE/'MANIFEST.json').read_text())
    z = np.load(HERE/'PATCHES.npz')
    x,y,truth,frame = [z[key] for key in ['X','Y','truth','frame']]
    assert x.dtype == np.float32 and y.dtype == bool and len(y) == 21885
    assert x.shape == y.shape == (len(manifest),12,12)
    assert set(np.unique(frame)) == set(selected)
    assert np.array_equal(frame,np.array([row['frame'] for row in manifest]))
    assert np.array_equal(truth,np.array([row['label'] for row in manifest]))
    keys = [canonical_hv(mask) for mask in y]
    assert keys == [bytes.fromhex(row['canonical']) for row in manifest]
    assert len(set(keys)) == len(keys) and not set(keys) & old_keys
    assert np.array_equal(dev.classes(y),truth)
    counts = np.bincount(truth,minlength=9)
    support = np.array([np.bincount(truth[frame==f],minlength=9) for f in selected])
    assert counts.tolist() == prepared['class_counts']
    assert (support>0).sum(0).tolist() == prepared['class_frame_support']
    for fi,f in enumerate(selected):
        assert support[fi].tolist() == prepared['per_frame'][str(f)]['class_counts']
    assert (counts >=32).all() and ((support>0).sum(0)>=8).all()
    sample_rows = []
    for f in selected:
        ids = np.flatnonzero(frame==f).tolist()
        ids.sort(key=lambda i:hashlib.sha256(('holdout-audit/'+manifest[i]['canonical']).encode()).hexdigest())
        image_path = HERE/f'newdata/dataset/sems/m2/sem{f:04}.png'
        svg_path = HERE/f'newdata/dataset/labels/m2/label{f:04}.svg'
        image = np.asarray(Image.open(image_path))
        mask, npaths = svg_from_tokens(svg_path,image.shape)
        assert npaths == prepared['per_frame'][str(f)]['svg_paths']
        for i in ids[:2]:
            row = manifest[i]; r,c = row['y'],row['x']
            assert (r-512)%24==0 and (c-512)%24==0
            assert 512<=r<=image.shape[0]-512-48 and 512<=c<=image.shape[1]-512-48
            raw = image[r:r+48,c:c+48].reshape(12,4,12,4).mean((1,3)).astype(np.float32)/255
            target = mask[r:r+48,c:c+48].reshape(12,4,12,4).mean((1,3)) >=.5
            assert np.array_equal(raw,x[i]) and np.array_equal(target,y[i])
            sample_rows.append(dict(index=i,frame=int(f),y=int(r),x=int(c),input_exact=True,target_exact=True))
    # HV classes have already been excluded. A remaining 90-degree relation is
    # exactly the extra relation introduced by full D4. It is diagnostic only.
    related_old = np.array([canonical_hv(np.rot90(mask)) in old_keys for mask in y])
    new_set = set(keys)
    related_new = np.array([canonical_hv(np.rot90(mask)) in new_set and canonical_hv(np.rot90(mask))!=keys[i]
                            for i,mask in enumerate(y)])
    output = dict(status='PASS', frozen_inputs_verified=verified,
        downloaded_member_sha_verified=len(download['files']),output_sha_verified=len(prepared['output_sha256']),
        frame_selection_recomputed_exact=True,new_frames=selected,old_frame_overlap=0,
        examples=len(y),old_canonical_count=len(old_keys),new_canonical_count=len(set(keys)),
        HV_old_overlap=0,HV_internal_duplicates=0,class_labels_exact=True,
        class_counts=counts.tolist(),class_frame_support=(support>0).sum(0).tolist(),data_gate=True,
        independent_svg_token_parser=True,source_patches_exact=sample_rows,
        D4_only_diagnostic=dict(old_related_examples=int(related_old.sum()),
            old_related_fraction=float(related_old.mean()),
            old_related_per_frame={str(int(f)):int(related_old[frame==f].sum()) for f in selected},
            old_related_class_counts=np.bincount(truth[related_old],minlength=9).tolist(),
            internally_quarter_turn_related_examples=int(related_new.sum()),
            interpretation='Diagnostic only; primary dataset unchanged; no model scores computed'),
        new_model_predictions_computed=False,seconds=time.monotonic()-start,
        audit_input_sha256=audit_frozen)
    assert all(sha(Path(path))==expected for path,expected in audit_frozen.items())
    (HERE/'DATA_AUDIT.json').write_text(json.dumps(output,indent=2)+'\n')
    # Store flags so later sensitivity can use the frozen diagnostic rather
    # than deciding a filter after seeing model outcomes.
    np.savez_compressed(HERE/'D4_DIAGNOSTIC.npz',old_related=related_old,internally_related=related_new,
                        truth=truth,frame=frame)
    print(json.dumps({k:v for k,v in output.items() if k not in ['source_patches_exact','audit_input_sha256']},indent=2))


if __name__=='__main__':
    main()
