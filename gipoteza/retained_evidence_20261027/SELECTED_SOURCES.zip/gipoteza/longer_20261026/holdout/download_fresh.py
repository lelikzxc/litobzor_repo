"""Select and range-download twelve frozen, unseen realSEM M2 frames."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys
import hashlib
import json
import re
import struct
import time
import zipfile
import zlib

HERE = Path(__file__).resolve().parent
OLD = HERE.parents[1] / 'search_20261026'
sys.path.insert(0, str(OLD))
from sem_remote_zip import RemoteZip, URL, SIZE


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')


def select():
    listing_path = OLD/'sem_zip_listing.json'
    listing = json.loads(listing_path.read_text())
    by_name = {row['name']: row for row in listing}
    manifests = [OLD/name/'MANIFEST.json' for name in
                 ['sem_electrical', 'sem_replication', 'sem_graded_test']]
    used = set(range(10))
    for path in manifests:
        used.update(int(row['frame']) for row in json.loads(path.read_text()))
    available = []
    for row in listing:
        match = re.fullmatch(r'dataset/sems/m2/sem(\d+)\.png', row['name'])
        if match and f'dataset/labels/m2/label{int(match.group(1)):04}.svg' in by_name:
            available.append(int(match.group(1)))
    pool = sorted(set(available)-used, key=lambda frame: hashlib.sha256(
        f'longer_20261026/{frame}'.encode()).hexdigest())
    selected = pool[:12]
    assert len(selected) == 12
    names = [name for frame in selected for name in
             [f'dataset/labels/m2/label{frame:04}.svg', f'dataset/sems/m2/sem{frame:04}.png']]
    rows = [by_name[name] for name in names]
    assert sum(row['size'] for row in rows) < 150_000_000
    result = dict(frames=selected, excluded_frames=sorted(used), available_pair_count=len(available),
        rule="first12 by SHA256 UTF-8('longer_20261026/'+decimalID_without_padding)",
        selected_members=rows, total_bytes=sum(row['size'] for row in rows),
        url=URL, persistent_id='doi:10.17617/3.HY5SYN', license='CC BY 4.0')
    dest = HERE/'REMOTE_SELECTION.json'
    if dest.exists():
        assert json.loads(dest.read_text()) == result
    else:
        save(dest, result)
    files = [Path(__file__), HERE/'REMOTE_PROTOCOL.md', listing_path, *manifests, dest,
             OLD/'sem_remote_zip.py']
    frozen = {str(path): sha(path) for path in files}
    target = HERE/'REMOTE_FROZEN.json'
    if target.exists():
        assert json.loads(target.read_text()) == frozen
    else:
        save(target, frozen)
    print(json.dumps(dict(status='SELECTION_FROZEN', frames=selected,
                         total_bytes=result['total_bytes'])), flush=True)
    return result, frozen


def fetch(info):
    name = info.filename
    dest = HERE/'newdata'/name
    assert info.compress_type == 0
    if dest.exists():
        raw = dest.read_bytes()
    else:
        remote = RemoteZip()
        remote.seek(info.header_offset)
        size = min(30+len(name.encode())+2048+info.file_size, SIZE-info.header_offset)
        block = remote.read(size)
        header = struct.unpack('<4s5H3L2H', block[:30])
        assert header[0] == b'PK\x03\x04'
        nname, nextra = header[-2:]
        assert block[30:30+nname].decode('utf-8') == name
        begin = 30+nname+nextra
        raw = block[begin:begin+info.file_size]
        assert len(raw) == info.file_size
        assert zlib.crc32(raw) == info.CRC
        dest.parent.mkdir(parents=True, exist_ok=True)
        temp = dest.with_suffix(dest.suffix+'.part')
        temp.write_bytes(raw); temp.replace(dest)
    assert len(raw) == info.file_size
    assert zlib.crc32(raw) == info.CRC
    return dict(name=name, bytes=len(raw), crc32=info.CRC,
                sha256=hashlib.sha256(raw).hexdigest())


def main():
    start = time.monotonic()
    chosen, frozen = select()
    with zipfile.ZipFile(RemoteZip()) as archive:
        infos = [archive.getinfo(row['name']) for row in chosen['selected_members']]
    for old, info in zip(chosen['selected_members'], infos):
        assert old['offset'] == info.header_offset and old['size'] == info.file_size
    records = []
    try:
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(fetch, info) for info in infos]
            for future in as_completed(futures):
                row = future.result(); records.append(row)
                save(HERE/'DOWNLOAD_PROGRESS.json', dict(completed=len(records), total=len(infos),
                      seconds=time.monotonic()-start, files=records))
                print(json.dumps(dict(completed=len(records), **row)), flush=True)
    except Exception as exc:
        save(HERE/'DOWNLOAD_ERROR.json', dict(error=repr(exc), files=records,
             seconds=time.monotonic()-start))
        raise
    assert all(sha(Path(path)) == expected for path, expected in frozen.items())
    result = dict(url=URL, persistent_id='doi:10.17617/3.HY5SYN', license='CC BY 4.0',
                  frames=chosen['frames'], files=sorted(records, key=lambda row: row['name']),
                  total_bytes=sum(row['bytes'] for row in records), seconds=time.monotonic()-start)
    save(HERE/'DOWNLOAD.json', result)
    print(json.dumps(dict(status='DOWNLOAD_COMPLETE', frames=result['frames'],
                         bytes=result['total_bytes'], seconds=result['seconds'])), flush=True)


if __name__ == '__main__':
    main()
