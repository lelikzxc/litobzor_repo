"""CPU synthetic-array checks; no real model scoring, training, or test access."""
from pathlib import Path
import hashlib
import json
import numpy as np
from sklearn.metrics import f1_score
import evaluate_long as ev

HERE = Path(__file__).resolve().parent


def independent_macro(cm):
    pieces = []
    for c in range(9):
        numerator = 2*cm[..., c, c]
        denominator = cm[..., c, :].sum(-1)+cm[..., :, c].sum(-1)
        pieces.append(np.divide(numerator, denominator, out=np.zeros_like(numerator, dtype=float), where=denominator>0))
    return np.stack(pieces, axis=-1).mean(-1)


def independent_bootstrap(cm):
    rng = np.random.default_rng(260026)
    samples = []
    for _ in range(4000):
        seeds = rng.integers(0, 8, 8)
        groups = rng.integers(0, cm.shape[2], cm.shape[2])
        weights = np.bincount(groups, minlength=cm.shape[2])
        combined = np.einsum('msgab,g->msab', cm, weights)
        samples.append(independent_macro(combined[:, seeds]).mean(-1))
    return np.array(samples)


def run():
    rng = np.random.default_rng(741852)
    n = 324
    truth = np.arange(n) % 9
    group = np.repeat(np.arange(12), 27)
    pred = rng.integers(0, 9, (len(ev.METHODS), 8, n), dtype=np.int8)
    cm = ev.confusion(truth, pred, group)
    assert cm.shape == (5, 8, 12, 9, 9)
    assert (cm.sum((-1,-2,-3)) == n).all()
    scores = ev.score(cm.sum(2))
    reference = np.array([[f1_score(truth, pred[m,s], labels=range(9), average='macro', zero_division=0)
                           for s in range(8)] for m in range(5)])
    np.testing.assert_allclose(scores, reference, atol=1e-15, rtol=0)
    boot = ev.bootstrap(cm)
    independent = independent_bootstrap(cm)
    np.testing.assert_allclose(boot, independent, atol=1e-15, rtol=0)
    # Same resampling produces exactly paired deltas, including identity=zero.
    assert np.array_equal(ev.bootstrap(cm)-boot, np.zeros_like(boot))
    alternate = cm.copy()
    alternate[..., 0,0] += 7
    delta = ev.bootstrap(alternate)-boot
    np.testing.assert_allclose(delta, independent_bootstrap(alternate)-independent, atol=1e-15, rtol=0)
    hard = rng.integers(0,2,(5,8,23,12,12)).astype(bool)
    packed = np.packbits(hard.reshape(5,8,23,144), axis=-1)
    assert packed.shape == (5,8,23,18)
    decoded = np.unpackbits(packed, axis=-1, count=144).astype(bool).reshape(hard.shape)
    assert np.array_equal(decoded, hard)
    blanks = np.arange(23)%3 == 0
    decoded_blanks = np.unpackbits(packed[0][:,blanks], axis=-1, count=144).astype(bool)
    assert np.array_equal(decoded_blanks, hard[0][:,blanks].reshape(8,-1,144))
    # Check checkpoint routing through the exact branch structure used in main.
    selection = dict(replay=400,strong_soft=1000,connectivity=2000,joint=1000)
    routes = {}
    for stage in ev.STAGES:
        routes[stage] = {}
        for method in ev.METHODS:
            step = 0 if method=='base' else 400 if stage=='fixed400' else 2000 if stage=='fixed2000' else selection[method]
            routes[stage][method] = step
    assert all(s == (0 if m=='base' else 2000) for m,s in routes['fixed2000'].items())
    assert all(s == (0 if m=='base' else 400) for m,s in routes['fixed400'].items())
    assert routes['val_selected']['base']==0
    assert {m:s for m,s in routes['val_selected'].items() if m!='base'} == selection
    report = dict(scope='Synthetic-array CPU helper audit; no real test/model scoring',
        fake_examples=n, methods=5, seeds=8, groups=12, bootstrap_draws=4000,
        f1_max_error=float(np.max(np.abs(scores-reference))),
        bootstrap_max_error=float(np.max(np.abs(boot-independent))),
        packed_bytes_per_mask=18, packed_roundtrip_exact=True, paired_growth_exact=True,
        fixed2000_route_exact=True,
        checked_script_sha256=hashlib.sha256((HERE/'evaluate_long.py').read_bytes()).hexdigest())
    (HERE/'EVALUATION_HELPER_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    run()
