"""Frozen REFICS transfer evaluation; never trains or selects by target labels."""
from pathlib import Path
import hashlib
import json
import sys
import time

import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from sklearn.metrics import f1_score
import torch

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'search_20261026'
sys.path.insert(0, str(OLD))
import sem_joint_development as dev
import structured12_learning as e6

SEEDS = [101, 173, 257]
METHODS = ['base', 'soft', 'strong_soft', 'connectivity', 'joint', 'otsu']
NORMS = ['raw', 'input_percentiles']
OUT = HERE / 'transfer_result'
START = time.monotonic()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def log(message):
    print(f'{time.monotonic()-START:.1f}s {message}', flush=True)


def checkpoint(method, seed):
    if method == 'strong_soft':
        return HERE / f'baselines/final_models/strong_soft_{seed}.pt'
    return OLD / f'sem_graded_test/{method}_{seed}.pt'


def prepare(manifest):
    xx, yy, uid, node, mag = [], [], [], [], []
    coarse_inputs = []
    for k, row in enumerate(manifest):
        paths = row['files']
        image = np.asarray(Image.open(HERE / 'transfer_data' / paths['sem']['path']))
        original = np.asarray(Image.open(HERE / 'transfer_data' / paths['mask']['path']))
        binary = np.asarray(Image.open(HERE / 'transfer_data' / paths['mask_binary']['path'])) > 0
        assert image.shape == original.shape == binary.shape == (250, 250)
        assert np.array_equal(original > 0, binary)
        x = image[5:245, 5:245].reshape(60, 4, 60, 4).mean((1, 3)).astype(np.float32) / 255
        y = binary[5:245, 5:245].reshape(60, 4, 60, 4).mean((1, 3)) >= .5
        coarse_inputs.append(x)
        for r in range(0, 60, 12):
            for c in range(0, 60, 12):
                xx.append(x[r:r+12, c:c+12]); yy.append(y[r:r+12, c:c+12])
                uid.append(k); node.append(row['node_nm']); mag.append(row['magnification'])
    assert len(xx) == 1600
    return (np.array(xx), np.array(yy), np.array(uid), np.array(node),
            np.array(mag), np.array(coarse_inputs))


def normalize(x, name):
    if name == 'raw':
        return x
    lo, hi = np.quantile(x, [.01, .99], axis=(1, 2))
    t = np.clip((x - lo[:, None, None]) / np.maximum(hi - lo, .05)[:, None, None], 0, 1)
    return (.1357843131 + t * (.9764705896 - .1357843131)).astype(np.float32)


def otsu_mask(x):
    # Fixed 256 bins in /255 grayscale units. Lowest maximizer wins ties.
    hist, edges = np.histogram(x, bins=256, range=(0., 1.))
    if np.count_nonzero(hist) <= 1:
        return np.zeros_like(x, dtype=bool)
    centers = (edges[:-1] + edges[1:]) / 2
    count = hist.cumsum(); sums = (hist * centers).cumsum()
    denom = count[:-1] * (count[-1] - count[:-1])
    score = np.divide((sums[-1] * count[:-1] - sums[:-1] * count[-1])**2,
                      denom, out=np.zeros(255), where=denom > 0)
    threshold = centers[int(np.argmax(score))]
    return x > threshold


def predict(method, seed, x):
    net = e6.network()
    net.load_state_dict(torch.load(checkpoint(method, seed), weights_only=True))
    net = net.to('mps').eval()
    masks = []
    with torch.inference_mode():
        for start in range(0, len(x), 256):
            batch = torch.tensor(5 * (x[start:start+256, None] - .2), device='mps')
            masks.append((net(batch)[:, 0] >= 0).cpu().numpy())
    return np.concatenate(masks)


def iou(hard, truth):
    intersection = (hard & truth).sum((-1, -2)); union = (hard | truth).sum((-1, -2))
    return np.divide(intersection, union, out=np.ones_like(union, dtype=float), where=union > 0)


def macro(cm, labels):
    tp = np.diagonal(cm, axis1=-2, axis2=-1)
    den = cm.sum(-1) + cm.sum(-2)
    values = np.divide(2 * tp, den, out=np.zeros_like(tp, dtype=float), where=den > 0)
    return values[..., labels].mean(-1)


def component_errors(hard, truth):
    """Local overlap diagnostics, not the published ESD metric/netlist errors."""
    rows = []
    for p, y in zip(hard, truth):
        a, na = ndi.label(y); b, nb = ndi.label(p)
        overlap = np.zeros((na+1, nb+1), bool)
        overlap[a.ravel(), b.ravel()] = True
        overlap = overlap[1:, 1:]
        opens = np.maximum(overlap.sum(1)-1, 0).sum()
        shorts = np.maximum(overlap.sum(0)-1, 0).sum()
        fp = (overlap.sum(0) == 0).sum()
        fn = (overlap.sum(1) == 0).sum()
        rows.append([opens, shorts, fp, fn])
    return np.array(rows, dtype=np.int64)


def assess(predictions, masks, truth, y, uid, node):
    all_metrics = {}
    cm = np.zeros((len(METHODS), len(SEEDS), 64, 9, 9), np.int64)
    for j in range(len(METHODS)):
        for s in range(len(SEEDS)):
            np.add.at(cm[j, s], (uid, truth, predictions[j, s]), 1)
    for domain in ['pooled', '32', '90']:
        ids = np.ones(len(y), bool) if domain == 'pooled' else node == int(domain)
        groups = np.unique(uid[ids]); labels = np.unique(truth[ids])
        blank = ids & ~y.any((1, 2)); nonblank = ids & y.any((1, 2))
        metrics = {}
        for j, method in enumerate(METHODS):
            pooled = cm[j][:, groups].sum(1)
            per_seed = macro(pooled, labels)
            assert np.allclose(per_seed, [f1_score(truth[ids], predictions[j, s, ids], labels=labels, average='macro', zero_division=0) for s in range(3)])
            ii = iou(masks[j], y[None])
            local = np.array([component_errors(masks[j, s, ids], y[ids]).sum(0) for s in range(3)])
            metrics[method] = dict(macro_f1_present=float(per_seed.mean()), per_seed_f1=per_seed.tolist(),
                macro_f1_all9=float(macro(pooled, np.arange(9)).mean()),
                mean_iou=float(ii[:, ids].mean()), nonblank_iou=float(ii[:, nonblank].mean()),
                blank_tiles=int(blank.sum()), blank_any_foreground_rate=float(masks[j, :, blank].any((-1,-2)).mean()),
                blank_false_connection_rate=float((predictions[j][:, blank] != 0).mean()),
                blank_foreground_pixel_fraction=float(masks[j, :, blank].mean()),
                local_component_errors_mean_total=dict(zip(['opens','shorts','false_positive','false_negative'], local.mean(0).tolist())))
        rng = np.random.default_rng(2301)
        boots = []
        for _ in range(4000):
            si = rng.integers(0, 3, 3); gi = groups[rng.integers(0, len(groups), len(groups))]
            pooled = cm[:, si][:, :, gi].sum(2)
            boots.append(macro(pooled, labels).mean(1))
        boots = np.array(boots); proposal = METHODS.index('joint'); comparisons = {}
        for j, method in enumerate(METHODS):
            if method == 'joint':
                continue
            comparisons[method] = dict(delta=metrics['joint']['macro_f1_present']-metrics[method]['macro_f1_present'],
                ci95=np.quantile(boots[:, proposal]-boots[:, j], [.025,.975]).tolist(),
                iou_delta=metrics['joint']['mean_iou']-metrics[method]['mean_iou'])
        comp = comparisons['strong_soft']
        passed = comp['delta'] >= .01 and comp['ci95'][0] > 0 and comp['iou_delta'] >= -.02
        all_metrics[domain] = dict(examples=int(ids.sum()), uids=len(groups), present_classes=labels.tolist(),
            class_counts=np.bincount(truth[ids], minlength=9).tolist(), metrics=metrics,
            comparisons=comparisons, gate=bool(passed))
    return all_metrics, cm


def main():
    OUT.mkdir(exist_ok=False)
    assert torch.backends.mps.is_available()
    torch.set_num_threads(2)
    manifest_path = HERE / 'transfer_data/refics_manifest.json'
    manifest = json.loads(manifest_path.read_text()); assert len(manifest) == 64
    files = [Path(__file__), HERE/'TRANSFER_PROTOCOL.md', manifest_path,
        HERE/'baselines/final_models/COMPLETE.json', HERE/'baselines/grid_v2/RESULT.json',
        OLD/'structured12_learning.py', OLD/'structured12_prepare.py', OLD/'sem_joint_development.py']
    for row in manifest:
        for kind in ['sem','mask','mask_binary']:
            item = row['files'][kind]; p = HERE/'transfer_data'/item['path']
            assert sha(p) == item['sha256']; files.append(p)
    files.extend(checkpoint(m, s) for m in METHODS if m != 'otsu' for s in SEEDS)
    frozen = {str(p):sha(p) for p in files}; save('FROZEN.json', frozen)
    x, y, uid, node, mag, coarse = prepare(manifest)
    truth = dev.classes(y)
    np.savez_compressed(OUT/'PATCHES.npz', X=x, Y=y, truth=truth, uid_index=uid, node_nm=node, magnification=mag)
    log(f'prepared {len(x)} tiles, counts={np.bincount(truth,minlength=9).tolist()}')
    predictions = []; masks_all = []; metrics_all = {}; confusion = []
    for norm in NORMS:
        xn = normalize(x, norm); masks = []; preds = []
        for method in METHODS:
            mm = []; pp = []
            if method == 'otsu':
                hard = np.array([otsu_mask(c) for c in coarse])
                hard = hard.reshape(64, 5, 12, 5, 12).transpose(0,1,3,2,4).reshape(-1,12,12)
            for seed in SEEDS:
                if method != 'otsu':
                    hard = predict(method, seed, xn)
                mm.append(hard); pp.append(dev.classes(hard))
                log(f'{norm} {method} seed={seed}')
            masks.append(mm); preds.append(pp)
        masks = np.array(masks); preds = np.array(preds)
        metrics, cm = assess(preds, masks, truth, y, uid, node)
        metrics_all[norm] = metrics; confusion.append(cm)
        masks_all.append(masks); predictions.append(preds)
        np.savez_compressed(OUT/f'PREDICTIONS_{norm}.npz', masks=masks, predictions=preds, truth=truth,
            uid_index=uid, node_nm=node, confusion=cm, methods=np.array(METHODS), seeds=np.array(SEEDS))
        save('PROGRESS.json', metrics_all)
    assert all(sha(Path(p)) == h for p,h in frozen.items())
    result = dict(scope='External synthetic REFICS geometries; no target training; proxy electrical classes',
        seconds=time.monotonic()-START, primary='raw', methods=METHODS, seeds=SEEDS,
        metrics=metrics_all, primary_gate=bool(all(v['gate'] for v in metrics_all['raw'].values())),
        limitations=['One AES layout per node, unknown overlapping crop locations',
            'No measured electrical values; binary unit-resistor proxy',
            'Local component overlap counts are not published ESD/netlist metrics'])
    save('RESULT.json', result); log(json.dumps(dict(primary_gate=result['primary_gate'], seconds=result['seconds'])))


if __name__ == '__main__':
    main()
