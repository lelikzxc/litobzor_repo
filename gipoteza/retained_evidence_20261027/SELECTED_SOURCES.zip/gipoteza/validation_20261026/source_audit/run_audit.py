"""Post-hoc corrected-control audit of frozen E14; no training or selection."""
from pathlib import Path
import sys, json, hashlib, time
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
VALIDATION = HERE.parent
OLD = VALIDATION.parent / 'search_20261026'
sys.path.insert(0, str(OLD))
import structured12_learning as e6
import sem_joint_development as dev

SEEDS = [101, 173, 257]


def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def infer(checkpoint, raw):
    net = e6.network()
    net.load_state_dict(torch.load(checkpoint, map_location='cpu', weights_only=True))
    net = net.to('mps').eval()
    masks = []
    with torch.inference_mode():
        for start in range(0, len(raw), 256):
            x = torch.tensor(5 * (raw[start:start+256, None] - .2), device='mps')
            masks.append((net(x)[:, 0] >= 0).cpu().numpy())
    return np.concatenate(masks)


def iou(masks, truth):
    inter = (masks & truth).sum((1, 2))
    union = (masks | truth).sum((1, 2))
    return np.divide(inter, union, out=np.ones(len(union)), where=union > 0)


def confusion(truth, prediction, frame):
    frames = np.unique(frame)
    out = np.zeros((len(prediction), len(frames), 9, 9), dtype=np.int64)
    for s, p in enumerate(prediction):
        for fi, f in enumerate(frames):
            ids = frame == f
            np.add.at(out[s, fi], (truth[ids], p[ids]), 1)
    return out


def score(cm):
    tp = np.diagonal(cm, axis1=-2, axis2=-1)
    den = cm.sum(-1) + cm.sum(-2)
    return np.divide(2*tp, den, out=np.zeros_like(tp, dtype=float), where=den > 0).mean(-1)


def main():
    start = time.monotonic()
    assert torch.backends.mps.is_available(), 'MPS required'
    torch.set_num_threads(2)
    files = [Path(__file__), VALIDATION/'TRANSFER_PROTOCOL.md',
             OLD/'structured12_learning.py', OLD/'structured12_prepare.py',
             OLD/'sem_joint_development.py', OLD/'sem_graded_test/PATCHES.npz',
             OLD/'sem_graded_test/PREDICTIONS.npz',
             VALIDATION/'baselines/final_models/COMPLETE.json',
             VALIDATION/'baselines/final_models/SELECTED.json']
    files += [VALIDATION/f'baselines/final_models/strong_soft_{s}.pt' for s in SEEDS]
    files += [OLD/f'sem_graded_test/joint_{s}.pt' for s in SEEDS]
    frozen = {str(p.resolve()): sha(p) for p in files}
    save(HERE/'FROZEN.json', frozen)
    data = np.load(OLD/'sem_graded_test/PATCHES.npz')
    previous = np.load(OLD/'sem_graded_test/PREDICTIONS.npz')
    raw, masks, truth, frame = (data[k] for k in ['X', 'Y', 'truth', 'frame'])
    assert np.array_equal(truth, previous['truth'])
    assert np.array_equal(frame, previous['frame'])
    assert len(raw) == 22419
    validations = []
    for si, seed in enumerate(SEEDS):
        reproduced = infer(OLD/f'sem_graded_test/joint_{seed}.pt', raw[:256])
        pp = dev.classes(reproduced)
        ii = iou(reproduced, masks[:256])
        assert np.array_equal(pp, previous['joint'][si, :256])
        assert np.array_equal(ii, previous['iou_joint'][si, :256])
        validations.append(dict(seed=seed, examples=256, class_exact=True, iou_exact=True))
    pred, hard, ious = [], [], []
    for seed in SEEDS:
        hh = infer(VALIDATION/f'baselines/final_models/strong_soft_{seed}.pt', raw)
        pp = dev.classes(hh)
        hard.append(hh); pred.append(pp); ious.append(iou(hh, masks))
        print('seed', seed, 'finished at', round(time.monotonic()-start, 2), flush=True)
        save(HERE/'PROGRESS.json', dict(seed=seed, seconds=time.monotonic()-start))
    pred, hard, ious = np.asarray(pred), np.asarray(hard), np.asarray(ious)
    names = ['joint', 'strong_soft', 'old_soft']
    predictions = [previous['joint'], pred, previous['soft']]
    io = [previous['iou_joint'], ious, previous['iou_soft']]
    cms = np.asarray([confusion(truth, pp, frame) for pp in predictions])
    np.savez_compressed(HERE/'PREDICTIONS.npz', truth=truth, frame=frame,
                        strong_soft=pred, hard_strong_soft=hard, iou_strong_soft=ious,
                        joint=previous['joint'], iou_joint=previous['iou_joint'],
                        old_soft=previous['soft'], iou_old_soft=previous['iou_soft'],
                        confusion=cms, methods=np.asarray(names), seeds=np.asarray(SEEDS))
    metrics = {}
    for name, cm, ii in zip(names, cms, io):
        per_seed = score(cm.sum(1))
        metrics[name] = dict(macro_f1=float(per_seed.mean()),
                             per_seed_f1=per_seed.tolist(), iou=float(ii.mean()),
                             per_seed_iou=ii.mean(1).tolist())
    rng = np.random.default_rng(2301)
    boot = []
    for _ in range(4000):
        si = rng.integers(0, 3, 3)
        fi = rng.integers(0, len(np.unique(frame)), len(np.unique(frame)))
        boot.append(score(cms[:, si][:, :, fi].sum(2)).mean(1))
    boot = np.asarray(boot)
    delta = metrics['joint']['macro_f1'] - metrics['strong_soft']['macro_f1']
    ci = np.quantile(boot[:, 0]-boot[:, 1], [.025, .975]).tolist()
    drop = metrics['strong_soft']['iou'] - metrics['joint']['iou']
    gate = bool(delta >= .01 and ci[0] > 0 and drop <= .02)
    assert all(sha(Path(p)) == h for p, h in frozen.items()), 'Frozen inputs changed'
    result = dict(scope='Post-hoc corrected-baseline audit of old E14 TEST; not fresh confirmation',
                  selection='Strong soft configuration selected exclusively on old TRAIN/VAL; test unused for selection',
                  examples=len(truth), frames=np.unique(frame).tolist(), seeds=SEEDS,
                  metrics=metrics,
                  comparison=dict(delta_joint_minus_strong_soft=delta, ci95_paired_frame_seed=ci,
                                  iou_drop_joint=drop, criterion_delta_min=.01,
                                  criterion_iou_drop_max=.02, bootstrap_draws=4000,
                                  bootstrap_seed=2301, gate=gate),
                  reproduction=validations, frozen_files_verified=len(frozen),
                  seconds=time.monotonic()-start)
    save(HERE/'RESULT.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
