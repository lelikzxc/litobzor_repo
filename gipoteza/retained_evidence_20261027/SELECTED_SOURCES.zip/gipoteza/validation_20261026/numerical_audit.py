"""Retained CPU-only numerical audit. No optimizer, training, or old-file writes.

These are fresh deterministic reruns, not recovery of the vanished historical
/private/tmp/e14_code_review/diagnostics.py or its exact random vectors.
"""
from pathlib import Path
import sys, json, hashlib, time
import numpy as np
import torch
from sklearn.metrics import f1_score

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'search_20261026'
sys.path.insert(0, str(OLD))
import structured12_learning as e6
import sem_joint_development as dev


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def independent_dirichlet(mask):
    """Build graph from coordinates; pinv all interior nodes, compare energy.

    Does not call the fast solver, its connected-component optimization, graph
    constants, or its Schur-complement expression.
    """
    mask = np.asarray(mask, bool)
    height, width = mask.shape
    n = height * width
    lap = np.zeros((n, n), dtype=np.float64)
    edges = []
    for y in range(height):
        for x in range(width):
            if not mask[y, x]:
                continue
            i = y*width+x
            for dy, dx in [(0, 1), (1, 0)]:
                yy, xx = y+dy, x+dx
                if yy < height and xx < width and mask[yy, xx]:
                    j = yy*width+xx
                    edges.append((i, j))
                    lap[i, i] += 1; lap[j, j] += 1
                    lap[i, j] -= 1; lap[j, i] -= 1
    left = np.arange(0, n, width)
    right = np.arange(width-1, n, width)
    boundary = np.r_[left, right]
    free = np.setdiff1d(np.arange(n), boundary)
    v = np.zeros(n, dtype=np.float64)
    v[right] = 1
    if len(free):
        rhs = -lap[np.ix_(free, boundary)] @ v[boundary]
        v[free] = np.linalg.pinv(lap[np.ix_(free, free)], hermitian=True, rcond=1e-12) @ rhs
    energy = sum((v[i]-v[j])**2 for i, j in edges)
    return float(energy / (height/(width-1)))


def joint_loss(prob, target):
    q = dev.probabilities(prob)
    lower, upper = dev.interval_bounds(q, target)
    lower = lower.max(1).values
    upper = upper.min(1).values
    return -.5*(upper.clamp_min(1e-7).log() + (1-lower).clamp_min(1e-7).log()).mean()


def run():
    start = time.monotonic()
    torch.set_num_threads(2)
    rng = np.random.default_rng(20261026)
    frozen = json.loads((OLD/'sem_graded_test/FROZEN.json').read_text())
    checks = {k: sha(OLD/k) == v for k, v in frozen.items()}
    assert len(checks) == 13 and all(checks.values())
    inputs = [Path(__file__), OLD/'sem_graded_test/FROZEN.json',
              OLD/'sem_graded_test/PREDICTIONS.npz', OLD/'sem_graded_test/RESULT.json',
              OLD/'structured12_learning.py', OLD/'structured12_prepare.py',
              OLD/'sem_joint_development.py']
    audit_frozen = {str(p.resolve()): sha(p) for p in inputs}

    analytic = [np.zeros((12, 12), bool), np.ones((12, 12), bool)]
    row = np.zeros((12, 12), bool); row[5, :] = True
    col = row.T.copy()
    analytic.extend([row, col, np.eye(12, dtype=bool)])
    images = np.asarray(analytic + [rng.random((12, 12)) < density for density in np.linspace(.1, .95, 36)])
    direct = np.asarray([independent_dirichlet(im) for im in images])
    fast = e6.binary_response(images)
    exact = np.asarray([0, 1, 1/12, 0, 0])
    binary_error = float(np.max(np.abs(direct-fast)))
    analytic_error = float(np.max(np.abs(direct[:5]-exact)))
    assert binary_error < 1e-10 and analytic_error < 1e-10
    print('binary', binary_error, flush=True)

    raw = rng.uniform(.05, .95, (3, 1, 12, 12))
    p = torch.tensor(raw, dtype=torch.float64, requires_grad=True)
    e6.soft_response(p).sum().backward()
    errors, coordinates = [], []
    for b in range(3):
        for flat in rng.choice(144, 8, replace=False):
            index = (b, 0, int(flat//12), int(flat%12))
            plus, minus = raw.copy(), raw.copy()
            plus[index] += 1e-6; minus[index] -= 1e-6
            fp = float(e6.soft_response(torch.tensor(plus, dtype=torch.float64)).sum())
            fm = float(e6.soft_response(torch.tensor(minus, dtype=torch.float64)).sum())
            finite = (fp-fm)/2e-6
            auto = float(p.grad[index])
            errors.append(abs(finite-auto))
            coordinates.append(dict(index=list(index), finite_difference=finite, autograd=auto))
    soft_error = float(max(errors))
    assert soft_error < 1e-6
    print('soft', soft_error, flush=True)

    # Strictly separated values keep each probability order fixed under ±eps.
    ordered = np.linspace(.07, .93, 144)
    raw = np.asarray([rng.permutation(ordered+rng.uniform(-1e-4, 1e-4, 144)) for _ in range(5)]).reshape(5, 1, 12, 12)
    p = torch.tensor(raw, dtype=torch.float64, requires_grad=True)
    target = torch.ones((5, 2), dtype=torch.long)  # class1 in each direction
    joint_loss(p, target).backward()
    active = np.argwhere(np.abs(p.grad.numpy()) > 1e-12)
    assert len(active) >= 8
    errors, joint_coordinates = [], []
    for idx in active[:8]:
        index = tuple(idx)
        plus, minus = raw.copy(), raw.copy()
        plus[index] += 1e-6; minus[index] -= 1e-6
        assert np.array_equal(np.argsort(plus.reshape(5, 144)), np.argsort(minus.reshape(5, 144)))
        fp = float(joint_loss(torch.tensor(plus, dtype=torch.float64), target))
        fm = float(joint_loss(torch.tensor(minus, dtype=torch.float64), target))
        finite = (fp-fm)/2e-6
        auto = float(p.grad[index])
        errors.append(abs(finite-auto))
        joint_coordinates.append(dict(index=idx.tolist(), finite_difference=finite, autograd=auto))
    joint_error = float(max(errors))
    assert joint_error < 1e-6
    print('joint', joint_error, flush=True)

    z = np.load(OLD/'sem_graded_test/PREDICTIONS.npz')
    original = json.loads((OLD/'sem_graded_test/RESULT.json').read_text())
    metric_rows = {}
    for name, original_row in original['metrics'].items():
        values = [float(f1_score(z['truth'], pred, labels=range(9), average='macro', zero_division=0)) for pred in z[name]]
        value = float(np.mean(values))
        err = abs(value-original_row['macro_f1'])
        assert err < 1e-14
        row = dict(macro_f1=value, per_seed_f1=values, absolute_error=err)
        if 'iou_'+name in z.files:
            row['iou'] = float(z['iou_'+name].mean())
            row['iou_absolute_error'] = abs(row['iou']-original_row['iou'])
            assert row['iou_absolute_error'] < 1e-14
        metric_rows[name] = row
    assert len(metric_rows) == 7
    assert all(sha(Path(p)) == value for p, value in audit_frozen.items())
    assert all(sha(OLD/p) == value for p, value in frozen.items())
    result = dict(scope='Fresh deterministic independent CPU numerical rerun; no training; no old-file writes',
                  historical_status='Does not recover old temporary script or exact historical random vectors; historical report numbers remain historical',
                  random_seed=20261026, python=sys.version, numpy=np.__version__, torch=torch.__version__,
                  binary=dict(masks=41, analytic_masks=['empty', 'full', 'one_horizontal_row', 'one_vertical_column', 'diagonal'],
                              independent_solver='Coordinate-built graph, all-interior pseudoinverse Dirichlet solve, energy current',
                              max_abs_error=binary_error, analytic_max_abs_error=analytic_error,
                              fast=fast.tolist(), independent=direct.tolist()),
                  soft_gradient=dict(dtype='float64', vectors=3, coordinates=24, epsilon=1e-6, max_abs_error=soft_error, details=coordinates),
                  joint_gradient=dict(dtype='float64', vectors=5, active_coordinates=8, epsilon=1e-6,
                                      target='middle class in both directions', strict_order_verified=True,
                                      max_abs_error=joint_error, details=joint_coordinates),
                  metrics=metric_rows, historical_frozen_sha256=dict(files=13, all_match=all(checks.values()), checks=checks),
                  audit_frozen_sha256=audit_frozen, seconds=time.monotonic()-start)
    (HERE/'NUMERICAL_AUDIT.json').write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
    print(json.dumps({k: result[k] for k in ['scope', 'seconds']}), flush=True)


if __name__ == '__main__':
    run()
