import cv2
from matplotlib import pyplot as plt
import numpy as np
from random import choice
import random
import os
import multiprocessing as mp
import time


class SemAugmentationGenerator:
    def __init__(self, full_image, shape_of_image=(250, 250)):
        self.full_image = full_image
        self.r_sample, self.c_sample = shape_of_image
        self.row_start, self.col_start = None, None
        self.image = None
        self._stitch_flag = True
        self.label = None
        self.ground_truth_im = np.zeros(shape_of_image)
        self.full_im_temp_buf = None

    def _erase_edges(self, radius, corner_point, corner_type):
        r, c = np.shape(self.image)
        if corner_type == "up_left":
            max_j = np.inf
            for i in range(corner_point[0], min(corner_point[0] + radius - 1, r)):
                flag, j = True, corner_point[1]
                while flag and j < max_j:
                    if j < c - 1:
                        if self.image[i, j]:
                            self.image[i, j] = 0
                        else:
                            max_j = min(j, max_j)
                            flag = False
                        j += 1
                    else:
                        max_j = min(j, max_j)
                        flag = False
        if corner_type == "up_right":
            max_j = np.inf
            for i in range(0, radius):
                flag, j = True, corner_point[1]
                while flag and j < max_j:
                    if j < c - 1:
                        if self.image[corner_point[0] - i, j]:
                            self.image[corner_point[0] - i, j] = 0
                        else:
                            max_j = min(j, max_j)
                            flag = False
                        j += 1
                    else:
                        max_j = min(j, max_j)
                        flag = False
        if corner_type == "bt_left":
            max_j = 0
            for i in range(corner_point[0], min(corner_point[0] + radius, r)):
                flag, j = True, corner_point[1]
                while flag and j > max_j:
                    if j > 0:
                        if self.image[i, j]:
                            self.image[i, j] = 0
                        else:
                            max_j = max(j, max_j)
                            flag = False
                        j -= 1
                    else:
                        max_j = max(j, max_j)
                        flag = False

        if corner_type == "bt_right":
            max_j = 0
            for i in range(0, radius):
                flag, j = True, corner_point[1]
                while flag and j > max_j:
                    if j > 0:
                        if self.image[corner_point[0] - i, j]:
                            self.image[corner_point[0] - i, j] = 0
                        else:
                            max_j = max(j, max_j)
                            flag = False
                        j -= 1
                    else:
                        max_j = max(j, max_j)
                        flag = False

    def _edge_distort(self, max_error_value, edge_list):
        r, c = np.shape(self.image)
        up_left, up_right, bt_left, bt_right = edge_list
        possible_values = [0, 255]
        for i in range(up_left[0], bt_left[0]):
            c_start = max(up_left[1] - choice(range(0, max_error_value)), 0)
            c_end = min(up_left[1] + choice(range(0, max_error_value)), c)
            self.image[i, c_start:c_end] = choice(possible_values)

        for i in range(up_right[0], bt_right[0]):
            c_start = max(up_right[1] - choice(range(0, max_error_value)), 0)
            c_end = min(up_right[1] + choice(range(0, max_error_value)), c)
            self.image[i, c_start:c_end] = choice(possible_values)

        for i in range(up_left[1], up_right[1]):
            r_start = max(up_right[0] - choice(range(0, max_error_value)), 0)
            r_end = min(up_right[0] + choice(range(0, max_error_value)), r)
            self.image[r_start:r_end, i] = choice(possible_values)

        for i in range(bt_left[1], bt_right[1]):
            r_start = max(bt_right[0] - choice(range(0, max_error_value)), 0)
            r_end = min(bt_right[0] + choice(range(0, max_error_value)), r)
            self.image[r_start:r_end, i] = choice(possible_values)

    @staticmethod
    def magnify_image(image, scale):
        r, c = np.shape(image)
        width = int(r * scale / 100)
        height = int(c * scale / 100)
        dim = (width, height)
        mid_y, mid_x = int(height / 2) - int(c / 2), int(width / 2) - int(r / 2)
        image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)[mid_x:mid_x + r, mid_y:mid_y + c]
        return image

    def apply_layout_to_wafer_corner_distortion(self, radius=4):
        r, c = np.shape(self.image)
        kernel = np.zeros((3, 3, 4))
        kernel[:, :, 0] = [[0, 0, 0], [0, 255, 255], [0, 255, 255]]
        kernel[:, :, 1] = [[0, 0, 0], [255, 255, 0], [255, 255, 0]]
        kernel[:, :, 2] = [[0, 255, 255], [0, 255, 255], [0, 0, 0]]
        kernel[:, :, 3] = [[255, 255, 0], [255, 255, 0], [0, 0, 0]]
        # k_up_left, k_up_right, k_bt_left, k_bt_right

        all_corners = []
        corner_labels = ["up_left", "up_right", "bt_left", "bt_right"]
        for i in range(1, r - 1):
            for j in range(1, c - 1):
                for idx, label in enumerate(corner_labels):
                    if np.array_equal(self.image[i - 1:i + 2, j - 1:j + 2], kernel[:, :, idx]):
                        all_corners.append(((i, j), label))

        for (x, y), lab in all_corners:
            if lab == "up_left":
                cv2.ellipse(self.image, (y + radius - 1, x + radius - 1), (radius, radius), 0, 180, 270, 0)
                self._erase_edges(radius, (x, y), lab)
            if lab == "up_right":
                cv2.ellipse(self.image, (y - radius + 1, x + radius - 1), (radius, radius), 0, 270, 360, 0)
                self._erase_edges(radius, (x, y), lab)
            if lab == "bt_left":
                cv2.ellipse(self.image, (y + radius - 1, x - radius + 1), (radius, radius), 0, 90, 180, 0)
                self._erase_edges(radius, (x, y), lab)
            if lab == "bt_right":
                cv2.ellipse(self.image, (y - radius + 1, x - radius + 1), (radius, radius), 0, 0, 90, 0)
                self._erase_edges(radius, (x, y), lab)

    @staticmethod
    def apply_vibration_and_drift(image, distortion_kernel_size=(5, 5)):
        x_drift, y_drift = distortion_kernel_size
        distortion_values = []
        for x in range(0, x_drift):
            for y in range(0, y_drift):
                distortion_values += [(x, y), (-x, y), (x, -y), (-x, -y)]

        r, c = np.shape(image)
        distorted_im = np.zeros((r, c))
        for i in range(0, r):
            for j in range(0, c):
                del_x, del_y = choice(distortion_values)
                del_x = min(max(0, i + del_x), r - 1)
                del_y = min(max(0, j + del_y), c - 1)
                distorted_im[i, j] = image[del_x, del_y]
        return distorted_im

    def induce_stitching_errors(self, stitch_axis=0, max_stitch_error=5, drift_settings=(1, 1)):
        max_tries = 3
        r, c = np.shape(self.image)
        vib_x, vib_y = drift_settings
        # x-axis = 0, y_axis = 1
        if not stitch_axis:
            stitch_direction, stitch_error = choice([1, -1]), choice(range(0, max_stitch_error))
            stitched_temp_im = np.zeros((r, c))
            stitch_point, tries = choice(range(0, r)), 0
            # stitch direction 1: first part moves. -1 first part stays
            if stitch_direction == 1:
                while len(np.unique(self.image[stitch_point, :])) <= 1 and tries < max_tries:
                    stitch_point = choice(range(0, r))
                    tries += 1
                temp_shift_index = self.col_start - stitch_error
                temp_ = self.full_image[self.row_start:self.row_start + stitch_point, temp_shift_index:temp_shift_index + c]
                stitched_temp_im[0:stitch_point, :] = self.apply_vibration_and_drift(temp_, (vib_x, vib_y))
                stitched_temp_im[stitch_point:, :] = self.apply_vibration_and_drift(self.image[stitch_point:, :], (vib_x, vib_y))
                self.image = stitched_temp_im
            else:
                while len(np.unique(self.image[stitch_point, :])) <= 1 and tries < max_tries:
                    stitch_point = choice(range(0, r))
                    tries += 1
                stitched_temp_im[0:stitch_point, :] = self.apply_vibration_and_drift(self.image[0:stitch_point, :], (vib_x, vib_y))
                temp_shift_index = self.col_start - stitch_error
                stitched_temp_im[stitch_point:, stitch_error:] = self.apply_vibration_and_drift(self.full_image[self.row_start + stitch_point:self.row_start + r, temp_shift_index:temp_shift_index + c], (vib_x, vib_y))
                self.image = stitched_temp_im
        else:
            stitch_direction, stitch_error = choice([1, -1]), choice(range(0, max_stitch_error))
            stitched_temp_im = np.zeros((r, c))
            stitch_point, tries = choice(range(0, c)), 0
            # stitch direction 1: first part moves. -1 first part stays
            if stitch_direction == 1:
                while len(np.unique(self.image[:, stitch_point])) <= 1 and tries < max_tries:
                    stitch_point = choice(range(0, c))
                    tries += 1
                stitched_temp_im[:, 0:stitch_point] = self.apply_vibration_and_drift(self.full_image[self.row_start - stitch_error:self.row_start + r - stitch_error, self.col_start:self.col_start + stitch_point], (vib_x, vib_y))
                stitched_temp_im[:, stitch_point:] = self.apply_vibration_and_drift(self.image[:, stitch_point:], (vib_x, vib_y))
                self.image = stitched_temp_im
            else:
                while len(np.unique(self.image[:, stitch_point])) <= 1 and tries < max_tries:
                    stitch_point = choice(range(0, c))
                    tries += 1
                stitched_temp_im[:, stitch_point:] = self.apply_vibration_and_drift(self.full_image[self.row_start - stitch_error:self.row_start + r - stitch_error, self.col_start + stitch_point:self.col_start + c], (vib_x, vib_y))
                stitched_temp_im[:, 0:stitch_point] = self.apply_vibration_and_drift(self.image[:, 0:stitch_point], (vib_x, vib_y))
                self.image = stitched_temp_im

    def generate_augmented_image(self, key):
        save_path, magnification_value, sample_id = key
        mag_factor = int(magnification_value / 100)
        self.full_image = self.magnify_image(self.full_image, magnification_value)
        
        r, c = np.shape(self.full_image)
        self.row_start = choice(range(0 + self.r_sample + 1, r - self.r_sample - 1))
        self.col_start = choice(range(0 + self.c_sample + 1, c - self.c_sample - 1))
        self.image = self.full_image[self.row_start:self.row_start + self.r_sample, self.col_start:self.col_start + self.c_sample]
        self.ground_truth_im = self.image.copy()

        corner_radius = 10 + choice(range(mag_factor))
        self.label = str(magnification_value)
        self.apply_layout_to_wafer_corner_distortion(radius=corner_radius)
        self.image = cv2.bitwise_not(self.image)
        self.apply_layout_to_wafer_corner_distortion(radius=corner_radius)
        self.image = cv2.bitwise_not(self.image)

        vib_x, vib_y = choice(range(2, 4)), choice(range(2, 4))
        stitch_selector = choice([0, 1, 2])
        if stitch_selector == 1:
            try:
                self.induce_stitching_errors(stitch_axis=0, max_stitch_error=6, drift_settings=(vib_x, vib_y))
            except ValueError:
                self.image = self.apply_vibration_and_drift(self.image, (vib_x, vib_y))
        elif stitch_selector == 2:
            try:
                self.induce_stitching_errors(stitch_axis=1, max_stitch_error=6, drift_settings=(vib_x, vib_y))
            except ValueError:
                self.image = self.apply_vibration_and_drift(self.image, (vib_x, vib_y))
        else:
            self.image = self.apply_vibration_and_drift(self.image, (vib_x, vib_y))
       
       
        cv2.imwrite(save_path + sample_id + "_" + str(magnification_value) + ".png", self.image)
        cv2.imwrite(save_path + sample_id + "_" + str(magnification_value) + "_gt.png", self.ground_truth_im)


class SemImageGenerator:
    def __init__(self, settings_path, output_folder):
        self.settings_path = settings_path
        self.proxy_secondary_emission_mean = int(os.listdir(settings_path)[0].split("_")[0])
        self.out_path = output_folder
        if not os.path.isdir(self.out_path):
            os.mkdir(self.out_path)

    def _read_distribution_from_sim(self, primary_emission_mean, secondary_emission_mean, secondary_emission_std, dwelling_time):
        aggregated_file_name = "_".join(
            [str(self.proxy_secondary_emission_mean), str(secondary_emission_std), str(primary_emission_mean), str(dwelling_time).replace(".", "$")]) + ".txt"
        dist = []
        with open(self.settings_path + aggregated_file_name) as f:
            for x in f.read().split("$$"):
                delta = min(max(int(x) - self.proxy_secondary_emission_mean + secondary_emission_mean, 0), 255)
                dist.append(delta)
        return dist

    def transform_noisy_mask_image(self, key):
        path_to_mask, primary_emission_mean, foreground_param, background_param, dwelling_time = key
        replace_mask = False

        background_mean, background_std = background_param
        background_dist = self._read_distribution_from_sim(primary_emission_mean, background_mean, background_std, dwelling_time)
        foreground_mean, foreground_std = foreground_param
        foreground_dist = self._read_distribution_from_sim(primary_emission_mean, foreground_mean, foreground_std, dwelling_time)

        # foreground:255, background: 0
        mask_im = cv2.imread(path_to_mask, 0)
        r, c = np.shape(mask_im)
        if replace_mask:
            for i in range(0, r):
                for j in range(0, c):
                    if mask_im[i, j]:
                        mask_im[i, j] = choice(foreground_dist)
                    else:
                        mask_im[i, j] = choice(background_dist)
            cv2.imwrite(path_to_mask, mask_im)
        else:
            temp_buf = np.zeros((r, c))
            for i in range(0, r):
                for j in range(0, c):
                    if mask_im[i, j]:
                        temp_buf[i, j] = choice(foreground_dist)
                    else:
                        temp_buf[i, j] = choice(background_dist)
            temp = path_to_mask.split("/")
            sim_setting_label = temp[-1][:-4] + "_"
            sim_setting_label += "_".join([str(primary_emission_mean), str(foreground_mean), str(foreground_std)]) + "_"
            sim_setting_label += "_".join([str(background_mean), str(background_std), str(dwelling_time).replace(".", "$")])
            path = self.out_path + "/" + sim_setting_label + ".png"
            cv2.imwrite(path, temp_buf)

# for 32 nm node technology layouts only
def parallel_wrapper_for_noisy_mask_generation(keys):
    a, b, c, d = keys
    start = time.perf_counter()
    d = cv2.imread("D:/REFICS Dataset/Synthetic Dataset/Design_images/design_DL_32nm_" + d + ".png", 0)
    augmenter = SemAugmentationGenerator(d)
    augmenter.generate_augmented_image((a, b, c))
    print(keys[2], "Time elapsed: ", time.perf_counter() - start)

# for 90 nm node technology layouts only
def wrapper(keys):
    a, b, c = keys
    start = time.perf_counter()
    d = cv2.imread("D:/REFICS Dataset/Synthetic Dataset/Design_images/design_M1_90nm.png", 0)
    augmenter = SemAugmentationGenerator(d)
    augmenter.generate_augmented_image((a, b, c))
    print(keys[2], "Time elapsed: ", time.perf_counter() - start)


if __name__ == "__main__":
    # Generate noisy mask images
    save_path = "D:/REFICS_synthetic_dataset/"
    no_of_samples = 36000
    keys, unique_ids = [], set([])
    while len(unique_ids) < no_of_samples:
        unique_ids.add(str(random.random())[2:])
    unique_ids = list(unique_ids)

    keys = []
    for x in range(0, no_of_samples):
        keys.append((save_path, choice([100, 200, 300, 400]), unique_ids[x] + "_32_DL", str(choice(range(1, 26)))))

    with mp.Pool(7) as p:
        p.map(parallel_wrapper_for_noisy_mask_generation, keys)

    # Transform noisy masks to SEM using previously simulated values
    sem_gen = SemImageGenerator("D:/REFICS_synthetic_dataset/simulation_data/smoothed_data/", "D:/REFICS_synthetic_dataset/90_PO_SEM/")
    path = "D:/REFICS_synthetic_dataset/90_PO_LAY/"

    possible_dwelling_time = [3.2, 10]
    possible_magnification = [100, 200, 300, 400]
    possible_primary_emission_mean = [2, 5, 10, 15, 20]
    possible_std_dev_settings = [5, 10, 20, 30]
    
    # user modifiable parameters
    background_mean, foreground_mean = 60, 110
    no_of_samples = 844
    
    file_names = [x for x in os.listdir(path) if x.split("_")[-1] != "gt.png"]

    all_possible_settings = []
    for dt in possible_dwelling_time:
        for pe in possible_primary_emission_mean:
            for se1 in possible_std_dev_settings:
                for se2 in possible_std_dev_settings:

                    mean_background = int(np.random.normal(background_mean, 10))
                    mean_foreground = int(np.random.normal(foreground_mean, 15))
                    all_possible_settings.append((pe, (mean_foreground, se1), (mean_background, se2), dt))
    keys = []
    for i in range(no_of_samples):
        pe, (mean_foreground, se1), (mean_background, se2), dt = choice(all_possible_settings)
        keys.append((path + choice(file_names), pe, (mean_foreground, se1), (mean_background, se2), dt))
    with mp.Pool(6) as p:
        p.map(sem_gen.transform_noisy_mask_image, keys)
