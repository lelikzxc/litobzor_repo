# PE emission (shot_noise_param)
# electron_count = 6.25 x 10^18 in 1 A/sec
# Secondary response: Assumed gaussian and ideal at 32 usec/pixel dwelling time

# Simulation parameters
# Poisson parameters 1:10, bound 99% tail density
# Simulate influence of dwell time
# Simulate influence of PE on ground truth dist

import numpy as np
from matplotlib import pyplot as plt
import multiprocessing as mp
import os
import cv2


def get_primary_emission(mean, lam, sample_length):
    poisson_noise = np.random.poisson(lam, sample_length)
    signal = [max(mean + np.random.choice([-1, 1]) * poisson_noise[x], 0) for x in range(0, len(poisson_noise))]
    return signal, min(signal), max(signal)


def get_secondary_emission_value(mean, std_dev, primary_value, primary_emission_parameters, alg_type=1):
    primary_mean, primary_min, primary_max = primary_emission_parameters
    primary_error = primary_value - primary_mean
    secondary_emission_value = -1
    if primary_error > 0:
        k = (primary_error / (primary_max - primary_mean))
        secondary_max_limit = mean + k * 2.5 * std_dev
        if alg_type == 1:
            flag = True
            while flag:
                temp_mean = int(np.random.normal(mean, std_dev))
                if mean <= temp_mean <= secondary_max_limit:
                    secondary_emission_value = int(np.random.normal(temp_mean, std_dev))
                    flag = False
        else:
            secondary_emission_value = int(np.random.normal(int(secondary_max_limit), std_dev))
    elif primary_error < 0:
        k = -1 * (primary_error / (primary_mean - primary_min))
        secondary_min_limit = mean - k * 2.5 * std_dev
        if alg_type == 1:
            flag = True
            while flag:
                temp_mean = int(np.random.normal(mean, std_dev))
                if secondary_min_limit <= temp_mean <= mean:
                    secondary_emission_value = int(np.random.normal(temp_mean, std_dev))
                    flag = False
        else:
            secondary_emission_value = int(np.random.normal(int(secondary_min_limit), std_dev))
    else:
        secondary_emission_value = int(np.random.normal(mean, std_dev))
    return min(max(0, secondary_emission_value), 255)


def get_secondary_response(no_of_pixels, material_mean, material_std, primary_emission_parameters, dwelling_time):
    primary_mean, lam = primary_emission_parameters
    secondary_pixels = np.zeros(no_of_pixels)
    for j in range(0, len(secondary_pixels)):
        primary_signal, primary_min, primary_max = get_primary_emission(primary_mean, lam, int(dwelling_time * 1000))
        secondary_result = np.zeros(len(primary_signal))
        for i in range(0, len(primary_signal)):
            secondary_result[i] = get_secondary_emission_value(material_mean, material_std, primary_signal[i], (primary_mean, min(primary_signal), max(primary_signal)), alg_type=2)
        secondary_pixels[j] = int(np.random.choice(secondary_result))
        print(secondary_pixels[j])
    return secondary_pixels


def secondary_sim_parallel_wrapper(key):
    sample_count, secondary_mean, secondary_std, primary_parameters, dwelling_time, write_path = key
    sec_response = get_secondary_response(sample_count, secondary_mean, secondary_std, primary_parameters,
                                          dwelling_time)
    with open(write_path, "a") as f:
        f.write("$$".join([str(int(x)) for x in sec_response]) + "\n")


if __name__ == "__main__":
   
    primary_mean, secondary_mean = 500, 125
    no_of_pixels_in_image = int(mp.cpu_count() * 2000)
    all_std_dev_values = [5, 10, 20, 30]
    all_dwelling_times = [10, 3.2]
    all_lambda = [2, 5, 10, 15, 20]
    output_path = "/home/ronaldwilson/research/REFICS/simulation/"
    
    for secondary_std in all_std_dev_values:
        for dwelling_time in all_dwelling_times:
            for primary_lambda in all_lambda:
                primary_parameters = (primary_mean, primary_lambda)
                samples_per_batch = int(no_of_pixels_in_image / mp.cpu_count())
                batch_id = 0
                aggregated_file_name = "_".join([str(secondary_mean), str(secondary_std), str(primary_lambda),
                                                 str(dwelling_time).replace(".", "$")]) + ".txt"
                if not os.path.isfile(output_path + aggregated_file_name):
                    print(aggregated_file_name)
                    keys = []
                    for i in range(0, no_of_pixels_in_image, samples_per_batch):
                        keys.append((len(range(i, min(i + samples_per_batch, no_of_pixels_in_image))), secondary_mean, secondary_std, primary_parameters, dwelling_time, output_path + str(batch_id) + "_" + aggregated_file_name))
                        batch_id += 1

                    with mp.Pool() as p:
                        p.map(secondary_sim_parallel_wrapper, keys)

                    aggregated_data = []
                    for i in range(0, batch_id):
                        with open(output_path + str(i) + "_" + aggregated_file_name) as f:
                            aggregated_data += [int(x) for x in f.read().split("$$")]
                        os.remove(output_path + str(i) + "_" + aggregated_file_name)
                    with open(output_path + aggregated_file_name, "a") as f:
                        f.write("$$".join([str(x) for x in aggregated_data]) + "\n")

