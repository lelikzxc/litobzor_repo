#!/usr/bin/env python3
"""Validate downloaded PNG triples, summarize labels, and make a contact sheet; no training."""
from pathlib import Path
import collections,hashlib,json
import numpy as np
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent

def main():
 manifest=json.loads((ROOT/'refics_manifest.json').read_text());stats=[]
 sheet=Image.new('RGB',(1000,550*2),(245,245,245));draw=ImageDraw.Draw(sheet)
 for idx,row in enumerate(manifest):
  arrays={};shapes={};values={}
  for kind,info in list(row['files'].items()):
   raw=(ROOT/info['path']).read_bytes()
   assert hashlib.sha256(raw).hexdigest()==info['sha256']
   with Image.open(ROOT/info['path']) as image:
    image.load();a=np.asarray(image);shapes[kind]=list(image.size);values[kind]=np.unique(a).tolist();arrays[kind]=a
  assert len(set(tuple(v) for v in shapes.values()))==1
  assert shapes['sem']==[250,250]
  for kind in ['mask','layout']:
   a=(arrays[kind]>0).astype(np.uint8)*255
   dest=ROOT/'subset'/str(row['node_nm'])/(kind+'_binary')/Path(row['files'][kind]['path']).name
   dest.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(a).save(dest)
   raw=dest.read_bytes();row['files'][kind+'_binary']={'path':str(dest.relative_to(ROOT)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'derived_from':kind,'rule':'uint8(original > 0) * 255'}
  mask=arrays['mask']>0;layout=arrays['layout']>0;sem=arrays['sem']
  stats.append({'node_nm':row['node_nm'],'uid':row['uid'],'magnification':row['magnification'],
   'shapes':shapes,'mask_values':values['mask'],'layout_values':values['layout'],'sem_percentiles':dict(zip(['p0','p1','p50','p99','p100'],map(float,np.percentile(sem,[0,1,50,99,100])))),'mask_nonbinary_pixel_fraction':float(((arrays['mask']>0)&(arrays['mask']<255)).mean()),'low_mask_gray_pixels':int(((arrays['mask']>0)&(arrays['mask']<128)).sum()),'sem_mean_on_low_mask_gray':float(arrays['sem'][(arrays['mask']>0)&(arrays['mask']<128)].mean()) if ((arrays['mask']>0)&(arrays['mask']<128)).any() else None,
   'mask_foreground_fraction':float(mask.mean()),'layout_foreground_fraction':float(layout.mean()),
   'mask_layout_iou':float((mask&layout).sum()/max(1,(mask|layout).sum())),
   'sem_mean_on_mask':float(sem[mask].mean()) if mask.any() else None,
   'sem_mean_on_background':float(sem[~mask].mean()) if (~mask).any() else None})
 # Four example UIDs per node (one per magnification), paired SEM/mask/layout in rows.
 for node_idx,node in enumerate([32,90]):
  examples=[r for r in manifest if r['node_nm']==node][:4]
  for col,row in enumerate(examples):
   x=col*250;y=node_idx*550
   draw.text((x+3,y+3),f'{node} nm MAG {row["magnification"]}',fill='black')
   for j,kind in enumerate(['sem','mask_binary','layout_binary']):
    with Image.open(ROOT/row['files'][kind]['path']) as im:
     small=im.convert('RGB').resize((166,166),Image.Resampling.NEAREST)
     sheet.paste(small,(x,y+24+j*174))
    draw.text((x+170,y+28+j*174),kind.replace('_binary',' >0'),fill='black')
 sheet.save(ROOT/'refics_contact_sheet.png')
 summaries=[]
 for node in [32,90]:
  rs=[r for r in stats if r['node_nm']==node]
  d={'node_nm':node,'triples':len(rs),'unique_uid':len(set(r['uid'] for r in rs)),
     'magnifications':dict(collections.Counter(r['magnification'] for r in rs))}
  for key in ['mask_foreground_fraction','mask_layout_iou','sem_mean_on_mask','sem_mean_on_background','mask_nonbinary_pixel_fraction']:
   v=[r[key] for r in rs if r[key] is not None]
   d[key]={'min':min(v),'mean':sum(v)/len(v),'max':max(v)}
  d['unique_mask_sha256']=len({r['files']['mask']['sha256'] for r in manifest if r['node_nm']==node})
  summaries.append(d)
 out={'all_triples_valid':True,'summary':summaries,'per_triple':stats}
 (ROOT/'refics_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (ROOT/'refics_qa.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(summaries,indent=2))
if __name__=='__main__':main()
