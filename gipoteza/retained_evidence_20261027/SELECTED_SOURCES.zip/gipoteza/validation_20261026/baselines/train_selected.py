from pathlib import Path
import sys,json,time,hashlib
import numpy as np
import torch
from torch.nn import functional as F
import soft_grid as grid

HERE=Path(__file__).resolve().parent;OLD=grid.OLD

if __name__=='__main__':
    out=HERE/'final_models';out.mkdir(exist_ok=False);start=time.monotonic()
    assert torch.backends.mps.is_available();torch.set_num_threads(2)
    chosen=json.loads((HERE/'grid_v2/RESULT.json').read_text())['chosen'];config=chosen['config']
    files=[Path(__file__),HERE/'soft_grid.py',HERE/'PROTOCOL.md',HERE/'grid_v2/RESULT.json',OLD/'sem_electrical/PATCHES.npz',OLD/'sem_joint_development/SELECTION.json',*[OLD/f'sem_graded_test/base_{s}.pt' for s in [101,173,257]]]
    frozen={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};grid.save(out/'FROZEN.json',frozen);grid.save(out/'SELECTED.json',chosen)
    data=grid.load_data('mps');a,w=data['anchor'],data['weak'];target=torch.stack([w['target']//3,w['target']%3],1)
    rows=[]
    for seed in [101,173,257]:
        net=grid.e6.network();net.load_state_dict(torch.load(OLD/f'sem_graded_test/base_{seed}.pt',weights_only=True));net=net.to('mps')
        opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed+10)
        for step in range(400):
            ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');wi=torch.tensor(rng.integers(0,len(w['x']),16),device='mps')
            opt.zero_grad(set_to_none=True);loss=F.binary_cross_entropy_with_logits(net(a['x'][ai]),a['y'][ai])+config['weight']*grid.auxiliary(net(w['x'][wi]),target[wi],config)
            loss.backward();opt.step()
            if step%100==0:
                grid.save(out/'PROGRESS.json',dict(seed=seed,step=step,seconds=time.monotonic()-start));print(seed,step,round(time.monotonic()-start,1),flush=True)
        torch.save(net.cpu().state_dict(),out/f'strong_soft_{seed}.pt');rows.append(dict(seed=seed,checkpoint=f'strong_soft_{seed}.pt'))
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in frozen.items())
    grid.save(out/'COMPLETE.json',dict(config=config,models=rows,seconds=time.monotonic()-start,scope='No TEST or target data used'))
