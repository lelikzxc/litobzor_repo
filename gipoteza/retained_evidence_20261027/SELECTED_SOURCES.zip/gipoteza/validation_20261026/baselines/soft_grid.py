from pathlib import Path
import sys,json,time,hashlib,itertools,argparse
import numpy as np
import torch
from torch.nn import functional as F

ROOT=Path(__file__).resolve().parents[2]
OLD=ROOT/'search_20261026'
sys.path.insert(0,str(OLD))
import structured12_learning as e6
import sem_joint_development as joint

SRC=torch.tensor(e6.physics.SRC);DST=torch.tensor(e6.physics.DST)
ABS=torch.tensor(e6.physics.ABS,dtype=torch.float64)
FREE=torch.tensor(e6.physics.FREE);RIGHT=torch.tensor(e6.physics.RIGHT)
G0=.5/((144-1)*e6.physics.FULL)

def response(p,kernel='min'):
    device=p.device;dtype=p.dtype
    q=p.reshape(-1,144).to('cpu').to(torch.float64).clamp(1e-5,1-1e-5)
    u,v=q[:,SRC],q[:,DST]
    w=torch.minimum(u,v) if kernel=='min' else 2*u*v/(u+v)
    lap=torch.diag_embed(w@ABS);lap[:,SRC,DST]=-w;lap[:,DST,SRC]=-w
    aa=lap[:,FREE][:,:,FREE];bb=-lap[:,FREE][:,:,RIGHT].sum(-1)
    potentials=torch.linalg.solve(aa,bb[:,:,None])[:,:,0]
    g=(lap[:,RIGHT][:,:,RIGHT].sum((1,2))-(bb*potentials).sum(-1))/e6.physics.FULL
    return g.clamp_min(1e-8).to(dtype).to(device)

def config_grid():
    configs=[]
    for family,a,b,kappa,weight in itertools.product(['log'],[1.,4.],[10.,40.],[1.,4.],[.1,.4]):
        configs.append(dict(family=family,a=a,b=b,kappa=kappa,weight=weight,kernel='min'))
    for a,kappa,weight in itertools.product([2.,8.],[1.,4.],[.1,.4]):
        configs.append(dict(family='scaled',a=a,b=20.,kappa=kappa,weight=weight,kernel='min'))
    for kappa,weight in itertools.product([1.,4.],[.1,.4]):
        configs.append(dict(family='log',a=4.,b=20.,kappa=kappa,weight=weight,kernel='harmonic'))
    for i,c in enumerate(configs):c['id']=f'c{i:02d}'
    return configs

def auxiliary(logits,target,config):
    p=(config['kappa']*logits).sigmoid()
    g=torch.stack([response(p,config['kernel']),response(p.transpose(-1,-2),config['kernel'])],1)
    first=config['a']*(g.log()-np.log(G0)) if config['family']=='log' else config['a']*(g/G0-1)
    second=config['b']*(g-.5)
    ordinal=(target[:,:,None]>torch.arange(2,device=logits.device)[None,None,:]).float()
    return F.binary_cross_entropy_with_logits(torch.stack([first,second],2),ordinal)

def load_data(device):
    selection=json.loads((OLD/'sem_joint_development/SELECTION.json').read_text())['selection']
    z=np.load(OLD/'sem_electrical/PATCHES.npz');out={}
    assert not set(selection['anchor'])&set(selection['weak'])
    for name,ids in selection.items():
        ids=np.array(ids);target=joint.classes(z['Y'][ids])
        out[name]=dict(x=torch.tensor((z['X'][ids,None]-.2)*5,device=device),
            y=torch.tensor(z['Y'][ids,None].astype(np.float32),device=device) if name!='weak' else None,
            target=torch.tensor(target,device=device,dtype=torch.long),truth=target)
    return out

def verify():
    bars=np.zeros((11,1,12,12))
    for width in range(1,12):bars[width-1,0,:width]=1
    actual=response(torch.tensor(bars,dtype=torch.float64)).numpy()
    analytic=np.arange(1,12)/12
    assert np.max(abs(actual-analytic))<3e-4
    rng=np.random.default_rng(2201);pp=rng.uniform(.1,.9,(2,1,12,12));p=torch.tensor(pp,requires_grad=True)
    response(p,'harmonic').sum().backward();errors=[]
    for index in [(0,0,3,5),(1,0,7,8),(0,0,1,0),(1,0,8,11)]:
        original=pp[index];eps=1e-6
        pp[index]=original+eps;a=response(torch.tensor(pp),'harmonic').sum().item()
        pp[index]=original-eps;b=response(torch.tensor(pp),'harmonic').sum().item();pp[index]=original
        errors.append(abs((a-b)/(2*eps)-p.grad[index].item()))
    assert max(errors)<1e-6
    return dict(bars_max_error=float(np.max(abs(actual-analytic))),finite_difference_max_error=max(errors),G0=G0,
        old_positive_probability_floor=float(torch.sigmoid(torch.tensor(-20*G0))))

def save(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default='grid');args=parser.parse_args()
    out=Path(__file__).resolve().parent/args.output;out.mkdir(exist_ok=False)
    assert torch.backends.mps.is_available(),'MPS required';torch.set_num_threads(2)
    start=time.monotonic();checks=verify();configs=config_grid();save(out/'CONFIGS.json',configs);save(out/'VERIFICATION.json',checks)
    files=[Path(__file__),Path(__file__).with_name('PROTOCOL.md'),OLD/'sem_electrical/PATCHES.npz',OLD/'sem_joint_development/SELECTION.json',OLD/'structured12_learning.py',OLD/'structured12_prepare.py',OLD/'sem_joint_development.py',*[OLD/f'sem_joint_development/base_{s}.pt' for s in [17,41]]]
    frozen={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};save(out/'FROZEN.json',frozen)
    data=load_data('mps');anchor,weak,val=data['anchor'],data['weak'],data['val'];target=torch.stack([weak['target']//3,weak['target']%3],1);rows=[]
    for config in configs:
        for seed in [17,41]:
            net=e6.network();net.load_state_dict(torch.load(OLD/f'sem_joint_development/base_{seed}.pt',weights_only=True));net=net.to('mps')
            opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed+10)
            for step in range(400):
                ai=torch.tensor(rng.integers(0,len(anchor['x']),16),device='mps');wi=torch.tensor(rng.integers(0,len(weak['x']),16),device='mps')
                opt.zero_grad(set_to_none=True)
                loss=F.binary_cross_entropy_with_logits(net(anchor['x'][ai]),anchor['y'][ai])+config['weight']*auxiliary(net(weak['x'][wi]),target[wi],config)
                loss.backward();opt.step()
                if step%100==0:
                    save(out/'PROGRESS.json',dict(config=config,seed=seed,step=step,completed=len(rows),total=56,seconds=time.monotonic()-start))
            net.eval();ev=joint.evaluate(net,val['x'],val['y'],val['truth']);row=dict(config=config,seed=seed,**ev);rows.append(row)
            torch.save(net.cpu().state_dict(),out/f'{config["id"]}_{seed}.pt');save(out/'ROWS.json',rows)
            print(f'{time.monotonic()-start:.1f}s {config["id"]} seed={seed} F1={ev["f1"]:.6f} IoU={ev["iou"]:.6f}',flush=True)
    aggregate=[]
    for config in configs:
        rr=[r for r in rows if r['config']['id']==config['id']]
        aggregate.append(dict(config=config,f1=float(np.mean([r['f1'] for r in rr])),iou=float(np.mean([r['iou'] for r in rr]))))
    chosen=sorted(aggregate,key=lambda r:(-r['f1'],-r['iou'],r['config']['id']))[0]
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in frozen.items())
    save(out/'RESULT.json',dict(scope='TRAIN/VAL only; stronger continuous-physics controls',chosen=chosen,aggregate=aggregate,seconds=time.monotonic()-start))
    print(json.dumps(chosen,indent=2),flush=True)
