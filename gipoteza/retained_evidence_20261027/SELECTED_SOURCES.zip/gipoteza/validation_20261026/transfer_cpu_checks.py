"""Read-only independent checks of frozen REFICS evaluation and its saved results.

Run with PYTHONDONTWRITEBYTECODE=1 .venv/bin/python <this file>.
Writes only TRANSFER_CPU_AUDIT.json alongside this script.
"""
from pathlib import Path
import hashlib
import importlib.util
import json

import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from sklearn.metrics import f1_score

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('transfer_evaluation', HERE/'evaluate_transfer.py')
ev = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ev)


def independent_components(pred, truth):
    total = np.zeros(4, dtype=np.int64)
    for p, y in zip(pred, truth):
        gt, ng = ndi.label(y); pr, npred = ndi.label(p)
        pairs = np.unique(np.stack([gt.ravel(), pr.ravel()], axis=1), axis=0)
        pairs = pairs[(pairs[:, 0] > 0) & (pairs[:, 1] > 0)]
        gt_degree = np.bincount(pairs[:, 0], minlength=ng+1)[1:]
        pr_degree = np.bincount(pairs[:, 1], minlength=npred+1)[1:]
        total += [np.maximum(gt_degree-1, 0).sum(), np.maximum(pr_degree-1, 0).sum(),
                  (pr_degree == 0).sum(), (gt_degree == 0).sum()]
    return total


def f1_from_confusion(cm, labels):
    result = []
    for c in labels:
        tp = cm[..., c, c]
        denom = cm[..., c, :].sum(-1) + cm[..., :, c].sum(-1)
        result.append(np.divide(2*tp, denom, out=np.zeros_like(tp, dtype=float), where=denom > 0))
    return np.array(result).mean(0)


def helper_checks():
    a = np.arange(64*60*60).reshape(64, 60, 60)
    tiles = a.reshape(64, 5, 12, 5, 12).transpose(0, 1, 3, 2, 4).reshape(-1, 12, 12)
    assert np.array_equal(tiles[0], a[0, :12, :12])
    assert np.array_equal(tiles[24], a[0, 48:60, 48:60])
    assert np.array_equal(tiles[25], a[1, :12, :12])
    cm = np.arange(6*3*64*9*9).reshape(6, 3, 64, 9, 9)
    si = np.array([2, 2, 0]); gi = np.array([0, 1, 1, 4])
    got = cm[:, si][:, :, gi].sum(2)
    for m in range(6):
        for k, s in enumerate(si):
            assert np.array_equal(got[m, k], sum(cm[m, s, g] for g in gi))
    assert not ev.otsu_mask(np.full((60, 60), .2)).any()
    y = np.zeros((12, 12), bool); y[5, 1:11] = True
    p = y.copy(); p[5, 5] = False
    assert np.array_equal(ev.component_errors(p[None], y[None]), [[1, 0, 0, 0]])
    assert np.array_equal(independent_components(p[None], y[None]), [1, 0, 0, 0])
    y[5, 5] = False; p[5, 5] = True
    assert np.array_equal(independent_components(p[None], y[None]), [0, 1, 0, 0])


def full_checks():
    out = HERE/'transfer_result'
    result = json.loads((out/'RESULT.json').read_text())
    frozen = json.loads((out/'FROZEN.json').read_text())
    for name, expected in frozen.items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected, name
    patches = np.load(out/'PATCHES.npz')
    x, y, truth = patches['X'], patches['Y'], patches['truth']
    uid, node = patches['uid_index'], patches['node_nm']
    manifest = json.loads((HERE/'transfer_data/refics_manifest.json').read_text())
    assert len(set((r['node_nm'], r['uid']) for r in manifest)) == 64
    assert np.array_equal(uid, np.repeat(np.arange(64), 25))
    for k, row in enumerate(manifest):
        assert (node[uid == k] == row['node_nm']).all()
        assert (patches['magnification'][uid == k] == row['magnification']).all()
        raw = np.asarray(Image.open(HERE/'transfer_data'/row['files']['sem']['path']))
        gt = np.asarray(Image.open(HERE/'transfer_data'/row['files']['mask']['path'])) > 0
        xx = raw[5:245, 5:245].reshape(60, 4, 60, 4).mean((1, 3)).astype(np.float32)/255
        yy = gt[5:245, 5:245].reshape(60, 4, 60, 4).mean((1, 3)) >= .5
        for r in range(5):
            for c in range(5):
                i = k*25+r*5+c
                assert np.array_equal(x[i], xx[12*r:12*r+12, 12*c:12*c+12])
                assert np.array_equal(y[i], yy[12*r:12*r+12, 12*c:12*c+12])
    assert np.array_equal(truth, ev.dev.classes(y))
    for norm in ev.NORMS:
        z = np.load(out/f'PREDICTIONS_{norm}.npz')
        pred, masks, confusion = z['predictions'], z['masks'], z['confusion']
        assert list(z['methods']) == ev.METHODS and list(z['seeds']) == ev.SEEDS
        assert np.array_equal(z['truth'], truth) and np.array_equal(z['uid_index'], uid)
        for j, method in enumerate(ev.METHODS):
            for s in range(3):
                assert np.array_equal(pred[j, s], ev.dev.classes(masks[j, s]))
                independently = np.zeros((64, 9, 9), int)
                for k in range(64):
                    independently[k] = np.bincount(9*truth[uid == k]+pred[j, s, uid == k], minlength=81).reshape(9, 9)
                assert np.array_equal(independently, confusion[j, s])
        for domain in ['pooled', '32', '90']:
            ids = np.ones(len(y), bool) if domain == 'pooled' else node == int(domain)
            groups = np.unique(uid[ids]); labels = np.unique(truth[ids])
            report = result['metrics'][norm][domain]
            assert report['class_counts'] == np.bincount(truth[ids], minlength=9).tolist()
            assert report['present_classes'] == labels.tolist()
            blank = ids & ~y.any((1, 2)); nonblank = ids & y.any((1, 2))
            for j, method in enumerate(ev.METHODS):
                metrics = report['metrics'][method]
                f1 = [f1_score(truth[ids], pred[j, s, ids], labels=labels, average='macro', zero_division=0) for s in range(3)]
                assert np.allclose(metrics['per_seed_f1'], f1, atol=1e-14)
                assert np.isclose(metrics['macro_f1_present'], np.mean(f1), atol=1e-14)
                intersection = (masks[j] & y).sum((-1, -2)); union = (masks[j] | y).sum((-1, -2))
                iou = np.divide(intersection, union, out=np.ones_like(union, dtype=float), where=union > 0)
                assert np.isclose(metrics['mean_iou'], iou[:, ids].mean(), atol=1e-14)
                assert np.isclose(metrics['nonblank_iou'], iou[:, nonblank].mean(), atol=1e-14)
                assert metrics['blank_tiles'] == int(blank.sum())
                assert np.isclose(metrics['blank_any_foreground_rate'], masks[j][:, blank].any((-1, -2)).mean())
                assert np.isclose(metrics['blank_false_connection_rate'], (pred[j][:, blank] != 0).mean())
                assert np.isclose(metrics['blank_foreground_pixel_fraction'], masks[j][:, blank].mean())
                counts = np.array([independent_components(masks[j, s, ids], y[ids]) for s in range(3)]).mean(0)
                assert np.allclose(list(metrics['local_component_errors_mean_total'].values()), counts)
            rng = np.random.default_rng(2301); draws = []
            for _ in range(4000):
                si = rng.integers(0, 3, 3); gi = groups[rng.integers(0, len(groups), len(groups))]
                # Sequential take has unambiguous method,seed,UID axes.
                resampled = np.take(np.take(confusion, si, axis=1), gi, axis=2).sum(2)
                draws.append(f1_from_confusion(resampled, labels).mean(1))
            draws = np.array(draws); joint = ev.METHODS.index('joint')
            for j, method in enumerate(ev.METHODS):
                if method != 'joint':
                    assert np.allclose(report['comparisons'][method]['ci95'], np.quantile(draws[:, joint]-draws[:, j], [.025, .975]), atol=1e-14)
    return dict(frozen_hashes=len(frozen), images=64, tiles=len(y), normalizations=ev.NORMS,
        checked=['source-mask and input pooling', 'UID/node/MAG mapping', 'binary physics classes',
            'all saved mask->class predictions', 'confusion matrices', 'Macro-F1', 'IoU and blank diagnostics',
            'independent component-overlap totals', '4000-draw crossed UID/seed bootstrap intervals'],
        status='PASS')


if __name__ == '__main__':
    helper_checks()
    audit = full_checks()
    (HERE/'TRANSFER_CPU_AUDIT.json').write_text(json.dumps(audit, indent=2)+'\n')
    print(json.dumps(audit, indent=2))
