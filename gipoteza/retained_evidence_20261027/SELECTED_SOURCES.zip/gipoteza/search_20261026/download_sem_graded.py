from pathlib import Path
import zipfile,json,hashlib
from sem_remote_zip import RemoteZip,URL

HERE=Path(__file__).resolve().parent
if __name__=='__main__':
    desired=json.loads((HERE/'sem_graded_download.json').read_text());manifest=[]
    with zipfile.ZipFile(RemoteZip()) as z:
        for name in desired:
            p=Path(name);assert not p.is_absolute() and '..' not in p.parts
            dest=HERE/'sem_full'/p;dest.parent.mkdir(parents=True,exist_ok=True)
            if not dest.exists():
                raw=z.read(name);tmp=dest.with_suffix(dest.suffix+'.part');tmp.write_bytes(raw);tmp.replace(dest)
            raw=dest.read_bytes();row=dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());manifest.append(row);print(json.dumps(row),flush=True)
    (HERE/'sem_full/DOWNLOAD_GRADED.json').write_text(json.dumps(dict(url=URL,persistent_id='doi:10.17617/3.HY5SYN',source_license='CC BY 4.0',files=manifest),indent=2)+'\n')
