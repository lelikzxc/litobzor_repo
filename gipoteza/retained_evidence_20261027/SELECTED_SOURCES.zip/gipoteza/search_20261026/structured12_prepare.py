from pathlib import Path
import hashlib,json,time
import numpy as np
from scipy import ndimage as ndi

HERE=Path(__file__).resolve().parent;OUT=HERE/'structured12';OUT.mkdir(exist_ok=True)
OLD=HERE.parent/'h7_readout_20261025';START=time.monotonic();B=12
EDGES=[(y*B+x,yy*B+xx) for y in range(B) for x in range(B) for yy,xx in [(y+1,x),(y,x+1)] if yy<B and xx<B]
SRC=np.array([a for a,b in EDGES]);DST=np.array([b for a,b in EDGES]);ABS=np.zeros((len(EDGES),B*B))
ABS[np.arange(len(EDGES)),SRC]=1;ABS[np.arange(len(EDGES)),DST]=1
FREE=np.array([y*B+x for y in range(B) for x in range(1,B-1)])
RIGHT=np.array([y*B+B-1 for y in range(B)]);FULL=B/(B-1)

def conductance(q):
    q=np.asarray(q,dtype=float).reshape(-1,B*B);w=np.minimum(q[:,SRC],q[:,DST])
    L=np.zeros((len(q),B*B,B*B));L[:,np.arange(B*B),np.arange(B*B)]=w@ABS
    L[:,SRC,DST]=-w;L[:,DST,SRC]=-w
    A=L[:,FREE][:,:,FREE];bb=-L[:,FREE][:,:,RIGHT].sum(-1)
    v=(np.linalg.pinv(A,hermitian=True,rcond=1e-10)@bb[:,:,None])[:,:,0]
    g=L[:,RIGHT][:,:,RIGHT].sum((1,2))-(bb*v).sum(-1)
    g=np.maximum(g/FULL,0);g[g<1e-8]=0
    return g

def canonical(a):
    return min(np.packbits(v).tobytes() for v in [a,a[::-1],a[:,::-1],a[::-1,::-1]])

if __name__=='__main__':
    sources=[OLD/'data/benchmark.npz',OLD/'extension_data/benchmark.npz']
    files=[Path(__file__),HERE/'STRUCTURED12_PROTOCOL.md',*sources]
    (OUT/'FROZEN_PREPARE.json').write_text(json.dumps({str(p.relative_to(HERE.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    pools={s:{} for s in ['train','val','test']};rng=np.random.default_rng(1414)
    for path in sources:
        z=np.load(path);geos=np.unique(z['geometry']);ordering=sorted(geos)
        for geo in geos:
            split='train' if path==sources[0] else 'val' if ordering.index(geo)<4 else 'test'
            ids=np.flatnonzero(z['geometry']==geo).tolist()
            ids.sort(key=lambda i:hashlib.sha256(f'E5-{i}'.encode()).hexdigest())
            for i in ids[:320]:
                a=np.unpackbits(z['native'][i]).reshape(256,256).astype(bool)
                boundary=ndi.binary_dilation(a)&~ndi.binary_erosion(a)
                boundary[:6]=False;boundary[-6:]=False;boundary[:,:6]=False;boundary[:,-6:]=False
                yy,xx=np.where(boundary)
                if not len(yy):continue
                choices=rng.choice(len(yy),min(32,len(yy)),replace=False)
                for k in choices:
                    y,x=int(yy[k]),int(xx[k]);patch=a[y-6:y+6,x-6:x+6]
                    if patch.sum() in [0,144]:continue
                    key=canonical(patch)
                    if key not in pools[split]:pools[split][key]=(patch.copy(),str(geo),int(i),y,x)
            print(f'{split} {str(geo)[:10]} motifs={len(pools[split])}, {time.monotonic()-START:.1f}s',flush=True)
    used=set();records=[];native=[];counts={}
    for split in ['train','val','test']:
        rows=[(key,value) for key,value in pools[split].items() if key not in used]
        used.update(key for key,value in rows)
        images=np.stack([v[0] for key,v in rows]);gg=[]
        for start in range(0,len(images),256):gg.extend(conductance(images[start:start+256]))
        gg=np.array(gg);classes=np.where(gg==0,0,np.where(gg<.5-1e-8,1,2))
        counts[split]=np.bincount(classes,minlength=3).tolist()
        for (key,v),g,c in zip(rows,gg,classes):
            native.append(v[0]);records.append(dict(split=split,geometry=v[1],event=v[2],y=v[3],x=v[4],
                canonical=key.hex(),conductance=float(g),label=int(c)))
    gate=all(min(counts[s])>=n for s,n in [('train',128),('val',32),('test',64)])
    np.savez_compressed(OUT/'PATCHES.npz',native=np.array(native),conductance=np.array([r['conductance'] for r in records]),
        label=np.array([r['label'] for r in records]),split=np.array([r['split'] for r in records]),geometry=np.array([r['geometry'] for r in records]))
    (OUT/'MANIFEST.json').write_text(json.dumps(records,indent=2)+'\n')
    result=dict(counts=counts,data_gate=gate,motifs=len(native),seconds=time.monotonic()-START,
        scope='Native simulated lithographic motifs; synthetic observation not yet created; all source geometries previously studied')
    (OUT/'PREPARE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
