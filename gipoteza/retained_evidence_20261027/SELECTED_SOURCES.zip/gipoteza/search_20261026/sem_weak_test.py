from pathlib import Path
import hashlib,json,time,copy
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score
import structured12_learning as e6
import sem_weak_development as dev

HERE=Path(__file__).resolve().parent;OUT=HERE/'sem_weak_test';OUT.mkdir(exist_ok=True)
START=time.monotonic();SEEDS=[101,173,257]
METHODS=['base','replay','cldice','soft_class','feature_head','connectivity','interval']

def log(s):print(f'{time.monotonic()-START:.1f}s {s}',flush=True)
def features(net,x):return net[:-1](x).flatten(1)

def predict(net,x,y,head=None):
    hard=[];hp=[]
    with torch.inference_mode():
        for i in range(0,len(x),256):
            logits=net(x[i:i+256]);hard.extend((logits[:,0]>=0).cpu().numpy())
            if head is not None:hp.extend(head(features(net,x[i:i+256])).argmax(1).cpu().numpy())
    hard=np.array(hard);pred=e6.label(e6.binary_response(hard));yy=y[:,0].cpu().numpy()>.5
    union=(hard|yy).sum((1,2));inter=(hard&yy).sum((1,2))
    return pred,np.divide(inter,union,out=np.ones(len(union)),where=union>0),np.array(hp) if head is not None else None

if __name__=='__main__':
    assert torch.backends.mps.is_available();torch.set_num_threads(2)
    files=[Path(__file__),HERE/'SEM_WEAK_TEST_PROTOCOL.md',HERE/'sem_weak_development.py',HERE/'structured12_learning.py',HERE/'sem_electrical/PATCHES.npz',HERE/'sem_weak_development/RESULT.json',HERE/'sem_feature_control/RESULT.json']
    (OUT/'FROZEN.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    d=dev.data();a,w=d['anchor'],d['weak']
    z=np.load(HERE/'sem_electrical/PATCHES.npz');ix=np.flatnonzero(z['split']=='test')
    x=torch.tensor((z['X'][ix,None]-.2)*5,device='mps');y=torch.tensor(z['Y'][ix,None].astype(np.float32),device='mps')
    truth=z['label'][ix];frame=z['frame'][ix];frames=np.unique(frame)
    ordinal=(w['target'][:,None]>torch.arange(2,device='mps')[None,:]).float()
    thresholds=torch.tensor([.5/((144-1)*e6.physics.FULL),.5],device='mps')
    predictions={m:[] for m in METHODS};predictions['head_class']=[];ious={m:[] for m in METHODS}
    for seed in SEEDS:
        torch.manual_seed(seed);base=e6.network().to('mps');opt=torch.optim.AdamW(base.parameters(),lr=.003,weight_decay=.0001);rng=np.random.default_rng(seed)
        for step in range(400):
            ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');opt.zero_grad(set_to_none=True)
            F.binary_cross_entropy_with_logits(base(a['x'][ai]),a['y'][ai]).backward();opt.step()
        for method in METHODS:
            net=copy.deepcopy(base);head=None
            if method!='base':
                torch.manual_seed(seed+1)
                if method=='feature_head':
                    head=nn.Sequential(nn.Linear(3456,64),nn.GELU(),nn.Linear(64,3)).to('mps')
                    opt=torch.optim.AdamW(head.parameters(),lr=.003,weight_decay=.0001)
                    with torch.no_grad():ff=features(net,a['x']).detach()
                    for _ in range(400):
                        opt.zero_grad(set_to_none=True);F.cross_entropy(head(ff),a['target']).backward();opt.step()
                params=list(net.parameters())+([] if head is None else list(head.parameters()))
                opt=torch.optim.AdamW(params,lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed+10)
                for step in range(200):
                    ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');wi=torch.tensor(rng.integers(0,len(w['x']),16),device='mps')
                    opt.zero_grad(set_to_none=True);al=net(a['x'][ai]);loss=F.binary_cross_entropy_with_logits(al,a['y'][ai])
                    if method=='cldice':loss=loss+.25*e6.small.cldice(al.sigmoid(),a['y'][ai])
                    elif method not in ['replay']:
                        logits=net(w['x'][wi]);p=logits.sigmoid()
                        if method=='soft_class':aux=F.binary_cross_entropy_with_logits(20*(e6.soft_response(p)[:,None]-thresholds),ordinal[wi])
                        elif method=='feature_head':aux=F.cross_entropy(head(features(net,w['x'][wi])),w['target'][wi])
                        else:
                            q=e6.class_probabilities(p)
                            aux=F.binary_cross_entropy((1-q[:,0]).clamp(1e-7,1-1e-7),ordinal[wi,0]) if method=='connectivity' else -q[torch.arange(len(wi),device='mps'),w['target'][wi]].clamp_min(1e-7).log().mean()
                        loss=loss+(1. if method=='feature_head' else .1)*aux
                    loss.backward();opt.step()
                    if step%50==0:log(f'{method} seed={seed} step={step}');assert time.monotonic()-START<580
            net.eval();pred,iou,hp=predict(net,x,y,head)
            predictions[method].append(pred);ious[method].append(iou)
            torch.save(net.cpu().state_dict(),OUT/f'{method}_{seed}.pt')
            if head is not None:
                predictions['head_class'].append(hp);torch.save(head.cpu().state_dict(),OUT/f'head_classifier_{seed}.pt')
            log(f'{method} seed={seed} F1={f1_score(truth,pred,labels=range(3),average="macro",zero_division=0):.6f} IoU={iou.mean():.6f}')
    np.savez_compressed(OUT/'PREDICTIONS.npz',truth=truth,frame=frame,index=ix,**{m:np.array(p) for m,p in predictions.items()},**{'iou_'+m:np.array(p) for m,p in ious.items()})
    names=list(predictions);cm=np.zeros((len(names),len(SEEDS),len(frames),3,3),int)
    metrics={}
    for j,m in enumerate(names):
        pp=np.array(predictions[m]);scores=[];byframe=[]
        for s in range(len(SEEDS)):
            scores.append(float(f1_score(truth,pp[s],labels=range(3),average='macro',zero_division=0)))
            byframe.append([float(f1_score(truth[frame==f],pp[s,frame==f],labels=range(3),average='macro',zero_division=0)) for f in frames])
            for k,f in enumerate(frames):
                ii=np.flatnonzero(frame==f);np.add.at(cm[j,s,k],(truth[ii],pp[s,ii]),1)
        metrics[m]=dict(macro_f1=float(np.mean(scores)),per_seed_f1=scores,per_seed_frame_f1=byframe,iou=float(np.mean(ious[m])) if m in ious else None)
    rng=np.random.default_rng(1714);boot=[]
    for _ in range(4000):
        si=rng.integers(0,len(SEEDS),len(SEEDS));fi=rng.integers(0,len(frames),len(frames))
        boot.append(e6.macro(cm[:,si][:,:,fi].sum(2)).mean(1))
    boot=np.array(boot);proposal=names.index('interval');comparisons={}
    for j,m in enumerate(names):
        if m=='interval':continue
        delta=metrics['interval']['macro_f1']-metrics[m]['macro_f1'];ci=np.quantile(boot[:,proposal]-boot[:,j],[.025,.975]).tolist()
        comparisons[m]=dict(delta=delta,ci95=ci)
    primary=['soft_class','feature_head','head_class']
    ioudrop=max(r['iou'] for r in metrics.values() if r['iou'] is not None)-metrics['interval']['iou']
    gate=all(comparisons[m]['delta']>=.01 and comparisons[m]['ci95'][0]>0 for m in primary) and all(c['delta']>=0 for c in comparisons.values()) and ioudrop<=.02
    result=dict(scope='Real SEM inputs, resistor-model labels, one IC and two TEST frames; miniature feasibility only',metrics=metrics,comparisons=comparisons,gate=gate,iou_drop=ioudrop,seeds=SEEDS,test_examples=len(ix),test_frames=frames.tolist(),seconds=time.monotonic()-START)
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');log(json.dumps(result,indent=2))
