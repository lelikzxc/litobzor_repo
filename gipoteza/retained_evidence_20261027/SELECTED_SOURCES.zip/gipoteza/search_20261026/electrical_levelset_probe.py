"""E1 exact electrical level-set loss and a deliberately tiny synthetic CNN probe."""
from pathlib import Path
import hashlib,json,time,os
import numpy as np
from scipy.ndimage import gaussian_filter
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score

HERE=Path(__file__).resolve().parent;OUT=HERE/'electrical_levelset';OUT.mkdir(exist_ok=True)
START=time.monotonic();SIDES=4;PIXELS=16
EDGES=[(y*4+x,yy*4+xx) for y in range(4) for x in range(4)
       for yy,xx in [(y+1,x),(y,x+1)] if yy<4 and xx<4]
SRC=np.array([a for a,b in EDGES]);DST=np.array([b for a,b in EDGES])
INC=np.zeros((len(EDGES),16))
INC[np.arange(len(EDGES)),SRC]=1;INC[np.arange(len(EDGES)),DST]=-1
FREE=np.array([y*4+x for y in range(4) for x in [1,2]])
RIGHT=np.array([y*4+3 for y in range(4)])
BITS=2**np.arange(16,dtype=np.int64)
METHODS=['bce','soft','cldice','levelset'];SEEDS=[17,41]

def log(s):print(f'{time.monotonic()-START:.1f}s {s}',flush=True)
def budget():
    if time.monotonic()-START>580:raise RuntimeError('E1 600-second budget exceeded')
def h(s):return hashlib.sha256(s.encode()).hexdigest()

def conductance(q):
    q=np.asarray(q,dtype=float).reshape(-1,16)
    w=np.minimum(q[:,SRC],q[:,DST]);L=np.einsum('be,ei,ej->bij',w,INC,INC,optimize=True)
    A=L[:,FREE][:,:,FREE];b=-L[:,FREE][:,:,RIGHT].sum(-1)
    v=(np.linalg.pinv(A,hermitian=True,rcond=1e-10)@b[:,:,None])[:,:,0]
    out=L[:,RIGHT][:,:,RIGHT].sum((1,2))-(b*v).sum(-1)
    return np.maximum(out,0)

def table():
    values=[]
    for start in range(0,65536,4096):
        masks=((np.arange(start,min(start+4096,65536))[:,None]>>np.arange(16))&1)
        values.append(conductance(masks));budget()
    g=np.concatenate(values);g[g<1e-8]=0
    assert abs(g[-1]-4/3)<1e-10
    assert abs(g[15]-1/3)<1e-10
    return g/g[-1]

def layerloss(p,target,gt):
    ordered,ix=p.reshape(-1,16).sort(dim=1,descending=True)
    bits=torch.tensor(BITS,device=p.device)
    codes=(bits[ix]).cumsum(1)
    codes=torch.cat([torch.zeros((len(p),1),device=p.device,dtype=torch.long),codes],1)
    values=(gt[codes]-target[:,None])**2
    weights=torch.cat([torch.ones_like(ordered[:,:1]),ordered],1)-torch.cat([ordered,torch.zeros_like(ordered[:,:1])],1)
    return (weights*values).sum(1)

def theory(g):
    rng=np.random.default_rng(1011);p=rng.uniform(.001,.999,(10000,16));targets=rng.integers(0,65536,len(p));star=g[targets]
    order=np.argsort(-p,axis=1);sorted_p=np.take_along_axis(p,order,axis=1)
    codes=np.concatenate([np.zeros((len(p),1),np.int64),np.cumsum(BITS[order],axis=1)],axis=1)
    weights=np.diff(np.concatenate([np.ones((len(p),1)),sorted_p,np.zeros((len(p),1))],axis=1),axis=1)*-1
    loss=(weights*(g[codes]-star[:,None])**2).sum(1)
    hard=(g[((p>=.5)*BITS).sum(1)]-star)**2
    residual=hard-2*loss
    assert residual.max()<1e-9
    max_gradient_error=0
    gt=torch.tensor(g,dtype=torch.float64)
    for i in range(10):
        q=torch.tensor(p[i:i+1],dtype=torch.float64,requires_grad=True)
        target=torch.tensor(star[i:i+1]);v=layerloss(q,target,gt).sum();v.backward()
        for j in range(16):
            eps=1e-6;plus=q.detach().clone();minus=plus.clone();plus[0,j]+=eps;minus[0,j]-=eps
            numerical=float((layerloss(plus,target,gt)-layerloss(minus,target,gt))/(2*eps))
            max_gradient_error=max(max_gradient_error,abs(numerical-float(q.grad[0,j])))
    assert max_gradient_error<1e-7
    example=dict(target_single_bar=float(g[15]),constant_probability=.25,
        soft_response=float(conductance(np.full((1,16),.25))[0]/(4/3)),
        hard_response=float(g[0]),soft_loss=0.,hard_squared_error=float(g[15]**2))
    return dict(bound_vectors=len(p),max_bound_residual=float(residual.max()),
        finite_difference_coordinates=160,max_gradient_error=max_gradient_error,
        counterexample=example)

def prepare(g):
    masks=((np.arange(65536)[:,None]>>np.arange(16))&1).reshape(-1,4,4)
    canonical=np.minimum.reduce([((v.reshape(-1,16))*BITS).sum(1)
        for v in [masks,masks[:,::-1],masks[:,:,::-1],masks[:,::-1,::-1]]])
    tag=np.array([int(h('E1-20261026-'+str(k))[:8],16)%10 for k in canonical])
    classes=np.where(g<1e-8,0,np.where(g<.5-1e-8,1,2))
    eligible=(masks.sum((1,2))>=2)&(masks.sum((1,2))<=14)
    selected=[];splits=[];available={}
    for name,sel,cap,minimum in [('train',tag<6,256,128),('val',(tag>=6)&(tag<8),64,32),('test',tag>=8,128,64)]:
        available[name]=[]
        for cls in range(3):
            candidates=np.flatnonzero(eligible&sel&(classes==cls)).tolist()
            candidates.sort(key=lambda k:h('E1-select-'+str(k)))
            available[name].append(len(candidates))
            if len(candidates)<minimum:raise RuntimeError(f'Insufficient {name} class {cls}: {len(candidates)}')
            ids=candidates[:cap];selected.extend(ids);splits.extend([name]*len(ids))
    ids=np.array(selected);splits=np.array(splits)
    native=masks[ids].astype(np.float32);blur=gaussian_filter(native,sigma=(0,.55,.55),mode='constant')
    rng=np.random.default_rng(1012);X=[];Y=[];index=[];tags=[];regimes=[]
    for i,s in enumerate(splits):
        noiselevels=rng.uniform(.2,.4,2) if s=='train' else [.2,.3,.4]
        for regime,level in enumerate(noiselevels):
            X.append(np.clip(blur[i]+rng.normal(0,level,(4,4)),0,1))
            Y.append(native[i]);index.append(i);tags.append(s);regimes.append(regime)
    data=dict(X=np.array(X,np.float32)[:,None],Y=np.array(Y,np.float32)[:,None],
        index=np.array(index),tags=np.array(tags),regimes=np.array(regimes),
        native_ids=ids,canonical=canonical[ids],native_tags=splits,classes=classes[ids])
    np.savez_compressed(OUT/'DATA.npz',**data,g=g)
    (OUT/'DATA_MANIFEST.json').write_text(json.dumps(dict(available=available,
        selected_per_split={s:int(np.sum(splits==s)) for s in ['train','val','test']},
        scope='Exhaustive synthetic 4x4 masks, not real semiconductor imagery'),indent=2)+'\n')
    assert not set(canonical[ids[splits=='train']])&set(canonical[ids[splits=='test']])
    return data

def soft_response(p):
    # Explicit CPU physics; autograd traverses the device transfers.
    q=p.reshape(-1,16).to('cpu').clamp(1e-5,1-1e-5)
    inc=torch.tensor(INC,dtype=q.dtype);src=torch.tensor(SRC);dst=torch.tensor(DST)
    free=torch.tensor(FREE);right=torch.tensor(RIGHT)
    w=torch.minimum(q[:,src],q[:,dst]);L=torch.einsum('be,ei,ej->bij',w,inc,inc)
    A=L[:,free][:,:,free];b=-L[:,free][:,:,right].sum(-1)
    v=torch.linalg.solve(A,b[:,:,None])[:,:,0]
    g=L[:,right][:,:,right].sum((1,2))-(b*v).sum(-1)
    return (g/(4/3)).to(p.device)

def skeleton(x):
    def erode(v):return torch.minimum(-F.max_pool2d(-v,(3,1),1,(1,0)),-F.max_pool2d(-v,(1,3),1,(0,1)))
    def opening(v):return F.max_pool2d(erode(v),3,1,1)
    sk=F.relu(x-opening(x))
    for _ in range(3):
        x=erode(x);delta=F.relu(x-opening(x));sk=sk+F.relu(delta-sk*delta)
    return sk

def cldice(p,y):
    sp=skeleton(p);sy=skeleton(y)
    tprec=(sp*y).sum((1,2,3))/(sp.sum((1,2,3))+1e-5)
    tsens=(sy*p).sum((1,2,3))/(sy.sum((1,2,3))+1e-5)
    return (1-2*tprec*tsens/(tprec+tsens+1e-5)).mean()

def model():return nn.Sequential(nn.Conv2d(1,24,3,padding=1),nn.GELU(),nn.Conv2d(24,24,3,padding=1),nn.GELU(),nn.Conv2d(24,1,1))
def hard_values(prob,g):return g[((prob[:,0]>=.5).reshape(-1,16)*BITS).sum(1)]
def label(values):return np.where(values<1e-8,0,np.where(values<.5-1e-8,1,2))
def evaluate(net,x,y,gt,truth,g):
    with torch.inference_mode():p=net(x).sigmoid().cpu().numpy()
    pred=label(hard_values(p,g));hard=p>=.5;yy=y.cpu().numpy()>=.5
    inter=(hard&yy).sum((1,2,3));union=(hard|yy).sum((1,2,3))
    iou=np.divide(inter,union,out=np.ones_like(inter,dtype=float),where=union>0)
    return dict(f1=float(f1_score(truth,pred,labels=range(3),average='macro',zero_division=0)),
                iou=float(iou.mean()),prediction=pred,p=p,iou_per_image=iou)

def learn(data,g):
    if not torch.backends.mps.is_available():raise RuntimeError('MPS required, no CPU training fallback')
    torch.set_num_threads(2);device='mps';gt=torch.tensor(g,dtype=torch.float32,device=device)
    tags=data['tags'];train=tags=='train';val=tags=='val';test=tags=='test'
    xt=torch.tensor(data['X'][train],device=device);yt=torch.tensor(data['Y'][train],device=device)
    xv=torch.tensor(data['X'][val],device=device);yv=torch.tensor(data['Y'][val],device=device)
    train_targets=torch.tensor(g[data['native_ids'][data['index'][train]]],dtype=torch.float32,device=device)
    truthval=data['classes'][data['index'][val]]
    chosen={};search=[]
    for seed in SEEDS:
        for method in METHODS:
            candidates=[]
            for weight in ([0.] if method=='bce' else [.25,1.]):
                budget();torch.manual_seed(seed);net=model().to(device)
                opt=torch.optim.AdamW(net.parameters(),lr=.003,weight_decay=.0001)
                rng=np.random.default_rng(seed)
                for step in range(400):
                    ids=rng.integers(0,len(xt),64);batch=torch.tensor(ids,device=device)
                    opt.zero_grad(set_to_none=True);logits=net(xt[batch]);p=logits.sigmoid()
                    loss=F.binary_cross_entropy_with_logits(logits,yt[batch])
                    if method=='soft':loss=loss+weight*((soft_response(p)-train_targets[batch])**2).mean()
                    elif method=='levelset':loss=loss+weight*layerloss(p,train_targets[batch],gt).mean()
                    elif method=='cldice':loss=loss+weight*cldice(p,yt[batch])
                    loss.backward();opt.step()
                    if step%100==0:budget()
                net.eval();ev=evaluate(net,xv,yv,None,truthval,g)
                path=OUT/f'{method}_{seed}_{weight}.pt'
                torch.save(net.cpu().state_dict(),path)
                row=dict(seed=seed,method=method,weight=weight,val_f1=ev['f1'],val_iou=ev['iou'],path=path.name)
                search.append(row);candidates.append(row)
                log(f'{method} seed={seed} weight={weight} VAL F1={ev["f1"]:.4f}')
            best=max(candidates,key=lambda r:(r['val_f1'],r['val_iou'],-r['weight']))
            chosen[f'{method}_{seed}']=best
    (OUT/'SELECTION.json').write_text(json.dumps(dict(chosen=chosen,search=search),indent=2)+'\n')
    # TEST predictions start only after every validation choice is saved.
    xe=torch.tensor(data['X'][test],device=device);ye=torch.tensor(data['Y'][test],device=device)
    truth=data['classes'][data['index'][test]];allpred=[];ious=[];metrics={}
    for method in METHODS:
        pp=[];ii=[];ss=[]
        for seed in SEEDS:
            row=chosen[f'{method}_{seed}'];net=model();net.load_state_dict(torch.load(OUT/row['path'],weights_only=True));net=net.to(device).eval()
            ev=evaluate(net,xe,ye,None,truth,g);pp.append(ev['prediction']);ii.append(ev['iou_per_image'])
            ss.append([float(f1_score(truth[data['regimes'][test]==r],ev['prediction'][data['regimes'][test]==r],labels=range(3),average='macro',zero_division=0)) for r in range(3)])
        allpred.append(pp);ious.append(ii)
        metrics[method]=dict(macro_f1=float(np.mean(ss)),iou=float(np.mean(ii)),per_seed_regime_f1=ss)
    P=np.array(allpred);I=np.array(ious)
    groups=data['canonical'][data['index'][test]];unique=np.unique(groups);regime=data['regimes'][test]
    np.savez_compressed(OUT/'PREDICTIONS.npz',prediction=P,iou=I,truth=truth,groups=groups,regime=regime)
    # Per-orbit confusion matrices preserve correlated replicas and reflections.
    cm=np.zeros((4,2,3,len(unique),3,3),int)
    for m in range(4):
        for s in range(2):
            for r in range(3):
                for j,grp in enumerate(unique):
                    ix=np.flatnonzero((groups==grp)&(regime==r))
                    np.add.at(cm[m,s,r,j],(truth[ix],P[m,s,ix]),1)
    def macro(c):
        tp=np.diagonal(c,axis1=-2,axis2=-1);den=c.sum(-1)+c.sum(-2)
        return np.divide(2*tp,den,out=np.zeros_like(tp,dtype=float),where=den>0).mean(-1)
    rng=np.random.default_rng(1013);boot=[]
    for _ in range(2000):
        ix=rng.integers(0,len(unique),len(unique));f=macro(cm[:,:,:,ix].sum(3)).mean((1,2));boot.append(f[3]-f[:3])
    comparisons={}
    for j,method in enumerate(METHODS[:3]):
        delta=metrics['levelset']['macro_f1']-metrics[method]['macro_f1'];ci=np.quantile(np.array(boot)[:,j],[.025,.975]).tolist()
        comparisons[method]=dict(delta=delta,ci95=ci,gate=bool(delta>=.02 and ci[0]>0))
    iou_drop=max(metrics[m]['iou'] for m in METHODS[:3])-metrics['levelset']['iou']
    return dict(metrics=metrics,comparisons=comparisons,test_orbits=len(unique),
        iou_drop=iou_drop,gate=bool(all(c['gate'] for c in comparisons.values()) and iou_drop<=.02),
        device=device,steps=400,seeds=SEEDS)

if __name__=='__main__':
    if not torch.backends.mps.is_available():raise RuntimeError('Real MPS unavailable')
    files=[Path(__file__),HERE/'ELECTRICAL_LEVELSET_PROTOCOL.md']
    (OUT/'FROZEN.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    g=table();log('all 65536 electrical responses computed');checks=theory(g);log('theory and gradient checked')
    data=prepare(g);log('data frozen');training=learn(data,g)
    result=dict(scope='Synthetic 4x4 mechanism and CNN pilot; not real semiconductor images',
        theory=checks,learning=training,total_seconds=time.monotonic()-START)
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
