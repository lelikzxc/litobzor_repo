from pathlib import Path
import re,json,hashlib,time,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw
import structured12_learning as physics
from structured12_prepare import canonical

HERE=Path(__file__).resolve().parent;OUT=HERE/'sem_electrical';OUT.mkdir(exist_ok=True)

if __name__=='__main__':
    start=time.monotonic();records=[];xs=[];ys=[];gs=[];used=set();counts={};imagehashes={}
    source=HERE/'sem_author/dataset'
    frozen={str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),HERE/'SEM_ELECTRICAL_PROTOCOL.md',HERE/'structured12_learning.py',*sorted(source.rglob('*.svg')),*sorted(source.rglob('*.png'))]}
    (OUT/'FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
    for split,frames in [('train',range(6)),('val',range(6,8)),('test',range(8,10))]:
        pool={}
        for frame in frames:
            im=np.array(Image.open(source/f'sems/sem{frame:04}.png'))
            svg=ET.parse(source/f'labels/label{frame:04}.svg')
            canvas=Image.new('L',(im.shape[1],im.shape[0]));draw=ImageDraw.Draw(canvas)
            for element in svg.iter('{http://www.w3.org/2000/svg}path'):
                coords=[(int(x),int(y)) for x,y in re.findall(r'[ML](\d+),(\d+) ',element.attrib['d'])]
                assert len(coords)>=3;draw.polygon(coords,fill=1)
            mask=np.array(canvas)
            xx=im[512:-512,512:-512];yy=mask[512:-512,512:-512]
            h,w=xx.shape;h=h//4*4;w=w//4*4
            xx=xx[:h,:w].reshape(h//4,4,w//4,4).mean((1,3)).astype(np.float32)/255
            yy=yy[:h,:w].reshape(h//4,4,w//4,4).mean((1,3))>=.5
            for y in range(0,len(yy)-11,6):
                for x in range(0,yy.shape[1]-11,6):
                    patch=yy[y:y+12,x:x+12]
                    if patch.sum() in [0,144]:continue
                    key=canonical(patch)
                    if key in used or key in pool:continue
                    obs=xx[y:y+12,x:x+12].copy()
                    pool[key]=(obs,patch.copy(),frame,y*4+512,x*4+512)
            print(split,frame,len(pool),round(time.monotonic()-start,2),flush=True)
        keys=sorted(pool);used.update(keys);binary=np.array([pool[k][1] for k in keys])
        conductance=physics.binary_response(binary);labels=physics.label(conductance)
        counts[split]=np.bincount(labels,minlength=3).tolist()
        for key,g,c in zip(keys,conductance,labels):
            obs,mask,frame,y,x=pool[key]
            ih=hashlib.sha256(obs.tobytes()).hexdigest()
            assert ih not in imagehashes or imagehashes[ih]==split
            imagehashes[ih]=split
            records.append(dict(split=split,frame=frame,y=y,x=x,canonical=key.hex(),conductance=float(g),label=int(c)))
            xs.append(obs);ys.append(mask);gs.append(g)
    np.savez_compressed(OUT/'PATCHES.npz',X=np.array(xs),Y=np.array(ys),conductance=np.array(gs),label=np.array([r['label'] for r in records]),split=np.array([r['split'] for r in records]),frame=np.array([r['frame'] for r in records]))
    (OUT/'MANIFEST.json').write_text(json.dumps(records,indent=2)+'\n')
    gate=all(min(counts[s])>=n for s,n in [('train',128),('val',32),('test',32)])
    result=dict(counts=counts,motifs=len(records),data_gate=gate,seconds=time.monotonic()-start,scope='Actual SEM inputs, downsampled annotated geometry, proxy resistor-network labels; one IC')
    (OUT/'PREPARE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
