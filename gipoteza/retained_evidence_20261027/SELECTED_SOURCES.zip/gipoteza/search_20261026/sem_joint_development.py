from pathlib import Path
import hashlib,json,time,copy
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score
import structured12_learning as e6

HERE=Path(__file__).resolve().parent;OUT=HERE/'sem_joint_development';OUT.mkdir(exist_ok=True)
START=time.monotonic()

def log(s):print(f'{time.monotonic()-START:.1f}s {s}',flush=True)
def probabilities(p):return torch.stack([e6.class_probabilities(p),e6.class_probabilities(p.transpose(-1,-2))],1)
def interval_bounds(q,targets):
    t1=1-q[:,:,0];t2=q[:,:,2]
    upper=torch.where(targets==0,torch.ones_like(t1),torch.where(targets==1,t1,t2))
    lower=torch.where(targets==0,t1,torch.where(targets==1,t2,torch.zeros_like(t1)))
    return lower,upper
def features(net,x):return net[:-1](x).flatten(1)
def classes(masks):
    return 3*e6.label(e6.binary_response(masks))+e6.label(e6.binary_response(np.asarray(masks).transpose(0,2,1)))

def evaluate(net,x,y,truth,head=None):
    with torch.inference_mode():
        logits=net(x);hard=(logits[:,0]>=0).cpu().numpy()
        hp=head(features(net,x)).argmax(1).cpu().numpy() if head is not None else None
    yy=y[:,0].cpu().numpy()>.5;union=(hard|yy).sum((1,2));inter=(hard&yy).sum((1,2));pred=classes(hard)
    return dict(f1=float(f1_score(truth,pred,labels=range(9),average='macro',zero_division=0)),iou=float(np.divide(inter,union,out=np.ones(len(union)),where=union>0).mean()),head_f1=float(f1_score(truth,hp,labels=range(9),average='macro',zero_division=0)) if head is not None else None)

def data():
    z=np.load(HERE/'sem_electrical/PATCHES.npz');manifest=json.loads((HERE/'sem_electrical/MANIFEST.json').read_text());selection={s:[] for s in ['anchor','weak','val']}
    target={};counts={}
    for split in ['train','val']:
        ids=np.flatnonzero(z['split']==split);lab=classes(z['Y'][ids]);counts[split]=np.bincount(lab,minlength=9).tolist();target.update(zip(ids.tolist(),lab.tolist()))
        for c in range(9):
            ii=ids[lab==c].tolist();ii.sort(key=lambda i:hashlib.sha256(('E13-select/'+manifest[i]['canonical']).encode()).hexdigest())
            if split=='train':selection['anchor'].extend(ii[:6]);selection['weak'].extend(ii[6:134])
            else:selection['val'].extend(ii[:96])
    out={}
    for name,ids in selection.items():
        ids=np.array(ids);lab=np.array([target[i] for i in ids]);out[name]=dict(x=torch.tensor((z['X'][ids,None]-.2)*5,device='mps'),y=torch.tensor(z['Y'][ids,None].astype(np.float32),device='mps') if name!='weak' else None,target=torch.tensor(lab,device='mps',dtype=torch.long),truth=lab)
    (OUT/'SELECTION.json').write_text(json.dumps(dict(selection=selection,class_counts=counts),indent=2)+'\n');return out

def verify():
    rng=np.random.default_rng(1914);p=torch.tensor(rng.uniform(.01,.99,(100,1,12,12)),dtype=torch.float64)
    target=torch.tensor(rng.integers(0,3,(100,2)),dtype=torch.long);q=probabilities(p);lower,upper=interval_bounds(q,target)
    valid=((lower.max(1).values<.5)&(upper.min(1).values>=.5)).numpy()
    truth=(3*target[:,0]+target[:,1]).numpy();actual=classes(p[:,0].numpy()>=.5)
    assert np.array_equal(valid,actual==truth)
    return dict(joint_equivalence_vectors=100)

if __name__=='__main__':
    assert torch.backends.mps.is_available();torch.set_num_threads(2);checks=verify()
    files=[Path(__file__),HERE/'SEM_JOINT_PROTOCOL.md',HERE/'structured12_learning.py',HERE/'sem_electrical/PATCHES.npz']
    (OUT/'FROZEN.json').write_text(json.dumps({str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    d=data();a,w,v=d['anchor'],d['weak'],d['val'];rows=[]
    wt=torch.stack([w['target']//3,w['target']%3],1);ordinal=(wt[:,:,None]>torch.arange(2,device='mps')[None,None,:]).float()
    thresholds=torch.tensor([.5/((144-1)*e6.physics.FULL),.5],device='mps')
    for seed in [17,41]:
        torch.manual_seed(seed);base=e6.network().to('mps');opt=torch.optim.AdamW(base.parameters(),lr=.003,weight_decay=.0001);rng=np.random.default_rng(seed)
        for _ in range(400):
            ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');opt.zero_grad(set_to_none=True);F.binary_cross_entropy_with_logits(base(a['x'][ai]),a['y'][ai]).backward();opt.step()
        row=dict(method='base',weight=0.,seed=seed,**evaluate(base,v['x'],v['y'],v['truth']));rows.append(row)
        torch.save(base.cpu().state_dict(),OUT/f'base_{seed}.pt');base=base.to('mps');log(str(row))
        for method in ['replay','soft','head','independent','indep_log','joint']:
            for weight in ([0.] if method=='replay' else [1.] if method=='head' else [.1,.4]):
                net=copy.deepcopy(base);head=None;torch.manual_seed(seed+1)
                if method=='head':
                    head=nn.Sequential(nn.Linear(3456,64),nn.GELU(),nn.Linear(64,9)).to('mps');opt=torch.optim.AdamW(head.parameters(),lr=.003,weight_decay=.0001)
                    with torch.no_grad():ff=features(net,a['x']).detach()
                    for _ in range(400):
                        opt.zero_grad(set_to_none=True);F.cross_entropy(head(ff),a['target']).backward();opt.step()
                opt=torch.optim.AdamW(list(net.parameters())+([] if head is None else list(head.parameters())),lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed+10)
                for step in range(400):
                    ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');wi=torch.tensor(rng.integers(0,len(w['x']),16),device='mps')
                    opt.zero_grad(set_to_none=True);loss=F.binary_cross_entropy_with_logits(net(a['x'][ai]),a['y'][ai])
                    if method!='replay':
                        logits=net(w['x'][wi]);p=logits.sigmoid()
                        if method=='head':aux=F.cross_entropy(head(features(net,w['x'][wi])),w['target'][wi])
                        elif method=='soft':
                            response=torch.stack([e6.soft_response(p),e6.soft_response(p.transpose(-1,-2))],1)
                            aux=F.binary_cross_entropy_with_logits(20*(response[:,:,None]-thresholds),ordinal[wi])
                        else:
                            q=probabilities(p)
                            if method=='indep_log':aux=-q.gather(2,wt[wi,:,None]).clamp_min(1e-7).log().mean()
                            else:
                                lower,upper=interval_bounds(q,wt[wi])
                                if method=='joint':lower=lower.max(1).values;upper=upper.min(1).values
                                aux=-.5*(upper.clamp_min(1e-7).log()+(1-lower).clamp_min(1e-7).log()).mean()
                        loss=loss+weight*aux
                    loss.backward();opt.step()
                    if step%100==0:log(f'{method} {weight} seed={seed} step={step}');assert time.monotonic()-START<580
                net.eval();row=dict(method=method,weight=weight,seed=seed,**evaluate(net,v['x'],v['y'],v['truth'],head));rows.append(row)
                torch.save(net.cpu().state_dict(),OUT/f'{method}_{weight}_{seed}.pt')
                if head is not None:torch.save(head.cpu().state_dict(),OUT/f'head_classifier_{seed}.pt')
                (OUT/'PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n');log(str(row))
    aggregate=[]
    for method in sorted({r['method'] for r in rows}):
        for weight in sorted({r['weight'] for r in rows if r['method']==method}):
            rr=[r for r in rows if r['method']==method and r['weight']==weight]
            aggregate.append(dict(method=method,weight=weight,f1=float(np.mean([r['f1'] for r in rr])),iou=float(np.mean([r['iou'] for r in rr])),head_f1=float(np.mean([r['head_f1'] for r in rr])) if method=='head' else None))
    chosen={m:max([r for r in aggregate if r['method']==m],key=lambda r:(r['f1'],r['iou'],-r['weight'])) for m in sorted({r['method'] for r in rows})}
    controls=[r for m,r in chosen.items() if m!='joint'];best=max(max(r['f1'],r['head_f1'] or 0) for r in controls);best_iou=max(r['iou'] for r in controls)
    gate=chosen['joint']['f1']>=best+.01 and chosen['joint']['iou']>=best_iou-.02
    result=dict(scope='Development TRAIN/VAL only, nine proxy joint electrical classes of real SEM structures',verification=checks,chosen=chosen,best_control_f1=best,development_gate=bool(gate),all_search=rows,seconds=time.monotonic()-START)
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');log(json.dumps({k:r for k,r in result.items() if k!='all_search'},indent=2))
