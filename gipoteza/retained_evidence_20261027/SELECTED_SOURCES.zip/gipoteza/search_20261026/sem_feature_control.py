from pathlib import Path
import json,time,hashlib
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score
import sem_weak_development as dev
import structured12_learning as e6

HERE=Path(__file__).resolve().parent;OUT=HERE/'sem_feature_control';OUT.mkdir(exist_ok=True)

def features(net,x):return net[:-1](x).flatten(1)

if __name__=='__main__':
    start=time.monotonic();assert torch.backends.mps.is_available();torch.set_num_threads(2)
    files=[Path(__file__),HERE/'SEM_FEATURE_CONTROL.md',HERE/'sem_weak_development.py']
    (OUT/'FROZEN.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    d=dev.data();a,w,v=d['anchor'],d['weak'],d['val'];rows=[]
    for seed in [17,41]:
        net=e6.network();net.load_state_dict(torch.load(HERE/f'sem_weak_development/base_{seed}.pt',weights_only=True));net=net.to('mps')
        torch.manual_seed(seed+1);head=nn.Sequential(nn.Linear(3456,64),nn.GELU(),nn.Linear(64,3)).to('mps')
        opt=torch.optim.AdamW(head.parameters(),lr=.003,weight_decay=.0001)
        with torch.no_grad():ff=features(net,a['x']).detach()
        for _ in range(400):
            opt.zero_grad(set_to_none=True);F.cross_entropy(head(ff),a['target']).backward();opt.step()
        opt=torch.optim.AdamW(list(net.parameters())+list(head.parameters()),lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed+10)
        for step in range(200):
            ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');wi=torch.tensor(rng.integers(0,len(w['x']),16),device='mps')
            opt.zero_grad(set_to_none=True)
            loss=F.binary_cross_entropy_with_logits(net(a['x'][ai]),a['y'][ai])+F.cross_entropy(head(features(net,w['x'][wi])),w['target'][wi])
            loss.backward();opt.step()
        net.eval();head.eval();ev=dev.evaluate(net,v['x'],v['y'],v['truth'])
        with torch.inference_mode():pred=head(features(net,v['x'])).argmax(1).cpu().numpy()
        ev['head_f1']=float(f1_score(v['truth'],pred,labels=range(3),average='macro',zero_division=0))
        row=dict(seed=seed,**ev);rows.append(row)
        torch.save(net.cpu().state_dict(),OUT/f'net_{seed}.pt');torch.save(head.cpu().state_dict(),OUT/f'head_{seed}.pt');print(json.dumps(row),flush=True)
    result=dict(rows=rows,mask_f1=float(np.mean([r['f1'] for r in rows])),head_f1=float(np.mean([r['head_f1'] for r in rows])),iou=float(np.mean([r['iou'] for r in rows])),seconds=time.monotonic()-start)
    prior=json.loads((HERE/'sem_weak_development/RESULT.json').read_text())
    result['proposal_val_gain']=prior['selected']['f1']-max(result['mask_f1'],result['head_f1'],prior['best_control_f1'])
    result['development_gate']=result['proposal_val_gain']>=.01
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
