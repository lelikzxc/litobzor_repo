from pathlib import Path
import hashlib,json,time,copy
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score
import structured12_learning as e6

HERE=Path(__file__).resolve().parent;OUT=HERE/'sem_weak_development';OUT.mkdir(exist_ok=True)
START=time.monotonic()

def log(s):print(f'{time.monotonic()-START:.1f}s {s}',flush=True)

def evaluate(net,x,y,truth,head=None):
    with torch.inference_mode():
        logits=net(x);p=logits.sigmoid().cpu().numpy()[:,0]
        hp=head(logits.flatten(1)).argmax(1).cpu().numpy() if head is not None else None
    hard=p>=.5;pred=e6.label(e6.binary_response(hard))
    yy=y[:,0].cpu().numpy()>.5;union=(hard|yy).sum((1,2));inter=(hard&yy).sum((1,2))
    iou=float(np.divide(inter,union,out=np.ones(len(union)),where=union>0).mean())
    return dict(f1=float(f1_score(truth,pred,labels=range(3),average='macro',zero_division=0)),iou=iou,
                head_f1=float(f1_score(truth,hp,labels=range(3),average='macro',zero_division=0)) if hp is not None else None)

def data():
    z=np.load(HERE/'sem_electrical/PATCHES.npz');manifest=json.loads((HERE/'sem_electrical/MANIFEST.json').read_text())
    groups={s:[] for s in ['anchor','weak','val']}
    for split in ['train','val']:
        for cls in range(3):
            ids=np.flatnonzero((z['split']==split)&(z['label']==cls)).tolist()
            ids.sort(key=lambda i:hashlib.sha256(('E10-select/'+manifest[i]['canonical']).encode()).hexdigest())
            if split=='train':groups['anchor'].extend(ids[:16]);groups['weak'].extend(ids[16:272])
            else:groups['val'].extend(ids[:192])
    out={}
    for group,ids in groups.items():
        ids=np.array(ids);out[group]=dict(x=torch.tensor((z['X'][ids,None]-.2)*5,device='mps'),
            y=torch.tensor(z['Y'][ids,None].astype(np.float32),device='mps') if group!='weak' else None,
            target=torch.tensor(z['label'][ids],device='mps',dtype=torch.long),truth=z['label'][ids])
    (OUT/'SELECTION.json').write_text(json.dumps(groups,indent=2)+'\n')
    return out

if __name__=='__main__':
    assert torch.backends.mps.is_available();torch.set_num_threads(2)
    files=[Path(__file__),HERE/'SEM_WEAK_DEVELOPMENT.md',HERE/'structured12_learning.py',HERE/'sem_electrical/PATCHES.npz']
    (OUT/'FROZEN.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    d=data();a=d['anchor'];w=d['weak'];v=d['val'];rows=[]
    ordinal=(w['target'][:,None]>torch.arange(2,device='mps')[None,:]).float()
    thresholds=torch.tensor([.5/((144-1)*e6.physics.FULL),.5],device='mps')
    for seed in [17,41]:
        torch.manual_seed(seed);base=e6.network().to('mps');opt=torch.optim.AdamW(base.parameters(),lr=.003,weight_decay=.0001);rng=np.random.default_rng(seed)
        for step in range(400):
            ids=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');opt.zero_grad(set_to_none=True)
            loss=F.binary_cross_entropy_with_logits(base(a['x'][ids]),a['y'][ids]);loss.backward();opt.step()
        row=dict(method='base',weight=0.,seed=seed,**evaluate(base,v['x'],v['y'],v['truth']));rows.append(row)
        torch.save(base.cpu().state_dict(),OUT/f'base_{seed}.pt');base=base.to('mps');log(str(row))
        for method in ['replay','cldice','soft_class','head','interval','boundary']:
            for weight in ([0.] if method=='replay' else [.25] if method=='cldice' else [1.] if method=='head' else [.1,.4]):
                net=copy.deepcopy(base);torch.manual_seed(seed+1)
                head=nn.Sequential(nn.Linear(144,64),nn.GELU(),nn.Linear(64,3)).to('mps') if method=='head' else None
                if head is not None:
                    hop=torch.optim.AdamW(head.parameters(),lr=.003,weight_decay=.0001)
                    with torch.no_grad():frozen=net(a['x']).flatten(1).detach()
                    for _ in range(400):
                        hop.zero_grad(set_to_none=True);F.cross_entropy(head(frozen),a['target']).backward();hop.step()
                params=list(net.parameters())+([] if head is None else list(head.parameters()))
                opt=torch.optim.AdamW(params,lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed+10)
                for step in range(200):
                    ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');wi=torch.tensor(rng.integers(0,len(w['x']),16),device='mps')
                    opt.zero_grad(set_to_none=True);al=net(a['x'][ai]);loss=F.binary_cross_entropy_with_logits(al,a['y'][ai])
                    if method=='cldice':loss=loss+weight*e6.small.cldice(al.sigmoid(),a['y'][ai])
                    elif method!='replay':
                        logits=net(w['x'][wi]);p=logits.sigmoid()
                        if method=='soft_class':aux=F.binary_cross_entropy_with_logits(20*(e6.soft_response(p)[:,None]-thresholds),ordinal[wi])
                        elif method=='head':aux=F.cross_entropy(head(logits.flatten(1)),w['target'][wi])
                        else:
                            q=e6.class_probabilities(p)
                            if method=='interval':aux=-q[torch.arange(len(wi),device='mps'),w['target'][wi]].clamp_min(1e-7).log().mean()
                            else:aux=F.binary_cross_entropy(torch.stack([1-q[:,0],q[:,2]],1).clamp(1e-7,1-1e-7),ordinal[wi])
                        loss=loss+weight*aux
                    loss.backward();opt.step()
                    if step%50==0:log(f'{method} {weight} seed={seed} step={step}');assert time.monotonic()-START<580
                net.eval();row=dict(method=method,weight=weight,seed=seed,**evaluate(net,v['x'],v['y'],v['truth'],head));rows.append(row)
                torch.save(net.cpu().state_dict(),OUT/f'{method}_{weight}_{seed}.pt')
                if head is not None:torch.save(head.cpu().state_dict(),OUT/f'head_classifier_{seed}.pt')
                (OUT/'PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n');log(str(row))
    aggregates=[]
    for method in sorted({r['method'] for r in rows}):
        for weight in sorted({r['weight'] for r in rows if r['method']==method}):
            rr=[r for r in rows if r['method']==method and r['weight']==weight]
            aggregates.append(dict(method=method,weight=weight,f1=float(np.mean([r['f1'] for r in rr])),iou=float(np.mean([r['iou'] for r in rr])),head_f1=float(np.mean([r['head_f1'] for r in rr])) if method=='head' else None))
    chosen={m:max([r for r in aggregates if r['method']==m],key=lambda r:(r['f1'],r['iou'],-r['weight'])) for m in sorted({r['method'] for r in rows})}
    controls=[r for m,r in chosen.items() if m not in ['interval','boundary']]
    best_control=max(max(r['f1'],r['head_f1'] or 0) for r in controls);best_iou=max(r['iou'] for r in controls)
    candidates=[r for m,r in chosen.items() if m in ['interval','boundary'] and r['iou']>=best_iou-.02]
    selected=max(candidates,key=lambda r:(r['f1'],r['iou'])) if candidates else None
    gate=bool(selected is not None and selected['f1']>=best_control+.01)
    result=dict(scope='Real SEM input; proxy electrical labels; TRAIN/VAL development only',chosen=chosen,selected=selected,best_control_f1=best_control,development_gate=gate,all_search=rows,seconds=time.monotonic()-START)
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');log(json.dumps({k:r for k,r in result.items() if k!='all_search'},indent=2))
