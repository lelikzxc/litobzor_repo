from pathlib import Path
import re,json,time,hashlib,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw
import torch
from torch import nn
from sklearn.metrics import f1_score
import structured12_learning as e6
from structured12_prepare import canonical
import sem_weak_test as e11

HERE=Path(__file__).resolve().parent;OUT=HERE/'sem_replication';OUT.mkdir(exist_ok=True)
START=time.monotonic()

def prepare():
    old=json.loads((HERE/'sem_electrical/MANIFEST.json').read_text());seen={bytes.fromhex(r['canonical']) for r in old}
    frames=json.loads((HERE/'sem_replication_frames.json').read_text());source=HERE/'sem_full/dataset'
    X=[];Y=[];records=[];counts={}
    for frame in frames:
        im=np.array(Image.open(source/f'sems/m2/sem{frame:04}.png'))
        svg=ET.parse(source/f'labels/m2/label{frame:04}.svg')
        canvas=Image.new('L',(im.shape[1],im.shape[0]));draw=ImageDraw.Draw(canvas)
        for element in svg.iter('{http://www.w3.org/2000/svg}path'):
            points=[(int(x),int(y)) for x,y in re.findall(r'[ML](\d+),(\d+) ',element.attrib['d'])]
            assert len(points)>=3;draw.polygon(points,fill=1)
        mask=np.array(canvas);xx=im[512:-512,512:-512];yy=mask[512:-512,512:-512]
        h,w=xx.shape;h=h//4*4;w=w//4*4
        xx=xx[:h,:w].reshape(h//4,4,w//4,4).mean((1,3)).astype(np.float32)/255
        yy=yy[:h,:w].reshape(h//4,4,w//4,4).mean((1,3))>=.5
        pool={}
        for y in range(0,len(yy)-11,6):
            for x in range(0,yy.shape[1]-11,6):
                patch=yy[y:y+12,x:x+12]
                if patch.sum() in [0,144]:continue
                key=canonical(patch)
                if key in seen or key in pool:continue
                pool[key]=(xx[y:y+12,x:x+12].copy(),patch.copy(),y*4+512,x*4+512)
        keys=sorted(pool);seen.update(keys)
        gs=e6.binary_response(np.array([pool[k][1] for k in keys]));classes=e6.label(gs)
        counts[str(frame)]=np.bincount(classes,minlength=3).tolist()
        for key,g,c in zip(keys,gs,classes):
            x,y,py,px=pool[key];X.append(x);Y.append(y);records.append(dict(frame=frame,y=py,x=px,canonical=key.hex(),conductance=float(g),label=int(c)))
        print('prepared',frame,len(keys),counts[str(frame)],flush=True)
    total=np.sum(list(counts.values()),0);support=(np.array(list(counts.values()))>0).sum(0)
    gate=bool(np.min(total)>=64 and np.min(support)>=8)
    (OUT/'MANIFEST.json').write_text(json.dumps(records,indent=2)+'\n')
    np.savez_compressed(OUT/'PATCHES.npz',X=np.array(X),Y=np.array(Y),truth=np.array([r['label'] for r in records]),frame=np.array([r['frame'] for r in records]))
    (OUT/'PREPARE_RESULT.json').write_text(json.dumps(dict(counts=counts,total=total.tolist(),class_frame_support=support.tolist(),data_gate=gate),indent=2)+'\n')
    return gate

if __name__=='__main__':
    assert torch.backends.mps.is_available();torch.set_num_threads(2)
    download=json.loads((HERE/'sem_full/DOWNLOAD.json').read_text())
    for row in download['files']:
        assert hashlib.sha256((HERE/'sem_full'/row['name']).read_bytes()).hexdigest()==row['sha256']
    files=[Path(__file__),HERE/'SEM_REPLICATION_PROTOCOL.md',HERE/'sem_remote_zip.py',HERE/'sem_weak_test.py',HERE/'structured12_learning.py',HERE/'structured12_prepare.py',HERE/'sem_full/DOWNLOAD.json',HERE/'sem_replication_frames.json',*sorted((HERE/'sem_weak_test').glob('*.pt'))]
    frozen={str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (OUT/'FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
    if not prepare():
        (OUT/'RESULT.json').write_text(json.dumps(dict(status='DATA_GATE_FAILED',seconds=time.monotonic()-START),indent=2)+'\n');raise SystemExit(0)
    z=np.load(OUT/'PATCHES.npz');truth=z['truth'];frame=z['frame'];frames=np.unique(frame)
    x=torch.tensor((z['X'][:,None]-.2)*5,device='mps');y=torch.tensor(z['Y'][:,None].astype(np.float32),device='mps')
    predictions={m:[] for m in e11.METHODS};predictions['head_class']=[];ious={m:[] for m in e11.METHODS}
    for method in e11.METHODS:
        for seed in e11.SEEDS:
            net=e6.network();net.load_state_dict(torch.load(HERE/f'sem_weak_test/{method}_{seed}.pt',weights_only=True));net=net.to('mps').eval();head=None
            if method=='feature_head':
                head=nn.Sequential(nn.Linear(3456,64),nn.GELU(),nn.Linear(64,3));head.load_state_dict(torch.load(HERE/f'sem_weak_test/head_classifier_{seed}.pt',weights_only=True));head=head.to('mps').eval()
            pp,ii,hp=e11.predict(net,x,y,head);predictions[method].append(pp);ious[method].append(ii)
            if hp is not None:predictions['head_class'].append(hp)
            print(method,seed,round(f1_score(truth,pp,labels=range(3),average='macro',zero_division=0),6),round(float(ii.mean()),6),flush=True)
            assert time.monotonic()-START<580
    np.savez_compressed(OUT/'PREDICTIONS.npz',truth=truth,frame=frame,**{m:np.array(p) for m,p in predictions.items()},**{'iou_'+m:np.array(p) for m,p in ious.items()})
    names=list(predictions);cm=np.zeros((len(names),3,len(frames),3,3),int);metrics={}
    for j,m in enumerate(names):
        pp=np.array(predictions[m]);scores=[];byframe=[]
        for s in range(3):
            scores.append(float(f1_score(truth,pp[s],labels=range(3),average='macro',zero_division=0)))
            byframe.append([float(f1_score(truth[frame==f],pp[s,frame==f],labels=range(3),average='macro',zero_division=0)) for f in frames])
            for k,f in enumerate(frames):
                ids=np.flatnonzero(frame==f);np.add.at(cm[j,s,k],(truth[ids],pp[s,ids]),1)
        metrics[m]=dict(macro_f1=float(np.mean(scores)),per_seed_f1=scores,per_seed_frame_f1=byframe,iou=float(np.mean(ious[m])) if m in ious else None)
    rng=np.random.default_rng(1814);boot=[]
    for _ in range(4000):
        si=rng.integers(0,3,3);fi=rng.integers(0,len(frames),len(frames));boot.append(e6.macro(cm[:,si][:,:,fi].sum(2)).mean(1))
    boot=np.array(boot);proposal=names.index('interval');comparisons={}
    for j,m in enumerate(names):
        if m=='interval':continue
        comparisons[m]=dict(delta=metrics['interval']['macro_f1']-metrics[m]['macro_f1'],ci95=np.quantile(boot[:,proposal]-boot[:,j],[.025,.975]).tolist())
    primary=['soft_class','feature_head','head_class'];ioudrop=max(r['iou'] for r in metrics.values() if r['iou'] is not None)-metrics['interval']['iou']
    gate=bool(all(comparisons[m]['delta']>=.01 and comparisons[m]['ci95'][0]>0 for m in primary) and all(r['delta']>=0 for r in comparisons.values()) and ioudrop<=.02)
    assert all(hashlib.sha256((HERE/p).read_bytes()).hexdigest()==sha for p,sha in frozen.items())
    result=dict(scope='Fresh SEM frames, frozen E11 models, one IC, proxy resistor labels; E11 remains failed',metrics=metrics,comparisons=comparisons,gate=gate,iou_drop=ioudrop,test_examples=len(truth),test_frames=frames.tolist(),seconds=time.monotonic()-START)
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
