from pathlib import Path
import json,time,hashlib
import numpy as np
import torch
from torch.nn import functional as F
import sem_joint_development as dev
import structured12_learning as e6

HERE=Path(__file__).resolve().parent;OUT=HERE/'sem_connectivity_control';OUT.mkdir(exist_ok=True)

if __name__=='__main__':
    start=time.monotonic();assert torch.backends.mps.is_available();torch.set_num_threads(2)
    files=[Path(__file__),HERE/'SEM_GRADED_CANDIDATE.md',HERE/'sem_joint_development.py']
    (OUT/'FROZEN.json').write_text(json.dumps({str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    d=dev.data();a,w,v=d['anchor'],d['weak'],d['val'];rows=[]
    wt=torch.stack([w['target']//3,w['target']%3],1);connected=(wt>0).float()
    for weight in [.1,.4]:
        for seed in [17,41]:
            net=e6.network();net.load_state_dict(torch.load(HERE/f'sem_joint_development/base_{seed}.pt',weights_only=True));net=net.to('mps')
            opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed+10)
            for step in range(400):
                ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');wi=torch.tensor(rng.integers(0,len(w['x']),16),device='mps')
                opt.zero_grad(set_to_none=True);q=dev.probabilities(net(w['x'][wi]).sigmoid())
                loss=F.binary_cross_entropy_with_logits(net(a['x'][ai]),a['y'][ai])+weight*F.binary_cross_entropy((1-q[:,:,0]).clamp(1e-7,1-1e-7),connected[wi])
                loss.backward();opt.step()
                if step%100==0:print(weight,seed,step,round(time.monotonic()-start,1),flush=True)
            net.eval();row=dict(weight=weight,seed=seed,**dev.evaluate(net,v['x'],v['y'],v['truth']));rows.append(row)
            torch.save(net.cpu().state_dict(),OUT/f'net_{weight}_{seed}.pt');print(json.dumps(row),flush=True)
    aggregate=[dict(weight=weight,f1=float(np.mean([r['f1'] for r in rows if r['weight']==weight])),iou=float(np.mean([r['iou'] for r in rows if r['weight']==weight]))) for weight in [.1,.4]]
    chosen=max(aggregate,key=lambda r:(r['f1'],r['iou'],-r['weight']));prior=json.loads((HERE/'sem_joint_development/RESULT.json').read_text())
    proposal=prior['chosen']['joint'];gate=proposal['f1']>=chosen['f1']+.01
    result=dict(scope='TRAIN/VAL connectivity-only ablation, no TEST',chosen=chosen,proposal=proposal,development_gate=bool(gate),all_search=rows,seconds=time.monotonic()-start)
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
