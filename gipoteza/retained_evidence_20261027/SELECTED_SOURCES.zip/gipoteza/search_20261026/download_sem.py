from pathlib import Path
from urllib.request import urlopen
from concurrent.futures import ThreadPoolExecutor
import json,hashlib,time

HERE=Path(__file__).resolve().parent
OUT=HERE/'sem_author';OUT.mkdir(exist_ok=True)
BASE='https://raw.githubusercontent.com/emsec/unsupervised-ic-sem-segmentation/main/'
tree=json.loads((HERE/'sem_tree.json').read_text())['tree']
paths=[r['path'] for r in tree if r.get('type')=='blob' and (r['path'].startswith('dataset/') or r['path'] in ['README.md','libs/labels.py','libs/datasets.py','eval.py'])]

def fetch(path):
    dest=OUT/path;dest.parent.mkdir(parents=True,exist_ok=True)
    if not dest.exists():
        with urlopen(BASE+path,timeout=90) as response:raw=response.read()
        tmp=dest.with_suffix(dest.suffix+'.part');tmp.write_bytes(raw);tmp.replace(dest)
    raw=dest.read_bytes()
    record=dict(path=path,url=BASE+path,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    print(json.dumps(record),flush=True);return record

if __name__=='__main__':
    start=time.monotonic()
    with ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(fetch,paths))
    (OUT/'DOWNLOAD.json').write_text(json.dumps(dict(source='Rothaug et al. ASHES 2023 author repository; dataset CC BY 4.0',files=records,seconds=time.monotonic()-start),indent=2)+'\n')
