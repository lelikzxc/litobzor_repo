from pathlib import Path
import re,json,time,hashlib,copy,xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score
import structured12_learning as e6
from structured12_prepare import canonical
import sem_joint_development as dev

HERE=Path(__file__).resolve().parent;OUT=HERE/'sem_graded_test';OUT.mkdir(exist_ok=True)
START=time.monotonic();SEEDS=[101,173,257];METHODS=['base','replay','soft','head','connectivity','joint']

def log(s):print(f'{time.monotonic()-START:.1f}s {s}',flush=True)
def prepare():
    prior=[]
    for name in ['sem_electrical','sem_replication']:prior.extend(json.loads((HERE/name/'MANIFEST.json').read_text()))
    seen={bytes.fromhex(r['canonical']) for r in prior};frames=json.loads((HERE/'sem_graded_frames.json').read_text());source=HERE/'sem_full/dataset'
    X=[];Y=[];records=[];counts={}
    for frame in frames:
        im=np.array(Image.open(source/f'sems/m2/sem{frame:04}.png'));svg=ET.parse(source/f'labels/m2/label{frame:04}.svg')
        canvas=Image.new('L',(im.shape[1],im.shape[0]));draw=ImageDraw.Draw(canvas)
        for element in svg.iter('{http://www.w3.org/2000/svg}path'):
            points=[(int(x),int(y)) for x,y in re.findall(r'[ML](\d+),(\d+) ',element.attrib['d'])];assert len(points)>=3;draw.polygon(points,fill=1)
        mask=np.array(canvas);xx=im[512:-512,512:-512];yy=mask[512:-512,512:-512];h,w=xx.shape;h=h//4*4;w=w//4*4
        xx=xx[:h,:w].reshape(h//4,4,w//4,4).mean((1,3)).astype(np.float32)/255;yy=yy[:h,:w].reshape(h//4,4,w//4,4).mean((1,3))>=.5
        pool={}
        for y in range(0,len(yy)-11,6):
            for x in range(0,yy.shape[1]-11,6):
                patch=yy[y:y+12,x:x+12]
                if patch.sum() in [0,144]:continue
                key=canonical(patch)
                if key in seen or key in pool:continue
                pool[key]=(xx[y:y+12,x:x+12].copy(),patch.copy(),y*4+512,x*4+512)
        keys=sorted(pool);seen.update(keys);labels=dev.classes(np.array([pool[k][1] for k in keys]));counts[str(frame)]=np.bincount(labels,minlength=9).tolist()
        for key,c in zip(keys,labels):
            x,y,py,px=pool[key];X.append(x);Y.append(y);records.append(dict(frame=frame,y=py,x=px,canonical=key.hex(),label=int(c)))
        log(f'prepared {frame} {len(keys)} {counts[str(frame)]}')
    total=np.sum(list(counts.values()),0);support=(np.array(list(counts.values()))>0).sum(0);gate=bool(np.min(total)>=32 and np.min(support)>=8)
    (OUT/'MANIFEST.json').write_text(json.dumps(records,indent=2)+'\n')
    np.savez_compressed(OUT/'PATCHES.npz',X=np.array(X),Y=np.array(Y),truth=np.array([r['label'] for r in records]),frame=np.array([r['frame'] for r in records]))
    (OUT/'PREPARE_RESULT.json').write_text(json.dumps(dict(counts=counts,total=total.tolist(),class_frame_support=support.tolist(),data_gate=gate),indent=2)+'\n');return gate

def predict(net,x,y,head=None):
    hard=[];hp=[]
    with torch.inference_mode():
        for i in range(0,len(x),256):
            logits=net(x[i:i+256]);hard.extend((logits[:,0]>=0).cpu().numpy())
            if head is not None:hp.extend(head(dev.features(net,x[i:i+256])).argmax(1).cpu().numpy())
    hard=np.array(hard);pred=dev.classes(hard);yy=y[:,0].cpu().numpy()>.5;union=(hard|yy).sum((1,2));inter=(hard&yy).sum((1,2))
    return pred,np.divide(inter,union,out=np.ones(len(union)),where=union>0),np.array(hp) if head is not None else None

if __name__=='__main__':
    assert torch.backends.mps.is_available();torch.set_num_threads(2)
    control=json.loads((HERE/'sem_connectivity_control/RESULT.json').read_text());assert control['development_gate'];cw=control['chosen']['weight']
    download=json.loads((HERE/'sem_full/DOWNLOAD_GRADED.json').read_text())
    for row in download['files']:assert hashlib.sha256((HERE/'sem_full'/row['name']).read_bytes()).hexdigest()==row['sha256']
    files=[Path(__file__),HERE/'SEM_GRADED_TEST_PROTOCOL.md',HERE/'SEM_GRADED_CANDIDATE.md',HERE/'sem_joint_development.py',HERE/'structured12_learning.py',HERE/'structured12_prepare.py',HERE/'sem_electrical/PATCHES.npz',HERE/'sem_electrical/MANIFEST.json',HERE/'sem_joint_development/RESULT.json',HERE/'sem_graded_frames.json',HERE/'sem_full/DOWNLOAD_GRADED.json',HERE/'sem_connectivity_control/RESULT.json',HERE/'sem_replication/MANIFEST.json']
    frozen={str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};(OUT/'FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
    if not prepare():
        (OUT/'RESULT.json').write_text(json.dumps(dict(status='DATA_GATE_FAILED',seconds=time.monotonic()-START),indent=2)+'\n');raise SystemExit(0)
    d=dev.data();a,w=d['anchor'],d['weak'];wt=torch.stack([w['target']//3,w['target']%3],1)
    ordinal=(wt[:,:,None]>torch.arange(2,device='mps')[None,None,:]).float();thresholds=torch.tensor([.5/((144-1)*e6.physics.FULL),.5],device='mps')
    z=np.load(OUT/'PATCHES.npz');truth=z['truth'];frame=z['frame'];frames=np.unique(frame)
    x=torch.tensor((z['X'][:,None]-.2)*5,device='mps');y=torch.tensor(z['Y'][:,None].astype(np.float32),device='mps')
    predictions={m:[] for m in METHODS};predictions['head_class']=[];ious={m:[] for m in METHODS}
    for seed in SEEDS:
        torch.manual_seed(seed);base=e6.network().to('mps');opt=torch.optim.AdamW(base.parameters(),lr=.003,weight_decay=.0001);rng=np.random.default_rng(seed)
        for _ in range(400):
            ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');opt.zero_grad(set_to_none=True);F.binary_cross_entropy_with_logits(base(a['x'][ai]),a['y'][ai]).backward();opt.step()
        for method in METHODS:
            net=copy.deepcopy(base);head=None
            if method!='base':
                torch.manual_seed(seed+1)
                if method=='head':
                    head=nn.Sequential(nn.Linear(3456,64),nn.GELU(),nn.Linear(64,9)).to('mps');opt=torch.optim.AdamW(head.parameters(),lr=.003,weight_decay=.0001)
                    with torch.no_grad():ff=dev.features(net,a['x']).detach()
                    for _ in range(400):
                        opt.zero_grad(set_to_none=True);F.cross_entropy(head(ff),a['target']).backward();opt.step()
                opt=torch.optim.AdamW(list(net.parameters())+([] if head is None else list(head.parameters())),lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed+10)
                for step in range(400):
                    ai=torch.tensor(rng.integers(0,len(a['x']),16),device='mps');wi=torch.tensor(rng.integers(0,len(w['x']),16),device='mps')
                    opt.zero_grad(set_to_none=True);loss=F.binary_cross_entropy_with_logits(net(a['x'][ai]),a['y'][ai])
                    if method!='replay':
                        logits=net(w['x'][wi]);p=logits.sigmoid()
                        if method=='head':aux=F.cross_entropy(head(dev.features(net,w['x'][wi])),w['target'][wi])
                        elif method=='soft':
                            response=torch.stack([e6.soft_response(p),e6.soft_response(p.transpose(-1,-2))],1);aux=F.binary_cross_entropy_with_logits(20*(response[:,:,None]-thresholds),ordinal[wi])
                        else:
                            q=dev.probabilities(p)
                            if method=='connectivity':aux=F.binary_cross_entropy((1-q[:,:,0]).clamp(1e-7,1-1e-7),ordinal[wi,:,0])
                            else:
                                lower,upper=dev.interval_bounds(q,wt[wi]);lower=lower.max(1).values;upper=upper.min(1).values
                                aux=-.5*(upper.clamp_min(1e-7).log()+(1-lower).clamp_min(1e-7).log()).mean()
                        loss=loss+(1. if method=='head' else cw if method=='connectivity' else .4)*aux
                    loss.backward();opt.step()
                    if step%100==0:log(f'{method} seed={seed} step={step}');assert time.monotonic()-START<580
            net.eval();pp,ii,hp=predict(net,x,y,head);predictions[method].append(pp);ious[method].append(ii)
            torch.save(net.cpu().state_dict(),OUT/f'{method}_{seed}.pt')
            if hp is not None:predictions['head_class'].append(hp);torch.save(head.cpu().state_dict(),OUT/f'head_classifier_{seed}.pt')
            log(f'{method} seed={seed} F1={f1_score(truth,pp,labels=range(9),average="macro",zero_division=0):.6f} IoU={ii.mean():.6f}')
    np.savez_compressed(OUT/'PREDICTIONS.npz',truth=truth,frame=frame,**{m:np.array(p) for m,p in predictions.items()},**{'iou_'+m:np.array(p) for m,p in ious.items()})
    names=list(predictions);cm=np.zeros((len(names),3,len(frames),9,9),int);metrics={}
    for j,m in enumerate(names):
        pp=np.array(predictions[m]);scores=[];byframe=[]
        for s in range(3):
            scores.append(float(f1_score(truth,pp[s],labels=range(9),average='macro',zero_division=0)))
            byframe.append([float(f1_score(truth[frame==f],pp[s,frame==f],labels=range(9),average='macro',zero_division=0)) for f in frames])
            for k,f in enumerate(frames):
                ids=np.flatnonzero(frame==f);np.add.at(cm[j,s,k],(truth[ids],pp[s,ids]),1)
        metrics[m]=dict(macro_f1=float(np.mean(scores)),per_seed_f1=scores,per_seed_frame_f1=byframe,iou=float(np.mean(ious[m])) if m in ious else None)
    rng=np.random.default_rng(2014);boot=[]
    for _ in range(4000):
        si=rng.integers(0,3,3);fi=rng.integers(0,len(frames),len(frames));boot.append(e6.macro(cm[:,si][:,:,fi].sum(2)).mean(1))
    boot=np.array(boot);proposal=names.index('joint');comparisons={}
    for j,m in enumerate(names):
        if m=='joint':continue
        comparisons[m]=dict(delta=metrics['joint']['macro_f1']-metrics[m]['macro_f1'],ci95=np.quantile(boot[:,proposal]-boot[:,j],[.025,.975]).tolist())
    primary=['soft','connectivity','head','head_class'];ioudrop=max(r['iou'] for r in metrics.values() if r['iou'] is not None)-metrics['joint']['iou']
    gate=bool(all(comparisons[m]['delta']>=.01 and comparisons[m]['ci95'][0]>0 for m in primary) and all(r['delta']>=0 for r in comparisons.values()) and ioudrop<=.02)
    assert all(hashlib.sha256((HERE/p).read_bytes()).hexdigest()==sha for p,sha in frozen.items())
    result=dict(scope='Fresh SEM frames and seeds; nine proxy electrical states, one IC; limited miniature test',metrics=metrics,comparisons=comparisons,gate=gate,iou_drop=ioudrop,test_examples=len(truth),test_frames=frames.tolist(),seeds=SEEDS,seconds=time.monotonic()-START)
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');log(json.dumps({k:r for k,r in result.items() if k!='metrics'},indent=2))
