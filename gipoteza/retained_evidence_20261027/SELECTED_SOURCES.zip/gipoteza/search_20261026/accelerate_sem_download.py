"""Fetch stored ZIP entries with one validated Range request each."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import struct,zipfile,zlib,json,hashlib
from sem_remote_zip import RemoteZip,SIZE

HERE=Path(__file__).resolve().parent

def fetch(info):
    name=info.filename;p=Path(name);assert not p.is_absolute() and '..' not in p.parts
    dest=HERE/'sem_full'/p
    if dest.exists():raw=dest.read_bytes()
    else:
        assert info.compress_type==0
        remote=RemoteZip();remote.seek(info.header_offset)
        block=remote.read(min(30+len(name.encode())+2048+info.file_size,SIZE-info.header_offset))
        header=struct.unpack('<4s5H3L2H',block[:30]);assert header[0]==b'PK\x03\x04'
        nname,nextra=header[-2:];actual_name=block[30:30+nname].decode('utf-8');assert actual_name==name
        begin=30+nname+nextra;raw=block[begin:begin+info.file_size];assert len(raw)==info.file_size
        assert zlib.crc32(raw)==info.CRC
        dest.parent.mkdir(parents=True,exist_ok=True);tmp=dest.with_suffix(dest.suffix+'.accelerated.part');tmp.write_bytes(raw);tmp.replace(dest)
    assert zlib.crc32(raw)==info.CRC
    row=dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());print(json.dumps(row),flush=True);return row

if __name__=='__main__':
    names=json.loads((HERE/'sem_graded_download.json').read_text())
    with zipfile.ZipFile(RemoteZip()) as z:infos=[z.getinfo(n) for n in names]
    with ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(fetch,infos))
    (HERE/'sem_full/ACCELERATED_DOWNLOAD.json').write_text(json.dumps(records,indent=2)+'\n')
