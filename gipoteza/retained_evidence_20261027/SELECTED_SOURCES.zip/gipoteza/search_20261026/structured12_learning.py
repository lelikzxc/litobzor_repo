from pathlib import Path
import hashlib,json,time
import numpy as np
from scipy import ndimage as ndi
from scipy.ndimage import gaussian_filter
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score
import structured12_prepare as physics
import electrical_levelset_probe as small

HERE=Path(__file__).resolve().parent;OUT=HERE/'structured12_learning';OUT.mkdir(exist_ok=True)
START=time.monotonic();B=12;P=144;METHODS=['bce','soft_class','cldice','interval'];SEEDS=[17,41]

def log(msg):print(f'{time.monotonic()-START:.1f}s {msg}',flush=True)
def budget():
    if time.monotonic()-START>580:raise RuntimeError('E6 600-second budget exceeded')
def label(g):return np.where(g<1e-8,0,np.where(g<.5-1e-8,1,2))

def binary_response(images):
    result=[]
    for im in np.asarray(images,bool).reshape(-1,B,B):
        labs,_=ndi.label(im,ndi.generate_binary_structure(2,1))
        left=np.unique(labs[:,0]);right=np.unique(labs[:,-1]);common=np.intersect1d(left[left>0],right[right>0])
        if not len(common):result.append(0.);continue
        mask=np.isin(labs,common).ravel();active_free=physics.FREE[mask[physics.FREE]]
        w=(mask[physics.SRC]&mask[physics.DST]).astype(float)
        L=np.zeros((P,P));L[np.arange(P),np.arange(P)]=w@physics.ABS
        L[physics.SRC,physics.DST]=-w;L[physics.DST,physics.SRC]=-w
        A=L[np.ix_(active_free,active_free)];bb=-L[np.ix_(active_free,physics.RIGHT)].sum(-1)
        v=np.linalg.solve(A,bb)
        g=(L[np.ix_(physics.RIGHT,physics.RIGHT)].sum()-bb@v)/physics.FULL
        result.append(max(0,float(g)))
    return np.array(result)

def class_probabilities(prob):
    ordered,order=prob.reshape(-1,P).sort(1,descending=True)
    o=order.detach().cpu().numpy();rank=np.empty_like(o);rank[np.arange(len(o))[:,None],o]=np.arange(P)
    ranks=[]
    for target in (1,2):
        low=np.zeros(len(o),int);high=np.full(len(o),P,int)
        while np.any(high-low>1):
            ids=np.flatnonzero(high-low>1);mid=(low[ids]+high[ids])//2
            masks=(rank[ids]<mid[:,None]).reshape(-1,B,B)
            yes=label(binary_response(masks))>=target
            high[ids[yes]]=mid[yes];low[ids[~yes]]=mid[~yes]
        ranks.append(torch.tensor(high-1,device=prob.device,dtype=torch.long))
    t1=ordered.gather(1,ranks[0][:,None])[:,0];t2=ordered.gather(1,ranks[1][:,None])[:,0]
    return torch.stack([1-t1,t1-t2,t2],1)

def soft_response(prob):
    q=prob.reshape(-1,P).to('cpu').clamp(1e-5,1-1e-5)
    src=torch.tensor(physics.SRC);dst=torch.tensor(physics.DST);aa=torch.tensor(physics.ABS,dtype=q.dtype)
    free=torch.tensor(physics.FREE);right=torch.tensor(physics.RIGHT)
    w=torch.minimum(q[:,src],q[:,dst]);L=torch.diag_embed(w@aa)
    L[:,src,dst]=-w;L[:,dst,src]=-w
    A=L[:,free][:,:,free];bb=-L[:,free][:,:,right].sum(-1)
    v=torch.linalg.solve(A,bb[:,:,None])[:,:,0]
    g=(L[:,right][:,:,right].sum((1,2))-(bb*v).sum(-1))/physics.FULL
    return g.to(prob.device)

def network():
    return nn.Sequential(nn.Conv2d(1,24,3,padding=1),nn.GELU(),
        nn.Conv2d(24,24,3,padding=2,dilation=2),nn.GELU(),
        nn.Conv2d(24,24,3,padding=4,dilation=4),nn.GELU(),nn.Conv2d(24,1,1))

def prepare():
    z=np.load(HERE/'structured12/PATCHES.npz');n=z['native'];rng=np.random.default_rng(1415)
    manifest=json.loads((HERE/'structured12/MANIFEST.json').read_text())
    selected=[]
    for split,cap in [('train',256),('val',64),('test',128)]:
        for cls in range(3):
            ids=np.flatnonzero((z['split']==split)&(z['label']==cls)).tolist()
            ids.sort(key=lambda i:hashlib.sha256(('E6-select-'+manifest[i]['canonical']).encode()).hexdigest())
            selected.extend(ids[:cap])
    selected=np.array(selected);X=[];Y=[];idx=[];tags=[];regime=[]
    blur=gaussian_filter(n[selected].astype(float),sigma=(0,.55,.55),mode='constant')
    for j,i in enumerate(selected):
        s=str(z['split'][i]);levels=rng.uniform(.2,.4,2) if s=='train' else [.2,.3,.4]
        for r,level in enumerate(levels):
            X.append(np.clip(blur[j]+rng.normal(0,level,(B,B)),0,1));Y.append(n[i]);idx.append(i);tags.append(s);regime.append(r)
    data=dict(X=np.array(X,np.float32)[:,None],Y=np.array(Y,np.float32)[:,None],
        index=np.array(idx),tags=np.array(tags),regime=np.array(regime),
        label=z['label'][idx],geometry=z['geometry'][idx],selected=selected)
    np.savez_compressed(OUT/'DATA.npz',**data)
    # All split and motif non-overlap assertions are evaluated before training.
    for a,b in [('train','val'),('train','test'),('val','test')]:
        assert not set(z['geometry'][selected[z['split'][selected]==a]])&set(z['geometry'][selected[z['split'][selected]==b]])
    reference=physics.conductance(n[selected[:32]])
    fast=binary_response(n[selected[:32]])
    assert np.max(np.abs(reference-fast))<1e-7
    return data

def evaluate(net,x,y,truth):
    with torch.inference_mode():p=net(x).sigmoid().cpu().numpy()
    hard=p[:,0]>=.5;response=binary_response(hard);pred=label(response);yy=y[:,0].cpu().numpy()>=.5
    intersection=(hard&yy).sum((1,2));union=(hard|yy).sum((1,2))
    iou=np.divide(intersection,union,out=np.ones_like(intersection,dtype=float),where=union>0)
    return pred,iou

def macro(cm):
    tp=np.diagonal(cm,axis1=-2,axis2=-1);den=cm.sum(-1)+cm.sum(-2)
    return np.divide(2*tp,den,out=np.zeros_like(tp,dtype=float),where=den>0).mean(-1)

if __name__=='__main__':
    if not torch.backends.mps.is_available():raise RuntimeError('MPS required, no fallback')
    files=[Path(__file__),HERE/'STRUCTURED12_LEARNING_PROTOCOL.md',HERE/'structured12_prepare.py',HERE/'electrical_levelset_probe.py',HERE/'structured12/PATCHES.npz']
    (OUT/'FROZEN.json').write_text(json.dumps({str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
    data=prepare();torch.set_num_threads(2);log('data frozen, solver equivalence verified')
    train=data['tags']=='train';val=data['tags']=='val';test=data['tags']=='test'
    xt=torch.tensor(data['X'][train],device='mps');yt=torch.tensor(data['Y'][train],device='mps')
    xv=torch.tensor(data['X'][val],device='mps');yv=torch.tensor(data['Y'][val],device='mps')
    targets=torch.tensor(data['label'][train],device='mps',dtype=torch.long)
    ordinal=(targets[:,None]>torch.arange(2,device='mps')[None,:]).float()
    thresholds=torch.tensor([.5/((P-1)*physics.FULL),.5],device='mps',dtype=torch.float32)
    validation=[]
    for method in METHODS:
        for seed in SEEDS:
            torch.manual_seed(seed);net=network().to('mps');opt=torch.optim.AdamW(net.parameters(),lr=.003,weight_decay=.0001)
            rng=np.random.default_rng(seed)
            for step in range(400):
                ids=torch.tensor(rng.integers(0,len(xt),16),device='mps')
                opt.zero_grad(set_to_none=True);logits=net(xt[ids]);prob=logits.sigmoid()
                loss=F.binary_cross_entropy_with_logits(logits,yt[ids])
                if method=='soft_class':loss=loss+.01*F.binary_cross_entropy_with_logits(20*(soft_response(prob)[:,None]-thresholds),ordinal[ids])
                elif method=='cldice':loss=loss+.25*small.cldice(prob,yt[ids])
                elif method=='interval':
                    q=class_probabilities(prob)
                    loss=loss-.025*q[torch.arange(len(ids),device='mps'),targets[ids]].clamp_min(1e-7).log().mean()
                loss.backward();opt.step()
                if step%100==0:log(f'{method} seed={seed} step={step} loss={float(loss.detach()):.5f}');budget()
            net.eval();pv,iv=evaluate(net,xv,yv,data['label'][val])
            validation.append(dict(method=method,seed=seed,f1=float(f1_score(data['label'][val],pv,labels=range(3),average='macro',zero_division=0)),iou=float(iv.mean())))
            torch.save(net.cpu().state_dict(),OUT/f'{method}_{seed}.pt')
            log(f'{method} seed={seed} complete');budget()
    (OUT/'VALIDATION.json').write_text(json.dumps(validation,indent=2)+'\n')
    xe=torch.tensor(data['X'][test],device='mps');ye=torch.tensor(data['Y'][test],device='mps');truth=data['label'][test]
    regime=data['regime'][test];geo=data['geometry'][test];unique=np.unique(geo)
    PRED=[];IOU=[];metrics={}
    for method in METHODS:
        pp=[];ii=[];ss=[]
        for seed in SEEDS:
            net=network();net.load_state_dict(torch.load(OUT/f'{method}_{seed}.pt',weights_only=True));net=net.to('mps').eval()
            p,iou=evaluate(net,xe,ye,truth);pp.append(p);ii.append(iou)
            ss.append([float(f1_score(truth[regime==r],p[regime==r],labels=range(3),average='macro',zero_division=0)) for r in range(3)])
        PRED.append(pp);IOU.append(ii);metrics[method]=dict(macro_f1=float(np.mean(ss)),iou=float(np.mean(ii)),per_seed_regime_f1=ss)
    PRED=np.array(PRED);IOU=np.array(IOU)
    np.savez_compressed(OUT/'PREDICTIONS.npz',prediction=PRED,iou=IOU,truth=truth,regime=regime,geometry=geo)
    cm=np.zeros((4,2,3,len(unique),3,3),int)
    for m in range(4):
        for s in range(2):
            for r in range(3):
                for j,g in enumerate(unique):
                    ix=np.flatnonzero((geo==g)&(regime==r));np.add.at(cm[m,s,r,j],(truth[ix],PRED[m,s,ix]),1)
    rng=np.random.default_rng(1416);boot=[]
    for _ in range(2000):
        ix=rng.integers(0,len(unique),len(unique));f=macro(cm[:,:,:,ix].sum(3)).mean((1,2));boot.append(f[3]-f[:3])
    comparisons={}
    for j,m in enumerate(METHODS[:3]):
        delta=metrics['interval']['macro_f1']-metrics[m]['macro_f1'];ci=np.quantile(np.array(boot)[:,j],[.025,.975]).tolist()
        comparisons[m]=dict(delta=delta,ci95=ci,gate=bool(delta>=.02 and ci[0]>0))
    bygeo=macro(cm).mean((1,2));positive=int(np.sum(bygeo[3]>bygeo[1]))
    ioudrop=max(metrics[m]['iou'] for m in METHODS[:3])-metrics['interval']['iou']
    result=dict(scope='Native simulated lithographic motifs, synthetic blur/noise; all source geometries previously studied',
        metrics=metrics,comparisons=comparisons,test_geometries=len(unique),
        positive_geometries_vs_soft=positive,iou_drop=ioudrop,
        gate=bool(all(c['gate'] for c in comparisons.values()) and positive>=4 and ioudrop<=.02),
        selected_counts={s:int(np.sum(data['tags']==s)) for s in ['train','val','test']},
        device='mps',physics_device='cpu',total_seconds=time.monotonic()-START)
    (OUT/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
