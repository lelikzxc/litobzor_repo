"""CPU numerical proof checks for a proposed mask-consistent circuit operator.

Synthetic probability grids only. No SEM data, labels, learned models, training,
or segmentation-quality estimates are used. Four virtual corner contacts are
structural probes, not measured electrical terminals of an IC.
"""
from pathlib import Path
import hashlib
import json
import time

import numpy as np
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent


def grid(q):
    q = np.asarray(q, dtype=np.float64)
    n = q.shape[0]
    assert q.shape == (n, n) and np.isfinite(q).all() and (q > 0).all()
    pairs = [(y*n+x, yy*n+xx) for y in range(n) for x in range(n)
             for yy, xx in ((y+1, x), (y, x+1)) if yy < n and xx < n]
    src, dst = np.array(pairs, dtype=int).T
    incidence = np.zeros((len(src), n*n))
    incidence[np.arange(len(src)), src] = 1
    incidence[np.arange(len(src)), dst] = -1
    c = np.minimum(q.ravel()[src], q.ravel()[dst])
    ports = np.array([0, n-1, n*n-1, n*(n-1)])
    free = np.setdiff1d(np.arange(n*n), ports)
    laplacian = incidence.T @ (c[:, None]*incidence)
    A = laplacian[np.ix_(free, free)]
    inverse = np.linalg.solve(A, np.eye(len(free)))
    cross = laplacian[np.ix_(ports, free)]
    response = laplacian[np.ix_(ports, ports)]-cross @ inverse @ cross.T
    BI = incidence[:, free].T
    BB = incidence[:, ports].T
    # Each column of T maps contact potentials to one edge voltage drop.
    T = BB-cross @ inverse @ BI
    return dict(q=q, n=n, src=src, dst=dst, incidence=incidence,
                c=c, ports=ports, free=free, laplacian=laplacian,
                inverse=inverse, BI=BI, T=T, response=response)


def direct_response(laplacian, free, ports):
    A = laplacian[np.ix_(free, free)]
    cross = laplacian[np.ix_(ports, free)]
    return laplacian[np.ix_(ports, ports)]-cross @ np.linalg.solve(A, cross.T)


def pixel_edit(system, index, target):
    """Exact joint update of all conductances affected by one mask pixel.

    For incident edges E, D=diag(delta_c), H=BI_E.T A^-1 BI_E:
        delta_S = T_E (D^-1 + H)^-1 T_E.T.
    Zero changes are omitted so D^-1 is always defined. This is not a sum of
    single-edge effects; off-diagonal entries of H retain joint interactions.
    """
    q = system['q'].ravel().copy()
    q[index] = target
    updated = np.minimum(q[system['src']], q[system['dst']])
    delta = updated-system['c']
    active = np.flatnonzero(np.abs(delta) > 1e-15)
    assert len(active) <= 4
    if not len(active):
        return np.zeros((4, 4)), active, delta
    BI = system['BI'][:, active]
    T = system['T'][:, active]
    H = BI.T @ system['inverse'] @ BI
    middle = np.diag(1/delta[active])+H
    change = T @ np.linalg.solve(middle, T.T)
    return change, active, delta


def maps(q, epsilon):
    """Two D4-equivariant magnitudes; no GT or class label is an input."""
    q = np.clip(np.asarray(q, dtype=float), epsilon, 1-epsilon)
    system = grid(q)
    full_response = grid(np.full(q.shape, 1-epsilon))['response']
    scale = np.linalg.norm(full_response, ord='fro')
    output = np.zeros((2, *q.shape))
    for i in range(q.size):
        for channel, target in enumerate([1-epsilon, epsilon]):
            change, _, _ = pixel_edit(system, i, target)
            output[channel].ravel()[i] = np.linalg.norm(change, ord='fro')/scale
    return output


def fixtures(n, rng):
    random = .02+.96*rng.random((n, n))
    uniform = np.full((n, n), .4)
    bridge = np.full((n, n), .02)
    bridge[n//2-1:n//2+1, :] = .98
    bridge[:, 0] = .98; bridge[:, -1] = .98
    bridge[n//2-1:n//2+1, n//2] = .12
    separated = np.full((n, n), .01)
    separated[1:3, :] = .98; separated[-3:-1, :] = .98
    return [('random', random), ('uniform', uniform), ('bottleneck', bridge),
            ('separated_tracks', separated)]


def main():
    start = time.monotonic()
    rng = np.random.default_rng(271102)
    maximum = dict(direct_Woodbury=0., symmetry=0., row_sum=0.,
                   monotonicity_violation=0., D4_equivariance=0.)
    records = []
    max_single_edge_gap = 0.; max_sum_edge_gap = 0.; witness = None
    with threadpool_limits(limits=2):
        for n in [8, 12]:
            for name, raw in fixtures(n, rng):
                for epsilon in [1e-3, 1e-4, 1e-5]:
                    q = np.clip(raw, epsilon, 1-epsilon)
                    system = grid(q)
                    chosen = sorted(set([0, n-1, n*(n-1), n*n-1,
                                         n//2, n*(n//2)+n//2, n*(n//2)+n//2-1]))
                    for index in chosen:
                        for direction, target in [('add', 1-epsilon), ('remove', epsilon)]:
                            change, active, delta = pixel_edit(system, index, target)
                            incidence = system['incidence']
                            new_laplacian = system['laplacian']+incidence.T @ (delta[:, None]*incidence)
                            exact = direct_response(new_laplacian, system['free'], system['ports'])
                            error = float(np.max(np.abs(system['response']+change-exact)))
                            maximum['direct_Woodbury'] = max(maximum['direct_Woodbury'], error)
                            maximum['symmetry'] = max(maximum['symmetry'], float(np.max(np.abs(change-change.T))))
                            maximum['row_sum'] = max(maximum['row_sum'], float(np.max(np.abs(change.sum(1)))))
                            eigenvalues = np.linalg.eigvalsh((change+change.T)/2)
                            violation = max(0., -float(eigenvalues.min())) if direction == 'add' else max(0., float(eigenvalues.max()))
                            maximum['monotonicity_violation'] = max(maximum['monotonicity_violation'], violation)
                            single_changes = []
                            for edge in active:
                                bi = system['BI'][:, edge]; t = system['T'][:, edge]
                                h = bi @ system['inverse'] @ bi
                                single_changes.append(delta[edge]/(1+delta[edge]*h)*np.outer(t, t))
                            single_gap = float(np.linalg.norm(change-single_changes[0])) if len(active) else 0.
                            sum_gap = float(np.linalg.norm(change-np.sum(single_changes, axis=0))) if len(active) else 0.
                            if sum_gap > max_sum_edge_gap:
                                max_sum_edge_gap = sum_gap
                                witness = dict(size=n, fixture=name, epsilon=epsilon, pixel=index,
                                               direction=direction, changed_edges=len(active),
                                               joint_vs_sum_single_edge_Frobenius_gap=sum_gap,
                                               joint_response_Frobenius=float(np.linalg.norm(change)))
                            max_single_edge_gap = max(max_single_edge_gap, single_gap)
                            records.append(dict(size=n, fixture=name, epsilon=epsilon, pixel=index,
                                                direction=direction, changed_edges=len(active), error=error))
        q = .03+.94*rng.random((8, 8)); epsilon = 1e-4
        original = maps(q, epsilon)
        map_bounds = [float(original.min()), float(original.max())]
        for reflected in [False, True]:
            for rotation in range(4):
                transformed_q = np.rot90(np.fliplr(q) if reflected else q, rotation)
                expected = np.rot90(np.flip(original, axis=2) if reflected else original, rotation, axes=(1, 2))
                actual = maps(transformed_q, epsilon)
                maximum['D4_equivariance'] = max(maximum['D4_equivariance'], float(np.max(np.abs(expected-actual))))
    checks = dict(direct_Woodbury_matches=maximum['direct_Woodbury'] < 1e-7,
                  response_symmetry=maximum['symmetry'] < 1e-7,
                  response_row_sums_zero=maximum['row_sum'] < 1e-7,
                  Rayleigh_monotonicity=maximum['monotonicity_violation'] < 1e-7,
                  D4_equivariance=maximum['D4_equivariance'] < 1e-7,
                  bounded_maps=map_bounds[0] >= -1e-12 and map_bounds[1] <= 1+1e-7,
                  joint_pixel_not_single_edge=max_single_edge_gap > 1e-5,
                  joint_pixel_not_sum_independent_edges=max_sum_edge_gap > 1e-5,
                  at_most_four_incident_edges=all(r['changed_edges'] <= 4 for r in records),
                  synthetic_inputs_only=True, no_GT_or_class_label_input=True,
                  no_training_or_segmentation_quality_claim=True)
    result = dict(status='PASS_NUMERICAL_OPERATOR_CHECK' if all(checks.values()) else 'FAIL_NUMERICAL_OPERATOR_CHECK',
                  checks=checks, seed=271102, pixel_intervention_cases=len(records),
                  sizes=[8, 12], epsilons=[1e-3, 1e-4, 1e-5],
                  maximum_errors=maximum, normalized_map_range=map_bounds,
                  maximum_joint_vs_one_edge_gap=max_single_edge_gap,
                  maximum_joint_vs_sum_edges_gap=max_sum_edge_gap, joint_interaction_witness=witness,
                  seconds=time.monotonic()-start,
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  scope='Numerical operator identities on synthetic grids only; no learned module, SEM experiment, novelty proof, physical IC calibration, or segmentation-gain evidence.',
                  mechanism_caveat='Finite maps are determined by harmonic voltage patterns and grounded Green/effective-resistance submatrices. They contain no extra measured information; the proposed contribution would be architectural use of joint mask-consistent edit responses.',
                  records=records)
    ROOT.mkdir(exist_ok=True)
    (ROOT/'MATH_CHECK.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'records'}, indent=2))
    assert all(checks.values()), checks


if __name__=='__main__':
    main()
