"""Report saved orbit-pooling inference trials without executing models."""
from __future__ import annotations

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
HELPER = ROOT.parent / "sem_arch_joint_adaptation_20261102" / "report.py"
spec = importlib.util.spec_from_file_location("saved_json_report_helpers", HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
read, sha, rel = helpers.read, helpers.sha, helpers.rel
percent, pp, passed, mean = helpers.percent, helpers.pp, helpers.passed, helpers.mean
discover, actual_rows = helpers.discover, helpers.actual_rows
plt, np = helpers.plt, helpers.np


def result_views(groups, trials):
    output = []
    for group in groups:
        complete = [trial for trial in trials if trial["result"] and trial["result"]["group"] == group]
        aggregates = [trial for trial in complete if trial["aggregate"]]
        if aggregates:
            chosen = aggregates[-1]
            output += [(f"{group}: all 3 seeds", chosen["aggregate"]),
                       (f"{group}: new 2 seeds", chosen["result"])]
        elif complete:
            output += [(f"{group}: {trial['result']['seeds']}", trial["result"]) for trial in complete]
    return output


def verify_result(result):
    rows = result["rows"]
    group = result["group"]
    passes = 4 if group == "C4" else 8
    assert result["fit_count"] == result["updates"] == 0
    assert result.get("optimizer_updates", 0) == 0
    units = {(row["source_lr"], row["budget"], row["seed"]) for row in rows}
    assert len(rows) == 2 * len(units)
    pairs = {}
    for row in rows:
        key = row["source_lr"], row["budget"], row["seed"]
        assert row["arm"] in ["identity", group]
        assert (key, row["arm"]) not in pairs
        pairs[key, row["arm"]] = row
        assert row["fit_count"] == row["optimizer_updates"] == row["trainable_parameters"] == 0
        assert row["parameters"] == 10681
        assert row["forward_passes_per_image"] == (1 if row["arm"] == "identity" else passes)
        assert row["scored_forward_examples"] == row["evaluated_images"] * row["forward_passes_per_image"]
        source = row["source"]
        for file_key, hash_key in [("checkpoint_file", "checkpoint_sha256"),
                                  ("control_result_file", "control_result_sha256"),
                                  ("source_audit_file", "source_audit_sha256"),
                                  ("config_snapshot_file", "config_snapshot_sha256")]:
            assert sha(REPO / source[file_key]) == source[hash_key]
    for key in units:
        identity, pooled = pairs[key, "identity"], pairs[key, group]
        assert identity["source"] == pooled["source"], "Pooling and identity must use the exact same weights"
    assert {key[0] for key in units} == {"high_lr", "low_lr"}


def avg(result, family, arm):
    rows = [row for row in result["rows"] if row["source_lr"] == family and row["arm"] == arm]
    return mean(rows)


def figure(result_views):
    if not result_views:
        return None
    path = ROOT / "figures" / "orbit_validation.png"
    path.parent.mkdir(exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.2))
    x = np.arange(len(result_views));width = .18
    for offset, family, pooled, label, color in [
        (-1.5, "high_lr", False, "identity: source lr=0.0005", "#777777"),
        (-.5, "high_lr", True, "orbit: source lr=0.0005", "#3c78a8"),
        (.5, "low_lr", False, "identity: source lr=0.0001", "#aaaaaa"),
        (1.5, "low_lr", True, "orbit: source lr=0.0001", "#b25a43")]:
        values = [100 * avg(result, family, result["group"] if pooled else "identity") for _, result in result_views]
        bars = axes[0].bar(x + offset * width, values, width, label=label, color=color)
        axes[0].bar_label(bars, fmt="%.2f", padding=3, fontsize=7)
    axes[0].set_ylim(0, min(100, max(bar.get_height() for bar in axes[0].patches) + 9))
    axes[0].set_ylabel("Validation Macro-F1, %")
    axes[0].set_title("Same source weights; separately selected thresholds")
    axes[0].legend(fontsize=8, loc="lower left")
    for offset, family, label, color in [(-.1, "high_lr", "orbit − identity: source lr=0.0005", "#3c78a8"),
                                          (.1, "low_lr", "orbit − identity: source lr=0.0001", "#b25a43")]:
        values = [100 * result["gates"]["A_architecture"]["by_source_lr"][family]["delta"] for _, result in result_views]
        axes[1].scatter(x + offset, values, s=55, color=color, label=label)
    axes[1].axhline(0, color="black", lw=.8)
    axes[1].axhline(.5, color="gray", ls="--", lw=.8, label="Mean-gain gate: +0.5 pp")
    axes[1].set_ylabel("Macro-F1 difference, percentage points")
    axes[1].set_title("Development estimates; no independent TEST")
    axes[1].legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.12))
    for axis in axes:
        axis.set_xticks(x, [name for name, _ in result_views])
        axis.set_xlim(-.6, len(x) - .4)
    fig.suptitle("Shared-weight orbit pooling: C4 costs 4 passes; D4 costs 8", fontsize=11)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def threshold_figure(diagnostic):
    if not diagnostic:
        return None
    path = ROOT / "figures" / "threshold_robustness.png"
    points = [(cohort, family) for cohort in ["all_three", "new_two"] for family in ["high_lr", "low_lr"]]
    fig, axis = plt.subplots(figsize=(9, 4.2))
    x = np.arange(len(points))
    original = [100 * diagnostic["original_seven_grid_gates"][cohort]["A_architecture"]["by_source_lr"][family]["delta"]
                for cohort, family in points]
    fine = [100 * diagnostic[cohort]["gates"]["by_source_lr"][family]["delta"] for cohort, family in points]
    axis.scatter(x - .08, original, s=55, label="Primary 7-threshold grid", color="#3c78a8")
    axis.scatter(x + .08, fine, s=55, marker="D", label="Secondary 81-threshold grid", color="#b25a43")
    for index, (before, after) in enumerate(zip(original, fine)):
        axis.plot([index - .08, index + .08], [before, after], color="gray", lw=.8, zorder=0)
    axis.axhline(0, color="black", lw=.8)
    axis.axhline(.5, color="gray", ls="--", lw=.8, label="Mean-gain gate: +0.5 pp")
    axis.set_xticks(x, [f"{'all 3 seeds' if cohort == 'all_three' else 'new 2 seeds'}\n{family}" for cohort, family in points])
    axis.set_ylabel("Macro-F1: C4 − identity, percentage points")
    axis.set_title("Secondary calibration check on the same saved VAL probabilities")
    axis.legend(fontsize=8, loc="center left")
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def build():
    config = read(ROOT / "CONFIG.json")
    trials = discover(ROOT)
    complete = [trial for trial in trials if trial["result"]]
    failures = [trial for trial in trials if trial["failure"]]
    pending = [trial for trial in trials if not trial["result"] and not trial["failure"]]
    previous = []
    for link in config["prior_stage_links"]:
        path = (ROOT / link).resolve()
        assert path.parent == ROOT.parent and path != ROOT
        assert path not in [stage["path"] for stage in previous]
        previous.append({"path": path, "trials": discover(path)})
    prior_trials = [trial for stage in previous for trial in stage["trials"]]
    prior_fit_rows = actual_rows(prior_trials)
    high_path = (REPO / config["high_lr_control_result"]).resolve()
    high = read(high_path)
    low_paths = [(REPO / path).resolve() for path in [config["low_lr_control_result"]] + config.get("low_lr_additional_control_results", [])]
    # Replication freezes its expanded controls in its own configuration; the
    # original screen configuration remains unchanged. Follow saved source refs.
    low_paths += [(REPO / source["control_result_file"]).resolve() for trial in complete
                  for source in trial["result"]["sources"] if source["source_lr"] == "low_lr"]
    low_paths = list(dict.fromkeys(low_paths))
    low = [row for path in low_paths for row in read(path)["rows"] if row["arm"] == "continued_base_low_lr"]
    assert len(low) == len({(row["budget"], row["seed"]) for row in low})
    extra_low = [row for row in low if row not in prior_fit_rows]
    local_control_rows = [row for path in low_paths if path.is_relative_to(ROOT)
                          for row in read(path)["rows"]
                          if row["arm"] == "continued_base_low_lr" and row not in prior_fit_rows]
    local_control_updates = sum(row["steps"] for row in local_control_rows)
    local_control_run_count = sum(path.is_relative_to(ROOT) for path in low_paths)
    prior_fits = len(prior_fit_rows) + len(high["rows"])
    unique_fits = prior_fits + len(extra_low)
    evaluations = actual_rows(trials)
    result_views_list = result_views(config["groups"], trials)
    for trial in complete:
        result = trial["result"]
        assert result["frozen_sha256"] == sha(trial["path"] / "FROZEN.json")
        assert trial["frozen"]["fit_count"] == trial["frozen"]["optimizer_updates"] == 0
        assert result["evaluation_count"] == len(result["rows"])
        assert result["scored_forward_examples"] == sum(row["scored_forward_examples"] for row in result["rows"])
        verify_result(result)
        if trial["aggregate"]:
            verify_result(trial["aggregate"])
    output_figure = figure(result_views_list)
    diagnostic_path = ROOT / "threshold_diagnostic" / "RESULT.json"
    diagnostic = read(diagnostic_path)
    diagnostic_audit_path = diagnostic_path.with_name("AUDIT.json")
    diagnostic_audit = read(diagnostic_audit_path)
    threshold_plot = None
    if diagnostic:
        assert diagnostic["frozen_sha256"] == sha(diagnostic_path.with_name("FROZEN.json"))
        assert diagnostic["thresholds"] == [round(.1 + .01 * index, 2) for index in range(81)]
        assert diagnostic["unique_scored_units"] == 24
        assert diagnostic["fit_count"] == diagnostic["optimizer_updates"] == diagnostic["model_forward_passes"] == 0
        threshold_plot = threshold_figure(diagnostic)
    text = [
        "# Объединение предсказаний CNN по симметриям", "",
        "Шестой последовательный этап разработки на прежней TRAIN/VAL: **меняется структура предсказания, "
        "обучения orbit-оператора нет**. Это ансамбль предсказаний с общими весами: "
        "одна исходная CNN с 10 681 общим параметром обрабатывает точные преобразования "
        "изображения; карты вероятности поворачиваются обратно и усредняются. "
        "Новые параметры, лосс и оптимизатор не вводятся. Веса прежних CNN получены с общим BCE+geometry_loss. "
        "Это адаптивная оценка на прежней VAL, без независимого TEST и заявления о новизне или уровне Q1.", "",
        "`P_G(x) = mean_g [g⁻¹ sigmoid(f_θ(gx))]`. C4 использует 0/90/180/270 градусов; "
        "D4 добавляет отражения и запускается отдельной попыткой только после неудачного C4. "
        "Преобразования переставляют пиксели без интерполяции. Маска и класс выводятся после объединения "
        "карт вероятности; номера классов не усредняются.", "",
        "Стоимость предсказания: identity — **1 проход CNN**, C4 — **4**, D4 — **8** на изображение. "
        "Это рост стоимости прямого прохода при тех же весах; ниже опубликованы измеренные времена. "
        "Предварительный прогрев для времени и технические проверки учитываются отдельно от оценочных проходов.", "",
        "## Попытки, обучения и оценки", "",
        f"В этом этапе начато попыток {len(trials)}; завершено {len(complete)}; технических ошибок {len(failures)}; "
        f"незавершённых {len(pending)}. Сохранено **{len(evaluations)} оценочных строк**. "
        "Каждая строка — оценка identity или orbit одной CNN, а не новое обучение. "
        "Новых обучений orbit-моделей: **0**, обновлений orbit-моделей: **0**. "
        f"Отдельно в этой папке сохранено новых CNN-контролей: {len(local_control_rows)}, "
        f"их обновлений: {local_control_updates:,}.", "",
        f"Пять предыдущих этапов содержат {len(prior_trials)} попыток и {prior_fits} уникальных обучений. "
        f"Дополнительных low-lr CNN-контролей вне прежних попыток: {len(extra_low)}; "
        f"уникальных обучений с ними: **{unique_fits}**. Общие веса и строки AGGREGATE_RESULT повторно не считаются. "
        f"Всего архитектурных попыток, включая оценки orbit: {len(prior_trials) + len(trials)}. "
        f"Отдельных локальных запусков обучения CNN-контролей: {local_control_run_count}.", "",
        "## Сравнение с identity при тех же весах", "",
        "Семьи источников оцениваются раздельно: уже дообученные CNN с lr=0,0005 и lr=0,0001. "
        "Identity и orbit каждой пары (семья весов, бюджет, seed) используют один и тот же checkpoint и его SHA. "
        "Нужен средний ΔMacro-F1 ≥0,5 п.п., ΔF1 каждого бюджета ≥−0,25 п.п., средний ΔIoU ≥−0,2 п.п. "
        "Общий A требует прохождения обеих семей. Бюджеты 18/27 равновесны. "
        "Это проверка архитектуры предсказания; добавочная польза физических карт здесь не проверяется. "
        "На расширении новые seed 5521/5557 и все три с 5501 публикуются отдельно, и нужны оба результата.", "",
    ]
    for path in [high_path] + low_paths:
        text.append(f"- Источник весов: [{rel(path, ROOT)}]({rel(path, ROOT)}), SHA-256 `{sha(path)}`.")
    text += ["", "| Вариант / набор seed | High-lr identity F1, % | High-lr orbit F1, % | Low-lr identity F1, % | Low-lr orbit F1, % | A high / low / обе |",
             "|---|---:|---:|---:|---:|---|"]
    for label, result in result_views_list:
        gate = result["gates"]["A_architecture"]
        text.append(f"| {label} | {percent(avg(result, 'high_lr', 'identity'))} | "
                    f"{percent(avg(result, 'high_lr', result['group']))} | {percent(avg(result, 'low_lr', 'identity'))} | "
                    f"{percent(avg(result, 'low_lr', result['group']))} | "
                    f"{passed(gate['by_source_lr']['high_lr']['passed'])} / "
                    f"{passed(gate['by_source_lr']['low_lr']['passed'])} / {passed(gate['passed'])} |")
    if not result_views_list:
        text += ["| Завершённых результатов ещё нет | — | — | — | — | — |"]
    text.append("")
    if output_figure:
        text += ["![Средние VAL и сравнение с identity](figures/orbit_validation.png)", "",
                 "Показаны точечные средние; интервалы независимого подтверждения не рассчитываются. "
                 "При расширении средние всех трёх и новых двух seed перекрываются по данным.", ""]
    if diagnostic:
        text += ["## Плотная сетка порога: вторичная проверка", "",
                 "[THRESHOLD_PROTOCOL.md](THRESHOLD_PROTOCOL.md) записан после C4-скрининга и до вычисления "
                 "плотной сетки. Исходные результаты семи порогов сохранены. Одна общая сетка 0,10…0,90 "
                 "с шагом 0,01 даёт 81 порог для каждого identity/C4, с прежним правилом выбора. "
                 "Проверены 24 уникальные сохранённые вероятностные карты, всего 1 944 оценки порога; "
                 "исходный seed из скрининга повторно не добавляется. Новых CNN-проходов или обучений нет.", "",
                 f"[Все оценки и выбранные пороги](threshold_diagnostic/RESULT.json), SHA-256 `{sha(diagnostic_path)}`; "
                 "[замороженные входы и SHA](threshold_diagnostic/FROZEN.json). "
                 "Ниже те же ограничения F1/бюджетов/IoU, отдельно на всех трёх и новых двух seed.", "",
                 "| Набор seed | Семья весов | ΔF1 C4 − identity, п.п. | ΔIoU, п.п. | ΔF1 бюджеты 18 / 27, п.п. | Вторичный критерий |",
                 "|---|---|---:|---:|---|---|"]
        for cohort, label in [("all_three", "все три"), ("new_two", "новые два")]:
            for family, gate in diagnostic[cohort]["gates"]["by_source_lr"].items():
                text.append(f"| {label} | {family} | {pp(gate['delta'])} | {pp(gate['IoU_delta'])} | "
                            f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
        text += ["", f"На исходной сетке все три и новые два seed: "
                 f"**{passed(diagnostic['original_seven_grid_robust_pass'])}**. "
                 f"На плотной сетке: **{passed(diagnostic['secondary_robustness_pass'])}**. "
                 f"Совместное условие устойчивости на обеих сетках: **{passed(diagnostic['robust_on_both_grids'])}**. "
                 "Это проверка устойчивости к калибровке на той же VAL, без независимого статистического подтверждения.", ""]
        if diagnostic_audit:
            text += [f"Аудит вторичной проверки: `{diagnostic_audit.get('status', 'см. файл')}`, "
                     f"{diagnostic_audit.get('checks_passed', 'см. файл')} / {diagnostic_audit.get('checks_total', 'см. файл')}. "
                     "[AUDIT.json](threshold_diagnostic/AUDIT.json).", ""]
        else:
            text += ["Независимый аудит плотной сетки пока не сохранён.", ""]
        text += ["![Исходная и плотная сетки порога](figures/threshold_robustness.png)", ""]
    text += ["## Все сохранённые попытки orbit", ""]
    for trial in trials:
        path = trial["path"]
        text += [f"### {path.name}", "", f"[FROZEN.json]({rel(path / 'FROZEN.json', ROOT)}).", ""]
        if not trial["result"]:
            if trial["failure"]:
                item = trial["failure"]
                text += [f"Техническая ошибка `{item.get('error_type', 'см. файл')}`: "
                         f"{str(item.get('error', '')).replace(chr(10), ' ')}. "
                         f"[FAILURE.json]({rel(path / 'FAILURE.json', ROOT)}). "
                         "Технический исход не считается отрицательным научным результатом.", ""]
            else:
                text += ["Попытка начата; итогового результата ещё нет.", ""]
            text += [f"Сохранённых оценок: {len(trial['partial'])}; новых обучений 0.", ""]
            continue
        result = trial["result"]
        text += [f"`{result['status']}`; {result['group']}; {result['phase']}; seed {result['seeds']}; "
                 f"оценок {result['evaluation_count']}; новых обучений 0; суммарное время {result['seconds']:.2f} с. "
                 f"[RESULT.json]({rel(path / 'RESULT.json', ROOT)}), SHA-256 `{sha(path / 'RESULT.json')}`.", "",
                 f"Оценочных CNN-проходов по отдельным изображениям: {result['scored_forward_examples']:,}; "
                 f"прогрев для измерения времени: {result['timing_warmup_forward_examples']:,}. "
                 "Это не включает отдельные эквивариантностные fixtures; их назначение — техническая проверка.", "",
                 "| Семья весов | Бюджет | Seed | Предсказание | Порог VAL | Macro-F1, % | IoU, % | Проходов / изображение | Прямой проход 695 VAL, с |",
                 "|---|---:|---:|---|---:|---:|---:|---:|---:|"]
        for row in result["rows"]:
            selected = row["selected"]
            text.append(f"| {row['source_lr']} | {row['budget']} | {row['seed']} | {row['arm']} | "
                        f"{selected['threshold']:.2f} | {percent(selected['mask_F1'])} | {percent(selected['IoU'])} | "
                        f"{row['forward_passes_per_image']} | {row['forward_seconds']:.4f} |")
        text.append("")
        gate_results = [("только эта попытка", result)]
        if trial["aggregate"]:
            gate_results.append(("все три seed", trial["aggregate"]))
            text += [f"[AGGREGATE_RESULT.json]({rel(path / 'AGGREGATE_RESULT.json', ROOT)}) "
                     "объединяет исходный скрининг и новые seed; повторно строки не считаются.", ""]
        for label, item in gate_results:
            text += [f"**{label}: {item['seeds']}**", "",
                     "| Семья весов | ΔF1 orbit − identity, п.п. | ΔIoU, п.п. | ΔF1 бюджеты 18 / 27, п.п. | A |",
                     "|---|---:|---:|---|---|"]
            for family, gate in item["gates"]["A_architecture"]["by_source_lr"].items():
                text.append(f"| {family} | {pp(gate['delta'])} | {pp(gate['IoU_delta'])} | "
                            f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
            text += ["", f"Совместный критерий двух семей: **{passed(item['gates']['A_any'])}**.", ""]
        if trial["aggregate"]:
            robust = trial["aggregate"]["gates"]["A_any"] and result["gates"]["A_any"]
            text += [f"Одновременно на всех трёх и новых двух seed: **{passed(robust)}**.", ""]
        audit = trial["audit"]
        text += [(f"Независимый CPU-аудит: `{audit.get('status', 'см. файл')}`, "
                  f"проверок {audit.get('checks_passed', 'см. файл')} / {audit.get('checks_total', 'см. файл')}. "
                  f"[AUDIT.json]({rel(path / 'AUDIT.json', ROOT)})." if audit else
                  "Итоговый независимый аудит ещё не сохранён."), ""]
        old_audits = sorted(path.glob("AUDIT_PREVIOUS_*.json"))
        if old_audits:
            text += ["Предыдущие версии технического аудита сохранены:", ""]
            for old_path in old_audits:
                old = read(old_path)
                text.append(f"- [{old_path.name}]({rel(old_path, ROOT)}): `{old.get('status', 'см. файл')}`.")
            text += ["", "Актуальный аудит использует contiguous CPU-вход для независимой свёртки; "
                     "прежний view-layout давал зависящее от шага памяти округление. "
                     "Модель, вероятности, допуск и критерии разработки сохранены. "
                     "Это исправление технической проверки, отдельное от обучения или научного исхода.", ""]
    text += ["## Все предыдущие обучающие попытки", "",
             "У этапов 1/2 A сравнивал с замороженной CNN, у этапов 3–5 — с двумя дообученными CNN. "
             "Эти прежние критерии сохранены; они не заменяются критерием orbit/identity.", "",
             "| Этап / попытка | Seed | Обучений | F1 каждого варианта, % | Прежний A каждого варианта | B / C |",
             "|---|---|---:|---|---|---|"]
    for stage in previous:
        for trial in stage["trials"]:
            result, path = trial["result"], trial["path"]
            label = f"{stage['path'].name} / {path.name}"
            if result:
                gates = result["gates"]
                arms = list(dict.fromkeys(row["arm"] for row in result["rows"]))
                values = "; ".join(f"{arm}: {percent(mean(result['rows'], arm))}" for arm in arms)
                a_values = "; ".join(f"{arm}: {passed(gate['passed'])}" for arm, gate in gates["A_architecture"].items())
                c_gate = gates.get("C_skip_route", gates.get("C_detail"))
                c_value = passed(c_gate["passed"]) if c_gate else "—"
                text.append(f"| [{label}]({rel(path / 'RESULT.json', ROOT)}) | {result['seeds']} | "
                            f"{len(result['rows'])} | {values} | {a_values} | {passed(gates['B_physics']['passed'])} / {c_value} |")
            else:
                text.append(f"| {label}: {'техническая ошибка' if trial['failure'] else 'незавершена'} | "
                            f"{trial['frozen'].get('seeds', 'см. файл')} | {len(trial['partial'])} | — | — | — |")
    text += ["", "## Данные и пределы вывода", "",
             "Оцениваются прежние 695 VAL из TRAIN_VAL; новых изображений, меток или независимых кадров нет. "
             "Порог каждого identity/orbit выбирается по одной VAL-сетке [0,30; 0,40; 0,45; 0,50; 0,55; 0,60; 0,70] "
             "по Macro-F1, затем IoU, близости к 0,5 и меньшему порогу. Девять классов выводятся из бинарной маски "
             "тем же геометрическим правилом, а не являются авторской типологией дефектов.", "",
             "Даже PASS на двух семьях весов остаётся результатом адаптивного поиска на многократно использованной VAL. "
             "Для независимого подтверждения нужны заранее зафиксированные модель/критерии и закрытые новые данные, "
             "не использованные в EDA, разработке или прежних тестах. Проверка на одном изделии не устанавливает перенос. "
             "Формальная симметрия и технический PASS сами по себе не доказывают численную пользу или новизну.", "",
             "[PROTOCOL.md](PROTOCOL.md) · [CONFIG.json](CONFIG.json) · [LEDGER.json](LEDGER.json) · "
             "[model.py](model.py) · [runner.py](runner.py) · [audit.py](audit.py).", ""]
    (ROOT / "REPORT.md").write_text("\n".join(text))
    secondary_readme = (f"Фиксированная плотная сетка81: совместное условие исходной/плотной сетки "
                        f"на всех3 и новых2 seed — **{passed(diagnostic['robust_on_both_grids'])}**. "
                        "[Все вторичные оценки](threshold_diagnostic/RESULT.json).\n\n" if diagnostic else "")
    (ROOT / "README.md").write_text(
        "# CNN с объединением вероятностей по симметриям\n\n"
        "Шестой этап — ансамбль предсказаний с общими весами: C4 требует 4 CNN-прохода, "
        "D4 — 8 вместо одного. Новых параметров, обучений и обновлений orbit-моделей нет. "
        "A сравнивает orbit/identity на одних весах отдельно для двух семей дообученных CNN.\n\n"
        f"Завершено попыток {len(complete)}, технических ошибок {len(failures)}, сохранено оценочных строк {len(evaluations)}. "
        f"Отдельно обучено локальных CNN-контролей {len(local_control_rows)}. "
        f"Уникальных обучений по связанным этапам {unique_fits}; оценки не считаются обучениями.\n\n"
        f"{secondary_readme}"
        "[Отчёт со всеми попытками и стоимостью](REPORT.md) · [Протокол](PROTOCOL.md) · "
        "[Конфигурация](CONFIG.json) · [Журнал](LEDGER.json).\n\n"
        "Только повторно используемая VAL. Нового TEST и независимого подтверждения нет.\n\n"
        "Пересоздать только отчёт и рисунок:\n\n"
        "```bash\n.venv/bin/python -B gipoteza/sem_arch_orbit_pool_20261102/report.py\n```\n")
    inputs = [HELPER, high_path] + low_paths
    if diagnostic:
        inputs += [diagnostic_path, diagnostic_path.with_name("FROZEN.json"), ROOT / "THRESHOLD_PROTOCOL.md",
                   ROOT / "threshold_diagnostic.py"]
        if diagnostic_audit:
            inputs.append(diagnostic_audit_path)
    for path in [high_path] + low_paths:
        inputs += [path.with_name(name) for name in ["FROZEN.json", "CONFIG_SNAPSHOT.json", "AUDIT.json"]
                   if path.with_name(name).exists()]
    for stage in previous + [{"path": ROOT, "trials": trials}]:
        inputs += [stage["path"] / name for name in ["PROTOCOL.md", "CONFIG.json", "QUEUE.json", "LEDGER.json", "STAGE_LINK.json"]
                   if (stage["path"] / name).exists()]
        for trial in stage["trials"]:
            inputs += [trial["path"] / name for name in ["FROZEN.json", "RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json",
                       "PARTIAL_RESULTS.json", "AUDIT.json", "SOURCE_MANIFEST.json", "CONFIG_SNAPSHOT.json"] if (trial["path"] / name).exists()]
            inputs += sorted(trial["path"].glob("AUDIT_PREVIOUS_*.json"))
    for trial in complete:
        for source in trial["result"]["sources"]:
            inputs += [REPO / source[key] for key in ["checkpoint_file", "control_result_file", "source_audit_file", "config_snapshot_file"]]
    outputs = [ROOT / "REPORT.md", ROOT / "README.md"] + ([output_figure] if output_figure else [])
    if threshold_plot:
        outputs.append(threshold_plot)
    manifest = dict(status="REPORT_GENERATED", scope="ADAPTIVE_REUSED_VAL_ZERO_TRAINING_INFERENCE",
        UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), report_script_sha256=sha(Path(__file__)),
        shared_report_helper_sha256=sha(HELPER), trial_count=len(trials), completed_trials=len(complete),
        failed_trials=len(failures), pending_trials=len(pending), actual_completed_fits=len(local_control_rows),
        local_control_fits=len(local_control_rows), local_control_run_count=local_control_run_count,
        new_orbit_model_fits=0, orbit_optimizer_updates=0,
        optimizer_updates=local_control_updates, evaluation_count=len(evaluations),
        scored_forward_examples=sum(row["scored_forward_examples"] for row in evaluations),
        timing_warmup_forward_examples=sum(row["timing_warmup_forward_examples"] for row in evaluations),
        nominal_passes_per_image=dict(identity=1, C4=4, D4=8),
        prior_unique_completed_fits=prior_fits, extra_low_lr_control_fits_outside_prior_trials=len(extra_low),
        linked_stage_total_attempts=len(prior_trials) + len(trials), linked_stage_unique_completed_fits=unique_fits,
        attempt_count_scope="Architecture trials; control training runs and secondary calibration diagnostic listed separately",
        reused_control_fits_counted_as_local=False, new_control_fits_counted_as_local=bool(local_control_rows),
        matching_unit=["source_lr", "budget", "seed"],
        secondary_threshold_diagnostic=({"result_sha256": sha(diagnostic_path),
            "original_seven_grid_robust_pass": diagnostic["original_seven_grid_robust_pass"],
            "secondary_robustness_pass": diagnostic["secondary_robustness_pass"],
            "robust_on_both_grids": diagnostic["robust_on_both_grids"],
            "threshold_score_evaluations": diagnostic["threshold_score_evaluations"]} if diagnostic else None),
        scientific_inputs_sha256={rel(path, ROOT): sha(path) for path in inputs},
        outputs_sha256={rel(path, ROOT): sha(path) for path in outputs})
    (ROOT / "REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
