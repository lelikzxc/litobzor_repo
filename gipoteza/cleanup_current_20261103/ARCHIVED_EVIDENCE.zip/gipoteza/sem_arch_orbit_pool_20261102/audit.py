"""Independent CPU audit of shared-weight symmetry pooling on reused VAL.

No training, optimization, downloads or TEST/EVAL access. Graph classes and
CNN/group operators are reconstructed independently of model and runner.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import time

import numpy as np
from scipy import linalg, ndimage
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
REPO = G.parent
PILOT = G / 'sem_architecture_pilot_20261102'
_DIRECTION_CACHE = {}
_CLASS_CACHE = {}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def digest(state):
    h = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()

def macro_f1(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    denominator = confusion.sum(0) + confusion.sum(1)
    return float(np.divide(2 * np.diag(confusion), denominator,
                           out=np.zeros(9, float), where=denominator > 0).mean())

def mean_iou(masks, target):
    union = (masks | target).sum((-2, -1))
    intersection = (masks & target).sum((-2, -1))
    return float(np.divide(intersection, union, out=np.ones(len(union)),
                           where=union > 0).mean())

def direction_class(mask):
    """Independent active-node Cholesky solve of the binary unit-edge graph."""
    mask = np.ascontiguousarray(mask, dtype=bool)
    key = np.packbits(mask).tobytes()
    if key in _DIRECTION_CACHE:
        return _DIRECTION_CACHE[key]
    components, _ = ndimage.label(mask, ndimage.generate_binary_structure(2, 1))
    spanning = np.intersect1d(components[:, 0], components[:, -1])
    spanning = spanning[spanning > 0]
    if not len(spanning):
        answer = 0
    else:
        active = np.isin(components, spanning)
        vertices = np.flatnonzero(active.ravel())
        lookup = np.full(144, -1, dtype=int)
        lookup[vertices] = np.arange(len(vertices))
        laplacian = np.zeros((len(vertices), len(vertices)), dtype=np.float64)
        for vertex in vertices:
            y, x = divmod(int(vertex), 12)
            for yy, xx in [(y + 1, x), (y, x + 1)]:
                if yy < 12 and xx < 12 and active[yy, xx]:
                    a, b = lookup[vertex], lookup[yy * 12 + xx]
                    laplacian[a, a] += 1; laplacian[b, b] += 1
                    laplacian[a, b] -= 1; laplacian[b, a] -= 1
        left = np.flatnonzero(vertices % 12 == 0)
        right = np.flatnonzero(vertices % 12 == 11)
        free = np.setdiff1d(np.arange(len(vertices)), np.r_[left, right])
        potential = np.zeros(len(vertices)); potential[right] = 1
        if len(free):
            potential[free] = linalg.solve(
                laplacian[np.ix_(free, free)],
                -laplacian[np.ix_(free, right)].sum(1), assume_a='pos',
                check_finite=False)
        conductance = float((laplacian[right] @ potential).sum()) / (12 / 11)
        answer = 0 if conductance < 1e-8 else (1 if conductance < .5 - 1e-8 else 2)
    _DIRECTION_CACHE[key] = answer
    return answer

def classify(masks):
    result = []
    for mask in np.asarray(masks, dtype=bool).reshape(-1, 12, 12):
        key = np.packbits(mask).tobytes()
        if key not in _CLASS_CACHE:
            _CLASS_CACHE[key] = 3 * direction_class(mask) + direction_class(mask.T)
        result.append(_CLASS_CACHE[key])
    return np.asarray(result, dtype=np.int64)

def conv(x, state, prefix, padding=0, dilation=1):
    return F.conv2d(x, state[prefix + '.weight'], state[prefix + '.bias'],
                    padding=padding, dilation=dilation)

def independent_backbone(x, state):
    features = x
    for index, dilation in [(0, 1), (2, 2), (4, 4)]:
        features = F.gelu(conv(features, state, str(index), dilation, dilation))
    coarse = conv(features, state, '6')
    return torch.cat((features, coarse, x), 1), coarse

def selected(scores):
    return max(scores, key=lambda row: (row['mask_F1'], row['IoU'],
                -abs(row['threshold'] - .5), -row['threshold']))

def gate(delta_f1, delta_iou, config):
    checks = {
        'mean_F1_gain': float(np.mean(delta_f1)) >= config['minimum_mean_F1_gain'],
        'each_budget_guard': min(delta_f1) >= config['minimum_budget_F1_delta'],
        'mean_IoU_guard': float(np.mean(delta_iou)) >= config['minimum_mean_IoU_delta'],
    }
    return {'passed': all(checks.values()), 'checks': checks,
            'mean_F1_delta': float(np.mean(delta_f1)),
            'budget_F1_deltas': list(map(float, delta_f1)),
            'mean_IoU_delta': float(np.mean(delta_iou))}

def compare_stored_gates(computed, stored):
    """Compare semantic gate outcomes, permitting only historical key spelling."""
    def canonical(value):
        if isinstance(value, dict):
            names = {'delta': 'mean_F1_delta', 'IoU_delta': 'mean_IoU_delta',
                     'budget_deltas': 'budget_F1_deltas', 'budget_F1_guard': 'each_budget_guard'}
            return {names.get(key, key): canonical(item) for key, item in value.items()
                    if key != 'interpretation'}
        if isinstance(value, list):
            return [canonical(item) for item in value]
        return value
    actual, observed = canonical(computed), canonical(stored)
    def compare(left, right):
        if isinstance(left, dict):
            assert set(left) == set(right), (set(left), set(right))
            return max([compare(left[key], right[key]) for key in left] + [0.])
        if isinstance(left, list):
            assert len(left) == len(right)
            return max([compare(a, b) for a, b in zip(left, right)] + [0.])
        if isinstance(left, bool):
            assert left == right, (left, right)
            return 0.
        return abs(float(left) - float(right))
    return compare(actual, observed)

def independent_transform(value, rotation, reflection=False):
    result = torch.rot90(value, int(rotation), (-2, -1))
    return result.flip(-1) if reflection else result


def independent_inverse(value, rotation, reflection=False):
    result = value.flip(-1) if reflection else value
    return torch.rot90(result, -int(rotation), (-2, -1))


def independent_pool(images, state, group):
    """Average inverse probability maps, never logits or scalar class labels."""
    elements = [(rotation, reflection) for reflection in ([False] if group == 'C4' else [False, True])
                for rotation in range(4)]
    restored = []
    for rotation, reflection in elements:
        # Canonical strides prevent CPU convolution choosing different rounding
        # paths for pixel-identical rotations represented by different views.
        transformed = independent_transform(images, rotation, reflection).contiguous()
        logits = independent_backbone(transformed, state)[1]
        restored.append(independent_inverse(logits.sigmoid(), rotation, reflection))
    return torch.stack(restored).mean(0), torch.stack(restored)


def independent_gates(rows, group, config):
    output = {}
    for source in ['high_lr', 'low_lr']:
        by_budget = {}
        for budget in [18, 27]:
            by_budget[budget] = {}
            for arm in ['identity', group]:
                chosen = [row for row in rows if row['budget'] == budget and
                          row['source_lr'] == source and row['arm'] == arm]
                by_budget[budget][arm] = {metric: float(np.mean([row['selected'][metric] for row in chosen]))
                                        for metric in ['mask_F1', 'IoU']}
        output[source] = gate([by_budget[budget][group]['mask_F1'] - by_budget[budget]['identity']['mask_F1']
                               for budget in [18, 27]],
                              [by_budget[budget][group]['IoU'] - by_budget[budget]['identity']['IoU']
                               for budget in [18, 27]], config['gates'])
    passed = all(item['passed'] for item in output.values())
    return dict(A_architecture=dict(by_source_lr=output, passed=passed), A_any=passed)

def independently_measure_equivariance(images, state, group, thresholds, chosen_threshold):
    elements = [(rotation, reflection) for reflection in ([False] if group == 'C4' else [False, True])
                for rotation in range(4)]
    inverse_exact = True; maximum = 0.; masks_equal = True; classes_equal = True
    with torch.inference_mode():
        base = independent_pool(images, state, group)[0]
        base_masks = base[:, 0].numpy() >= chosen_threshold
        base_classes = classify(base_masks)
        for rotation, reflection in elements:
            transformed = independent_transform(images, rotation, reflection)
            inverse_exact &= torch.equal(independent_inverse(transformed, rotation, reflection), images)
            output = independent_pool(transformed, state, group)[0]
            restored = independent_inverse(output, rotation, reflection)
            maximum = max(maximum, float((restored - base).abs().max()))
            for threshold in thresholds:
                masks_equal &= torch.equal(restored >= threshold, base >= threshold)
            restored_masks = restored[:, 0].numpy() >= chosen_threshold
            classes_equal &= np.array_equal(classify(restored_masks), base_classes)
            transformed_masks = output[:, 0].numpy() >= chosen_threshold
            expected_classes = 3 * (base_classes % 3) + base_classes // 3 if rotation % 2 else base_classes
            classes_equal &= np.array_equal(classify(transformed_masks), expected_classes)
    return dict(group=group, elements=len(elements), input_inverse_bit_exact=bool(inverse_exact),
        maximum_probability_equivariance_error=maximum, all_grid_restored_masks_exact=bool(masks_equal),
        restored_and_rotated_direction_classes_exact=bool(classes_equal))

def audit_trial(folder):
    start = time.monotonic()
    read = lambda name: json.loads((folder / name).read_text())
    result, frozen, config = (read(name) for name in ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json'])
    monitored = [folder / name for name in ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json', 'SOURCE_MANIFEST.json', 'PROTOCOL.md']]
    monitored += [ROOT / 'model.py', ROOT / 'runner.py', PILOT / 'TRAIN_VAL.npz']
    before = {str(path): sha(path) for path in monitored}
    checks = {}
    group, phase, seeds = result['group'], result['phase'], result['seeds']
    expected_seeds = [5501] if phase == 'screen' else [5521, 5557]
    elements = [(rotation, reflection) for reflection in ([False] if group == 'C4' else [False, True])
                for rotation in range(4)]
    checks['explicit_zero_training_reused_VAL_scope'] = (
        result['status'] == 'COMPLETE_ZERO_TRAINING_DEVELOPMENT' and
        result['fit_count'] == result['updates'] == result['optimizer_updates'] == 0 and
        frozen['fit_count'] == frozen['optimizer_updates'] == 0 and
        'reused-VAL' in result['scope'] and 'no TEST/EVAL' in frozen['scope'])
    checks['fixed_protocol_configuration_source_snapshots'] = (
        sha(folder / 'FROZEN.json') == result['frozen_sha256'] and
        sha(folder / 'PROTOCOL.md') == config['protocol_sha256'] == frozen['protocol_sha256'] and
        sha(folder / 'CONFIG_SNAPSHOT.json') == frozen['config_sha256'] and
        all(sha(ROOT / name) == value for name, value in frozen['source_sha256'].items()) and
        all(sha(folder / 'source' / name) == frozen['source_sha256'][name] for name in ['model.py', 'runner.py']))
    checks['fixed_grid_thresholds_gates_and_equivariance_tolerance'] = (
        result['candidate'] == frozen['candidate'] == config['candidate'] == 'orbit_probability_pool' and
        config['groups'] == ['C4', 'D4'] and group in config['groups'] and config['budgets'] == [18, 27] and
        config['screen_seeds'] == [5501] and config['replication_seeds'] == [5501, 5521, 5557] and
        config['thresholds'] == [.3, .4, .45, .5, .55, .6, .7] and config['technical_seed'] == 6503 and
        config['equivariance_tolerance'] == 1e-6 and
        config['gates'] == dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025, minimum_mean_IoU_delta=-.002))
    tree = ast.parse((folder / 'source' / 'runner.py').read_text())
    model_tree = ast.parse((folder / 'source' / 'model.py').read_text())
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)]
    prohibited = [node for node in calls if isinstance(node.func, ast.Attribute) and node.func.attr in
                  ['backward', 'step', 'Adam', 'AdamW', 'SGD']]
    reads = [node for node in calls if isinstance(node.func, ast.Attribute) and
             isinstance(node.func.value, ast.Name) and node.func.value.id == 'np' and node.func.attr == 'load']
    val_function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'val_inputs')
    forward_function = next(node for node in ast.walk(model_tree) if isinstance(node, ast.FunctionDef) and node.name == 'forward_details')
    forward_source = ast.unparse(forward_function)
    checks['source_no_optimizer_training_or_new_loss_only_VAL_archive_read'] = (
        not prohibited and len(reads) == 1 and reads[0] in list(ast.walk(val_function)) and
        "PILOT / 'TRAIN_VAL.npz'" in ast.unparse(val_function) and
        "z['role'] == 'val'" in ast.unparse(val_function))
    checks['source_shared_weights_inverse_probability_maps_no_interpolation'] = (
        'self.backbone(transform(x, element)).sigmoid()' in forward_source and
        'inverse_transform(' in forward_source and 'aligned = torch.stack(aligned)' in forward_source and
        'probability=aligned.mean(0)' in forward_source and
        not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and
                node.func.attr in ['interpolate', 'grid_sample', 'affine_grid'] for node in ast.walk(model_tree)))
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        val = np.flatnonzero(archive['role'] == 'val')
        images = torch.tensor(5 * (archive['X'][val] - .2))
        truth = archive['label'][val]; target = archive['Y'][val, 0].astype(bool)
        frames = archive['frame'][val]
    checks['unchanged_695_VAL_indices_frames_and_truth'] = (
        sha(PILOT / 'TRAIN_VAL.npz') == frozen['lineage']['TRAIN_VAL_sha256'] and
        sha(PILOT / 'INITIAL_LINEAGE.json') == frozen['lineage']['initial_lineage_sha256'] and
        frozen['lineage']['VAL_indices'] == val.tolist() and len(val) == 695 and set(frames) == {6, 7} and
        np.array_equal(classify(target), truth))
    refs, rows = result['sources'], result['rows']
    grid = {(source, budget, seed) for source in ['high_lr', 'low_lr'] for budget in [18, 27] for seed in expected_seeds}
    checks['exact_source_and_identity_orbit_grids_no_seed_double_count'] = (
        seeds == frozen['seeds'] == expected_seeds and refs == frozen['sources'] == read('SOURCE_MANIFEST.json') and
        len(refs) == result['source_model_count'] == frozen['source_model_count'] == len(grid) and
        {(ref['source_lr'], ref['budget'], ref['seed']) for ref in refs} == grid and
        len(rows) == result['evaluation_count'] == frozen['evaluation_count'] == 2 * len(grid) and
        {(row['source_lr'], row['budget'], row['seed'], row['arm']) for row in rows} ==
        {(*item, arm) for item in grid for arm in ['identity', group]})
    architecture = frozen['architecture']
    checks['10681_shared_parameters_zero_new_or_trainable_and_explicit_pass_cost'] = (
        architecture['backbone_parameters'] == 10681 and architecture['new_parameters'] == 0 and
        architecture['trainable_parameters'] == architecture['optimizer_updates'] == 0 and
        architecture['forward_passes_per_image'] == len(elements) and
        architecture['elements'] == [[rotation, reflection] for rotation, reflection in elements])
    states = {}; original_rows = {}; sources_ok = True; paired = True
    for ref in refs:
        key = ref['source_lr'], ref['budget'], ref['seed']
        for file_key, hash_key in [('checkpoint_file', 'checkpoint_sha256'), ('control_result_file', 'control_result_sha256'),
                                   ('source_audit_file', 'source_audit_sha256'), ('config_snapshot_file', 'config_snapshot_sha256')]:
            path = REPO / ref[file_key]
            sources_ok &= sha(path) == ref[hash_key]
            before[str(path)] = sha(path)
        control_path = REPO / ref['control_result_file']
        control = json.loads(control_path.read_text())
        source_audit = json.loads((REPO / ref['source_audit_file']).read_text())
        source_settings = json.loads((REPO / ref['config_snapshot_file']).read_text())
        old = next(row for row in control['rows'] if row['budget'] == ref['budget'] and row['seed'] == ref['seed'] and
                   (ref['source_lr'] == 'high_lr' or row['arm'] == 'continued_base_low_lr'))
        checkpoint_path = REPO / ref['checkpoint_file']
        checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
        state = checkpoint['model']; states[key] = state; original_rows[key] = old
        expected_lr = .0005 if ref['source_lr'] == 'high_lr' else .0001
        observed_lr = source_settings['learning_rate'] if ref['source_lr'] == 'high_lr' else source_settings['backbone_learning_rate']
        sources_ok &= (source_audit['status'] == 'PASS_AUDIT' and all(source_audit['checks'].values()) and
            source_audit['result_sha256'] == sha(control_path) and
            checkpoint['settings'] == old and control['checkpoint_hashes'][checkpoint_path.name] == sha(checkpoint_path) and
            digest(state) == ref['backbone_state_sha256'] == old['backbone_after_sha256'] and
            sum(value.numel() for value in state.values()) == 10681 and
            all(torch.isfinite(value).all().item() for value in state.values()) and
            expected_lr == observed_lr == ref['learning_rate'] and source_settings['steps'] == old['steps'] == 500 and
            source_settings['thresholds'] == config['thresholds'] and
            ref['source_batch_sequence_sha256'] == old['batch_sequence_sha256'] and
            ref['original_backbone_before_sha256'] == old['backbone_before_sha256'])
    for budget in [18, 27]:
        for seed in seeds:
            pair = [ref for ref in refs if ref['budget'] == budget and ref['seed'] == seed]
            paired &= (len({ref['source_batch_sequence_sha256'] for ref in pair}) == 1 and
                       len({ref['original_backbone_before_sha256'] for ref in pair}) == 1)
    checks['all_original_source_CHECKPOINT_audits_LRs_states_and_metadata'] = bool(sources_ok)
    checks['both_source_families_share_original_initialization_and_batches'] = bool(paired)
    errors = dict(metrics=0., probabilities=0., aligned_probabilities=0., stored_equivariance=0., fixtures=0., fixture_forward=0., source_identity_metrics=0.)
    arrays_ok = True; metrics_ok = True; selection_ok = True; cost_ok = True; fixtures_ok = True
    equivariance_ok = True; evidence = []; recomputed_rows = []
    for row in rows:
        source, budget, seed, arm = row['source_lr'], row['budget'], row['seed'], row['arm']
        key = source, budget, seed; state = states[key]
        ref = next(item for item in refs if (item['source_lr'], item['budget'], item['seed']) == key)
        stem = f'{source}_b{budget}_s{seed}_{arm}'
        count = 1 if arm == 'identity' else len(elements)
        cost_ok &= (row['source'] == ref and row['parameters'] == 10681 and row['trainable_parameters'] == 0 and
                    row['optimizer_updates'] == row['fit_count'] == 0 and row['forward_passes_per_image'] == count and
                    row['evaluated_images'] == 695 and row['scored_forward_examples'] == 695 * count and
                    row['timing_warmup_images'] == 8 and row['timing_warmup_forward_examples'] == 8 * count and
                    row['forward_seconds'] > 0)
        with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
            arrays = {name: archive[name] for name in archive.files}
        arrays_ok &= (arrays['probability'].shape == (695, 1, 12, 12) and
            arrays['aligned_probability'].shape == (count, 695, 1, 12, 12) and
            np.isfinite(arrays['probability']).all() and np.isfinite(arrays['aligned_probability']).all() and
            arrays['probability'].min() >= 0 and arrays['probability'].max() <= 1 and
            np.array_equal(arrays['truth'], truth) and np.array_equal(arrays['target'], target) and
            arrays['thresholds'].tolist() == config['thresholds'])
        arrays_ok &= np.max(np.abs(arrays['probability'] - arrays['aligned_probability'].mean(0))) < 3e-7
        expected_parts, aligned_parts = [], []
        with torch.inference_mode():
            for batch in images.split(16):
                if arm == 'identity':
                    probability = independent_backbone(batch, state)[1].sigmoid()
                    aligned = probability[None]
                else:
                    probability, aligned = independent_pool(batch, state, group)
                    if group == 'D4':
                        aligned = aligned[[0, 1, 2, 3, 4, 7, 6, 5]]
                expected_parts.append(probability.numpy()); aligned_parts.append(aligned.numpy())
        expected = np.concatenate(expected_parts); expected_aligned = np.concatenate(aligned_parts, axis=1)
        errors['probabilities'] = max(errors['probabilities'], float(np.max(np.abs(expected - arrays['probability']))))
        errors['aligned_probabilities'] = max(errors['aligned_probabilities'], float(np.max(np.abs(expected_aligned - arrays['aligned_probability']))))
        scores = []
        for index, threshold in enumerate(config['thresholds']):
            masks = arrays['probability'][:, 0] >= threshold
            prediction = classify(masks)
            metrics_ok &= np.array_equal(prediction, arrays['predictions'][index])
            metrics_ok &= np.array_equal(np.packbits(masks.reshape(695, 144), axis=1), arrays['packed_masks'][index])
            score = dict(threshold=threshold, mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target)); scores.append(score)
            for name, value in score.items():
                errors['metrics'] = max(errors['metrics'], abs(value - row['VAL_scores_all_thresholds'][index][name]))
                if arm == 'identity':
                    old_scores = original_rows[key]['VAL_scores_all_thresholds']
                    if isinstance(old_scores, dict):
                        old_scores = old_scores['actual']
                    errors['source_identity_metrics'] = max(errors['source_identity_metrics'], abs(value - old_scores[index][name]))
        winner = selected(scores)
        for name, value in winner.items():
            errors['metrics'] = max(errors['metrics'], abs(value - row['selected'][name]))
        selection_ok &= winner['threshold'] == float(arrays['selected_threshold'])
        with np.load(folder / 'fixtures' / f'{stem}.npz', allow_pickle=False) as archive:
            fixture = {name: archive[name] for name in archive.files}
        row_elements = [(0, False)] if arm == 'identity' else elements
        fixtures_ok &= (np.array_equal(fixture['x'], images[:16].numpy()) and
                        fixture['elements'].tolist() == [[rotation, int(reflection)] for rotation, reflection in row_elements] and
                        float(fixture['selected_threshold']) == winner['threshold'])
        errors['fixtures'] = max(errors['fixtures'], float(np.max(np.abs(fixture['probability'] - arrays['probability'][:16]))))
        restored = []
        for index, (rotation, reflection) in enumerate(row_elements):
            # The model convention is R^k F; our independent operator is F R^k.
            own_rotation = -rotation if reflection else rotation
            transformed_input = independent_transform(images[:16], own_rotation, reflection)
            with torch.inference_mode():
                expected_transformed = (independent_backbone(transformed_input, state)[1].sigmoid() if arm == 'identity'
                                        else independent_pool(transformed_input, state, group)[0])
            errors['fixture_forward'] = max(errors['fixture_forward'], float(np.max(np.abs(
                expected_transformed.numpy() - fixture['transformed_probability'][index]))))
            restored.append(independent_inverse(torch.tensor(fixture['transformed_probability'][index]), own_rotation, reflection).numpy())
        restored = np.asarray(restored)
        errors['fixtures'] = max(errors['fixtures'], float(np.max(np.abs(restored - fixture['restored_probability']))))
        observed_error = float(np.max(np.abs(restored - fixture['probability'][None])))
        errors['stored_equivariance'] = max(errors['stored_equivariance'], abs(observed_error - row['equivariance_max_error']))
        equivariance_ok &= observed_error <= config['equivariance_tolerance']
        for index, value in enumerate(restored):
            equivariance_ok &= np.array_equal(value[:, 0] >= winner['threshold'], fixture['probability'][:, 0] >= winner['threshold'])
        if arm != 'identity':
            independent = independently_measure_equivariance(images[:16], state, group, config['thresholds'], winner['threshold'])
            equivariance_ok &= (independent['input_inverse_bit_exact'] and
                independent['maximum_probability_equivariance_error'] <= config['equivariance_tolerance'] and
                independent['all_grid_restored_masks_exact'] and independent['restored_and_rotated_direction_classes_exact'])
            evidence.append(dict(source_lr=source, budget=budget, seed=seed, **independent))
        recomputed_rows.append(dict(source_lr=source, budget=budget, seed=seed, arm=arm, selected=winner))
    checks.update(all_saved_VAL_arrays_range_shapes_and_inverse_probability_means=bool(arrays_ok),
        independent_functional_CNN_all_orbit_probability_parity=errors['probabilities'] < 1e-5 and errors['aligned_probabilities'] < 1e-5 and errors['fixture_forward'] < 1e-5,
        all_9class_predictions_packed_masks_metrics_and_thresholds=bool(metrics_ok and selection_ok) and errors['metrics'] < 2e-7,
        identity_metrics_exactly_match_original_audited_CNN_controls=errors['source_identity_metrics'] < 2e-7,
        fixtures_recomputed_and_exact_inverse_spatial_restoration=bool(fixtures_ok) and errors['fixtures'] < 3e-7,
        independently_measured_group_equivariance_masks_and_direction_classes=bool(equivariance_ok) and errors['stored_equivariance'] < 1e-10,
        all_zero_update_shared_weight_and_explicit_compute_cost_rows=bool(cost_ok),
        total_scored_and_warmup_forward_examples_exact=(
            result['scored_forward_examples'] == sum(row['scored_forward_examples'] for row in rows) and
            result['timing_warmup_forward_examples'] == sum(row['timing_warmup_forward_examples'] for row in rows)))
    gates = independent_gates(recomputed_rows, group, config)
    checks['both_source_family_architecture_gates_independently_recomputed'] = compare_stored_gates(gates, result['gates']) < 2e-7
    if group == 'D4':
        previous = [path for path in (ROOT / 'trials').glob('*/RESULT.json') if json.loads(path.read_text())['group'] == 'C4' and
                    json.loads(path.read_text())['phase'] == 'screen']
        checks['D4_only_after_failed_prespecified_C4_screen'] = len(previous) == 1 and not json.loads(previous[0].read_text())['gates']['A_any']
    replication = {}
    if phase == 'replicate':
        aggregate = read('AGGREGATE_RESULT.json')
        old_folder = ROOT / aggregate['source_trials'][0]
        old = json.loads((old_folder / 'RESULT.json').read_text()); old_audit = json.loads((old_folder / 'AUDIT.json').read_text())
        checks['valid_screen_exact_three_seed_aggregation_no_double_count'] = (
            old_audit['status'] == 'PASS_AUDIT' and old_audit['result_sha256'] == sha(old_folder / 'RESULT.json') and
            old['seeds'] == [5501] and old['group'] == group and old['gates']['A_any'] and
            old['signature'] == result['signature'] and aggregate['seeds'] == [5501, 5521, 5557] and
            aggregate['rows'] == old['rows'] + rows and len(aggregate['rows']) == 24 and
            len({(row['source_lr'], row['budget'], row['seed'], row['arm']) for row in aggregate['rows']}) == 24)
        all_gates = independent_gates(old['rows'] + recomputed_rows, group, config)
        checks['all_three_new_two_and_robust_gates_recomputed'] = (
            compare_stored_gates(all_gates, aggregate['gates']) < 2e-7 and
            compare_stored_gates(gates, aggregate['new_seed_gates']) < 2e-7 and
            aggregate['robust_architecture_pass'] == (gates['A_any'] and all_gates['A_any']))
        replication = dict(all_three_seeds=all_gates, new_two_seeds=gates)
    checks['all_input_artifacts_unchanged_by_audit'] = all(sha(path) == value for path, value in before.items())
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        scope='INDEPENDENT_CPU_ZERO_TRAINING_ADAPTIVE_REUSED_VAL_AUDIT', group=group, phase=phase,
        trial=str(folder.relative_to(ROOT)), audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        maximum_errors=errors, independent_equivariance=evidence, independent_gates=gates, replication=replication,
        fit_count=0, optimizer_updates=0, seconds=time.monotonic() - start,
        numerical_note='Independent CPU CNN inputs use canonical contiguous strides. The initial view-stride audit produced layout-dependent convolution rounding; its failed output is preserved. No source model, probabilities, tolerance, or development gate was changed.',
        caveat='Reused development VAL; no new training or TEST, statistical or novelty confirmation. C4/D4 inference costs four/eight shared-CNN passes.')


def audit_low_lr_controls(folder):
    """Audit only four newly required low-lr CNN fits; the orbit stays unfitted."""
    started = time.monotonic()
    read = lambda name: json.loads((folder / name).read_text())
    result, frozen, config, proof = (read(name) for name in
        ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json', 'IMPLEMENTATION_PROOF.json'])
    checks = {}
    checks['four_new_low_lr_control_scope_and_exact_design'] = (
        result['status'] == 'COMPLETE_ADDITIONAL_LOW_LR_CONTROLS_VAL_ONLY' and
        result['seeds'] == frozen['seeds'] == [5521, 5557] and result['budgets'] == frozen['budgets'] == [18, 27] and
        result['models'] == frozen['models'] == 4 and result['updates'] == frozen['total_updates'] == 2000 and
        frozen['steps_each'] == config['steps'] == 500 and frozen['learning_rate'] == config['backbone_learning_rate'] == .0001 and
        frozen['trainable_parameters'] == 10681 and config['batch_size'] == 8 and config['physics_weight'] == 1 and
        config['weight_decay'] == .0001 and config['subset_seed'] == 5303 and
        config['thresholds'] == [.3, .4, .45, .5, .55, .6, .7] and 'no orbit fitting or TEST' in result['scope'])
    checks['frozen_new_control_protocol_configuration_and_sources'] = (
        sha(folder / 'FROZEN.json') == result['frozen_sha256'] and
        sha(folder / 'IMPLEMENTATION_PROOF.json') == result['proof_sha256'] and
        sha(folder / 'PROTOCOL.md') == frozen['control_protocol_sha256'] == sha(ROOT / 'LOW_LR_CONTROL_PROTOCOL.md') and
        sha(REPO / frozen['source_config_file']) == frozen['source_config_sha256'] == sha(folder / 'CONFIG_SNAPSHOT.json') and
        all(sha(REPO / name) == value for name, value in frozen['source_sha256'].items()) and
        sha(folder / 'source' / 'train_low_lr_controls.py') == sha(ROOT / 'train_low_lr_controls.py') and
        all(sha(folder / 'source' / name) == sha(G / 'sem_arch_joint_adaptation_20261102' / name) for name in ['runner.py', 'model.py']))
    source = (folder / 'source' / 'runner.py').read_text(); tree = ast.parse(source)
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    lines = source.splitlines(keepends=True)
    actual_functions = {name: hashlib.sha256(''.join(lines[functions[name].lineno - 1:functions[name].end_lineno]).encode()).hexdigest()
                        for name in ['inputs', 'make', 'fit', 'evaluate', 'fixtures']}
    fit_source = ast.unparse(functions['fit'])
    wrapper = ast.parse((folder / 'source' / 'train_low_lr_controls.py').read_text())
    wrapper_source = ast.unparse(wrapper)
    checks['exact_unchanged_imported_functions_old_loss_and_all500_CNN_steps'] = (
        actual_functions == frozen['function_source_sha256'] == proof['function_source_sha256'] and
        "loss = F.binary_cross_entropy_with_logits(dense, values['dense']['mask'][ai])" in fit_source and
        "loss = loss + c['physics_weight'] * physics.geometry_loss(weak, direction)" in fit_source and
        "torch.optim.AdamW(model.parameters(), lr=c['backbone_learning_rate']" in fit_source and
        "ARM = 'continued_base_low_lr'" in wrapper_source and
        'r.fit(c, net, data[budget], budget, seed, ARM, OUT, counter)' in wrapper_source and
        not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and
                isinstance(node.func.value, ast.Name) and node.func.value.id == 'np' and node.func.attr == 'load'
                for node in ast.walk(wrapper)))
    input_source = ast.unparse(functions['inputs'])
    checks['imported_inputs_TRAIN_VAL_only_no_weak_masks'] = (
        "np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False)" in input_source and "if role != 'weak':" in input_source)
    checks['protected_historical_artifacts_unchanged_progress_redirected'] = (
        proof['status'] == 'PASS_UNCHANGED_SOURCE_CONTROL_IMPLEMENTATION' and
        proof['source_sha256_before'] == proof['source_sha256_after'] == frozen['source_sha256'] and
        proof['protected_historical_sha256_before'] == proof['protected_historical_sha256_after'] == frozen['protected_historical_sha256'] and
        all(sha(REPO / name) == value for name, value in frozen['protected_historical_sha256'].items()) and
        proof['original_runner_functions_reused'] and proof['old_loss_unchanged'] and
        proof['all_source_batch_sequences_match_high_lr'] and proof['progress_writes_redirected_without_source_edits'] and
        'r.ROOT = OUT' in wrapper_source and 'r.ROOT = original_root' in wrapper_source)
    lineage = frozen['lineage']; subsets = json.loads((PILOT / 'SUBSETS.json').read_text())
    checks['unchanged_TRAIN_VAL_subsets_initial_sources'] = (
        sha(PILOT / 'TRAIN_VAL.npz') == lineage['TRAIN_VAL_sha256'] == subsets['train_val_sha256'] and
        sha(PILOT / 'SUBSETS.json') == lineage['subsets_sha256'] and
        sha(PILOT / 'INITIAL_LINEAGE.json') == lineage['initial_lineage_sha256'] and len(lineage['sources']) == 4 and
        all(sha(G / item['file']) == item['sha256'] for item in lineage['sources'].values()))
    high_path = REPO / frozen['high_lr_control_file']; high = json.loads(high_path.read_text())
    checks['shared_high_lr_reference_unchanged'] = sha(high_path) == frozen['high_lr_control_sha256']
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        val = np.flatnonzero(archive['role'] == 'val')
        images = torch.tensor(5 * (archive['X'][val] - .2))
        truth = archive['label'][val]; target = archive['Y'][val, 0].astype(bool)
    rows = result['rows']
    checks['exact_four_model_grid_and_checkpoint_hashes'] = (
        len(rows) == 4 and {(row['budget'], row['seed']) for row in rows} == {(b, s) for b in [18, 27] for s in [5521, 5557]} and
        len(result['checkpoint_hashes']) == 4 and all(sha(folder / 'models' / name) == value for name, value in result['checkpoint_hashes'].items()))
    before = {str(path): sha(path) for path in [folder / 'RESULT.json', folder / 'FROZEN.json', folder / 'IMPLEMENTATION_PROOF.json']}
    metadata_ok = True; states_ok = True; batches_ok = True; scores_ok = True; selection_ok = True; fixture_ok = True
    errors = dict(metrics=0., forward=0., probabilities=0.)
    recomputed = []
    for row in rows:
        budget, seed = row['budget'], row['seed']; stem = f'b{budget}_continued_base_low_lr_s{seed}'
        payload = torch.load(folder / 'models' / f'{stem}.pt', map_location='cpu', weights_only=True)
        state = payload['model']; source = lineage['sources'][f'{budget}:{seed}']
        initial = torch.load(G / source['file'], map_location='cpu', weights_only=True)['segmenter']
        reference = next(item for item in high['rows'] if item['budget'] == budget and item['seed'] == seed)
        metadata_ok &= (payload['settings'] == row and row['arm'] == 'continued_base_low_lr' and
            row['source_initial'] == reference['source_initial'] == source and row['steps'] == row['CNN_updates'] == 500 and
            row['refiner_updates'] == row['warmup_steps'] == row['joint_steps'] == 0 and
            row['trainable_parameters'] == row['total_parameters'] == 10681 and
            row['backbone_learning_rate'] == .0001 and row['refiner_learning_rate'] is None and
            row['optimizer_groups'] == [dict(parameters='backbone', learning_rate=.0001, update_steps=[1, 500])])
        states_ok &= (digest(initial) == source['backbone_sha256'] == row['backbone_before_sha256'] == reference['backbone_before_sha256'] and
            digest(state) == row['backbone_after_sha256'] != row['backbone_before_sha256'] and
            sum(value.numel() for value in state.values()) == 10681 and all(torch.isfinite(value).all().item() for value in state.values()))
        rng = np.random.default_rng(seed + 1000); trace = hashlib.sha256()
        for _ in range(500):
            trace.update(rng.integers(0, budget, 8).astype(np.int64).tobytes())
            trace.update(rng.integers(0, 1152, 8).astype(np.int64).tobytes())
        batches_ok &= trace.hexdigest() == row['batch_sequence_sha256'] == reference['batch_sequence_sha256']
        with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
            arrays = {key: archive[key] for key in archive.files}
        metadata_ok &= (arrays['variants'].tolist() == ['actual'] and arrays['thresholds'].tolist() == config['thresholds'] and
            np.array_equal(arrays['truth'], truth) and np.array_equal(arrays['target'], target) and
            arrays['logits'].shape == (1, 695, 1, 12, 12) and arrays['probability'].shape == (1, 695, 12, 12) and
            np.isfinite(arrays['logits']).all() and np.isfinite(arrays['probability']).all())
        with torch.inference_mode():
            logits = np.concatenate([independent_backbone(batch, state)[1].numpy() for batch in images.split(16)])
        errors['forward'] = max(errors['forward'], float(np.max(np.abs(logits - arrays['logits'][0]))))
        errors['probabilities'] = max(errors['probabilities'], float(np.max(np.abs(
            torch.tensor(arrays['logits'][0, :, 0]).sigmoid().numpy() - arrays['probability'][0]))))
        scores = []
        for index, threshold in enumerate(config['thresholds']):
            masks = arrays['probability'][0] >= threshold; prediction = classify(masks)
            scores_ok &= np.array_equal(prediction, arrays['predictions'][0, index])
            scores_ok &= np.array_equal(np.packbits(masks.reshape(695, 144), axis=1), arrays['packed_masks'][0, index])
            score = dict(threshold=threshold, mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target)); scores.append(score)
            for name, value in score.items():
                errors['metrics'] = max(errors['metrics'], abs(value - row['VAL_scores_all_thresholds']['actual'][index][name]))
        winner = selected(scores)
        for name, value in winner.items():
            errors['metrics'] = max(errors['metrics'], abs(value - row['selected'][name]))
        selection_ok &= winner['threshold'] == float(arrays['selected_threshold'])
        with np.load(folder / 'fixtures' / f'{stem}.npz', allow_pickle=False) as archive:
            fixture_ok &= np.array_equal(archive['x'], images[:16].numpy())
            errors['forward'] = max(errors['forward'], float(np.max(np.abs(logits[:16] - archive['full_logits'][0]))))
        recomputed.append(dict(budget=budget, seed=seed, selected=winner, batch_sequence_sha256=trace.hexdigest()))
    checks.update(all_metadata_optimizer_schedule_and_10681_parameter_counts=bool(metadata_ok),
        exact_source_initial_states_and_updated_finite_final_CNNs=bool(states_ok),
        all500_batches_reconstructed_paired_to_high_lr=bool(batches_ok),
        all_classes_masks_metrics_and_thresholds_independently_recomputed=bool(scores_ok and selection_ok) and errors['metrics'] < 2e-7,
        independent_original_CNN_forward_CPU_MPS_parity=bool(fixture_ok) and errors['forward'] < 1e-4,
        sigmoid_probability_parity=errors['probabilities'] < 3e-7,
        audit_inputs_unchanged=all(sha(path) == value for path, value in before.items()))
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        scope='INDEPENDENT_CPU_AUDIT_FOUR_ADDITIONAL_TRAIN_VAL_LOW_LR_CNN_CONTROLS',
        audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        maximum_errors=errors, recomputed=recomputed, fit_count=4, optimizer_updates=2000,
        seconds=time.monotonic() - started,
        caveat='Four additional source CNN fits, not orbit fitting. Reused development TRAIN/VAL only; no new TEST confirmation.')


def audit_threshold_diagnostic(folder):
    """Validate all ranks/IoUs and independently classify24 selected masks."""
    started = time.monotonic()
    result = json.loads((folder / 'RESULT.json').read_text())
    frozen = json.loads((folder / 'FROZEN.json').read_text())
    config = json.loads((ROOT / 'CONFIG.json').read_text())
    grid = [round(.10 + .01 * index, 2) for index in range(81)]
    checks = {}
    checks['secondary_frozen_protocol_same81_thresholds_and_zero_inference_training'] = (
        result['status'] == 'COMPLETE_SECONDARY_FINE_THRESHOLD_DIAGNOSTIC' and
        frozen['scope'] == 'SECONDARY_FINE_THRESHOLD_ROBUSTNESS_ON_REUSED_VAL_ONLY' and
        result['thresholds'] == frozen['thresholds'] == grid and result['threshold_count'] == frozen['threshold_count'] == 81 and
        result['unique_scored_units'] == frozen['row_count'] == frozen['canonical_unique_units'] == 24 and
        result['threshold_score_evaluations'] == 1944 and
        result['fit_count'] == result['optimizer_updates'] == result['model_forward_passes'] == 0 and
        frozen['fit_count'] == frozen['optimizer_updates'] == frozen['model_forward_passes'] == 0 and
        frozen['limits'] == config['gates'] and frozen['seeds_all'] == [5501, 5521, 5557] and frozen['seeds_new'] == [5521, 5557] and
        result['original_seven_grid_results_modified'] is False and frozen['original_seven_grid_results_modified'] is False)
    checks['protocol_script_and_all_original_prediction_source_SHA256_unchanged'] = (
        sha(folder / 'FROZEN.json') == result['frozen_sha256'] and
        sha(folder / 'THRESHOLD_PROTOCOL.md') == sha(ROOT / 'THRESHOLD_PROTOCOL.md') == frozen['protocol_sha256'] and
        sha(folder / 'threshold_diagnostic.py') == sha(ROOT / 'threshold_diagnostic.py') and
        all(sha(path) == value for path, value in frozen['source_sha256'].items()))
    source_tree = ast.parse((folder / 'threshold_diagnostic.py').read_text())
    checks['diagnostic_no_model_execution_optimization_or_new_data_access'] = not any(
        isinstance(node, ast.Call) and ((isinstance(node.func, ast.Attribute) and node.func.attr in
        ['backward', 'step', 'AdamW', 'SGD', 'forward', 'forward_details', 'make_model']) or
        (isinstance(node.func, ast.Name) and node.func.id == 'OrbitPoolSegmenter')) for node in ast.walk(source_tree))
    aggregate_path = ROOT / frozen['canonical_aggregate']
    aggregate = json.loads(aggregate_path.read_text())
    checks['exact_original_three_seed_aggregate_and_zero_update_lineage'] = (
        sha(aggregate_path) == frozen['canonical_aggregate_sha256'] and aggregate['group'] == 'C4' and
        aggregate['seeds'] == [5501, 5521, 5557] and aggregate['fit_count'] == aggregate['updates'] == 0)
    unit = lambda row: (row['source_lr'], row['budget'], row['seed'], row['arm'])
    original = {unit(row): row for row in aggregate['rows']}
    archives = {}; result_sources_ok = True; replicate = None
    for relative in aggregate['source_trials']:
        trial = ROOT / relative
        old = json.loads((trial / 'RESULT.json').read_text())
        old_audit = json.loads((trial / 'AUDIT.json').read_text())
        result_sources_ok &= old_audit['status'] == 'PASS_AUDIT' and old_audit['result_sha256'] == sha(trial / 'RESULT.json')
        if old['phase'] == 'replicate':
            replicate = old
        for row in old['rows']:
            key = unit(row)
            archives[key] = trial / 'val_probs' / f'{key[0]}_b{key[1]}_s{key[2]}_{key[3]}.npz'
    checks['both_original_trials_independently_audited_and_exact24_unit_grid'] = (
        result_sources_ok and replicate is not None and len(result['rows']) == 24 and len(original) == len(archives) == 24 and
        {unit(row) for row in result['rows']} == set(original))
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        val = np.flatnonzero(archive['role'] == 'val')
        truth = archive['label'][val]; target = archive['Y'][val, 0].astype(bool)
    checks['same_frozen_695_VAL_population'] = (len(val) == 695 and frozen['lineage']['VAL_indices'] == val.tolist() and
        frozen['lineage']['TRAIN_VAL_sha256'] == sha(PILOT / 'TRAIN_VAL.npz'))
    rows_ok = True; rank_ok = True; metric_error = 0.; all_IoU_error = 0.; selected_rows = []; selected_evidence = []
    for row in result['rows']:
        key = unit(row); path = ROOT / row['probability_file']
        rows_ok &= (path.resolve() == archives[key].resolve() and sha(path) == row['probability_sha256'] == frozen['source_sha256'][str(path.resolve())] and
                    row['original_seven_grid_selected'] == original[key]['selected'] and row['threshold_count'] == 81 and
                    row['evaluated_images'] == 695 and row['fit_count'] == row['model_forward_passes'] == 0)
        scores = row['VAL_scores_all_thresholds']
        rank_ok &= len(scores) == 81 and [score['threshold'] for score in scores] == grid and selected(scores) == row['selected']
        with np.load(path, allow_pickle=False) as archive:
            probability = archive['probability'][:, 0]
            rows_ok &= np.array_equal(archive['truth'], truth) and np.array_equal(archive['target'], target)
        for score in scores:
            all_IoU_error = max(all_IoU_error, abs(mean_iou(probability >= score['threshold'], target) - score['IoU']))
        masks = probability >= row['selected']['threshold']
        prediction = classify(masks)
        computed = dict(threshold=row['selected']['threshold'], mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target))
        for name, value in computed.items():
            metric_error = max(metric_error, abs(value - row['selected'][name]))
        metric_error = max(metric_error,
            abs(computed['mask_F1'] - original[key]['selected']['mask_F1'] - row['F1_change_from_seven_grid']),
            abs(computed['IoU'] - original[key]['selected']['IoU'] - row['IoU_change_from_seven_grid']))
        selected_rows.append(dict(source_lr=key[0], budget=key[1], seed=key[2], arm=key[3], selected=computed))
        selected_evidence.append(dict(source_lr=key[0], budget=key[1], seed=key[2], arm=key[3], selected=computed,
            packed_selected_masks_sha256=hashlib.sha256(np.packbits(masks.reshape(695, 144), axis=1).tobytes()).hexdigest(),
            selected_classes_sha256=hashlib.sha256(prediction.astype(np.int64).tobytes()).hexdigest()))
    checks['all24_original_probability_archives_exact_source_metadata'] = bool(rows_ok)
    checks['all24_rankings_selected_from_same81_value_grid'] = bool(rank_ok)
    checks['all1944_threshold_IoUs_recomputed'] = all_IoU_error < 2e-7
    checks['all24_selected_hard_classes_F1_IoU_and_changes_recomputed'] = metric_error < 2e-7
    cohorts = {}; gates_ok = True; pairs_ok = True
    for label, seeds in [('all_three', [5501, 5521, 5557]), ('new_two', [5521, 5557])]:
        observed = result[label]
        chosen = [row for row in selected_rows if row['seed'] in seeds]
        computed = independent_gates(chosen, 'C4', config)
        values = observed['gates']['by_source_lr']
        canonical = {name: {key: value for key, value in values[name].items() if key != 'paired_units'}
                     for name in ['high_lr', 'low_lr']}
        comparison = dict(A_architecture=dict(by_source_lr=canonical, passed=observed['gates']['passed_both_source_families']),
                          A_any=observed['gates']['passed_both_source_families'])
        gates_ok &= compare_stored_gates(computed, comparison) < 2e-7
        pairs_ok &= (observed['seeds'] == seeds and len(observed['pairs']) == 4 * len(seeds) and
            all(values[name]['paired_units'] == 2 * len(seeds) for name in ['high_lr', 'low_lr']))
        for pair in observed['pairs']:
            identity = next(row for row in chosen if unit(row) == (pair['source_lr'], pair['budget'], pair['seed'], 'identity'))['selected']
            orbit = next(row for row in chosen if unit(row) == (pair['source_lr'], pair['budget'], pair['seed'], 'C4'))['selected']
            pairs_ok &= pair['identity_selected'] == identity and pair['C4_selected'] == orbit
            pairs_ok &= abs(pair['F1_delta'] - (orbit['mask_F1'] - identity['mask_F1'])) < 2e-7
            pairs_ok &= abs(pair['IoU_delta'] - (orbit['IoU'] - identity['IoU'])) < 2e-7
        cohorts[label] = computed
    checks['fine_grid_all_three_new_two_exact_pairs_and_both_LR_gates'] = bool(gates_ok and pairs_ok)
    secondary = cohorts['all_three']['A_any'] and cohorts['new_two']['A_any']
    primary = aggregate['gates']['A_any'] and replicate['gates']['A_any']
    checks['original_seven_grid_gates_untouched_and_combined_robustness_exact'] = (
        result['original_seven_grid_gates'] == dict(all_three=aggregate['gates'], new_two=replicate['gates']) and
        result['secondary_robustness_pass'] == secondary and result['original_seven_grid_robust_pass'] == primary and
        result['robust_on_both_grids'] == (primary and secondary))
    checks['all_frozen_inputs_unchanged_after_audit'] = all(sha(path) == value for path, value in frozen['source_sha256'].items())
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        scope='INDEPENDENT_CPU_SECONDARY_FINE_THRESHOLD_DIAGNOSTIC_REUSED_VAL_ONLY',
        audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        maximum_errors=dict(selected_metrics=metric_error, all_threshold_IoU=all_IoU_error),
        selected_mask_class_evidence=selected_evidence, independent_cohorts=cohorts,
        secondary_robustness_pass=secondary, robust_on_both_grids=bool(primary and secondary), seconds=time.monotonic() - started,
        coverage='All81 ranks and IoUs per row; all24 selected masks/classes/F1 independently recomputed. Unselected-threshold F1 values use the previously validated fixed classifier implementation.',
        caveat='Post-selection calibration sensitivity on reused VAL; no additional inference/training or independent TEST confirmation.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trial', type=Path)
    parser.add_argument('--baseline-control', type=Path)
    parser.add_argument('--threshold-diagnostic', type=Path)
    args = parser.parse_args()
    torch.set_num_threads(2)
    if args.threshold_diagnostic:
        folder = args.threshold_diagnostic if args.threshold_diagnostic.is_absolute() else ROOT / args.threshold_diagnostic
        with threadpool_limits(limits=2):
            outcome = audit_threshold_diagnostic(folder)
        destination = folder / 'AUDIT.json'
        assert not destination.exists(), 'Immutable secondary audit already exists'
        destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
        print(json.dumps({key: outcome[key] for key in ['status', 'checks_passed', 'checks_total', 'maximum_errors',
              'independent_cohorts', 'secondary_robustness_pass', 'robust_on_both_grids', 'seconds']}, ensure_ascii=False), flush=True)
        assert outcome['status'] == 'PASS_AUDIT'
        return
    if args.baseline_control:
        folder = args.baseline_control if args.baseline_control.is_absolute() else ROOT / args.baseline_control
        with threadpool_limits(limits=2):
            outcome = audit_low_lr_controls(folder)
        destination = folder / 'AUDIT.json'
        if destination.exists():
            previous = json.loads(destination.read_text())
            assert previous['result_sha256'] == outcome['result_sha256']
            if previous['audit_source_sha256'] != outcome['audit_source_sha256']:
                archive = folder / f"AUDIT_PREVIOUS_{previous['audit_source_sha256'][:12]}.json"
                assert not archive.exists(); destination.rename(archive)
            else:
                outcome = previous
        if not destination.exists():
            destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
        print(json.dumps(outcome, ensure_ascii=False), flush=True)
        assert outcome['status'] == 'PASS_AUDIT'
        return
    folders = [args.trial if args.trial.is_absolute() else ROOT / args.trial] if args.trial else sorted(
        path.parent for path in (ROOT / 'trials').glob('*/RESULT.json'))
    assert folders, 'No completed inference trial'
    torch.set_num_threads(2)
    outcomes = []
    with threadpool_limits(limits=2):
        for folder in folders:
            destination = folder / 'AUDIT.json'
            if destination.exists():
                previous = json.loads(destination.read_text())
                assert previous['result_sha256'] == sha(folder / 'RESULT.json')
                if previous['audit_source_sha256'] == sha(__file__):
                    outcome = previous
                else:
                    archive = folder / f"AUDIT_PREVIOUS_{previous['audit_source_sha256'][:12]}.json"
                    assert not archive.exists(); destination.rename(archive)
                    outcome = audit_trial(folder)
                    destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
            else:
                outcome = audit_trial(folder)
                destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
            outcomes.append(outcome)
            print(json.dumps({name: outcome[name] for name in ['status', 'trial', 'checks_passed', 'checks_total',
                  'maximum_errors', 'independent_gates', 'replication', 'seconds']}, ensure_ascii=False), flush=True)
    assert all(outcome['status'] == 'PASS_AUDIT' for outcome in outcomes)


if __name__ == '__main__':
    main()
