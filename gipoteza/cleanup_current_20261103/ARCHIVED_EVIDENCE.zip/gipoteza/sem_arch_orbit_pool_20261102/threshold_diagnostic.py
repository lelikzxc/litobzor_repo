"""Secondary threshold-grid robustness check using saved VAL probabilities.

No model execution, training, new images, or TEST access. Run only after the
three-seed C4 aggregate and its low-lr source controls have been completed.
The original seven-threshold results are immutable inputs to this diagnostic.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import time
import traceback

import numpy as np
from threadpoolctl import threadpool_limits

import runner as r

ROOT = Path(__file__).resolve().parent
GRID = [round(.10 + .01 * index, 2) for index in range(81)]
SEEDS = [5501, 5521, 5557]
NEW_SEEDS = [5521, 5557]
LIMITS = dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025, minimum_mean_IoU_delta=-.002)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, item):
    r.save(path, item)


def unit(row):
    return row["source_lr"], row["budget"], row["seed"], row["arm"]


def relative(path):
    return str(Path(path).resolve().relative_to(ROOT))


def canonical_inputs():
    """Use one aggregate, resolving each scored row to its actual saved archive."""
    paths = sorted((ROOT / "trials").glob("C4_replicate_*/AGGREGATE_RESULT.json"))
    assert len(paths) == 1, "Exactly one completed three-seed C4 aggregate is required"
    aggregate_path = paths[0]
    aggregate = read(aggregate_path)
    assert aggregate["group"] == "C4" and aggregate["seeds"] == SEEDS
    assert aggregate["fit_count"] == aggregate["updates"] == 0
    expected = {(family, budget, seed, arm) for family in ["high_lr", "low_lr"]
                for budget in [18, 27] for seed in SEEDS for arm in ["identity", "C4"]}
    assert len(aggregate["rows"]) == 24 and {unit(row) for row in aggregate["rows"]} == expected
    assert len({unit(row) for row in aggregate["rows"]}) == len(aggregate["rows"])
    source_rows, archives, inputs, source_results = {}, {}, [aggregate_path], []
    frozen_lineage = None
    for name in aggregate["source_trials"]:
        trial = (ROOT / name).resolve()
        assert trial.is_relative_to(ROOT / "trials")
        result_path, frozen_path = trial / "RESULT.json", trial / "FROZEN.json"
        result, frozen = read(result_path), read(frozen_path)
        assert result["group"] == "C4" and result["frozen_sha256"] == sha(frozen_path)
        assert result["fit_count"] == result["updates"] == result["optimizer_updates"] == 0
        if frozen_lineage is None:
            frozen_lineage = frozen["lineage"]
        else:
            assert frozen["lineage"] == frozen_lineage, "Source VAL populations differ"
        inputs += [result_path, frozen_path]
        source_results.append(result)
        for row in result["rows"]:
            key = unit(row)
            assert key not in source_rows, "Screen seed must occur only once"
            source_rows[key] = row
            path = trial / "val_probs" / f"{key[0]}_b{key[1]}_s{key[2]}_{key[3]}.npz"
            assert path.is_file()
            archives[key] = path
            inputs.append(path)
    assert set(source_rows) == expected
    assert all(source_rows[unit(row)] == row for row in aggregate["rows"])
    assert len(source_results) == 2
    screen = next(item for item in source_results if item["phase"] == "screen")
    replicate = next(item for item in source_results if item["phase"] == "replicate")
    assert screen["seeds"] == [5501] and replicate["seeds"] == NEW_SEEDS
    return aggregate_path, aggregate, replicate, archives, inputs, frozen_lineage


def cohort(rows, seeds):
    selected = [row for row in rows if row["seed"] in seeds]
    expected = {(family, budget, seed, arm) for family in ["high_lr", "low_lr"]
                for budget in [18, 27] for seed in seeds for arm in ["identity", "C4"]}
    by_unit = {unit(row): row for row in selected}
    assert len(selected) == len(expected) and set(by_unit) == expected
    pairs = []
    for family in ["high_lr", "low_lr"]:
        for budget in [18, 27]:
            for seed in seeds:
                identity = by_unit[family, budget, seed, "identity"]["selected"]
                pooled = by_unit[family, budget, seed, "C4"]["selected"]
                pairs.append(dict(source_lr=family, budget=budget, seed=seed,
                    identity_selected=identity, C4_selected=pooled,
                    F1_delta=pooled["mask_F1"] - identity["mask_F1"],
                    IoU_delta=pooled["IoU"] - identity["IoU"]))
    gates = {}
    for family in ["high_lr", "low_lr"]:
        family_pairs = [row for row in pairs if row["source_lr"] == family]
        budget_deltas = [float(np.mean([row["F1_delta"] for row in family_pairs if row["budget"] == budget]))
                         for budget in [18, 27]]
        f1 = float(np.mean(budget_deltas))
        iou = float(np.mean([row["IoU_delta"] for row in family_pairs]))
        checks = dict(mean_F1_gain=bool(f1 >= LIMITS["minimum_mean_F1_gain"]),
            budget_F1_guard=bool(min(budget_deltas) >= LIMITS["minimum_budget_F1_delta"]),
            mean_IoU_guard=bool(iou >= LIMITS["minimum_mean_IoU_delta"]))
        gates[family] = dict(delta=f1, IoU_delta=iou, budget_deltas=budget_deltas,
            checks=checks, passed=all(checks.values()), paired_units=len(family_pairs))
    return dict(seeds=seeds, pairs=pairs, gates=dict(by_source_lr=gates,
        passed_both_source_families=all(gate["passed"] for gate in gates.values())))


def run(output):
    started = time.monotonic()
    protocol = ROOT / "THRESHOLD_PROTOCOL.md"
    assert protocol.is_file(), "The secondary protocol must be frozen before evaluation"
    aggregate_path, aggregate, replicate, archives, inputs, lineage = canonical_inputs()
    assert output.parent == ROOT and output.name.startswith("threshold_diagnostic")
    assert not output.exists(), "Immutable diagnostic output already exists; no overwrite or resume"
    config = read(ROOT / "CONFIG.json")
    assert config["gates"] == LIMITS
    inputs += [protocol, ROOT / "CONFIG.json", ROOT / "PROTOCOL.md", Path(__file__)]
    inputs += [ROOT / name for name in r.source_hashes()]
    input_hashes = {str(path.resolve()): sha(path) for path in inputs}
    output.mkdir()
    shutil.copy2(protocol, output / "THRESHOLD_PROTOCOL.md")
    shutil.copy2(Path(__file__), output / "threshold_diagnostic.py")
    frozen = dict(scope="SECONDARY_FINE_THRESHOLD_ROBUSTNESS_ON_REUSED_VAL_ONLY", UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        thresholds=GRID, threshold_count=81, ranking=["Macro-F1", "IoU", "distance_to_0.5", "smaller_threshold"],
        seeds_all=SEEDS, seeds_new=NEW_SEEDS, limits=LIMITS, canonical_aggregate=relative(aggregate_path),
        canonical_aggregate_sha256=sha(aggregate_path), row_count=24, canonical_unique_units=24,
        lineage=lineage, protocol_sha256=sha(protocol), classification_rule="runner.hard_classes with shared mask cache",
        source_sha256=input_hashes, model_forward_passes=0, fit_count=0, optimizer_updates=0,
        original_seven_grid_results_modified=False)
    save(output / "FROZEN.json", frozen)
    rows = []

    def progress(**fields):
        item = dict(stage="SECONDARY_FINE_THRESHOLD_VAL_ONLY", completed_units=len(rows), total_units=24,
                    seconds=time.monotonic() - started, cached_masks=len(r.CLASS_CACHE), **fields)
        save(output / "PROGRESS.json", item)
        with (output / "progress.jsonl").open("a") as handle:
            handle.write(json.dumps(item) + "\n")
        print(json.dumps(item), flush=True)

    canonical_truth = canonical_target = None
    try:
        for old in aggregate["rows"]:
            key = unit(old);path = archives[key]
            progress(source_lr=key[0], budget=key[1], seed=key[2], arm=key[3], completed_thresholds=0)
            with np.load(path, allow_pickle=False) as archive:
                probability = archive["probability"].copy()
                truth = archive["truth"].copy()
                target = archive["target"].astype(bool)
            assert probability.shape == (695, 1, 12, 12) and truth.shape == (695,) and target.shape == (695, 12, 12)
            assert np.isfinite(probability).all() and probability.min() >= 0 and probability.max() <= 1
            if canonical_truth is None:
                canonical_truth, canonical_target = truth.copy(), target.copy()
            else:
                assert np.array_equal(truth, canonical_truth) and np.array_equal(target, canonical_target)
            scores = []
            for index, threshold in enumerate(GRID, 1):
                mask = probability[:, 0] >= threshold
                prediction = r.hard_classes(mask)
                union = (mask | target).sum((1, 2))
                intersection = (mask & target).sum((1, 2))
                iou = np.divide(intersection, union, out=np.ones(len(mask)), where=union > 0)
                scores.append(dict(threshold=threshold, mask_F1=float(r.f1_score(truth, prediction,
                    labels=range(9), average="macro", zero_division=0)), IoU=float(iou.mean())))
                if index % 27 == 0:
                    progress(source_lr=key[0], budget=key[1], seed=key[2], arm=key[3], completed_thresholds=index)
            chosen = max(scores, key=r.rank)
            rows.append(dict(source_lr=key[0], budget=key[1], seed=key[2], arm=key[3],
                probability_file=relative(path), probability_sha256=sha(path), selected=chosen,
                VAL_scores_all_thresholds=scores, original_seven_grid_selected=old["selected"],
                F1_change_from_seven_grid=chosen["mask_F1"] - old["selected"]["mask_F1"],
                IoU_change_from_seven_grid=chosen["IoU"] - old["selected"]["IoU"],
                evaluated_images=695, threshold_count=81, fit_count=0, model_forward_passes=0))
            save(output / "PARTIAL_RESULTS.json", rows)
            progress(source_lr=key[0], budget=key[1], seed=key[2], arm=key[3], completed_thresholds=81)
        assert len(rows) == 24
        all_three, new_two = cohort(rows, SEEDS), cohort(rows, NEW_SEEDS)
        secondary = bool(all_three["gates"]["passed_both_source_families"] and
                         new_two["gates"]["passed_both_source_families"])
        primary = bool(aggregate["gates"]["A_any"] and replicate["gates"]["A_any"])
        assert all(sha(path) == expected for path, expected in input_hashes.items()), "Diagnostic input changed during evaluation"
        result = dict(status="COMPLETE_SECONDARY_FINE_THRESHOLD_DIAGNOSTIC", rows=rows,
            thresholds=GRID, threshold_count=81, unique_scored_units=24, threshold_score_evaluations=24 * 81,
            all_three=all_three, new_two=new_two, secondary_robustness_pass=secondary,
            original_seven_grid_robust_pass=primary, robust_on_both_grids=bool(primary and secondary),
            original_seven_grid_gates=dict(all_three=aggregate["gates"], new_two=replicate["gates"]),
            fit_count=0, optimizer_updates=0, model_forward_passes=0, cached_masks=len(r.CLASS_CACHE),
            frozen_sha256=sha(output / "FROZEN.json"), seconds=time.monotonic() - started,
            scope="Secondary calibration robustness on reused development VAL; not independent confirmation",
            original_seven_grid_results_modified=False)
        save(output / "RESULT.json", result)
        save(output / "PROGRESS.json", dict(status=result["status"], completed_units=24, total_units=24,
            threshold_score_evaluations=1944, secondary_robustness_pass=secondary,
            robust_on_both_grids=result["robust_on_both_grids"], seconds=result["seconds"]))
        print(json.dumps(dict(status=result["status"], all_three=all_three["gates"], new_two=new_two["gates"],
            robust_on_both_grids=result["robust_on_both_grids"], seconds=result["seconds"])), flush=True)
    except BaseException as error:
        save(output / "FAILURE.json", dict(status="FAILED_SECONDARY_THRESHOLD_DIAGNOSTIC",
            error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc(),
            saved_units=len(rows), seconds=time.monotonic() - started))
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "threshold_diagnostic")
    args = parser.parse_args()
    with threadpool_limits(limits=2):
        run(args.output.resolve())


if __name__ == "__main__":
    main()
