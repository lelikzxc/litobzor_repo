"""Inference-only C4/D4 probability pooling of an immutable source CNN.

Every operation on the square12-grid is an exact index permutation. Individual
outputs are inverse-transformed before their probabilities are averaged. The
module introduces no learned parameters, loss, interpolation, or optimization.
"""
from pathlib import Path
import importlib.util

import torch
from torch import nn

PILOT = Path(__file__).resolve().parents[1] / "sem_architecture_pilot_20261102"
spec = importlib.util.spec_from_file_location("orbit_pool_source_model", PILOT / "model.py")
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
state_digest = original.state_digest
GROUPS = ("C4", "D4")


def group_elements(group):
    assert group in ("identity", *GROUPS), group
    if group == "identity":
        return [(0, False)]
    return [(k, flip) for flip in ([False, True] if group == "D4" else [False]) for k in range(4)]


def transform(x, element):
    k, flip = element
    if flip:
        x = x.flip(-1)
    return torch.rot90(x, k, (-2, -1))


def inverse_transform(x, element):
    k, flip = element
    x = torch.rot90(x, -k, (-2, -1))
    return x.flip(-1) if flip else x


class OrbitPoolSegmenter(nn.Module):
    def __init__(self, backbone_state, group="C4"):
        super().__init__()
        self.elements = group_elements(group)
        self.group = group
        self.backbone = original.make_backbone()
        self.backbone.load_state_dict(backbone_state, strict=True)
        self.requires_grad_(False)
        assert sum(p.numel() for p in self.parameters()) == 10681

    def forward_details(self, x):
        assert x.ndim == 4 and x.shape[1:] == (1, 12, 12), x.shape
        aligned = [inverse_transform(self.backbone(transform(x, element)).sigmoid(), element)
                   for element in self.elements]
        aligned = torch.stack(aligned)
        return dict(probability=aligned.mean(0), aligned_probability=aligned)

    def forward(self, x):
        return self.forward_details(x)["probability"]


def architecture_spec(group):
    return dict(candidate="orbit_probability_pool", group=group,
        elements=[[k, flip] for k, flip in group_elements(group)],
        aggregation="arithmetic mean of inverse-transformed probabilities",
        grid_operations="rot90 and optional horizontal flip; no interpolation",
        backbone_parameters=10681, new_parameters=0, trainable_parameters=0,
        optimizer_updates=0, forward_passes_per_image=len(group_elements(group)),
        scope="Inference architecture on reused VAL; known group pooling, no novelty claim")
