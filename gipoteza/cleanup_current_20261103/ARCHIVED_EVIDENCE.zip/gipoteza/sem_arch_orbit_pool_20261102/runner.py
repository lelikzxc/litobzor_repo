"""Immutable zero-training C4/D4 probes on historical VAL; never TEST/EVAL."""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import time
import traceback

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "0"
import numpy as np
import torch
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits
from model import (GROUPS, OrbitPoolSegmenter, architecture_spec, group_elements,
                   inverse_transform, state_digest, transform)

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PILOT = ROOT.parent / "sem_architecture_pilot_20261102"
SOURCE_LRS = ["high_lr", "low_lr"]
CLASS_CACHE = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".{os.getpid()}.partial")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    tmp.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


preparation = module("orbit_pool_fixed_class_rule", PILOT / "prepare.py")


def resolve(path):
    path = Path(path)
    return path if path.is_absolute() else REPO / path


def configuration(path):
    c = json.loads(path.read_text())
    assert c["candidate"] == "orbit_probability_pool" and c["groups"] == list(GROUPS)
    assert c["budgets"] == [18, 27] and c["screen_seeds"] == [5501]
    assert c["replication_seeds"] == [5501, 5521, 5557]
    assert c["thresholds"] == [.3, .4, .45, .5, .55, .6, .7]
    assert c["gates"] == dict(minimum_mean_F1_gain=.005,
        minimum_budget_F1_delta=-.0025, minimum_mean_IoU_delta=-.002)
    assert c["technical_seed"] == 6503 and c["equivariance_tolerance"] == 1e-6
    assert c["protocol_sha256"] == sha(ROOT / "PROTOCOL.md")
    assert isinstance(c["prior_stage_links"], list) and len(c["prior_stage_links"]) == 5
    return c


def source_hashes():
    names = ["model.py", "runner.py", "../sem_architecture_pilot_20261102/model.py",
        "../sem_architecture_pilot_20261102/prepare.py", "../sem_confirmation_20261028/prepare.py",
        "../retained_evidence_20261027/SELECTED_SOURCES.zip"]
    return {name: sha(ROOT / name) for name in names}


def append_ledger(event):
    with (ROOT / ".ledger.lock").open("a") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        path = ROOT / "LEDGER.json"
        ledger = json.loads(path.read_text()) if path.exists() else dict(
            version=1, scope="ZERO_TRAINING_ADAPTIVE_REUSED_VAL_ONLY", events=[])
        ledger["events"].append(dict(event, index=len(ledger["events"]),
            UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        save(path, ledger)
        fcntl.flock(handle, fcntl.LOCK_UN)


def val_inputs(device):
    lineage = json.loads((PILOT / "INITIAL_LINEAGE.json").read_text())
    path = PILOT / "TRAIN_VAL.npz"
    assert sha(path) == lineage["TRAIN_VAL_sha256"]
    with np.load(path, allow_pickle=False) as z:
        ids = np.flatnonzero(z["role"] == "val")
        values = dict(x=torch.tensor(5 * (z["X"][ids] - .2), device=device),
            truth=z["label"][ids].copy(), target=z["Y"][ids, 0].astype(bool), indices=ids.tolist())
    assert len(ids) == 695
    return values, dict(TRAIN_VAL_sha256=sha(path), VAL_indices=ids.tolist(),
        initial_lineage_sha256=sha(PILOT / "INITIAL_LINEAGE.json"))


def sources(c, seeds):
    paths = [("high_lr", c["high_lr_control_result"]),
             ("low_lr", c["low_lr_control_result"])]
    paths += [("low_lr", name) for name in c.get("low_lr_additional_control_results", [])]
    rows, states = [], {}
    for source_lr, name in paths:
        result_path = resolve(name)
        result = json.loads(result_path.read_text())
        audit = result_path.parent / "AUDIT.json"
        assert audit.is_file(), "Source control must have completed independent audit"
        snapshot = result_path.parent / "CONFIG_SNAPSHOT.json"
        settings = json.loads(snapshot.read_text())
        assert settings["steps"] == 500 and settings["thresholds"] == c["thresholds"]
        learning_rate = settings["learning_rate"] if source_lr == "high_lr" else settings["backbone_learning_rate"]
        assert learning_rate == (.0005 if source_lr == "high_lr" else .0001)
        for old in result["rows"]:
            if old["seed"] not in seeds or old["budget"] not in c["budgets"]:
                continue
            if source_lr == "low_lr" and old["arm"] != "continued_base_low_lr":
                continue
            budget, seed = old["budget"], old["seed"]
            filename = (f"base_b{budget}_s{seed}.pt" if source_lr == "high_lr"
                        else f"b{budget}_continued_base_low_lr_s{seed}.pt")
            checkpoint = result_path.parent / "models" / filename
            assert sha(checkpoint) == result["checkpoint_hashes"][filename]
            payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
            state = payload["model"]
            assert state_digest(state) == old["backbone_after_sha256"]
            assert sum(v.numel() for v in state.values()) == 10681
            key = source_lr, budget, seed
            assert key not in states, "Repeated source model"
            states[key] = state
            rows.append(dict(source_lr=source_lr, budget=budget, seed=seed,
                learning_rate=learning_rate, checkpoint_file=str(checkpoint.relative_to(REPO)),
                checkpoint_sha256=sha(checkpoint), backbone_state_sha256=state_digest(state),
                control_result_file=str(result_path.relative_to(REPO)), control_result_sha256=sha(result_path),
                source_audit_file=str(audit.relative_to(REPO)), source_audit_sha256=sha(audit),
                config_snapshot_file=str(snapshot.relative_to(REPO)), config_snapshot_sha256=sha(snapshot),
                source_batch_sequence_sha256=old["batch_sequence_sha256"],
                original_backbone_before_sha256=old["backbone_before_sha256"]))
    expected = {(lr, b, s) for lr in SOURCE_LRS for b in c["budgets"] for s in seeds}
    assert set(states) == expected, "Missing source CNNs; supply audited low-lr controls before replication"
    for b in c["budgets"]:
        for seed in seeds:
            pair = [row for row in rows if row["budget"] == b and row["seed"] == seed]
            assert len({row["source_batch_sequence_sha256"] for row in pair}) == 1
            assert len({row["original_backbone_before_sha256"] for row in pair}) == 1
    return rows, states


def hard_classes(masks):
    masks = np.asarray(masks, dtype=bool).reshape(-1, 12, 12)
    keys = [r.tobytes() for r in np.packbits(masks.reshape(len(masks), 144), axis=1)]
    missing = sorted(set(keys) - CLASS_CACHE.keys())
    if missing:
        values = np.array([np.unpackbits(np.frombuffer(k, dtype=np.uint8)).reshape(12, 12)
                           for k in missing], dtype=bool)
        CLASS_CACHE.update(zip(missing, preparation.class_labels(values).tolist()))
    return np.array([CLASS_CACHE[key] for key in keys], dtype=np.int64)


def rank(row):
    return row["mask_F1"], row["IoU"], -abs(row["threshold"] - .5), -row["threshold"]


def score(probability, values, thresholds):
    rows, predictions, bits = [], [], []
    for threshold in thresholds:
        mask = probability[:, 0] >= threshold
        prediction = hard_classes(mask)
        union = (mask | values["target"]).sum((1, 2))
        iou = np.divide((mask & values["target"]).sum((1, 2)), union,
                        out=np.ones(len(mask)), where=union > 0)
        rows.append(dict(threshold=threshold, mask_F1=float(f1_score(values["truth"], prediction,
            labels=range(9), average="macro", zero_division=0)), IoU=float(iou.mean())))
        predictions.append(prediction)
        bits.append(np.packbits(mask.reshape(len(mask), 144), axis=1))
    return dict(selected=max(rows, key=rank), VAL_scores_all_thresholds=rows), dict(
        probability=probability, truth=values["truth"], target=values["target"],
        thresholds=np.array(thresholds), predictions=np.array(predictions), packed_masks=np.array(bits))


def evaluate(model, values, device):
    model.eval()
    probabilities, aligned = [], []
    with torch.no_grad():
        # Warmup is for timing only and never produces a scored row.
        model(values["x"][:8])
        if device == "mps":
            torch.mps.synchronize()
        start = time.monotonic()
        for x in values["x"].split(16):
            details = model.forward_details(x)
            probabilities.append(details["probability"].cpu().numpy())
            aligned.append(details["aligned_probability"].cpu().numpy())
        if device == "mps":
            torch.mps.synchronize()
    return np.concatenate(probabilities), np.concatenate(aligned, axis=1), dict(
        forward_seconds=time.monotonic() - start, forward_passes_per_image=len(model.elements),
        evaluated_images=len(values["x"]), scored_forward_examples=len(values["x"]) * len(model.elements),
        timing_warmup_images=8, timing_warmup_forward_examples=8 * len(model.elements))


def equivariance_fixture(model, x):
    with torch.no_grad():
        probability = model(x)
        transformed = torch.stack([model(transform(x, element)) for element in model.elements])
        restored = torch.stack([inverse_transform(value, element)
            for value, element in zip(transformed, model.elements)])
        error = float((restored - probability[None]).abs().max().cpu())
    return dict(x=x.cpu().numpy(), probability=probability.cpu().numpy(),
        transformed_probability=transformed.cpu().numpy(), restored_probability=restored.cpu().numpy(),
        elements=np.array([[k, int(flip)] for k, flip in model.elements])), error


def gates(rows, c, group):
    means = {lr: {b: {arm: {metric: float(np.mean([row["selected"][metric]
        for row in rows if row["source_lr"] == lr and row["budget"] == b and row["arm"] == arm]))
        for metric in ["mask_F1", "IoU"]} for arm in ["identity", group]}
        for b in c["budgets"]} for lr in SOURCE_LRS}
    comparisons = {}
    for lr in SOURCE_LRS:
        f1 = [means[lr][b][group]["mask_F1"] - means[lr][b]["identity"]["mask_F1"] for b in c["budgets"]]
        iou = [means[lr][b][group]["IoU"] - means[lr][b]["identity"]["IoU"] for b in c["budgets"]]
        gain, iou_gain = float(np.mean(f1)), float(np.mean(iou))
        checks = dict(mean_F1_gain=bool(gain >= c["gates"]["minimum_mean_F1_gain"]),
            budget_F1_guard=bool(min(f1) >= c["gates"]["minimum_budget_F1_delta"]),
            mean_IoU_guard=bool(iou_gain >= c["gates"]["minimum_mean_IoU_delta"]))
        comparisons[lr] = dict(delta=gain, IoU_delta=iou_gain, budget_deltas=f1,
                               checks=checks, passed=all(checks.values()))
    passed = all(row["passed"] for row in comparisons.values())
    return dict(A_architecture=dict(by_source_lr=comparisons, passed=passed), A_any=passed,
        interpretation="Must pass both immutable source-lr families on reused development VAL"), means


def signature(c, group):
    return digest(dict(configuration={k: v for k, v in c.items()
        if k != "low_lr_additional_control_results"}, group=group, source_sha256=source_hashes(),
        TRAIN_VAL_sha256=sha(PILOT / "TRAIN_VAL.npz")))


def previous_screen(group, expected_signature=None):
    found = []
    for path in (ROOT / "trials").glob("*/RESULT.json"):
        row = json.loads(path.read_text())
        if row["group"] == group and row["phase"] == "screen" and row["status"] == "COMPLETE_ZERO_TRAINING_DEVELOPMENT":
            if expected_signature is None or row["signature"] == expected_signature:
                found.append((path, row))
    assert len(found) == 1, "Require exactly one compatible completed screen"
    return found[0]


def preflight(c, group):
    refs, states = sources(c, [5501])
    generator = torch.Generator().manual_seed(c["technical_seed"])
    x = torch.randn((2, 1, 12, 12), generator=generator)
    errors = []
    for row in refs:
        key = row["source_lr"], row["budget"], row["seed"]
        model = OrbitPoolSegmenter(states[key], group).eval()
        fixture, error = equivariance_fixture(model, x)
        assert error <= c["equivariance_tolerance"]
        identity = OrbitPoolSegmenter(states[key], "identity").eval()
        with torch.no_grad():
            assert torch.equal(identity(x), model.backbone(x).sigmoid())
            assert all(torch.equal(inverse_transform(transform(x, e), e), x) for e in model.elements)
        assert state_digest(model.backbone.state_dict()) == row["backbone_state_sha256"]
        name = f'{group}_{row["source_lr"]}_b{row["budget"]}_s{row["seed"]}'
        np.savez_compressed(ROOT / f"TECHNICAL_{name}.npz", **fixture)
        errors.append(dict(source_lr=row["source_lr"], budget=row["budget"], seed=row["seed"], error=error))
    result = dict(status="PASS_PREFLIGHT", group=group, equivariance=errors,
        equivariance_tolerance=c["equivariance_tolerance"], identity_exact=True,
        no_interpolation=True, parameters=10681, trainable_parameters=0, updates=0,
        forward_passes_per_image=len(group_elements(group)), source_sha256=source_hashes(), sources=refs)
    save(ROOT / f"PREFLIGHT_{group}.json", result)
    print(json.dumps(result), flush=True)


def run(c, group, phase, config_path):
    assert torch.backends.mps.is_available() and os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] == "0"
    started = time.monotonic()
    seeds = c["screen_seeds"] if phase == "screen" else [s for s in c["replication_seeds"] if s not in c["screen_seeds"]]
    training_signature = signature(c, group)
    inherited = previous_screen(group, training_signature) if phase == "replicate" else None
    if inherited is not None:
        assert inherited[1]["gates"]["A_any"], "Replication requires a passing architecture screen"
    if group == "D4":
        assert not previous_screen("C4")[1]["gates"]["A_any"], "D4 queued only after failed C4"
    refs, states = sources(c, seeds)  # Missing controls fail before creating a trial.
    values, lineage = val_inputs("mps")
    trial_id = f'{group}_{phase}_s{"-".join(map(str, seeds))}_{digest(source_hashes())[:10]}'
    trial = ROOT / "trials" / trial_id
    assert not trial.exists(), "Immutable trial exists; no overwrite or implicit resume"
    for folder in [trial, trial / "val_probs", trial / "fixtures", trial / "source"]:
        folder.mkdir(parents=True, exist_ok=False)
    hashes = source_hashes()
    save(trial / "CONFIG_SNAPSHOT.json", c)
    shutil.copy2(ROOT / "PROTOCOL.md", trial / "PROTOCOL.md")
    for name in ["model.py", "runner.py"]:
        shutil.copy2(ROOT / name, trial / "source" / name)
    save(trial / "SOURCE_MANIFEST.json", refs)
    frozen = dict(candidate=c["candidate"], group=group, phase=phase, seeds=seeds,
        signature=training_signature, source_sha256=hashes, sources=refs, lineage=lineage,
        protocol_sha256=sha(ROOT / "PROTOCOL.md"), config_sha256=sha(config_path),
        architecture=architecture_spec(group), prior_stage_links=c["prior_stage_links"],
        fit_count=0, optimizer_updates=0, source_model_count=len(refs), evaluation_count=2 * len(refs),
        scope="Zero-training inference architecture; reused VAL only, no TEST/EVAL")
    save(trial / "FROZEN.json", frozen)
    append_ledger(dict(status="RUNNING", trial=trial_id, group=group, phase=phase, signature=training_signature))
    rows = []
    try:
        for reference in refs:
            key = reference["source_lr"], reference["budget"], reference["seed"]
            for arm in ["identity", group]:
                model = OrbitPoolSegmenter(states[key], arm).to("mps").eval()
                probability, aligned, timing = evaluate(model, values, "mps")
                evaluation, arrays = score(probability, values, c["thresholds"])
                arrays["aligned_probability"] = aligned
                arrays["selected_threshold"] = np.array(evaluation["selected"]["threshold"])
                name = f'{reference["source_lr"]}_b{reference["budget"]}_s{reference["seed"]}_{arm}'
                np.savez_compressed(trial / "val_probs" / f"{name}.npz", **arrays)
                fixture, error = equivariance_fixture(model, values["x"][:16])
                assert error <= c["equivariance_tolerance"]
                fixture["selected_threshold"] = np.array(evaluation["selected"]["threshold"])
                np.savez_compressed(trial / "fixtures" / f"{name}.npz", **fixture)
                assert state_digest(model.backbone.state_dict()) == reference["backbone_state_sha256"]
                row = dict(source_lr=reference["source_lr"], budget=reference["budget"], seed=reference["seed"],
                    arm=arm, source=reference, parameters=10681, trainable_parameters=0,
                    optimizer_updates=0, fit_count=0, equivariance_max_error=error, **timing, **evaluation)
                rows.append(row)
                save(trial / "PARTIAL_RESULTS.json", rows)
                progress = dict(stage="ORBIT_POOL_VAL_INFERENCE_ONLY", trial=trial_id,
                    group=group, phase=phase, completed_evaluations=len(rows), target_evaluations=2 * len(refs),
                    source_lr=row["source_lr"], budget=row["budget"], seed=row["seed"], arm=arm,
                    seconds=time.monotonic() - started, fit_count=0, optimizer_updates=0)
                save(ROOT / "PROGRESS.json", progress)
                print(json.dumps(progress), flush=True)
                del model
        assert all(sha(ROOT / name) == value for name, value in hashes.items())
        assert sha(config_path) == frozen["config_sha256"] and sha(ROOT / "PROTOCOL.md") == frozen["protocol_sha256"]
        for ref in refs:
            for file_key, hash_key in [("checkpoint_file", "checkpoint_sha256"),
                ("control_result_file", "control_result_sha256"), ("source_audit_file", "source_audit_sha256")]:
                assert sha(REPO / ref[file_key]) == ref[hash_key]
        development, means = gates(rows, c, group)
        result = dict(status="COMPLETE_ZERO_TRAINING_DEVELOPMENT", candidate=c["candidate"], group=group,
            phase=phase, seeds=seeds, signature=training_signature, rows=rows, sources=refs,
            gates=development, means=means, fit_count=0, updates=0, optimizer_updates=0,
            evaluation_count=len(rows), source_model_count=len(refs), seconds=time.monotonic() - started,
            scored_forward_examples=sum(row["scored_forward_examples"] for row in rows),
            timing_warmup_forward_examples=sum(row["timing_warmup_forward_examples"] for row in rows),
            frozen_sha256=sha(trial / "FROZEN.json"), scope="Adaptive reused-VAL inference architecture; no new training or TEST")
        save(trial / "RESULT.json", result)
        aggregate = None
        if inherited is not None:
            old_path, old = inherited
            all_rows = old["rows"] + rows
            assert len({(r["source_lr"], r["budget"], r["seed"], r["arm"]) for r in all_rows}) == len(all_rows)
            ag, am = gates(all_rows, c, group)
            aggregate = dict(status="COMPLETE_REUSED_VAL_ZERO_TRAINING_REPLICATION", group=group,
                seeds=c["replication_seeds"], rows=all_rows, gates=ag, means=am,
                new_seed_gates=development, robust_architecture_pass=bool(ag["A_any"] and development["A_any"]),
                source_trials=[str(old_path.parent.relative_to(ROOT)), str(trial.relative_to(ROOT))], fit_count=0, updates=0)
            save(trial / "AGGREGATE_RESULT.json", aggregate)
        summary = dict(status=result["status"], group=group, phase=phase, trial=str(trial.relative_to(ROOT)),
            result_sha256=sha(trial / "RESULT.json"), gates=aggregate["gates"] if aggregate else development,
            means=aggregate["means"] if aggregate else means, fit_count=0, updates=0)
        append_ledger(summary)
        save(ROOT / "LATEST_RESULT.json", summary)
        print(json.dumps(summary), flush=True)
    except BaseException as error:
        failure = dict(status="FAILED", trial=trial_id, group=group, phase=phase,
            error=str(error), error_type=type(error).__name__, traceback=traceback.format_exc())
        save(trial / "FAILURE.json", failure)
        append_ledger(failure)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", choices=GROUPS, required=True)
    parser.add_argument("--phase", choices=["screen", "replicate"], default="screen")
    parser.add_argument("--config", type=Path, default=ROOT / "CONFIG.json")
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    c = configuration(args.config)
    torch.set_num_threads(2)
    if args.preflight:
        preflight(c, args.group)
    else:
        run(c, args.group, args.phase, args.config)


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
