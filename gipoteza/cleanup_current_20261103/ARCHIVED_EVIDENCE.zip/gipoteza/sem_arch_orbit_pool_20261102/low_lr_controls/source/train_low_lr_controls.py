"""Complete only the missing5521/5557 low-lr CNN controls for C4 replication.

The historical stage3 inputs/make/fit/evaluate functions are imported without
editing them. Its ROOT is redirected in memory so even progress writes stay
under this new control directory. This script never fits an orbit model and
never opens a TEST/EVAL array or historical test metric.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import inspect
import json
import os
import shutil
import sys
import time
import traceback

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "0"
import numpy as np
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
STAGE3 = ROOT.parent / "sem_arch_joint_adaptation_20261102"
OUT = ROOT / "low_lr_controls"
PROTOCOL = ROOT / "LOW_LR_CONTROL_PROTOCOL.md"
SEEDS = [5521, 5557]
ARM = "continued_base_low_lr"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def unchanged_stage3_runner():
    # Stage3 imports "model" by its historical short name. Bind precisely
    # that original module while loading, then restore the caller's binding.
    historical_model = load_module("additional_low_lr_original_model", STAGE3 / "model.py")
    previous = sys.modules.get("model")
    sys.modules["model"] = historical_model
    try:
        result = load_module("additional_low_lr_original_runner", STAGE3 / "runner.py")
    finally:
        if previous is None:
            del sys.modules["model"]
        else:
            sys.modules["model"] = previous
    return result


r = unchanged_stage3_runner()


def configuration():
    config_path = STAGE3 / "CONFIG.json"
    c = r.configuration(config_path)
    assert c["steps"] == 500 and c["backbone_learning_rate"] == .0001
    assert c["physics_weight"] == 1. and c["batch_size"] == 8
    assert c["budgets"] == [18, 27] and c["replication_seeds"] == [5501, 5521, 5557]
    assert PROTOCOL.is_file(), "Freeze the separate low-lr-control protocol before fitting"
    return c, config_path


def numerical_sources():
    files = {str((STAGE3 / name).resolve().relative_to(REPO)): value
             for name, value in r.source_hashes().items()}
    files[str(Path(__file__).relative_to(REPO))] = sha(Path(__file__))
    return files


def function_hashes():
    return {name: hashlib.sha256(inspect.getsource(getattr(r, name)).encode()).hexdigest()
            for name in ["inputs", "make", "fit", "evaluate", "fixtures"]}


def preflight(c):
    data, states, lineage = r.inputs(c, SEEDS, "cpu")
    evidence = []
    for budget in c["budgets"]:
        for seed in SEEDS:
            net = r.make(c, ARM, states[budget, seed], seed, "cpu")
            before = r.state_digest(net.state_dict())
            assert before == lineage["sources"][f"{budget}:{seed}"]["backbone_sha256"]
            assert sum(p.numel() for p in net.parameters() if p.requires_grad) == 10681
            # A CPU backward probe proves the unchanged objective can update
            # every CNN layer; it deliberately takes no optimizer step.
            dense = net(data[budget]["dense"]["x"][:2])
            weak = net(data[budget]["weak"]["x"][:2])
            labels = data[budget]["weak"]["label"][:2]
            direction = torch.stack((labels // 3, labels % 3), dim=1)
            loss = F.binary_cross_entropy_with_logits(dense, data[budget]["dense"]["mask"][:2])
            loss = loss + c["physics_weight"] * r.physics.geometry_loss(weak, direction)
            loss.backward()
            assert torch.isfinite(loss)
            assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in net.parameters())
            assert any(float(p.grad.abs().sum()) > 0 for p in net.parameters())
            assert r.state_digest(net.state_dict()) == before
            evidence.append(dict(budget=budget, seed=seed, source_state_sha256=before,
                parameters=10681, finite_old_loss_and_gradients=True, optimizer_updates=0))
    proof = dict(status="PASS_ADDITIONAL_LOW_LR_PREFLIGHT", seeds=SEEDS, rows=evidence,
        imported_runner_file=str((STAGE3 / "runner.py").relative_to(REPO)),
        source_sha256=numerical_sources(), function_source_sha256=function_hashes(),
        control_protocol_sha256=sha(PROTOCOL), lineage=lineage,
        updates=0, no_historical_file_writes=True)
    r.save(ROOT / "LOW_LR_CONTROL_PREFLIGHT.json", proof)
    print(json.dumps(proof), flush=True)


def run(c, source_config):
    assert torch.backends.mps.is_available() and os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] == "0"
    assert not OUT.exists(), "Immutable additional control exists; no overwrite or implicit resume"
    numerical = numerical_sources()
    functions = function_hashes()
    protected = {str(path.relative_to(REPO)): sha(path) for path in [
        STAGE3 / "PROGRESS.json", STAGE3 / "CONFIG.json", STAGE3 / "PROTOCOL.md",
        ROOT / "model.py", ROOT / "runner.py", ROOT / "CONFIG.json", ROOT / "PROTOCOL.md"]}
    control_protocol_sha = sha(PROTOCOL)
    started = time.monotonic()
    data, states, lineage = r.inputs(c, SEEDS, "mps")
    high_path = REPO / c["high_lr_control_result"]
    high_result = json.loads(high_path.read_text())
    reference = {(row["budget"], row["seed"]): row for row in high_result["rows"]
                 if row["seed"] in SEEDS}
    assert set(reference) == {(b, s) for b in c["budgets"] for s in SEEDS}
    for folder in [OUT, OUT / "models", OUT / "val_probs", OUT / "fixtures", OUT / "source"]:
        folder.mkdir(parents=True, exist_ok=False)
    r.save(OUT / "CONFIG_SNAPSHOT.json", c)
    shutil.copy2(PROTOCOL, OUT / "PROTOCOL.md")
    shutil.copy2(Path(__file__), OUT / "source" / "train_low_lr_controls.py")
    for name in ["runner.py", "model.py"]:
        shutil.copy2(STAGE3 / name, OUT / "source" / name)
    frozen = dict(scope="ADDITIONAL_LOW_LR_CONTROLS_TRAIN_VAL_ONLY", seeds=SEEDS,
        budgets=c["budgets"], arm=ARM, models=4, steps_each=500, total_updates=2000,
        trainable_parameters=10681, learning_rate=.0001, weight_decay=c["weight_decay"],
        objective="unchanged BCE(dense)+1*geometry_loss(weak)",
        source_sha256=numerical, function_source_sha256=functions,
        source_config_file=str(source_config.relative_to(REPO)), source_config_sha256=sha(source_config),
        control_protocol_sha256=control_protocol_sha, lineage=lineage,
        high_lr_control_file=str(high_path.relative_to(REPO)), high_lr_control_sha256=sha(high_path),
        protected_historical_sha256=protected, progress_root_redirected_in_memory=str(OUT.relative_to(REPO)),
        paired_batches="unchanged np.default_rng(seed+1000), dense8 then weak8 for500steps",
        original_orbit_sources_and_config_unchanged=True)
    r.save(OUT / "FROZEN.json", frozen)
    rows, hashes, counter = [], {}, [0]
    # This changes only a Python variable in the imported module. In particular,
    # its exact fit implementation now writes progress exclusively to OUT.
    original_root = r.ROOT
    r.ROOT = OUT
    r.START = started
    try:
        for budget in c["budgets"]:
            for seed in SEEDS:
                net = r.make(c, ARM, states[budget, seed], seed, "mps")
                timing, warmup = r.fit(c, net, data[budget], budget, seed, ARM, OUT, counter)
                assert warmup is None and timing["CNN_updates"] == 500
                assert timing["backbone_before_sha256"] == reference[budget, seed]["backbone_before_sha256"]
                assert timing["batch_sequence_sha256"] == reference[budget, seed]["batch_sequence_sha256"]
                evaluation, arrays = r.evaluate(c, net, data[budget]["val"], ARM)
                fixture, parity = r.fixtures(net, data[budget]["val"], ARM)
                row = dict(candidate="additional_low_lr_source_CNN", budget=budget, seed=seed, arm=ARM,
                    source_initial=lineage["sources"][f"{budget}:{seed}"],
                    **timing, **evaluation, cache_full_max_errors=parity)
                name = f"b{budget}_{ARM}_s{seed}"
                path = OUT / "models" / f"{name}.pt"
                temporary = path.with_suffix(".pt.partial")
                torch.save(dict(model={key: value.detach().cpu() for key, value in net.state_dict().items()},
                                settings=row), temporary)
                temporary.replace(path)
                hashes[path.name] = sha(path)
                np.savez_compressed(OUT / "val_probs" / f"{name}.npz", **arrays)
                np.savez_compressed(OUT / "fixtures" / f"{name}.npz", **fixture)
                rows.append(row)
                r.save(OUT / "PARTIAL_RESULTS.json", rows)
                r.save(OUT / "CHECKPOINT_HASHES.json", hashes)
                del net
        assert counter[0] == 2000 and len(rows) == 4
        assert all(sha(REPO / name) == value for name, value in numerical.items())
        assert all(sha(REPO / name) == value for name, value in protected.items())
        assert sha(PROTOCOL) == control_protocol_sha and sha(high_path) == frozen["high_lr_control_sha256"]
        assert all(sha(ROOT.parent / value["file"]) == value["sha256"] for value in lineage["sources"].values())
        proof = dict(status="PASS_UNCHANGED_SOURCE_CONTROL_IMPLEMENTATION",
            source_sha256_before=numerical,
            source_sha256_after={name: sha(REPO / name) for name in numerical},
            protected_historical_sha256_before=protected,
            protected_historical_sha256_after={name: sha(REPO / name) for name in protected},
            function_source_sha256=functions, original_runner_functions_reused=True,
            old_loss_unchanged=True, all_source_batch_sequences_match_high_lr=True,
            progress_writes_redirected_without_source_edits=True)
        r.save(OUT / "IMPLEMENTATION_PROOF.json", proof)
        result = dict(status="COMPLETE_ADDITIONAL_LOW_LR_CONTROLS_VAL_ONLY", rows=rows,
            seeds=SEEDS, budgets=c["budgets"], models=4, updates=2000, checkpoint_hashes=hashes,
            seconds=time.monotonic() - started, frozen_sha256=sha(OUT / "FROZEN.json"),
            proof_sha256=sha(OUT / "IMPLEMENTATION_PROOF.json"),
            scope="Four required source-CNN controls; reused TRAIN/VAL only, no orbit fitting or TEST")
        r.save(OUT / "RESULT.json", result)
        r.save(OUT / "PROGRESS.json", dict(stage=result["status"], models=4, updates=2000))
        print(json.dumps(result), flush=True)
    except BaseException as error:
        r.save(OUT / "FAILURE.json", dict(status="FAILED_ADDITIONAL_LOW_LR_CONTROLS",
            error=str(error), error_type=type(error).__name__, traceback=traceback.format_exc()))
        raise
    finally:
        r.ROOT = original_root


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    c, config_path = configuration()
    torch.set_num_threads(2)
    if args.preflight:
        preflight(c)
    else:
        run(c, config_path)


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
