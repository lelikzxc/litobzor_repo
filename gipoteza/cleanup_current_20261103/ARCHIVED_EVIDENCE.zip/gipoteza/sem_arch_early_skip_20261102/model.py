"""FiLM eta4 with a controlled early-feature skip and matched late skip.

The loss is deliberately absent. Conditioning maps use the current coarse
prediction, detached from autograd; the visual and coarse residual paths
remain differentiable when the CNN is unfrozen. No datasets are read here.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path

import torch
from torch import nn


PILOT = Path(__file__).resolve().parents[1] / "sem_architecture_pilot_20261102"
CANDIDATES = ("film_early_skip",)
ARMS = ("plain", "joint", "late_joint")
ROLL_SHIFT = (5, 5)


def _load_source(name, filename):
    spec = importlib.util.spec_from_file_location(name, PILOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_original = _load_source("early_skip_original_model", "model.py")
_circuit = _load_source("early_skip_original_circuit", "circuit.py")
state_digest = _original.state_digest
make_backbone = _original.make_backbone


def normalize_maps(raw, scale=100.0, floor=1e-6):
    assert raw.ndim == 4 and raw.shape[1:] == (2, 12, 12), raw.shape
    transformed = torch.log1p(float(scale) * raw)
    centered = transformed - transformed.mean((-2, -1), keepdim=True)
    return centered / torch.sqrt(
        centered.square().mean((-2, -1), keepdim=True) + float(floor)
    )


class FiLMRefiner(nn.Module):
    """Preserve every prior FiLM tensor; append 24 zero-initialized kernels."""

    def __init__(self):
        super().__init__()
        self.visual = nn.Sequential(nn.Conv2d(26, 16, 3, padding=1), nn.GELU())
        self.conditioning = nn.Conv2d(2, 32, 3, padding=1)
        self.output = nn.Sequential(
            nn.Conv2d(16, 8, 3, padding=1), nn.GELU(), nn.Conv2d(8, 1, 1),
        )
        nn.init.zeros_(self.output[-1].weight)
        nn.init.zeros_(self.output[-1].bias)
        # Construct all previous modules first, in their original RNG order.
        # Thus the first26 channels, conditioning and output exactly match
        # stage3 at the same seed. Additional channels initially contribute0.
        previous = self.visual[0]
        expanded = nn.Conv2d(50, 16, 3, padding=1)
        with torch.no_grad():
            expanded.weight.zero_()
            expanded.weight[:, :26].copy_(previous.weight)
            expanded.bias.copy_(previous.bias)
        self.visual[0] = expanded

    def forward(self, visual, maps):
        features = self.visual(visual)
        gamma, beta = self.conditioning(maps).chunk(2, dim=1)
        modulated = features * (1 + 0.5 * gamma.tanh()) + 0.5 * beta.tanh()
        return self.output(modulated)


class EarlySkipSegmenter(nn.Module):
    def __init__(self, arm, backbone_state=None, *, decoder_seed=None,
                 epsilon=0.001, eta=4.0, scale=100.0, norm_floor=1e-6):
        super().__init__()
        assert arm in ARMS, arm
        assert 0 < epsilon < 0.5 and eta > 0 and scale > 0 and norm_floor > 0
        self.arm = arm
        self.skip_route = "late_F3" if arm == "late_joint" else "early_F1"
        self.epsilon, self.eta = float(epsilon), float(eta)
        self.scale, self.norm_floor = float(scale), float(norm_floor)
        if decoder_seed is not None:
            torch.manual_seed(int(decoder_seed))
        self.backbone = make_backbone()
        self.refiner = FiLMRefiner()
        if backbone_state is not None:
            self.backbone.load_state_dict(backbone_state, strict=True)
        self.circuit = _circuit.CircuitMaps(epsilon=self.epsilon)
        self.set_backbone_trainable(False)
        assert self.parameter_counts()["backbone"] == 10681
        assert self.parameter_counts()["refiner"] == 8993

    def set_backbone_trainable(self, trainable):
        for parameter in self.backbone.parameters():
            parameter.requires_grad_(bool(trainable))

    def parameter_counts(self):
        return {
            "backbone": sum(p.numel() for p in self.backbone.parameters()),
            "refiner": sum(p.numel() for p in self.refiner.parameters()),
            "trainable": sum(p.numel() for p in self.parameters() if p.requires_grad),
            "total": sum(p.numel() for p in self.parameters()),
        }

    def current_inputs(self, x):
        """Live CNN paths and detached, label-free current-prediction maps."""
        assert x.ndim == 4 and x.shape[1:] == (1, 12, 12), x.shape
        early = self.backbone[:2](x)
        middle = self.backbone[2:4](early)
        features = self.backbone[4:6](middle)
        coarse = self.backbone[-1](features)
        with torch.no_grad():
            detached = coarse.detach()
            if self.arm == "plain":
                p = detached.sigmoid()
                raw = torch.cat((p, 4 * p * (1 - p)), dim=1)
            else:
                raw = self.circuit(detached, mode="joint")
            maps = normalize_maps(raw, self.scale, self.norm_floor)
        assert not maps.requires_grad and not raw.requires_grad
        skip = features if self.arm == "late_joint" else early
        return {"visual": torch.cat((features, coarse, x, skip), dim=1),
                "coarse": coarse, "maps": maps, "maps_raw": raw,
                "early_features": early, "late_features": features, "skip_features": skip}

    def _refine(self, inputs, intervention="actual"):
        assert intervention in ("actual", "zero", "roll"), intervention
        visual, coarse, maps = (inputs[k] for k in ("visual", "coarse", "maps"))
        if intervention == "zero":
            maps = torch.zeros_like(maps)
        elif intervention == "roll":
            maps = torch.roll(maps, shifts=ROLL_SHIFT, dims=(-2, -1))
        residual = self.refiner(visual, maps)
        correction = self.eta * residual.tanh()
        return {"logits": coarse + correction, "coarse": coarse,
                "correction": correction, "residual": residual,
                "maps_normalized": maps, "maps_raw": inputs["maps_raw"]}

    @torch.no_grad()
    def precompute(self, x):
        """Ephemeral evaluation cache; never a training cache after unfreezing."""
        return {k: v.detach().clone() for k, v in self.current_inputs(x).items()}

    def forward_cached(self, cache, intervention="actual"):
        assert not self.training, "Cached CNN features are evaluation-only"
        return self._refine(cache, intervention)

    def forward_details(self, x, intervention="actual"):
        return self._refine(self.current_inputs(x), intervention)

    def forward(self, x):
        return self.forward_details(x)["logits"]


def make_model(arm, backbone_state=None, **kwargs):
    return EarlySkipSegmenter(arm, backbone_state, **kwargs)


def architecture_spec():
    return dict(
        candidate="film_early_skip", arms=list(ARMS), backbone_parameters=10681,
        refiner_parameters=8993, total_parameters=19674,
        refiner="prior FiLM with visual Conv2d inputs26to50; old26 copied,new24zero",
        correction="4*tanh(signed_residual)",
        conditioning="current coarse prediction, detached; log1p100 centered/RMS",
        visual_channels=["CNN_F3_24", "coarse_logit1", "SEM1", "skip24"],
        skip_routes=dict(plain="F1", joint="F1", late_joint="F3"),
        maps_label_free=True, map_gradient=False,
        training_schedule="100 refiner-only + 400 refiner-and-CNN updates",
        training_cache=False, identity_initialization="zero final convolution",
        matching="all3 arms exact initial weights/parameters; late_joint controls skip route",
        roll_intervention=list(ROLL_SHIFT),
        scope="reused TRAIN/VAL development; unchanged loss; no novelty claim",
    )
