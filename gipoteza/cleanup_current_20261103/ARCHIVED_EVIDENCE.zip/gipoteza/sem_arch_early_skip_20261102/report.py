"""Report saved early-skip development trials; never execute a model."""
from __future__ import annotations

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
HELPER = ROOT.parent / "sem_arch_joint_adaptation_20261102" / "report.py"
spec = importlib.util.spec_from_file_location("saved_json_report_helpers", HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
read, sha, rel = helpers.read, helpers.sha, helpers.rel
percent, pp, passed, mean = helpers.percent, helpers.pp, helpers.passed, helpers.mean
discover, actual_rows, views = helpers.discover, helpers.actual_rows, helpers.views
plt, np = helpers.plt, helpers.np
ARMS = ["plain", "joint", "late_joint"]


def control_sources(config):
    high_path = (REPO / config["high_lr_control_result"]).resolve()
    high = read(high_path)
    assert high["frozen_sha256"] == sha(high_path.with_name("FROZEN.json"))
    paths = [(REPO / path).resolve() for path in
             [config["low_lr_control_result"]] + config.get("low_lr_additional_control_results", [])]
    assert len(paths) == len(set(paths))
    low = [row for path in paths for row in read(path)["rows"] if row["arm"] == "continued_base_low_lr"]
    assert len(low) == len({(row["budget"], row["seed"]) for row in low}), "Duplicate low-lr control units"
    return high_path, high, paths, low


def verify_control(result, high, low):
    units = {(row["budget"], row["seed"]) for row in result["rows"]}
    for arm in ARMS:
        rows = [row for row in result["rows"] if row["arm"] == arm]
        assert len(rows) == len(units) and {(row["budget"], row["seed"]) for row in rows} == units
    for name, source in [("high_lr_controls", high["rows"]), ("low_lr_controls", low)]:
        selected = [row for row in source if (row["budget"], row["seed"]) in units]
        reference = {(row["budget"], row["seed"]): row for row in selected}
        copied = {(row["budget"], row["seed"]): row for row in result[name]}
        assert len(selected) == len(units) and len(result[name]) == len(units)
        assert set(reference) == units and copied == reference
        for row in result["rows"]:
            control = reference[row["budget"], row["seed"]]
            for field in ["backbone_before_sha256", "batch_sequence_sha256", "steps"]:
                assert row[field] == control[field], field
    return result["high_lr_controls"], result["low_lr_controls"]


def figure(result_views):
    if not result_views:
        return None
    path = ROOT / "figures" / "early_skip_validation.png"
    path.parent.mkdir(exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.2))
    x = np.arange(len(result_views));width = .15
    for offset, arm, key, label, color in [
        (-2, None, "low_lr_controls", "shared CNN lr=0.0001", "#777777"),
        (-1, "plain", "rows", "early plain", "#3c78a8"),
        (0, "joint", "rows", "early joint", "#b25a43"),
        (1, "late_joint", "rows", "late joint (same capacity)", "#8d6cab"),
        (2, None, "high_lr_controls", "shared CNN lr=0.0005", "#90734e")]:
        values = [100 * mean(result[key], arm) for _, result in result_views]
        bars = axes[0].bar(x + offset * width, values, width, label=label, color=color)
        axes[0].bar_label(bars, fmt="%.2f", padding=3, fontsize=7)
    axes[0].set_ylim(0, min(100, max(bar.get_height() for bar in axes[0].patches) + 9))
    axes[0].set_ylabel("Validation Macro-F1, %")
    axes[0].set_title("Selected thresholds; equal budget weights")
    axes[0].legend(fontsize=8, loc="lower left")
    for offset, kind, field, label, color, marker in [
        (-.24, "A_architecture", "vs_low_lr", "A early joint − CNN lr=0.0001", "#b25a43", "o"),
        (-.08, "A_architecture", "vs_high_lr", "A early joint − CNN lr=0.0005", "#90734e", "x"),
        (.08, "B_physics", None, "B early joint − early plain", "#4d8d63", "D"),
        (.24, "C_skip_route", None, "C early joint − late joint", "#8d6cab", "s")]:
        values = [100 * (result["gates"][kind]["joint"][field]["delta"] if field else
                         result["gates"][kind]["delta"]) for _, result in result_views]
        axes[1].scatter(x + offset, values, s=50, color=color, marker=marker, label=label)
    axes[1].axhline(0, color="black", lw=.8)
    axes[1].axhline(.5, color="gray", ls="--", lw=.8, label="Mean-gain gate: +0.5 pp")
    axes[1].set_ylabel("Macro-F1 difference, percentage points")
    axes[1].set_title("Development estimates; no independent TEST")
    axes[1].legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.12), ncol=2)
    for axis in axes:
        axis.set_xticks(x, [name for name, _ in result_views])
        axis.set_xlim(-.6, len(x) - .4)
    fig.suptitle("Early CNN features versus a matched late-feature capacity control", fontsize=11)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def build():
    config = read(ROOT / "CONFIG.json")
    trials = discover(ROOT)
    previous = []
    for link in config["prior_stage_links"]:
        path = (ROOT / link).resolve()
        assert path.parent == ROOT.parent and path != ROOT
        assert path not in [stage["path"] for stage in previous]
        previous.append({"path": path, "trials": discover(path)})
    high_path, high, low_paths, low = control_sources(config)
    complete = [trial for trial in trials if trial["result"]]
    failures = [trial for trial in trials if trial["failure"]]
    pending = [trial for trial in trials if not trial["result"] and not trial["failure"]]
    prior_trials = [trial for stage in previous for trial in stage["trials"]]
    prior_rows, local_rows = actual_rows(prior_trials), actual_rows(trials)
    # Reused low-lr CNNs already occur in stage 3. Count genuinely new control
    # rows only if an explicit additional control source was later supplied.
    extra_low = [row for row in low if row not in prior_rows]
    prior_unique = len(prior_rows) + len(high["rows"])
    unique_fits = prior_unique + len(local_rows) + len(extra_low)
    result_views = views(trials)
    for trial in complete:
        assert trial["result"]["frozen_sha256"] == sha(trial["path"] / "FROZEN.json")
        assert trial["frozen"]["high_lr_control"]["result_sha256"] == sha(high_path)
        for source in trial["frozen"]["low_lr_control"]["sources"]:
            assert sha(REPO / source["file"]) == source["result_sha256"]
            assert sha((REPO / source["file"]).with_name("CONFIG_SNAPSHOT.json")) == source["config_snapshot_sha256"]
        verify_control(trial["result"], high, low)
        if trial["aggregate"]:
            verify_control(trial["aggregate"], high, low)
    output_figure = figure(result_views)
    text = [
        "# Ранние признаки CNN и контроль ёмкости FiLM", "",
        "Четвёртый этап последовательной разработки на прежних TRAIN/VAL. "
        "Меняется модель при предсказании; прежние BCE и geometry_loss с весом 1 остаются общими. "
        "Нового независимого TEST нет. Критерии разработки не доказывают новизну или статистическое превосходство.", "",
        "К визуальному входу FiLM `[F3, coarse, SEM]` добавлены 24 ранних канала F1: 26→50 каналов. "
        "Новые ядра нулевые при старте, исходные ядра сохраняют начальные значения. "
        "Plain/joint используют ранний F1; late_joint использует ещё одну копию позднего F3 при том же размере. "
        "Во всех трёх вариантах уточнитель имеет 8 993 параметра, CNN — 10 681, всего 19 674. "
        "Этот контроль отделяет источник информации от одной ёмкости блока.", "",
        "Амплитуда `4*tanh(residual)`, первые 100 шагов только уточнитель, затем 400 шагов совместной адаптации. "
        "AdamW: lr CNN 0,0001, lr уточнителя 0,0005, weight_decay 0,0001; батч 8 плотных + 8 слабых. "
        "Карты и признаки пересчитываются по текущей CNN; карты отделены от градиента. "
        "Начальные параметры и батчи трёх вариантов совпадают.", "",
        "## Объём поиска и общие контроли", "",
        f"Локально начато попыток {len(trials)}; завершено {len(complete)}; технических ошибок {len(failures)}; "
        f"незавершённых {len(pending)}. Сохранено {len(local_rows)} новых обучений уточнителей, "
        f"{sum(row['steps'] for row in local_rows):,} обновлений. CNN-контроли внутри этих попыток не переучиваются.", "",
        f"Три предыдущих этапа содержат {len(prior_trials)} попыток и {prior_unique} уникальных обучений "
        "с общим высокоскоростным CNN-контролем. "
        f"Уникальных обучений вместе с текущим этапом: **{unique_fits}**. "
        f"Дополнительных low-lr контролей вне предыдущих попыток: {len(extra_low)}. "
        "Копии low_lr_controls/high_lr_controls и AGGREGATE_RESULT не считаются новыми обучениями.", "",
        f"Общий CNN lr=0,0005: [RESULT.json]({rel(high_path, ROOT)}), SHA-256 `{sha(high_path)}`. "
        "CNN lr=0,0001 берётся из явно указанных сохранённых источников:", "",
    ]
    for path in low_paths:
        text.append(f"- [{rel(path, ROOT)}]({rel(path, ROOT)}), SHA-256 `{sha(path)}`.")
    text += ["", "Сравниваются точные пары **(бюджет, seed)**; проверены SHA исходных CNN, "
             "последовательности батчей и 500 шагов, а также совпадение сохранённых копий контролей. "
             "Контроль другого seed не подставляется при отсутствии пары.", "",
             "## Раздельные критерии A/B/C", "",
             "A для каждого из plain/joint/late_joint требует выигрыша относительно **каждой** из двух дообученных CNN. "
             "B сравнивает early joint с early plain и требует прохождения A joint. "
             "C сравнивает early joint с late_joint; это отдельная проверка пути признаков, её прохождение не требуется для A. "
             "Для каждого сравнения: средний ΔF1 ≥0,5 п.п.; ΔF1 каждого бюджета ≥−0,25 п.п.; "
             "средний ΔIoU ≥−0,2 п.п. Бюджеты 18/27 имеют равный вес. "
             "При расширении публикуются все три и новые два seed отдельно. "
             "Прежние критерии предыдущих этапов сохраняются без пересмотра.", ""]
    if result_views:
        text += ["| Набор seed | Low-lr CNN F1, % | High-lr CNN F1, % | Plain F1, % | Joint F1, % | Late joint F1, % | A plain / joint / late | B | C |",
                 "|---|---:|---:|---:|---:|---:|---|---|---|"]
        for label, result in result_views:
            gates = result["gates"]
            text.append(f"| {label}: {result['seeds']} | {percent(mean(result['low_lr_controls']))} | "
                        f"{percent(mean(result['high_lr_controls']))} | {percent(mean(result['rows'], 'plain'))} | "
                        f"{percent(mean(result['rows'], 'joint'))} | {percent(mean(result['rows'], 'late_joint'))} | "
                        f"{' / '.join(passed(gates['A_architecture'][arm]['passed']) for arm in ARMS)} | "
                        f"{passed(gates['B_physics']['passed'])} | {passed(gates['C_skip_route']['passed'])} |")
        text.append("")
    else:
        text += ["Завершённого результата пока нет; вывод о прохождении A/B/C не сделан.", ""]
    if output_figure:
        text += ["![Средние VAL и раздельные сравнения](figures/early_skip_validation.png)", "",
                 "Точечные средние без интервалов независимого подтверждения. "
                 "При наличии расширения средние всех трёх и новых двух seed перекрываются по данным.", ""]
    text += ["## Все сохранённые попытки этого этапа", ""]
    for trial in trials:
        path = trial["path"]
        text += [f"### {path.name}", "", f"[FROZEN.json]({rel(path / 'FROZEN.json', ROOT)}).", ""]
        if not trial["result"]:
            if trial["failure"]:
                item = trial["failure"]
                text += [f"Техническая ошибка `{item.get('error_type', 'см. файл')}`: "
                         f"{str(item.get('error', '')).replace(chr(10), ' ')}. "
                         f"[FAILURE.json]({rel(path / 'FAILURE.json', ROOT)}). "
                         "Это технический исход, а не отрицательный научный результат.", ""]
            else:
                text += ["Попытка начата; итоговый RESULT.json ещё не сохранён.", ""]
            text += [f"Завершённых сохранённых обучений: {len(trial['partial'])}.", ""]
            continue
        result = trial["result"]
        text += [f"`{result['status']}`; {result['phase']}; seed {result['seeds']}; "
                 f"{result['updates']:,} обновлений; {result['seconds']:.2f} с. "
                 f"[RESULT.json]({rel(path / 'RESULT.json', ROOT)}), SHA-256 `{sha(path / 'RESULT.json')}`.", "",
                 "| Бюджет | Seed | Вариант / путь | Порог VAL | Macro-F1, % | IoU, % | Шагов CNN / уточнителя | Zero ΔF1, п.п. | Roll ΔF1, п.п. |",
                 "|---:|---:|---|---:|---:|---:|---|---:|---:|"]
        for row in result["rows"]:
            selected = row["selected"];ablations = row["ablations"]
            text.append(f"| {row['budget']} | {row['seed']} | {row['arm']} / {row['skip_route']} | "
                        f"{selected['threshold']:.2f} | {percent(selected['mask_F1'])} | {percent(selected['IoU'])} | "
                        f"{row['CNN_updates']} / {row['refiner_updates']} | "
                        f"{pp(ablations['zero']['mask_F1'] - selected['mask_F1'])} | "
                        f"{pp(ablations['roll']['mask_F1'] - selected['mask_F1'])} |")
        text.append("")
        gate_results = [("только эта попытка", result)]
        if trial["aggregate"]:
            gate_results.append(("все три seed", trial["aggregate"]))
            text += [f"[AGGREGATE_RESULT.json]({rel(path / 'AGGREGATE_RESULT.json', ROOT)}) "
                     "объединяет прежний скрининг и новые seed; обучений не добавляет.", ""]
        for label, item in gate_results:
            text += [f"**{label}: {item['seeds']}**", "",
                     "| Сравнение | ΔF1, п.п. | ΔIoU, п.п. | ΔF1 по бюджетам 18 / 27, п.п. | Критерий |",
                     "|---|---:|---:|---|---|"]
            comparisons = []
            for arm in ARMS:
                comparisons += [(f"A {arm} − CNN lr={lr}", item["gates"]["A_architecture"][arm][key])
                                for key, lr in [("vs_low_lr", "0,0001"), ("vs_high_lr", "0,0005")]]
            comparisons += [("B early joint − early plain, с требованием A joint", item["gates"]["B_physics"]),
                            ("C early joint − late joint", item["gates"]["C_skip_route"])]
            for name, gate in comparisons:
                text.append(f"| {name} | {pp(gate['delta'])} | {pp(gate['IoU_delta'])} | "
                            f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
            text.append("")
        if trial["aggregate"]:
            aggregate = trial["aggregate"]
            robust = {arm: aggregate["gates"]["A_architecture"][arm]["passed"] and
                      result["gates"]["A_architecture"][arm]["passed"] for arm in ARMS}
            text += ["Одновременно на всех трёх и новых двух seed: " +
                     "; ".join(f"A {arm} {passed(robust[arm])}" for arm in ARMS) + "; " +
                     "; ".join(f"{name} {passed(aggregate['gates'][key]['passed'] and result['gates'][key]['passed'])}"
                               for name, key in [("B", "B_physics"), ("C", "C_skip_route")]) + ".", ""]
        audit = trial["audit"]
        text += [(f"Независимый CPU-аудит: `{audit.get('status', 'см. файл')}`; "
                  f"[AUDIT.json]({rel(path / 'AUDIT.json', ROOT)})." if audit else
                  "Итоговый независимый аудит этой попытки ещё не сохранён."), ""]
    text += ["## Предыдущие попытки адаптивного поиска", "",
             "Все предыдущие отрицательные варианты остаются частью поиска. "
             "У этапов 1/2 A сравнивал с замороженной CNN; у этапа 3 — с двумя дообученными CNN. "
             "Эти критерии не смешиваются.", "",
             "| Этап / попытка | Seed | Сохранённых обучений | Plain F1, % | Joint F1, % | Прежний A plain / joint / B |",
             "|---|---|---:|---:|---:|---|"]
    for stage in previous:
        for trial in stage["trials"]:
            result, path = trial["result"], trial["path"]
            label = f"{stage['path'].name} / {path.name}"
            if result:
                gates = result["gates"]
                text.append(f"| [{label}]({rel(path / 'RESULT.json', ROOT)}) | {result['seeds']} | "
                            f"{len(result['rows'])} | {percent(mean(result['rows'], 'plain'))} | "
                            f"{percent(mean(result['rows'], 'joint'))} | "
                            f"{passed(gates['A_architecture']['plain']['passed'])} / "
                            f"{passed(gates['A_architecture']['joint']['passed'])} / {passed(gates['B_physics']['passed'])} |")
            else:
                text.append(f"| {label}: {'техническая ошибка' if trial['failure'] else 'незавершена'} | "
                            f"{trial['frozen'].get('seeds', 'см. файл')} | {len(trial['partial'])} | — | — | — |")
    text += ["", "## Границы вывода", "",
             "Те же TRAIN/VAL: пул 54 плотных масок, 1152 слабых примера, 695 VAL, бюджеты 18/27, розыгрыш 5303. "
             "Слабые маски оптимизатору не передаются. Девять классов рассчитаны условной решёткой. "
             "Порог каждой модели выбирается на VAL из [0,30; 0,40; 0,45; 0,50; 0,55; 0,60; 0,70] "
             "по F1, затем IoU, близости к 0,5 и меньшему порогу. Zero/roll используют фиксированный actual-порог.", "",
             "При B FAIL добавочная польза физических карт по заданному критерию не установлена. "
             "При C FAIL выигрыш нельзя приписывать раннему пропуску. Чувствительность к картам не доказывает их пользу. "
             "Для независимого подтверждения нужны заранее зафиксированные модель/критерии и закрытые новые данные, "
             "не использованные в EDA, разработке или прежних тестах. Такой проверки здесь нет. "
             "Перенос на другие изделия и новизна рассматриваются отдельно.", "",
             "[PROTOCOL.md](PROTOCOL.md) · [CONFIG.json](CONFIG.json) · [LEDGER.json](LEDGER.json) · "
             "[model.py](model.py) · [runner.py](runner.py) · [audit.py](audit.py).", ""]
    (ROOT / "REPORT.md").write_text("\n".join(text))
    (ROOT / "README.md").write_text(
        "# Ранний пропуск в CNN-FiLM\n\n"
        "Четвёртый этап модели с прежним лоссом: plain/joint используют ранний F1, "
        "late_joint — поздний F3 при тех же 8 993 параметрах уточнителя. "
        "A проверяется против двух общих дообученных CNN, B — физические карты, C — ранний путь.\n\n"
        f"Завершено попыток {len(complete)}, технических ошибок {len(failures)}, локальных обучений {len(local_rows)}. "
        f"Уникальных обучений по четырём этапам {unique_fits}; общие контроли повторно не считаются.\n\n"
        "[Отчёт со всеми попытками](REPORT.md) · [Протокол](PROTOCOL.md) · [Конфигурация](CONFIG.json) · [Журнал](LEDGER.json).\n\n"
        "Только повторно используемые TRAIN/VAL. Нового TEST нет; независимое подтверждение требует закрытых новых данных.\n\n"
        "Пересоздать только отчёт и рисунок:\n\n"
        "```bash\n.venv/bin/python -B gipoteza/sem_arch_early_skip_20261102/report.py\n```\n")
    inputs = [HELPER, high_path, high_path.with_name("FROZEN.json"), high_path.with_name("CONFIG_SNAPSHOT.json")]
    for path in low_paths:
        inputs += [path, path.with_name("CONFIG_SNAPSHOT.json")]
    for stage in previous + [{"path": ROOT, "trials": trials}]:
        inputs += [stage["path"] / name for name in ["PROTOCOL.md", "CONFIG.json", "QUEUE.json", "LEDGER.json", "STAGE_LINK.json"]
                   if (stage["path"] / name).exists()]
        for trial in stage["trials"]:
            inputs += [trial["path"] / name for name in ["FROZEN.json", "RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json",
                       "PARTIAL_RESULTS.json", "AUDIT.json", "HIGH_LR_CONTROL_SNAPSHOT.json", "LOW_LR_CONTROL_SNAPSHOT.json"]
                       if (trial["path"] / name).exists()]
    outputs = [ROOT / "REPORT.md", ROOT / "README.md"] + ([output_figure] if output_figure else [])
    manifest = dict(status="REPORT_GENERATED", scope="ADAPTIVE_REUSED_TRAIN_VAL_ONLY",
        UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), report_script_sha256=sha(Path(__file__)),
        shared_report_helper_sha256=sha(HELPER), trial_count=len(trials), completed_trials=len(complete),
        failed_trials=len(failures), pending_trials=len(pending), actual_completed_fits=len(local_rows),
        local_control_fits=0, prior_unique_completed_fits=prior_unique,
        extra_low_lr_control_fits_outside_prior_trials=len(extra_low),
        referenced_high_lr_control_fits=len(high["rows"]), referenced_low_lr_control_fits=len(low),
        linked_stage_total_attempts=len(prior_trials) + len(trials), linked_stage_unique_completed_fits=unique_fits,
        controls_counted_as_local=False, matching_unit=["budget", "seed"],
        matched_fields=["backbone_before_sha256", "batch_sequence_sha256", "steps"],
        control_sources=dict(high=dict(file=rel(high_path, ROOT), sha256=sha(high_path)),
            low=[dict(file=rel(path, ROOT), sha256=sha(path)) for path in low_paths]),
        scientific_inputs_sha256={rel(path, ROOT): sha(path) for path in inputs},
        outputs_sha256={rel(path, ROOT): sha(path) for path in outputs})
    (ROOT / "REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
