"""Append-only early-skip FiLM checks on historical TRAIN/VAL only.

Each screen fits early plain/joint and matched-capacity late-joint FiLM models
for both budgets. Both continued-CNN controls are reused immutable artifacts.
No TEST/EVAL archive, prediction, or historical test metric is opened.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import time
import traceback

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "0"
import numpy as np
import torch
from torch.nn import functional as F
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits
from model import make_model, make_backbone, state_digest, architecture_spec

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
REPO = ROOT.parents[1]
PILOT = G / "sem_architecture_pilot_20261102"
ARMS = ["plain", "joint", "late_joint"]
VARIANTS = ["actual", "zero", "roll"]
CACHE_KEYS = ["visual", "coarse", "maps", "maps_raw"]
CLASS_CACHE = {}
START = None


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".{os.getpid()}.partial")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    tmp.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


physics = module("early_skip_unchanged_physics", PILOT / "physics_adapter.py")
preparation = module("early_skip_unchanged_class_rule", PILOT / "prepare.py")


def resolve_repo(path):
    path = Path(path)
    return path if path.is_absolute() else REPO / path


def configuration(path):
    c = json.loads(path.read_text())
    assert c["candidate"] == "film_early_skip" and c["arms"] == ARMS
    assert c["budgets"] == [18, 27] and c["subset_seed"] == 5303
    assert c["screen_seeds"] == [5501] and c["replication_seeds"] == [5501, 5521, 5557]
    assert c["steps"] == 500 and c["warmup_steps"] == 100 and c["batch_size"] == 8
    assert c["backbone_learning_rate"] == .0001 and c["refiner_learning_rate"] == .0005
    assert c["weight_decay"] == .0001 and c["physics_weight"] == 1.
    assert c["epsilon"] == .001 and c["eta"] == 4.
    assert c["normalization_scale"] == 100. and c["normalization_variance_floor"] == 1e-6
    assert c["thresholds"] == [.30, .40, .45, .50, .55, .60, .70]
    assert c["gates"] == dict(minimum_mean_F1_gain=.005,
        minimum_budget_F1_delta=-.0025, minimum_mean_IoU_delta=-.002)
    assert c["protocol_sha256"] == sha(ROOT / "PROTOCOL.md")
    assert c["prior_stage_links"] == ["../sem_arch_iterative_20261102",
        "../sem_arch_amplitude4_20261102", "../sem_arch_joint_adaptation_20261102"]
    assert resolve_repo(c["high_lr_control_result"]).resolve() == (
        G / "sem_arch_iterative_20261102/baseline_control/RESULT.json").resolve()
    assert resolve_repo(c["low_lr_control_result"]).is_file()
    assert isinstance(c.get("low_lr_additional_control_results", []), list)
    return c


def source_hashes():
    names = ["runner.py", "model.py", "../sem_arch_joint_adaptation_20261102/model.py",
        "../sem_architecture_pilot_20261102/model.py",
        "../sem_architecture_pilot_20261102/circuit.py",
        "../sem_architecture_pilot_20261102/physics_adapter.py",
        "../sem_architecture_pilot_20261102/prepare.py",
        "../sem_physics_materials/physics_loss_example.py",
        "../sem_confirmation_20261028/prepare.py",
        "../retained_evidence_20261027/SELECTED_SOURCES.zip"]
    return {name: sha(ROOT / name) for name in names}


def append_ledger(event):
    with (ROOT / ".ledger.lock").open("a") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        path = ROOT / "LEDGER.json"
        ledger = json.loads(path.read_text()) if path.exists() else dict(
            version=1, scope="ADAPTIVE_REUSED_VAL_ONLY", events=[])
        event = dict(event, UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     index=len(ledger["events"]))
        ledger["events"].append(event)
        save(path, ledger)
        fcntl.flock(handle, fcntl.LOCK_UN)


def inputs(c, seeds, device):
    lineage = json.loads((PILOT / "INITIAL_LINEAGE.json").read_text())
    subsets = json.loads((PILOT / "SUBSETS.json").read_text())
    with np.load(PILOT / "TRAIN_VAL.npz", allow_pickle=False) as z:
        assert set(z["role"]) == {"dense", "weak", "val"}
        arrays = {k: z[k].copy() for k in z.files}
    assert sha(PILOT / "TRAIN_VAL.npz") == lineage["TRAIN_VAL_sha256"] == subsets["train_val_sha256"]
    data, states, sources = {}, {}, {}
    for budget in c["budgets"]:
        data[budget] = {}
        for role in ["dense", "weak", "val"]:
            ids = (np.array(subsets["dense_indices"][str(budget)]) if role == "dense"
                   else np.flatnonzero(arrays["role"] == role))
            values = dict(x=torch.tensor(5 * (arrays["X"][ids] - .2), device=device),
                label=torch.tensor(arrays["label"][ids], device=device), indices=ids.tolist())
            if role != "weak":
                values["mask"] = torch.tensor(arrays["Y"][ids].astype(np.float32), device=device)
            data[budget][role] = values
        assert len(data[budget]["dense"]["x"]) == budget
        assert len(data[budget]["weak"]["x"]) == 1152 and len(data[budget]["val"]["x"]) == 695
        assert np.array_equal(np.bincount(data[budget]["dense"]["label"].cpu().numpy(),
            minlength=9), np.full(9, budget // 9))
        for seed in seeds:
            row = lineage["initials"][f"{budget}:{seed}"]
            path = PILOT / row["file"]
            assert sha(path) == row["sha256"]
            state = torch.load(path, map_location="cpu", weights_only=True)["segmenter"]
            assert state_digest(state) == row["backbone_state_sha256"]
            states[budget, seed] = state
            sources[f"{budget}:{seed}"] = dict(file=str(path.relative_to(G)),
                sha256=sha(path), backbone_sha256=state_digest(state))
    return data, states, dict(TRAIN_VAL_sha256=sha(PILOT / "TRAIN_VAL.npz"), sources=sources,
        initial_lineage_sha256=sha(PILOT / "INITIAL_LINEAGE.json"),
        subsets_sha256=sha(PILOT / "SUBSETS.json"))


def high_lr_control(c, seeds, lineage):
    path = resolve_repo(c["high_lr_control_result"])
    result = json.loads(path.read_text())
    snapshot = path.parent / "CONFIG_SNAPSHOT.json"
    settings = json.loads(snapshot.read_text())
    assert result["status"] == "COMPLETE_CONTINUED_BASELINE_VAL_ONLY"
    assert settings["steps"] == c["steps"] and settings["learning_rate"] == .0005
    for key in ["batch_size", "weight_decay", "physics_weight", "thresholds", "subset_seed", "budgets"]:
        assert settings[key] == c[key], key
    rows = [row for row in result["rows"] if row["seed"] in seeds]
    assert len(rows) == len(seeds) * len(c["budgets"])
    assert len({(r["budget"], r["seed"]) for r in rows}) == len(rows)
    for row in rows:
        source = lineage["sources"][f'{row["budget"]}:{row["seed"]}']
        assert row["steps"] == c["steps"]
        assert row["backbone_before_sha256"] == source["backbone_sha256"]
        assert row["source_initial"]["sha256"] == source["sha256"]
    return rows, dict(file=str(path.relative_to(REPO)), result_sha256=sha(path),
        config_snapshot_sha256=sha(snapshot), learning_rate=.0005)


def low_lr_control(c, seeds, lineage):
    rows, sources = [], []
    paths = [c["low_lr_control_result"]] + c.get("low_lr_additional_control_results", [])
    assert len(paths) == len(set(paths)), "Duplicate low-lr control source"
    for name in paths:
        path = resolve_repo(name)
        result = json.loads(path.read_text())
        assert result["status"] in ["COMPLETE_DEVELOPMENT_TRIAL", "COMPLETE_REUSED_VAL_REPLICATION"]
        snapshot = path.parent / "CONFIG_SNAPSHOT.json"
        settings = json.loads(snapshot.read_text())
        assert settings["steps"] == 500 and settings["backbone_learning_rate"] == .0001
        for key in ["batch_size", "weight_decay", "physics_weight", "thresholds", "subset_seed", "budgets"]:
            assert settings[key] == c[key], key
        selected = [row for row in result["rows"] if row["arm"] == "continued_base_low_lr" and row["seed"] in seeds]
        rows.extend(selected)
        sources.append(dict(file=str(path.relative_to(REPO)), result_sha256=sha(path),
            config_snapshot_sha256=sha(snapshot), learning_rate=.0001,
            selected_pairs=[[row["budget"], row["seed"]] for row in selected]))
    assert len(rows) == len(seeds) * len(c["budgets"]), "Missing low-lr CNN controls; fit/provide them before replication"
    assert len({(row["budget"], row["seed"]) for row in rows}) == len(rows), "Duplicate low-lr CNN controls"
    for row in rows:
        source = lineage["sources"][f'{row["budget"]}:{row["seed"]}']
        assert row["steps"] == 500 and row["CNN_updates"] == 500
        assert row["backbone_learning_rate"] == .0001
        assert row["backbone_before_sha256"] == source["backbone_sha256"]
        assert row["source_initial"]["sha256"] == source["sha256"]
    return rows, dict(sources=sources, learning_rate=.0001)


def make(c, arm, state, seed, device):
    net = make_model(arm, state, decoder_seed=seed + 100003, epsilon=c["epsilon"],
        eta=c["eta"], scale=c["normalization_scale"],
        norm_floor=c["normalization_variance_floor"])
    return net.to(device)


def hard_classes(masks):
    masks = np.asarray(masks, dtype=bool).reshape(-1, 12, 12)
    keys = [r.tobytes() for r in np.packbits(masks.reshape(len(masks), 144), axis=1)]
    missing = sorted(set(keys) - CLASS_CACHE.keys())
    if missing:
        values = np.array([np.unpackbits(np.frombuffer(k, dtype=np.uint8)).reshape(12, 12)
                           for k in missing], dtype=bool)
        CLASS_CACHE.update(zip(missing, preparation.class_labels(values).tolist()))
    return np.array([CLASS_CACHE[k] for k in keys], dtype=np.int64)


def rank(row):
    return row["mask_F1"], row["IoU"], -abs(row["threshold"] - .5), -row["threshold"]


def score_probabilities(probability, truth, target, thresholds):
    rows, predictions, packed = [], [], []
    for threshold in thresholds:
        mask = probability >= threshold
        prediction = hard_classes(mask)
        union = (mask | target).sum((1, 2))
        iou = np.divide((mask & target).sum((1, 2)), union,
                        out=np.ones(len(mask)), where=union > 0)
        rows.append(dict(threshold=threshold, mask_F1=float(f1_score(truth, prediction,
            labels=range(9), average="macro", zero_division=0)), IoU=float(iou.mean())))
        predictions.append(prediction)
        packed.append(np.packbits(mask.reshape(len(mask), 144), axis=1))
    return rows, np.array(predictions), np.array(packed)


def evaluate(c, model, values, arm):
    model.eval()
    variants = ["actual"] if arm == "continued_base_low_lr" else VARIANTS
    outputs = [[] for _ in variants]
    with torch.no_grad():
        for x in values["x"].split(16):
            if arm == "continued_base_low_lr":
                outputs[0].append(model(x).cpu().numpy())
            else:
                cache = model.precompute(x)
                for i, variant in enumerate(variants):
                    outputs[i].append(model.forward_cached(cache, variant)["logits"].cpu().numpy())
    logits = np.array([np.concatenate(parts) for parts in outputs])
    probability = 1 / (1 + np.exp(-np.clip(logits[:, :, 0], -80, 80)))
    truth = values["label"].cpu().numpy()
    target = values["mask"][:, 0].cpu().numpy().astype(bool)
    scores, predictions, packed = [], [], []
    for p in probability:
        rows, pred, bits = score_probabilities(p, truth, target, c["thresholds"])
        scores.append(rows)
        predictions.append(pred)
        packed.append(bits)
    selected = max(scores[0], key=rank)
    ti = c["thresholds"].index(selected["threshold"])
    actual = probability[0] >= selected["threshold"]
    ablations = {name: dict(**scores[i][ti],
        mask_flip_fraction=float(np.mean((probability[i] >= selected["threshold"]) != actual)),
        logit_mean_absolute_difference=float(np.abs(logits[i] - logits[0]).mean()),
        logit_max_absolute_difference=float(np.abs(logits[i] - logits[0]).max()))
        for i, name in enumerate(variants)}
    return dict(selected=selected, ablations=ablations,
        VAL_scores_all_thresholds=dict(zip(variants, scores))), dict(logits=logits,
        probability=probability, truth=truth, target=target, thresholds=np.array(c["thresholds"]),
        variants=np.array(variants), predictions=np.array(predictions), packed_masks=np.array(packed),
        selected_threshold=np.array(selected["threshold"]))


def fit(c, model, values, budget, seed, arm, trial, counter, device="mps"):
    refined = arm != "continued_base_low_lr"
    backbone = model.backbone if refined else model
    before = state_digest(backbone.state_dict())
    decoder_initial = state_digest(model.refiner.state_dict()) if refined else None
    if refined:
        optimizer = torch.optim.AdamW([
            dict(params=model.backbone.parameters(), lr=c["backbone_learning_rate"]),
            dict(params=model.refiner.parameters(), lr=c["refiner_learning_rate"])],
            weight_decay=c["weight_decay"])
    else:
        optimizer = torch.optim.AdamW(model.parameters(), lr=c["backbone_learning_rate"],
                                     weight_decay=c["weight_decay"])
    rng = np.random.default_rng(seed + 1000)
    batches = hashlib.sha256()
    model.train()
    start = time.monotonic()
    warmup_digest = None
    warmup_decoder_digest = None
    warmup_states = None
    for step in range(1, c["steps"] + 1):
        if refined and step == c["warmup_steps"] + 1:
            warmup_digest = state_digest(backbone.state_dict())
            assert warmup_digest == before, "CNN changed during head-only warmup"
            model.set_backbone_trainable(True)
        ai = rng.integers(0, len(values["dense"]["x"]), c["batch_size"])
        wi = rng.integers(0, len(values["weak"]["x"]), c["batch_size"])
        batches.update(ai.astype(np.int64).tobytes())
        batches.update(wi.astype(np.int64).tobytes())
        ai, wi = torch.tensor(ai, device=device), torch.tensor(wi, device=device)
        optimizer.zero_grad(set_to_none=True)
        # One current-prediction pass over dense8+weak8; maps are never cached
        # across updates. Separate loss reductions preserve the old objective.
        logits = model(torch.cat((values["dense"]["x"][ai], values["weak"]["x"][wi])))
        dense, weak = logits.split(c["batch_size"])
        loss = F.binary_cross_entropy_with_logits(dense, values["dense"]["mask"][ai])
        y = values["weak"]["label"][wi]
        direction = torch.stack((y // 3, y % 3), dim=1)
        loss = loss + c["physics_weight"] * physics.geometry_loss(weak, direction)
        assert torch.isfinite(loss)
        loss.backward()
        if refined and step <= c["warmup_steps"]:
            assert all(p.grad is None for p in backbone.parameters())
        else:
            assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in backbone.parameters())
            assert any(float(p.grad.abs().sum()) > 0 for p in backbone.parameters())
        params = [p for p in model.parameters() if p.requires_grad]
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params)
        assert any(p.grad is not None and float(p.grad.abs().sum()) > 0 for p in params)
        optimizer.step()
        counter[0] += 1
        if refined and step == c["warmup_steps"]:
            warmup_states = dict(
                warmup_backbone={k: v.detach().cpu().clone() for k, v in backbone.state_dict().items()},
                warmup_refiner={k: v.detach().cpu().clone() for k, v in model.refiner.state_dict().items()})
            warmup_digest = state_digest(warmup_states["warmup_backbone"])
            warmup_decoder_digest = state_digest(warmup_states["warmup_refiner"])
            assert warmup_digest == before
        if step % 100 == 0 or step == c["steps"]:
            row = dict(stage="EARLY_SKIP_TRAIN_VAL", trial=trial.name,
                budget=budget, seed=seed, arm=arm, step=step, target_steps=c["steps"],
                CNN_trainable=not refined or step > c["warmup_steps"],
                completed_updates=counter[0], seconds=time.monotonic() - START)
            save(trial / "PROGRESS.json", row)
            save(ROOT / "PROGRESS.json", row)
            with (trial / "progress.jsonl").open("a") as handle:
                handle.write(json.dumps(row) + "\n")
            print(json.dumps(row), flush=True)
    if device == "mps":
        torch.mps.synchronize()
    after = state_digest(backbone.state_dict())
    assert before != after
    decoder_final = state_digest(model.refiner.state_dict()) if refined else None
    if refined:
        assert decoder_initial != decoder_final and warmup_digest == before
    return dict(seconds=time.monotonic() - start, steps=c["steps"],
        warmup_steps=c["warmup_steps"] if refined else 0,
        joint_steps=c["steps"] - c["warmup_steps"] if refined else 0,
        CNN_updates=c["steps"] - c["warmup_steps"] if refined else c["steps"],
        refiner_updates=c["steps"] if refined else 0,
        backbone_learning_rate=c["backbone_learning_rate"],
        refiner_learning_rate=c["refiner_learning_rate"] if refined else None,
        backbone_before_sha256=before, backbone_after_sha256=after,
        backbone_after_warmup_sha256=warmup_digest,
        decoder_initial_sha256=decoder_initial, decoder_final_sha256=decoder_final,
        decoder_after_warmup_sha256=warmup_decoder_digest,
        optimizer_groups=([dict(parameters="backbone", learning_rate=c["backbone_learning_rate"],
            update_steps=[c["warmup_steps"] + 1, c["steps"]]),
            dict(parameters="refiner", learning_rate=c["refiner_learning_rate"], update_steps=[1, c["steps"]])]
            if refined else [dict(parameters="backbone", learning_rate=c["backbone_learning_rate"],
                update_steps=[1, c["steps"]])]),
        batch_sequence_sha256=batches.hexdigest(),
        trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
        total_parameters=sum(p.numel() for p in model.parameters())), warmup_states


def gates(rows, high_rows, low_rows, c):
    budgets = c["budgets"]
    means = {b: {arm: {key: float(np.mean([row["selected"][key] for row in rows
        if row["budget"] == b and row["arm"] == arm])) for key in ["mask_F1", "IoU"]}
        for arm in ARMS} for b in budgets}
    high = {b: {key: float(np.mean([row["selected"][key] for row in high_rows
        if row["budget"] == b])) for key in ["mask_F1", "IoU"]} for b in budgets}
    low = {b: {key: float(np.mean([row["selected"][key] for row in low_rows
        if row["budget"] == b])) for key in ["mask_F1", "IoU"]} for b in budgets}
    limits = c["gates"]

    def compare(left, right):
        deltas = [left[b]["mask_F1"] - right[b]["mask_F1"] for b in budgets]
        gain = float(np.mean(deltas))
        iou = float(np.mean([left[b]["IoU"] - right[b]["IoU"] for b in budgets]))
        checks = dict(mean_F1_gain=bool(gain >= limits["minimum_mean_F1_gain"]),
            budget_F1_guard=bool(min(deltas) >= limits["minimum_budget_F1_delta"]),
            mean_IoU_guard=bool(iou >= limits["minimum_mean_IoU_delta"]))
        return dict(delta=gain, IoU_delta=iou, budget_deltas=deltas,
                    checks=checks, passed=all(checks.values()))

    architecture = {}
    for arm in ARMS:
        left = {b: means[b][arm] for b in budgets}
        low_comparison = compare(left, low)
        high_comparison = compare(left, high)
        architecture[arm] = dict(vs_low_lr=low_comparison, vs_high_lr=high_comparison,
            passed=bool(low_comparison["passed"] and high_comparison["passed"]))
    physical = compare({b: means[b]["joint"] for b in budgets},
                       {b: means[b]["plain"] for b in budgets})
    physical["joint_architecture_gate"] = architecture["joint"]["passed"]
    physical["passed"] = bool(physical["passed"] and physical["joint_architecture_gate"])
    skip = compare({b: means[b]["joint"] for b in budgets},
                   {b: means[b]["late_joint"] for b in budgets})
    return dict(A_architecture=architecture, A_any=any(row["passed"] for row in architecture.values()),
        B_physics=physical, C_skip_route=skip,
        interpretation="Reused-VAL development; C describes skip route and is not required for A"), dict(
        by_budget=means, high_lr_control_by_budget=high, low_lr_control_by_budget=low)


def training_signature(c):
    return digest(dict(configuration={k: v for k, v in c.items()
        if k not in ["protocol_sha256", "low_lr_additional_control_results"]},
        source_sha256=source_hashes(), protocol_sha256=c["protocol_sha256"],
        high_lr_control_sha256=sha(resolve_repo(c["high_lr_control_result"])),
        low_lr_control_sha256=sha(resolve_repo(c["low_lr_control_result"])),
        TRAIN_VAL_sha256=sha(PILOT / "TRAIN_VAL.npz")))


def previous_screen(signature):
    found = []
    for path in (ROOT / "trials").glob("*/RESULT.json"):
        row = json.loads(path.read_text())
        if row["phase"] == "screen" and row["signature"] == signature and row["status"] == "COMPLETE_DEVELOPMENT_TRIAL":
            found.append((path, row))
    assert len(found) == 1, "Require exactly one matching screen; seed5501 retained once"
    assert found[0][1]["gates"]["A_any"], "Replication requires a passing screen architecture gate"
    return found[0]


def preflight(c):
    data, states, lineage = inputs(c, [5501], "cpu")
    high, control = high_lr_control(c, [5501], lineage)
    low, low_control = low_lr_control(c, [5501], lineage)
    prior = module("early_skip_prior_film", G / "sem_arch_joint_adaptation_20261102/model.py")
    hashes, counts = [], []
    x = data[18]["dense"]["x"][:2]
    for arm in ARMS:
        net = make(c, arm, states[18, 5501], 5501, "cpu")
        previous = prior.make_model("joint" if arm == "late_joint" else arm,
            states[18, 5501], decoder_seed=5501 + 100003, epsilon=c["epsilon"], eta=c["eta"],
            scale=c["normalization_scale"], norm_floor=c["normalization_variance_floor"])
        previous_state, current_state = previous.refiner.state_dict(), net.refiner.state_dict()
        for key in previous_state:
            observed = current_state[key][:, :26] if key == "visual.0.weight" else current_state[key]
            assert torch.equal(previous_state[key], observed), key
        assert torch.count_nonzero(current_state["visual.0.weight"][:, 26:]) == 0
        before = state_digest(net.backbone.state_dict())
        result = net.forward_details(x)
        assert torch.equal(result["logits"], result["coarse"])
        assert not result["maps_normalized"].requires_grad
        hashes.append(state_digest(net.refiner.state_dict()))
        counts.append(net.parameter_counts())
        result["logits"].sum().backward()
        assert all(p.grad is None for p in net.backbone.parameters())
        assert any(p.grad is not None and float(p.grad.abs().sum()) > 0 for p in net.refiner.parameters())
        net.zero_grad(set_to_none=True)
        net.set_backbone_trainable(True)
        live = net.forward_details(x)
        live["logits"].sum().backward()
        assert live["coarse"].requires_grad and not live["maps_normalized"].requires_grad
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in net.backbone.parameters())
        assert any(float(p.grad.abs().sum()) > 0 for p in net.backbone.parameters())
        assert state_digest(net.backbone.state_dict()) == before
        live_inputs = net.current_inputs(x)
        assert live_inputs["visual"].shape[1] == 50
        route = "late_features" if arm == "late_joint" else "early_features"
        assert torch.equal(live_inputs["skip_features"], live_inputs[route])
        assert torch.equal(live_inputs["visual"][:, 26:], live_inputs[route])
        assert live_inputs["visual"].requires_grad and live_inputs["coarse"].requires_grad
        assert not live_inputs["maps"].requires_grad and not live_inputs["maps_raw"].requires_grad
        net.eval()
        with torch.no_grad():
            cache = net.precompute(x)
            for variant in VARIANTS:
                a = net.forward_details(x, variant)["logits"]
                b = net.forward_cached(cache, variant)["logits"]
                assert torch.equal(a, b)
    assert len(set(hashes)) == 1 and counts[0] == counts[1] == counts[2]
    result = dict(status="PASS_PREFLIGHT", identity=True, matched_initialization=True,
        warmup_CNN_gradient_absent=True, live_CNN_gradient_present=True, maps_detached=True,
        visual_path_live=True, coarse_path_live=True, raw_maps_detached=True,
        evaluation_cache_parity=True, counts=counts[0], control=control, low_lr_control=low_control,
        prior_FiLM_weights_copied_exactly=True, added24_kernel_channels_zero=True,
        early_and_late_skip_routes_checked=True,
        source_sha256=source_hashes(), lineage=lineage)
    save(ROOT / "PREFLIGHT.json", result)
    print(json.dumps(result), flush=True)


def fixtures(model, values, arm):
    x = values["x"][:16]
    if arm == "continued_base_low_lr":
        with torch.no_grad():
            logits = model(x).cpu().numpy()
        return dict(x=x.cpu().numpy(), full_logits=logits[None], variants=np.array(["actual"])), {}
    with torch.no_grad():
        cache = model.precompute(x)
        full, errors = [], {}
        for variant in VARIANTS:
            a = model.forward_details(x, variant)["logits"]
            b = model.forward_cached(cache, variant)["logits"]
            errors[variant] = float((a - b).abs().max().cpu())
            assert errors[variant] < 1e-5
            full.append(a.cpu().numpy())
    return dict(x=x.cpu().numpy(), full_logits=np.array(full), variants=np.array(VARIANTS),
                **{k: v.cpu().numpy() for k, v in cache.items()}), errors


def run(c, phase, config_path):
    global START
    START = time.monotonic()
    assert torch.backends.mps.is_available() and os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] == "0"
    seeds = c["screen_seeds"] if phase == "screen" else [s for s in c["replication_seeds"] if s not in c["screen_seeds"]]
    signature = training_signature(c)
    inherited = previous_screen(signature) if phase == "replicate" else None
    trial_id = f'film_early_skip_{phase}_s{"-".join(map(str, seeds))}_{digest(source_hashes())[:10]}'
    trial = ROOT / "trials" / trial_id
    assert not trial.exists(), "Immutable trial exists; no overwrite or implicit resume"
    for folder in [trial, trial / "models", trial / "val_probs", trial / "fixtures", trial / "source"]:
        folder.mkdir(parents=True, exist_ok=False)
    save(trial / "CONFIG_SNAPSHOT.json", c)
    shutil.copy2(ROOT / "PROTOCOL.md", trial / "PROTOCOL.md")
    sources = source_hashes()
    for name in ["runner.py", "model.py"]:
        shutil.copy2(ROOT / name, trial / "source" / name)
    data, states, lineage = inputs(c, seeds, "mps")
    high_rows, high_meta = high_lr_control(c, seeds, lineage)
    low_rows, low_meta = low_lr_control(c, seeds, lineage)
    save(trial / "HIGH_LR_CONTROL_SNAPSHOT.json", dict(rows=high_rows, source=high_meta))
    save(trial / "LOW_LR_CONTROL_SNAPSHOT.json", dict(rows=low_rows, source=low_meta))
    frozen = dict(candidate="film_early_skip", phase=phase, seeds=seeds, signature=signature,
        source_sha256=sources, lineage=lineage, high_lr_control=high_meta,
        low_lr_control=low_meta,
        protocol_sha256=sha(ROOT / "PROTOCOL.md"), config_sha256=sha(config_path),
        config_snapshot_sha256=sha(trial / "CONFIG_SNAPSHOT.json"),
        architecture=architecture_spec(), prior_stage_links=c["prior_stage_links"],
        models=len(c["budgets"]) * len(seeds) * len(ARMS),
        total_updates=len(c["budgets"]) * len(seeds) * len(ARMS) * c["steps"],
        scope="Reused TRAIN/VAL development only; no TEST/EVAL or old test metrics")
    save(trial / "FROZEN.json", frozen)
    append_ledger(dict(status="RUNNING", trial=trial_id, phase=phase, signature=signature))
    rows, hashes, counter = [], {}, [0]
    try:
        for budget in c["budgets"]:
            for seed in seeds:
                paired = []
                reference = next(row for row in high_rows if row["budget"] == budget and row["seed"] == seed)
                low_reference = next(row for row in low_rows if row["budget"] == budget and row["seed"] == seed)
                for arm in ARMS:
                    net = make(c, arm, states[budget, seed], seed, "mps")
                    timing, warmup_states = fit(c, net, data[budget], budget, seed, arm, trial, counter)
                    assert timing["batch_sequence_sha256"] == reference["batch_sequence_sha256"]
                    assert timing["batch_sequence_sha256"] == low_reference["batch_sequence_sha256"]
                    evaluation, arrays = evaluate(c, net, data[budget]["val"], arm)
                    fixture, errors = fixtures(net, data[budget]["val"], arm)
                    row = dict(candidate="film_early_skip", budget=budget, seed=seed, arm=arm,
                        skip_route=net.skip_route,
                        source_initial=lineage["sources"][f"{budget}:{seed}"],
                        **timing, **evaluation, cache_full_max_errors=errors)
                    name = f"b{budget}_{arm}_s{seed}"
                    path = trial / "models" / f"{name}.pt"
                    tmp = path.with_suffix(".pt.partial")
                    torch.save(dict(model={k: v.detach().cpu() for k, v in net.state_dict().items()},
                                    settings=row, **(warmup_states or {})), tmp)
                    tmp.replace(path)
                    hashes[path.name] = sha(path)
                    np.savez_compressed(trial / "val_probs" / f"{name}.npz", **arrays)
                    np.savez_compressed(trial / "fixtures" / f"{name}.npz", **fixture)
                    rows.append(row)
                    paired.append(row)
                    save(trial / "PARTIAL_RESULTS.json", rows)
                    save(trial / "CHECKPOINT_HASHES.json", hashes)
                    del net
                assert len({row["batch_sequence_sha256"] for row in paired}) == 1
                refiners = paired
                assert len({row["decoder_initial_sha256"] for row in refiners}) == 1
                assert len({row["trainable_parameters"] for row in refiners}) == 1
        assert all(sha(ROOT / name) == value for name, value in sources.items())
        assert sha(ROOT / "PROTOCOL.md") == frozen["protocol_sha256"]
        assert sha(config_path) == frozen["config_sha256"]
        assert sha(resolve_repo(c["high_lr_control_result"])) == high_meta["result_sha256"]
        assert all(sha(REPO / item["file"]) == item["result_sha256"] for item in low_meta["sources"])
        assert all(sha(G / value["file"]) == value["sha256"] for value in lineage["sources"].values())
        development, means = gates(rows, high_rows, low_rows, c)
        result = dict(status="COMPLETE_DEVELOPMENT_TRIAL", candidate="film_early_skip", phase=phase,
            seeds=seeds, signature=signature, rows=rows, high_lr_controls=high_rows,
            low_lr_controls=low_rows,
            gates=development, means=means, checkpoint_hashes=hashes, updates=counter[0],
            seconds=time.monotonic() - START, frozen_sha256=sha(trial / "FROZEN.json"),
            scope="Adaptive reused VAL development; no independent confirmation or publication claim")
        save(trial / "RESULT.json", result)
        aggregate = None
        if inherited is not None:
            path, old = inherited
            all_rows, all_high, all_low = (old["rows"] + rows,
                old["high_lr_controls"] + high_rows, old["low_lr_controls"] + low_rows)
            assert {row["seed"] for row in all_rows} == set(c["replication_seeds"])
            assert len({(row["budget"], row["seed"], row["arm"]) for row in all_rows}) == len(all_rows)
            ag, am = gates(all_rows, all_high, all_low, c)
            robust_by_arm = {arm: bool(ag["A_architecture"][arm]["passed"] and
                development["A_architecture"][arm]["passed"]) for arm in ARMS}
            aggregate = dict(status="COMPLETE_REUSED_VAL_REPLICATION", candidate="film_early_skip",
                seeds=c["replication_seeds"], source_trials=[str(path.parent.relative_to(ROOT)),
                    str(trial.relative_to(ROOT))], rows=all_rows, high_lr_controls=all_high,
                low_lr_controls=all_low,
                gates=ag, means=am, new_seed_gates=development,
                robust_architecture_by_arm=robust_by_arm,
                robust_architecture_pass=any(robust_by_arm.values()),
                signature=signature, scope="Three seeds on reused VAL; no new TEST")
            save(trial / "AGGREGATE_RESULT.json", aggregate)
        summary = dict(status=result["status"], trial=str(trial.relative_to(ROOT)),
            candidate="film_early_skip", phase=phase, result_sha256=sha(trial / "RESULT.json"),
            gates=aggregate["gates"] if aggregate else development,
            means=aggregate["means"] if aggregate else means)
        append_ledger(summary)
        save(ROOT / "LATEST_RESULT.json", summary)
        print(json.dumps(summary), flush=True)
    except BaseException as error:
        failure = dict(status="FAILED", trial=trial_id, phase=phase, error=str(error),
                       error_type=type(error).__name__, traceback=traceback.format_exc())
        save(trial / "FAILURE.json", failure)
        append_ledger(failure)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["screen", "replicate"], default="screen")
    parser.add_argument("--config", type=Path, default=ROOT / "CONFIG.json")
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    c = configuration(args.config)
    torch.set_num_threads(2)
    if args.preflight:
        preflight(c)
    else:
        run(c, args.phase, args.config)


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
