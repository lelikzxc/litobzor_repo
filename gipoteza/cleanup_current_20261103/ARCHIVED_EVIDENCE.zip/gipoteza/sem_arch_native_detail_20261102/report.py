"""Report saved native-detail development trials; never execute a model."""
from __future__ import annotations

import datetime
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
HELPER = ROOT.parent / "sem_arch_joint_adaptation_20261102" / "report.py"
spec = importlib.util.spec_from_file_location("saved_json_report_helpers", HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
read, sha, rel = helpers.read, helpers.sha, helpers.rel
percent, pp, passed, mean = helpers.percent, helpers.pp, helpers.passed, helpers.mean
discover, actual_rows, views = helpers.discover, helpers.actual_rows, helpers.views
plt, np = helpers.plt, helpers.np
ARMS = ["lowres_plain", "native_plain", "native_joint"]


def percent(value):
    return f"{100 * value:.3f}"


def pp(value):
    return f"{100 * value:+.3f}"


def control_sources(config):
    high_path = (REPO / config["high_lr_control_result"]).resolve()
    high = read(high_path)
    assert high["frozen_sha256"] == sha(high_path.with_name("FROZEN.json"))
    paths = [(REPO / path).resolve() for path in
             [config["low_lr_control_result"]] + config.get("low_lr_additional_control_results", [])]
    assert len(paths) == len(set(paths))
    low = [row for path in paths for row in read(path)["rows"] if row["arm"] == "continued_base_low_lr"]
    assert len(low) == len({(row["budget"], row["seed"]) for row in low}), "Duplicate low-lr control units"
    return high_path, high, paths, low


def verify_control(result, high, low):
    units = {(row["budget"], row["seed"]) for row in result["rows"]}
    for arm in ARMS:
        rows = [row for row in result["rows"] if row["arm"] == arm]
        assert len(rows) == len(units) and {(row["budget"], row["seed"]) for row in rows} == units
    for name, source in [("high_lr_controls", high["rows"]), ("low_lr_controls", low)]:
        selected = [row for row in source if (row["budget"], row["seed"]) in units]
        reference = {(row["budget"], row["seed"]): row for row in selected}
        copied = {(row["budget"], row["seed"]): row for row in result[name]}
        assert len(selected) == len(units) and len(result[name]) == len(units)
        assert set(reference) == units and copied == reference
        for row in result["rows"]:
            control = reference[row["budget"], row["seed"]]
            for field in ["backbone_before_sha256", "batch_sequence_sha256", "steps"]:
                assert row[field] == control[field], field
    return result["high_lr_controls"], result["low_lr_controls"]


def figure(result_views):
    if not result_views:
        return None
    path = ROOT / "figures" / "native_detail_validation.png"
    path.parent.mkdir(exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.2))
    x = np.arange(len(result_views));width = .15
    for offset, arm, key, label, color in [
        (-2, None, "low_lr_controls", "shared CNN lr=0.0001", "#777777"),
        (-1, "lowres_plain", "rows", "upsampled-12 plain", "#3c78a8"),
        (0, "native_plain", "rows", "native-48 plain", "#8d6cab"),
        (1, "native_joint", "rows", "native-48 joint", "#b25a43"),
        (2, None, "high_lr_controls", "shared CNN lr=0.0005", "#90734e")]:
        values = [100 * mean(result[key], arm) for _, result in result_views]
        bars = axes[0].bar(x + offset * width, values, width, label=label, color=color)
        axes[0].bar_label(bars, fmt="%.3f", padding=3, fontsize=7)
    axes[0].set_ylim(0, min(100, max(bar.get_height() for bar in axes[0].patches) + 9))
    axes[0].set_ylabel("Validation Macro-F1, %")
    axes[0].set_title("Selected thresholds; equal budget weights")
    axes[0].legend(fontsize=8, loc="lower left")
    for offset, kind, field, label, color, marker in [
        (-.24, "A_architecture", "vs_low_lr", "A native joint − CNN lr=0.0001", "#b25a43", "o"),
        (-.08, "A_architecture", "vs_high_lr", "A native joint − CNN lr=0.0005", "#90734e", "x"),
        (.08, "B_physics", None, "B native joint − native plain", "#4d8d63", "D"),
        (.24, "C_detail", None, "C native plain − upsampled plain", "#8d6cab", "s")]:
        values = [100 * (result["gates"][kind]["native_joint"][field]["delta"] if field else
                         result["gates"][kind]["delta"]) for _, result in result_views]
        axes[1].scatter(x + offset, values, s=50, color=color, marker=marker, label=label)
    axes[1].axhline(0, color="black", lw=.8)
    axes[1].axhline(.5, color="gray", ls="--", lw=.8, label="Mean-gain gate: +0.5 pp")
    axes[1].set_ylabel("Macro-F1 difference, percentage points")
    axes[1].set_title("Development estimates; no independent TEST")
    axes[1].legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.12), ncol=2)
    for axis in axes:
        axis.set_xticks(x, [name for name, _ in result_views])
        axis.set_xlim(-.6, len(x) - .4)
    fig.suptitle("Native SEM detail versus upsampled low-resolution capacity control", fontsize=11)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def build():
    config = read(ROOT / "CONFIG.json")
    trials = discover(ROOT)
    previous = []
    for link in config["prior_stage_links"]:
        path = (ROOT / link).resolve()
        assert path.parent == ROOT.parent and path != ROOT
        assert path not in [stage["path"] for stage in previous]
        previous.append({"path": path, "trials": discover(path)})
    high_path, high, low_paths, low = control_sources(config)
    native_path = ROOT / "NATIVE_LINEAGE.json"
    native = read(native_path)
    native_audit = read(ROOT / "NATIVE_AUDIT.json")
    native_archive = ROOT / native["archive"]
    assert sha(native_archive) == native["archive_sha256"]
    assert native["exact_4x4_reductions"] == 1901 and native["max_absolute_reconstruction_error"] == 0
    if native_audit:
        assert native_audit["native_archive_sha256"] == sha(native_archive)
        assert native_audit["native_lineage_sha256"] == sha(native_path)
    complete = [trial for trial in trials if trial["result"]]
    failures = [trial for trial in trials if trial["failure"]]
    pending = [trial for trial in trials if not trial["result"] and not trial["failure"]]
    prior_trials = [trial for stage in previous for trial in stage["trials"]]
    prior_rows, local_rows = actual_rows(prior_trials), actual_rows(trials)
    # Reused low-lr CNNs already occur in stage 3. Count genuinely new control
    # rows only if an explicit additional control source was later supplied.
    extra_low = [row for row in low if row not in prior_rows]
    prior_unique = len(prior_rows) + len(high["rows"])
    unique_fits = prior_unique + len(local_rows) + len(extra_low)
    result_views = views(trials)
    for trial in complete:
        assert trial["result"]["frozen_sha256"] == sha(trial["path"] / "FROZEN.json")
        assert trial["frozen"]["high_lr_control"]["result_sha256"] == sha(high_path)
        assert trial["frozen"]["lineage"]["native_lineage_sha256"] == sha(native_path)
        assert trial["frozen"]["lineage"]["native_archive_sha256"] == sha(native_archive)
        assert trial["frozen"]["lineage"]["native_preparation"] == native
        for source in trial["frozen"]["low_lr_control"]["sources"]:
            assert sha(REPO / source["file"]) == source["result_sha256"]
            assert sha((REPO / source["file"]).with_name("CONFIG_SNAPSHOT.json")) == source["config_snapshot_sha256"]
        verify_control(trial["result"], high, low)
        if trial["aggregate"]:
            verify_control(trial["aggregate"], high, low)
    output_figure = figure(result_views)
    text = [
        "# Исходная детализация SEM и отдельная CNN-ветвь", "",
        "Пятый этап последовательной разработки на прежних TRAIN/VAL. "
        "Меняется модель при предсказании; прежние BCE и geometry_loss с весом 1 остаются общими. "
        "Нового независимого TEST нет. Критерии разработки не доказывают новизну или статистическое превосходство.", "",
        "К визуальному входу FiLM `[F3, coarse, SEM]` добавлены 24 канала отдельной CNN-ветви: "
        "Conv(1→8, 3×3, stride 2, pad 1), GELU, Conv(8→24, 3×3, stride 2, pad 1), GELU. "
        "Она переводит 48×48 в 24 канала 12×12; визуальный вход FiLM меняется 26→50 каналов. "
        "Новые входные ядра FiLM нулевые при старте, исходные ядра сохраняют начальные значения. "
        "Во всех трёх вариантах FiLM имеет 8 993 параметра, новая ветвь — 1 832, новый блок — 10 825, "
        "исходная CNN — 10 681, всего 21 506.", "",
        "Lowres_plain подаёт в новую ветвь прежний SEM12×12, растянутый nearest-neighbor до 48×48. "
        "Native_plain использует исходный crop48×48 при обычных картах вероятности/неопределённости. "
        "Native_joint использует тот же crop48×48 с картами совместной пиксельной правки. "
        "Архитектуры, число параметров, инициализация и батчи совпадают; контроль lowres_plain "
        "отделяет исходные детали от новой ёмкости и входного размера. Исходная CNN продолжает получать прежний X12.", "",
        "## Привязка исходных участков", "",
        f"[NATIVE_LINEAGE.json](NATIVE_LINEAGE.json), SHA-256 `{sha(native_path)}`, фиксирует "
        "1 901 участок 48×48 из кадров 0–7 по координатам прежних записей TRAIN/VAL. "
        f"Число точных усреднений 4×4 до прежнего X12: {native['exact_4x4_reductions']}; "
        f"максимальная ошибка {native['max_absolute_reconstruction_error']:g}. "
        f"Архив [NATIVE_TRAIN_VAL.npz](NATIVE_TRAIN_VAL.npz), SHA-256 `{sha(native_archive)}`. "
        "Роли, индексы, классы, маски и поле обзора прежние; это не новые независимые кадры. "
        "Для новой ветви native = `5*(uint8/255−0.2)`, lowres = `nearest_x4(5*(X12−0.2))`.", "",
        "Амплитуда `4*tanh(residual)`, первые 100 шагов только уточнитель, затем 400 шагов совместной адаптации. "
        "AdamW: lr CNN 0,0001, lr уточнителя 0,0005, weight_decay 0,0001; батч 8 плотных + 8 слабых. "
        "Карты и признаки пересчитываются по текущей CNN; карты отделены от градиента. "
        "Начальные параметры и батчи трёх вариантов совпадают.", "",
        "## Объём поиска и общие контроли", "",
        f"Локально начато попыток {len(trials)}; завершено {len(complete)}; технических ошибок {len(failures)}; "
        f"незавершённых {len(pending)}. Сохранено {len(local_rows)} новых обучений уточнителей, "
        f"{sum(row['steps'] for row in local_rows):,} обновлений. CNN-контроли внутри этих попыток не переучиваются.", "",
        f"Четыре предыдущих этапа содержат {len(prior_trials)} попыток и {prior_unique} уникальных обучений "
        "с общим высокоскоростным CNN-контролем. "
        f"Уникальных обучений вместе с текущим этапом: **{unique_fits}**. "
        f"Дополнительных low-lr контролей вне предыдущих попыток: {len(extra_low)}. "
        "Копии low_lr_controls/high_lr_controls и AGGREGATE_RESULT не считаются новыми обучениями.", "",
        f"Общий CNN lr=0,0005: [RESULT.json]({rel(high_path, ROOT)}), SHA-256 `{sha(high_path)}`. "
        "CNN lr=0,0001 берётся из явно указанных сохранённых источников:", "",
    ]
    if native_audit:
        index = text.index("## Объём поиска и общие контроли")
        text[index:index] = [f"Независимая проверка исходных участков: "
                            f"`{native_audit['status']}`, {native_audit['checks_passed']} / {native_audit['checks_total']}. "
                            "[NATIVE_AUDIT.json](NATIVE_AUDIT.json). "
                            "Технический PASS подтверждает привязку данных и не заменяет A/B/C.", ""]
    for path in low_paths:
        text.append(f"- [{rel(path, ROOT)}]({rel(path, ROOT)}), SHA-256 `{sha(path)}`.")
    text += ["", "Сравниваются точные пары **(бюджет, seed)**; проверены SHA исходных CNN, "
             "последовательности батчей и 500 шагов, а также совпадение сохранённых копий контролей. "
             "Контроль другого seed не подставляется при отсутствии пары.", "",
             "## Раздельные критерии A/B/C", "",
             "A для каждого из lowres_plain/native_plain/native_joint требует выигрыша относительно "
             "**каждой** из двух дообученных CNN. B сравнивает native_joint с native_plain "
             "и требует прохождения A native_joint. C сравнивает native_plain с lowres_plain. "
             "Вывод о пользе исходных деталей требует одновременно C и A native_plain. "
             "Числа A/B/C и условие вывода о детализации публикуются раздельно. "
             "Для каждого сравнения: средний ΔF1 ≥0,5 п.п.; ΔF1 каждого бюджета ≥−0,25 п.п.; "
             "средний ΔIoU ≥−0,2 п.п. Бюджеты 18/27 имеют равный вес. "
             "При расширении публикуются все три и новые два seed отдельно. "
             "Прежние критерии предыдущих этапов сохраняются без пересмотра.", ""]
    if result_views:
        text += ["| Набор seed | Low-lr CNN F1, % | High-lr CNN F1, % | Lowres plain F1, % | Native plain F1, % | Native joint F1, % | A lowres / native plain / native joint | B | C / вывод о деталях |",
                 "|---|---:|---:|---:|---:|---:|---|---|---|"]
        for label, result in result_views:
            gates = result["gates"]
            text.append(f"| {label}: {result['seeds']} | {percent(mean(result['low_lr_controls']))} | "
                        f"{percent(mean(result['high_lr_controls']))} | {percent(mean(result['rows'], 'lowres_plain'))} | "
                        f"{percent(mean(result['rows'], 'native_plain'))} | {percent(mean(result['rows'], 'native_joint'))} | "
                        f"{' / '.join(passed(gates['A_architecture'][arm]['passed']) for arm in ARMS)} | "
                        f"{passed(gates['B_physics']['passed'])} | {passed(gates['C_detail']['passed'])} / "
                        f"{passed(gates['detail_claim_passed'])} |")
        text.append("")
    else:
        text += ["Завершённого результата пока нет; вывод о прохождении A/B/C не сделан.", ""]
    if output_figure:
        text += ["![Средние VAL и раздельные сравнения](figures/native_detail_validation.png)", "",
                 "Точечные средние без интервалов независимого подтверждения. "
                 "При наличии расширения средние всех трёх и новых двух seed перекрываются по данным.", ""]
    text += ["## Все сохранённые попытки этого этапа", ""]
    for trial in trials:
        path = trial["path"]
        text += [f"### {path.name}", "", f"[FROZEN.json]({rel(path / 'FROZEN.json', ROOT)}).", ""]
        if not trial["result"]:
            if trial["failure"]:
                item = trial["failure"]
                text += [f"Техническая ошибка `{item.get('error_type', 'см. файл')}`: "
                         f"{str(item.get('error', '')).replace(chr(10), ' ')}. "
                         f"[FAILURE.json]({rel(path / 'FAILURE.json', ROOT)}). "
                         "Это технический исход, а не отрицательный научный результат.", ""]
            else:
                text += ["Попытка начата; итоговый RESULT.json ещё не сохранён.", ""]
            text += [f"Завершённых сохранённых обучений: {len(trial['partial'])}.", ""]
            continue
        result = trial["result"]
        text += [f"`{result['status']}`; {result['phase']}; seed {result['seeds']}; "
                 f"{result['updates']:,} обновлений; {result['seconds']:.2f} с. "
                 f"[RESULT.json]({rel(path / 'RESULT.json', ROOT)}), SHA-256 `{sha(path / 'RESULT.json')}`.", "",
                 "| Бюджет | Seed | Вариант / источник | Порог VAL | Macro-F1, % | IoU, % | Шагов CNN / нового блока | Zero ΔF1, п.п. | Roll ΔF1, п.п. |",
                 "|---:|---:|---|---:|---:|---:|---|---:|---:|"]
        for row in result["rows"]:
            selected = row["selected"];ablations = row["ablations"]
            text.append(f"| {row['budget']} | {row['seed']} | {row['arm']} / {row['detail_source']} | "
                        f"{selected['threshold']:.2f} | {percent(selected['mask_F1'])} | {percent(selected['IoU'])} | "
                        f"{row['CNN_updates']} / {row['refiner_updates']} | "
                        f"{pp(ablations['zero']['mask_F1'] - selected['mask_F1'])} | "
                        f"{pp(ablations['roll']['mask_F1'] - selected['mask_F1'])} |")
        text.append("")
        gate_results = [("только эта попытка", result)]
        if trial["aggregate"]:
            gate_results.append(("все три seed", trial["aggregate"]))
            text += [f"[AGGREGATE_RESULT.json]({rel(path / 'AGGREGATE_RESULT.json', ROOT)}) "
                     "объединяет прежний скрининг и новые seed; обучений не добавляет.", ""]
        for label, item in gate_results:
            text += [f"**{label}: {item['seeds']}**", "",
                     "| Сравнение | ΔF1, п.п. | ΔIoU, п.п. | ΔF1 по бюджетам 18 / 27, п.п. | Критерий |",
                     "|---|---:|---:|---|---|"]
            comparisons = []
            for arm in ARMS:
                comparisons += [(f"A {arm} − CNN lr={lr}", item["gates"]["A_architecture"][arm][key])
                                for key, lr in [("vs_low_lr", "0,0001"), ("vs_high_lr", "0,0005")]]
            comparisons += [("B native_joint − native_plain, с требованием A native_joint", item["gates"]["B_physics"]),
                            ("C native_plain − lowres_plain", item["gates"]["C_detail"])]
            for name, gate in comparisons:
                text.append(f"| {name} | {pp(gate['delta'])} | {pp(gate['IoU_delta'])} | "
                            f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
            text.append("")
            text += [f"Условие вывода о детализации (C и A native_plain): "
                     f"**{passed(item['gates']['detail_claim_passed'])}**.", ""]
        if trial["aggregate"]:
            aggregate = trial["aggregate"]
            robust = {arm: aggregate["gates"]["A_architecture"][arm]["passed"] and
                      result["gates"]["A_architecture"][arm]["passed"] for arm in ARMS}
            text += ["Одновременно на всех трёх и новых двух seed: " +
                     "; ".join(f"A {arm} {passed(robust[arm])}" for arm in ARMS) + "; " +
                     "; ".join(f"{name} {passed(aggregate['gates'][key]['passed'] and result['gates'][key]['passed'])}"
                               for name, key in [("B", "B_physics"), ("C", "C_detail")]) + "; " +
                     f"вывод о деталях {passed(aggregate['gates']['detail_claim_passed'] and result['gates']['detail_claim_passed'])}.", ""]
        audit = trial["audit"]
        text += [(f"Независимый CPU-аудит: `{audit.get('status', 'см. файл')}`; "
                  f"проверок {audit.get('checks_passed', 'см. файл')} / {audit.get('checks_total', 'см. файл')}; "
                  f"[AUDIT.json]({rel(path / 'AUDIT.json', ROOT)})." if audit else
                  "Итоговый независимый аудит этой попытки ещё не сохранён."), ""]
    text += ["## Предыдущие попытки адаптивного поиска", "",
             "Все предыдущие отрицательные варианты остаются частью поиска. "
             "У этапов 1/2 A сравнивал с замороженной CNN; у этапов 3/4 — с двумя дообученными CNN. "
             "Эти критерии не смешиваются.", "",
             "| Этап / попытка | Seed | Сохранённых обучений | F1 каждого варианта, % | Прежний A каждого варианта | B / C |",
             "|---|---|---:|---|---|---|"]
    for stage in previous:
        for trial in stage["trials"]:
            result, path = trial["result"], trial["path"]
            label = f"{stage['path'].name} / {path.name}"
            if result:
                gates = result["gates"]
                arms = list(dict.fromkeys(row["arm"] for row in result["rows"]))
                values = "; ".join(f"{arm}: {percent(mean(result['rows'], arm))}" for arm in arms)
                a_values = "; ".join(f"{arm}: {passed(gate['passed'])}" for arm, gate in gates["A_architecture"].items())
                c_gate = gates.get("C_skip_route", gates.get("C_detail"))
                c_value = passed(c_gate["passed"]) if c_gate else "—"
                text.append(f"| [{label}]({rel(path / 'RESULT.json', ROOT)}) | {result['seeds']} | "
                            f"{len(result['rows'])} | {values} | {a_values} | "
                            f"{passed(gates['B_physics']['passed'])} / {c_value} |")
            else:
                text.append(f"| {label}: {'техническая ошибка' if trial['failure'] else 'незавершена'} | "
                            f"{trial['frozen'].get('seeds', 'см. файл')} | {len(trial['partial'])} | — | — | — |")
    text += ["", "## Границы вывода", "",
             "Те же TRAIN/VAL: пул 54 плотных масок, 1152 слабых примера, 695 VAL, бюджеты 18/27, розыгрыш 5303. "
             "Слабые маски оптимизатору не передаются. Девять классов рассчитаны условной решёткой. "
             "Порог каждой модели выбирается на VAL из [0,30; 0,40; 0,45; 0,50; 0,55; 0,60; 0,70] "
             "по F1, затем IoU, близости к 0,5 и меньшему порогу. Zero/roll используют фиксированный actual-порог.", "",
             "При B FAIL добавочная польза физических карт по заданному критерию не установлена. "
             "При провале условия C и A native_plain выигрыш нельзя приписывать исходной детализации. "
             "Чувствительность к картам не доказывает их пользу. "
             "Для независимого подтверждения нужны заранее зафиксированные модель/критерии и закрытые новые данные, "
             "не использованные в EDA, разработке или прежних тестах. Такой проверки здесь нет. "
             "Перенос на другие изделия и новизна рассматриваются отдельно.", "",
             "[PROTOCOL.md](PROTOCOL.md) · [CONFIG.json](CONFIG.json) · [LEDGER.json](LEDGER.json) · "
             "[model.py](model.py) · [runner.py](runner.py) · [audit.py](audit.py).", ""]
    (ROOT / "REPORT.md").write_text("\n".join(text))
    (ROOT / "README.md").write_text(
        "# CNN-ветвь исходной детализации SEM\n\n"
        "Пятый этап модели с прежним лоссом: новая CNN-ветвь сравнивает native48 с увеличенным X12 "
        "при тех же 21 506 общих параметрах. A проверяется против двух общих дообученных CNN, "
        "B — физические карты, C — исходные детали; вывод о деталях требует C и A native_plain.\n\n"
        f"Завершено попыток {len(complete)}, технических ошибок {len(failures)}, локальных обучений {len(local_rows)}. "
        f"Уникальных обучений по пяти этапам {unique_fits}; общие контроли повторно не считаются.\n\n"
        "[Отчёт со всеми попытками](REPORT.md) · [Протокол](PROTOCOL.md) · [Конфигурация](CONFIG.json) · [Журнал](LEDGER.json).\n\n"
        "Только повторно используемые TRAIN/VAL. Нового TEST нет; независимое подтверждение требует закрытых новых данных.\n\n"
        "Пересоздать только отчёт и рисунок:\n\n"
        "```bash\n.venv/bin/python -B gipoteza/sem_arch_native_detail_20261102/report.py\n```\n")
    inputs = [HELPER, high_path, high_path.with_name("FROZEN.json"), high_path.with_name("CONFIG_SNAPSHOT.json"),
              native_path, native_archive, ROOT / "prepare.py"]
    if native_audit:
        inputs.append(ROOT / "NATIVE_AUDIT.json")
    for path in low_paths:
        inputs += [path, path.with_name("CONFIG_SNAPSHOT.json")]
    for stage in previous + [{"path": ROOT, "trials": trials}]:
        inputs += [stage["path"] / name for name in ["PROTOCOL.md", "CONFIG.json", "QUEUE.json", "LEDGER.json", "STAGE_LINK.json"]
                   if (stage["path"] / name).exists()]
        for trial in stage["trials"]:
            inputs += [trial["path"] / name for name in ["FROZEN.json", "RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json",
                       "PARTIAL_RESULTS.json", "AUDIT.json", "HIGH_LR_CONTROL_SNAPSHOT.json", "LOW_LR_CONTROL_SNAPSHOT.json"]
                       if (trial["path"] / name).exists()]
    outputs = [ROOT / "REPORT.md", ROOT / "README.md"] + ([output_figure] if output_figure else [])
    manifest = dict(status="REPORT_GENERATED", scope="ADAPTIVE_REUSED_TRAIN_VAL_ONLY",
        UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), report_script_sha256=sha(Path(__file__)),
        shared_report_helper_sha256=sha(HELPER), trial_count=len(trials), completed_trials=len(complete),
        failed_trials=len(failures), pending_trials=len(pending), actual_completed_fits=len(local_rows),
        local_control_fits=0, prior_unique_completed_fits=prior_unique,
        extra_low_lr_control_fits_outside_prior_trials=len(extra_low),
        referenced_high_lr_control_fits=len(high["rows"]), referenced_low_lr_control_fits=len(low),
        linked_stage_total_attempts=len(prior_trials) + len(trials), linked_stage_unique_completed_fits=unique_fits,
        controls_counted_as_local=False, matching_unit=["budget", "seed"],
        matched_fields=["backbone_before_sha256", "batch_sequence_sha256", "steps"],
        native_data=dict(lineage_path=rel(native_path, ROOT), lineage_sha256=sha(native_path),
            archive_sha256=sha(native_archive), exact_reductions=native["exact_4x4_reductions"],
            maximum_reconstruction_error=native["max_absolute_reconstruction_error"], new_independent_frames=False),
        control_sources=dict(high=dict(file=rel(high_path, ROOT), sha256=sha(high_path)),
            low=[dict(file=rel(path, ROOT), sha256=sha(path)) for path in low_paths]),
        scientific_inputs_sha256={rel(path, ROOT): sha(path) for path in inputs},
        outputs_sha256={rel(path, ROOT): sha(path) for path in outputs})
    (ROOT / "REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
