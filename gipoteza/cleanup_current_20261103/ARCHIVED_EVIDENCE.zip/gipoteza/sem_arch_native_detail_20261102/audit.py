"""Independent CPU audit for native-detail CNN/FiLM TRAIN/VAL development.

No optimization, external downloads, or TEST/EVAL data access.  Development
gates are not confirmatory tests.  This file is maintained independently of
the model and training runner.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import time

import numpy as np
from scipy import linalg, ndimage
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
PILOT = G / 'sem_architecture_pilot_20261102'
VARIANTS = ['actual', 'zero', 'roll']
COUNTS = {'film': 8993, 'detail': 1832}
ARMS = ['lowres_plain', 'native_plain', 'native_joint']
REPO = G.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def digest(state):
    h = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()


def macro_f1(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    denominator = confusion.sum(0) + confusion.sum(1)
    return float(np.divide(2 * np.diag(confusion), denominator,
                           out=np.zeros(9, float), where=denominator > 0).mean())


def mean_iou(masks, target):
    union = (masks | target).sum((-2, -1))
    intersection = (masks & target).sum((-2, -1))
    return float(np.divide(intersection, union, out=np.ones(len(union)),
                           where=union > 0).mean())


def normalized_maps(raw):
    value = np.log1p(100 * np.asarray(raw, dtype=np.float64))
    centered = value - value.mean((-2, -1), keepdims=True)
    return centered / np.sqrt((centered * centered).mean((-2, -1), keepdims=True) + 1e-6)


_DIRECTION_CACHE = {}
_CLASS_CACHE = {}


def direction_class(mask):
    """Independent active-node Cholesky solve of the binary unit-edge graph."""
    mask = np.ascontiguousarray(mask, dtype=bool)
    key = np.packbits(mask).tobytes()
    if key in _DIRECTION_CACHE:
        return _DIRECTION_CACHE[key]
    components, _ = ndimage.label(mask, ndimage.generate_binary_structure(2, 1))
    spanning = np.intersect1d(components[:, 0], components[:, -1])
    spanning = spanning[spanning > 0]
    if not len(spanning):
        answer = 0
    else:
        active = np.isin(components, spanning)
        vertices = np.flatnonzero(active.ravel())
        lookup = np.full(144, -1, dtype=int)
        lookup[vertices] = np.arange(len(vertices))
        laplacian = np.zeros((len(vertices), len(vertices)), dtype=np.float64)
        for vertex in vertices:
            y, x = divmod(int(vertex), 12)
            for yy, xx in [(y + 1, x), (y, x + 1)]:
                if yy < 12 and xx < 12 and active[yy, xx]:
                    a, b = lookup[vertex], lookup[yy * 12 + xx]
                    laplacian[a, a] += 1; laplacian[b, b] += 1
                    laplacian[a, b] -= 1; laplacian[b, a] -= 1
        left = np.flatnonzero(vertices % 12 == 0)
        right = np.flatnonzero(vertices % 12 == 11)
        free = np.setdiff1d(np.arange(len(vertices)), np.r_[left, right])
        potential = np.zeros(len(vertices)); potential[right] = 1
        if len(free):
            potential[free] = linalg.solve(
                laplacian[np.ix_(free, free)],
                -laplacian[np.ix_(free, right)].sum(1), assume_a='pos',
                check_finite=False)
        conductance = float((laplacian[right] @ potential).sum()) / (12 / 11)
        answer = 0 if conductance < 1e-8 else (1 if conductance < .5 - 1e-8 else 2)
    _DIRECTION_CACHE[key] = answer
    return answer


def classify(masks):
    result = []
    for mask in np.asarray(masks, dtype=bool).reshape(-1, 12, 12):
        key = np.packbits(mask).tobytes()
        if key not in _CLASS_CACHE:
            _CLASS_CACHE[key] = 3 * direction_class(mask) + direction_class(mask.T)
        result.append(_CLASS_CACHE[key])
    return np.asarray(result, dtype=np.int64)


def conv(x, state, prefix, padding=0, dilation=1):
    return F.conv2d(x, state[prefix + '.weight'], state[prefix + '.bias'],
                    padding=padding, dilation=dilation)


def independent_backbone(x, state):
    features = x
    for index, dilation in [(0, 1), (2, 2), (4, 4)]:
        features = F.gelu(conv(features, state, str(index), dilation, dilation))
    coarse = conv(features, state, '6')
    return torch.cat((features, coarse, x), 1), coarse


def independent_logits(candidate, state, visual, coarse, maps, intervention='actual'):
    """Functional reconstruction; does not import the candidate model code."""
    if intervention == 'zero':
        maps = torch.zeros_like(maps)
    elif intervention == 'roll':
        maps = torch.roll(maps, (5, 5), (-2, -1))
    if candidate == 'direct':
        residual = conv(F.gelu(conv(torch.cat((visual, maps), 1), state,
                                     'network.0', 1)), state, 'network.2')
    elif candidate == 'split':
        f = F.gelu(conv(visual, state, 'visual.0', 1))
        m = F.gelu(conv(maps, state, 'conditioning.0', 1))
        residual = conv(F.gelu(conv(torch.cat((f, m), 1), state,
                                     'fusion.0')), state, 'fusion.2')
    else:
        features = F.gelu(conv(visual, state, 'visual.0', 1))
        condition = conv(maps, state, 'conditioning', 1)
        if candidate == 'film':
            gamma, beta = condition.chunk(2, 1)
            features = features * (1 + .5 * gamma.tanh()) + .5 * beta.tanh()
        elif candidate == 'gated':
            features = features * (1 + .5 * condition.tanh())
        else:
            raise ValueError(candidate)
        residual = conv(F.gelu(conv(features, state, 'output.0', 1)), state, 'output.2')
    return coarse + 4 * residual.tanh()


def selected(scores):
    return max(scores, key=lambda row: (row['mask_F1'], row['IoU'],
                -abs(row['threshold'] - .5), -row['threshold']))


def gate(delta_f1, delta_iou, config):
    checks = {
        'mean_F1_gain': float(np.mean(delta_f1)) >= config['minimum_mean_F1_gain'],
        'each_budget_guard': min(delta_f1) >= config['minimum_budget_F1_delta'],
        'mean_IoU_guard': float(np.mean(delta_iou)) >= config['minimum_mean_IoU_delta'],
    }
    return {'passed': all(checks.values()), 'checks': checks,
            'mean_F1_delta': float(np.mean(delta_f1)),
            'budget_F1_deltas': list(map(float, delta_f1)),
            'mean_IoU_delta': float(np.mean(delta_iou))}



def independent_gates(rows, low_rows, high_rows, config):
    """Recompute the two CNN controls and the matched-map comparison."""
    def means(arm):
        return {budget: {metric: float(np.mean([row['selected'][metric] for row in rows
            if row['budget'] == budget and row['arm'] == arm])) for metric in ['mask_F1', 'IoU']}
            for budget in [18, 27]}
    reference = {
        'low_lr': {budget: {metric: float(np.mean([row['selected'][metric] for row in low_rows
            if row['budget'] == budget])) for metric in ['mask_F1', 'IoU']} for budget in [18, 27]},
        'high_lr': {budget: {metric: float(np.mean([row['selected'][metric] for row in high_rows
            if row['budget'] == budget])) for metric in ['mask_F1', 'IoU']} for budget in [18, 27]},
    }
    values = {arm: means(arm) for arm in ARMS}
    def compare(left, right):
        return gate([left[budget]['mask_F1'] - right[budget]['mask_F1'] for budget in [18, 27]],
                    [left[budget]['IoU'] - right[budget]['IoU'] for budget in [18, 27]], config['gates'])
    architecture = {arm: {name: compare(values[arm], baseline) for name, baseline in reference.items()}
                    for arm in ARMS}
    passes = {arm: all(item['passed'] for item in architecture[arm].values()) for arm in architecture}
    physics = compare(values['native_joint'], values['native_plain'])
    physics['joint_architecture_gate'] = passes['native_joint']
    physics['passed'] &= passes['native_joint']
    output = {arm: dict(vs_low_lr=architecture[arm]['low_lr'],
                       vs_high_lr=architecture[arm]['high_lr'], passed=passes[arm])
              for arm in ARMS}
    capacity = compare(values['native_plain'], values['lowres_plain'])
    return dict(A_architecture=output, A_any=any(passes.values()),
                B_physics=physics, C_detail=capacity,
                detail_claim_passed=bool(capacity['passed'] and passes['native_plain']))


def expected_batch_digest(budget, seed):
    rng = np.random.default_rng(seed + 1000)
    trace = hashlib.sha256()
    for _ in range(500):
        trace.update(rng.integers(0, budget, 8).astype(np.int64).tobytes())
        trace.update(rng.integers(0, 1152, 8).astype(np.int64).tobytes())
    return trace.hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def compare_stored_gates(computed, stored):
    """Compare semantic gate outcomes, permitting only historical key spelling."""
    def canonical(value):
        if isinstance(value, dict):
            names = {'delta': 'mean_F1_delta', 'IoU_delta': 'mean_IoU_delta',
                     'budget_deltas': 'budget_F1_deltas', 'budget_F1_guard': 'each_budget_guard'}
            return {names.get(key, key): canonical(item) for key, item in value.items()
                    if key != 'interpretation'}
        if isinstance(value, list):
            return [canonical(item) for item in value]
        return value
    actual, observed = canonical(computed), canonical(stored)
    def compare(left, right):
        if isinstance(left, dict):
            assert set(left) == set(right), (set(left), set(right))
            return max([compare(left[key], right[key]) for key in left] + [0.])
        if isinstance(left, list):
            assert len(left) == len(right)
            return max([compare(a, b) for a, b in zip(left, right)] + [0.])
        if isinstance(left, bool):
            assert left == right, (left, right)
            return 0.
        return abs(float(left) - float(right))
    return compare(actual, observed)



def audit_native_data():
    """Independently reconstruct the historical crops without loading masks."""
    from PIL import Image
    start = time.monotonic()
    config = json.loads((ROOT / 'CONFIG.json').read_text())
    path = ROOT / config['native_archive']
    lineage = json.loads((ROOT / 'NATIVE_LINEAGE.json').read_text())
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        data = {key: archive[key] for key in ['X', 'role', 'frame', 'label']}
    with np.load(path, allow_pickle=False) as archive:
        native = {key: archive[key] for key in archive.files}
    manifest_path = REPO / lineage['metadata_file']
    records = json.loads(manifest_path.read_text())['records'][:1901]
    canonical = hashlib.sha256(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    checks = {}
    checks['native_scope_hashes_frozen_sources_and_image_only_fields'] = (
        lineage['scope'] == 'TRAIN_VAL_ONLY_NATIVE_CROPS_NO_TEST' and config['native_archive'] == 'NATIVE_TRAIN_VAL.npz' and
        lineage['archive_sha256'] == sha(path) and lineage['TRAIN_VAL_sha256'] == sha(PILOT / 'TRAIN_VAL.npz') and
        lineage['prepare_sha256'] == sha(ROOT / 'prepare.py') and
        lineage['protocol_sha256'] == config['protocol_sha256'] == sha(ROOT / 'PROTOCOL.md') and
        manifest_path.resolve() == (G / 'sem_scarcity_20261102/DATA_MANIFEST.json').resolve() and
        lineage['metadata_sha256'] == sha(manifest_path) and lineage['first1901_records_sha256'] == canonical and
        set(native) == set(lineage['fields']) == {'native_uint8', 'row_index', 'frame', 'role', 'y', 'x'} and
        native['native_uint8'].shape == (1901, 1, 48, 48) and native['native_uint8'].dtype == np.uint8)
    checks['native_exact_metadata_indices_coordinates_and_TRAIN_VAL_roles'] = (
        len(records) == 1901 and np.array_equal(native['row_index'], np.arange(1901, dtype=np.int64)) and
        np.array_equal(native['frame'], data['frame']) and np.array_equal(native['role'], data['role']) and
        set(data['frame']) == set(range(8)) and set(data['role']) == {'dense', 'weak', 'val'} and
        all((row['frame'], row['role'], row['label'], row['y'], row['x']) ==
            (int(data['frame'][i]), str(data['role'][i]), int(data['label'][i]), int(native['y'][i]), int(native['x'][i]))
            for i, row in enumerate(records)))
    expected_sources = {frame: G / f'sem_confirmation_20261028/sources/sem{frame:04}.png' for frame in range(8)}
    checks['only_eight_original_TRAIN_VAL_PNG_sources'] = (
        len(lineage['source_files']) == 8 and {row['frame'] for row in lineage['source_files']} == set(range(8)) and
        all((REPO / row['file']).resolve() == expected_sources[row['frame']].resolve() and
            sha(REPO / row['file']) == row['sha256'] for row in lineage['source_files']))
    registry_path = G / 'shared_data/ic_sem_m2/SOURCE_MEMBERS.json'
    registry = json.loads(registry_path.read_text())['png_original_sources']
    original_hashes = {Path(row['path']).name: row['sha256'] for row in registry}
    checks['native_PNG_hashes_match_retained_original_source_registry'] = all(
        original_hashes[f'sem{frame:04}.png'] == sha(path) for frame, path in expected_sources.items())
    all_crops = True; reduced_exact = True; max_reduction_error = 0.
    for frame, source in expected_sources.items():
        pixels = np.asarray(Image.open(source))
        all_crops &= pixels.shape == (3536, 4096) and pixels.dtype == np.uint8
        for index in np.flatnonzero(data['frame'] == frame):
            y, x = int(native['y'][index]), int(native['x'][index])
            all_crops &= 0 <= y <= pixels.shape[0] - 48 and 0 <= x <= pixels.shape[1] - 48
            crop = pixels[y:y + 48, x:x + 48]
            all_crops &= np.array_equal(crop, native['native_uint8'][index, 0])
            reduced = crop.reshape(12, 4, 12, 4).sum((1, 3)).astype(np.float32) / (16 * 255)
            reduced_exact &= np.array_equal(reduced, data['X'][index, 0])
            max_reduction_error = max(max_reduction_error, float(np.max(np.abs(reduced - data['X'][index, 0]))))
    checks['all1901_native_uint8_crops_reconstructed_from_original_PNG'] = bool(all_crops)
    checks['all1901_4x4_reductions_bit_exact_to_original_X12'] = (
        bool(reduced_exact) and max_reduction_error == 0. and lineage['exact_4x4_reductions'] == 1901 and
        lineage['max_absolute_reconstruction_error'] == 0.)
    tree = ast.parse((ROOT / 'prepare.py').read_text())
    source = ast.unparse(tree)
    reads = [ast.unparse(node) for node in ast.walk(tree) if isinstance(node, ast.Call) and
             isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and
             node.func.value.id == 'np' and node.func.attr == 'load']
    checks['preparation_image_only_original_TRAIN_VAL_and_frames0to7'] = (
        len(reads) == 1 and 'np.load(TRAIN_VAL, allow_pickle=False)' == reads[0] and
        "['X', 'role', 'frame', 'label']" in source and "['records'][:1901]" in source and
        'for frame in range(8):' in source and "SOURCES / f'sem{frame:04}.png'" in source and
        not any(isinstance(node, ast.Subscript) and isinstance(node.slice, ast.Constant) and node.slice.value == 'Y'
                for node in ast.walk(tree)))
    outcome = dict(status='PASS_NATIVE_DATA_AUDIT' if all(checks.values()) else 'FAIL_NATIVE_DATA_AUDIT',
        scope='INDEPENDENT_CPU_TRAIN_VAL_NATIVE_IMAGE_ALIGNMENT_NO_TEST', audit_source_sha256=sha(__file__),
        native_archive_sha256=sha(path), native_lineage_sha256=sha(ROOT / 'NATIVE_LINEAGE.json'),
        original_source_registry_sha256=sha(registry_path),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        crops_reconstructed=1901, maximum_4x4_reduction_error=max_reduction_error, seconds=time.monotonic() - start)
    return native, lineage, outcome


def independent_predictions(weights, arm, images, native_uint8, circuit):
    """Reconstruct backbone, strided detail CNN, maps and FiLM independently."""
    backbone = {key[len('backbone.'):]: value for key, value in weights.items() if key.startswith('backbone.')}
    refiner = {key[len('refiner.'):]: value for key, value in weights.items() if key.startswith('refiner.')}
    detail = {key[len('detail.'):]: value for key, value in weights.items() if key.startswith('detail.')}
    outputs = [[] for _ in VARIANTS]
    fixture = None
    with torch.inference_mode():
        for start in range(0, len(images), 16):
            batch = images[start:start + 16]
            source = native_uint8[start:start + 16]
            visual26, coarse = independent_backbone(batch, backbone)
            if arm == 'lowres_plain':
                detail_input = batch.repeat_interleave(4, -2).repeat_interleave(4, -1)
            else:
                detail_input = 5 * (source.to(dtype=torch.float32) / 255 - .2)
            first = F.gelu(F.conv2d(detail_input, detail['0.weight'], detail['0.bias'], stride=2, padding=1))
            features = F.gelu(F.conv2d(first, detail['2.weight'], detail['2.bias'], stride=2, padding=1))
            visual = torch.cat((visual26, features), 1)
            if arm != 'native_joint':
                probability = coarse.sigmoid()
                raw = torch.cat((probability, 4 * probability * (1 - probability)), 1)
            else:
                raw = circuit(coarse, mode='joint')
            maps = torch.tensor(normalized_maps(raw.numpy()), dtype=torch.float32)
            logits = [independent_logits('film', refiner, visual, coarse, maps, variant) for variant in VARIANTS]
            if fixture is None:
                fixture = dict(x=batch.numpy(), native_uint8=source.numpy(), visual=visual.numpy(), coarse=coarse.numpy(),
                               maps_raw=raw.numpy(), maps=maps.numpy(), detail_input=detail_input.numpy(),
                               detail_features=features.numpy())
            for index, value in enumerate(logits):
                outputs[index].append(value.numpy())
    return np.asarray([np.concatenate(parts) for parts in outputs]), fixture


def audit_trial(folder):
    started = time.monotonic()
    read_local = lambda name: json.loads((folder / name).read_text())
    result, frozen, config = (read_local(name) for name in
                             ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json'])
    monitored = list(folder.glob('*.json')) + list((folder / 'models').glob('*.pt'))
    monitored += [folder / 'PROTOCOL.md', ROOT / 'model.py', ROOT / 'runner.py', ROOT / 'prepare.py',
                  ROOT / 'NATIVE_TRAIN_VAL.npz', ROOT / 'NATIVE_LINEAGE.json', PILOT / 'TRAIN_VAL.npz']
    before = {str(path): sha(path) for path in monitored if not path.name.startswith('AUDIT')}
    checks = {}
    checks['development_scope_explicit'] = (
        result['status'] == 'COMPLETE_DEVELOPMENT_TRIAL' and 'VAL' in result['scope'] and
        'no independent confirmation' in result['scope'] and 'no TEST/EVAL' in frozen['scope'])
    checks['frozen_configuration_protocol_and_sources'] = (
        sha(folder / 'FROZEN.json') == result['frozen_sha256'] and
        sha(folder / 'CONFIG_SNAPSHOT.json') == frozen['config_snapshot_sha256'] and
        sha(folder / 'PROTOCOL.md') == frozen['protocol_sha256'] == config['protocol_sha256'] and
        all(sha(ROOT / name) == value for name, value in frozen['source_sha256'].items()) and
        all(sha(folder / 'source' / name) == frozen['source_sha256'][name] for name in ['prepare.py', 'runner.py', 'model.py']))
    checks['fixed_design_hyperparameters_and_two_controls'] = (
        config['candidate'] == 'film_native_detail' and config['arms'] == ARMS and config['budgets'] == [18, 27] and
        config['screen_seeds'] == [5501] and config['replication_seeds'] == [5501, 5521, 5557] and
        config['steps'] == 500 and config['warmup_steps'] == 100 and config['batch_size'] == 8 and
        config['backbone_learning_rate'] == .0001 and config['refiner_learning_rate'] == .0005 and
        config['weight_decay'] == .0001 and config['physics_weight'] == 1 and
        config['epsilon'] == .001 and config['eta'] == 4 and config['subset_seed'] == 5303 and
        config['normalization_scale'] == 100 and config['normalization_variance_floor'] == 1e-6 and
        config['thresholds'] == [.3, .4, .45, .5, .55, .6, .7] and
        config['gates'] == dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025,
                               minimum_mean_IoU_delta=-.002))
    tree = ast.parse((folder / 'source' / 'runner.py').read_text())
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    array_reads = [(name, ast.unparse(node)) for name, function in functions.items()
                   for node in ast.walk(function) if isinstance(node, ast.Call) and
                   isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and
                   node.func.value.id == 'np' and node.func.attr == 'load']
    inputs_source = ast.unparse(functions['inputs'])
    checks['runner_array_access_only_TRAIN_VAL_no_weak_masks'] = (
        len(array_reads) == 2 and all(name == 'inputs' for name, _ in array_reads) and
        any("PILOT / 'TRAIN_VAL.npz'" in source for _, source in array_reads) and
        any('np.load(native_path, allow_pickle=False)' == source for _, source in array_reads) and
        "if role != 'weak':" in inputs_source)
    fit = functions['fit']; fit_source = ast.unparse(fit)
    loss_assignments = [ast.unparse(node) for node in ast.walk(fit)
                        if isinstance(node, ast.Assign) and any(
                            isinstance(target, ast.Name) and target.id == 'loss' for target in node.targets)]
    checks['exact_old_BCE_plus_geometry_loss_and_live_training_forward'] = (
        loss_assignments == ["loss = dense_loss + c['physics_weight'] * geometry_loss"] and
        "dense_loss = F.binary_cross_entropy_with_logits(dense, values['dense']['mask'][ai])" in fit_source and
        'geometry_loss = physics.geometry_loss(weak, direction)' in fit_source and
        "logits = model(torch.cat((values['dense']['x'][ai], values['weak']['x'][wi])), torch.cat((values['dense']['native_uint8'][ai], values['weak']['native_uint8'][wi])))" in fit_source and
        'forward_cached' not in fit_source and 'precompute' not in fit_source)
    checks['source_100_400_schedule_and_fixed_optimizer_groups'] = (
        "step == c['warmup_steps'] + 1" in fit_source and
        'model.set_backbone_trainable(True)' in fit_source and
        "step <= c['warmup_steps']" in fit_source and
        'all((p.grad is None for p in backbone.parameters()))' in fit_source and
        'all((p.grad is not None and torch.isfinite(p.grad).all() for p in backbone.parameters()))' in fit_source and
        "dict(params=model.backbone.parameters(), lr=c['backbone_learning_rate'])" in fit_source and
        "dict(params=model.refiner.parameters(), lr=c['refiner_learning_rate'])" in fit_source and
        "dict(params=model.detail.parameters(), lr=c['refiner_learning_rate'])" in fit_source and
        "torch.optim.AdamW(model.parameters(), lr=c['backbone_learning_rate']" in fit_source and
        "range(1, c['steps'] + 1)" in fit_source)
    model_tree = ast.parse((folder / 'source' / 'model.py').read_text())
    current = next(node for node in ast.walk(model_tree) if isinstance(node, ast.FunctionDef) and node.name == 'current_inputs')
    current_source = ast.unparse(current)
    checks['source_current_maps_detached_label_free_live_CNN_paths'] = (
        [argument.arg for argument in current.args.args] == ['self', 'x', 'native_uint8'] and
        'features = self.backbone[:-1](x)' in current_source and
        'coarse = self.backbone[-1](features)' in current_source and
        'with torch.no_grad():' in current_source and 'detached = coarse.detach()' in current_source and
        "self.circuit(detached, mode='joint')" in current_source and
        "'visual': torch.cat((features, coarse, x, detail_features), dim=1)" in current_source and
        "detail_input = F.interpolate(x, scale_factor=4, mode='nearest')" in current_source and
        'detail_input = 5 * (native_uint8.to(dtype=x.dtype) / 255 - 0.2)' in current_source and
        'detail_features = self.detail(detail_input)' in current_source and
        not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and
                node.func.attr in ['load', 'load_state_dict'] for node in ast.walk(current)))
    lineage = frozen['lineage']; subsets = json.loads((PILOT / 'SUBSETS.json').read_text())
    checks['unchanged_TRAIN_VAL_subsets_and_source_lineage'] = (
        sha(PILOT / 'TRAIN_VAL.npz') == lineage['TRAIN_VAL_sha256'] == subsets['train_val_sha256'] and
        sha(PILOT / 'SUBSETS.json') == lineage['subsets_sha256'] and
        sha(PILOT / 'INITIAL_LINEAGE.json') == lineage['initial_lineage_sha256'] and
        all(sha(G / source['file']) == source['sha256'] for source in lineage['sources'].values()))
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    val = np.flatnonzero(data['role'] == 'val')
    images = torch.tensor(5 * (data['X'][val] - .2))
    truth, target = data['label'][val], data['Y'][val, 0].astype(bool)
    checks['data_roles_frames_and_nested_balanced_subsets'] = (
        {role: int(np.sum(data['role'] == role)) for role in set(data['role'])} ==
        {'dense': 54, 'weak': 1152, 'val': 695} and
        set(data['frame'][val]) == {6, 7} and set(data['frame'][data['role'] != 'val']) == set(range(6)) and
        all(np.array_equal(np.bincount(data['label'][subsets['dense_indices'][str(budget)]], minlength=9),
                           np.full(9, budget // 9)) for budget in [18, 27]) and
        set(subsets['dense_indices']['18']).issubset(subsets['dense_indices']['27']))
    checks['independent_graph_classifier_matches_all_VAL_truth'] = np.array_equal(classify(target), truth)
    native, native_lineage, native_audit = audit_native_data()
    checks.update(native_audit['checks'])
    native_images = torch.tensor(native['native_uint8'][val])
    checks['native_data_lineage_frozen_with_trial'] = (lineage['native_preparation'] == native_lineage and
        lineage['native_archive_sha256'] == native_audit['native_archive_sha256'] and
        lineage['native_lineage_sha256'] == native_audit['native_lineage_sha256'])
    phase, seeds = result['phase'], result['seeds']
    expected_seeds = [5501] if phase == 'screen' else [5521, 5557]
    expected_grid = {(budget, seed, arm) for budget in [18, 27] for seed in expected_seeds for arm in ARMS}
    rows = result['rows']
    checks['exact_planned_grid_no_reused_seed_double_count'] = (
        seeds == frozen['seeds'] == expected_seeds and result['candidate'] == frozen['candidate'] == 'film_native_detail' and
        len(rows) == frozen['models'] == len(expected_grid) and
        {(row['budget'], row['seed'], row['arm']) for row in rows} == expected_grid and
        result['updates'] == frozen['total_updates'] == 500 * len(rows) and
        len(lineage['sources']) == 2 * len(seeds))
    checks['all_checkpoint_file_SHA256'] = len(result['checkpoint_hashes']) == len(rows) and all(
        sha(folder / 'models' / name) == value for name, value in result['checkpoint_hashes'].items())
    high_path = REPO / config['high_lr_control_result']
    high_result = json.loads(high_path.read_text())
    high_audit = json.loads((high_path.parent / 'AUDIT.json').read_text())
    high_frozen = json.loads((high_path.parent / 'FROZEN.json').read_text())
    high_snapshot = read_local('HIGH_LR_CONTROL_SNAPSHOT.json')
    high_rows = [row for row in high_result['rows'] if row['seed'] in seeds]
    checks['shared_high_lr_control_independently_audited_and_exact_snapshot'] = (
        high_path.resolve() == (G / 'sem_arch_iterative_20261102/baseline_control/RESULT.json').resolve() and
        sha(high_path) == frozen['high_lr_control']['result_sha256'] == high_audit['result_sha256'] and
        sha(high_path.parent / 'CONFIG_SNAPSHOT.json') == frozen['high_lr_control']['config_snapshot_sha256'] and
        high_audit['status'] == 'PASS_AUDIT' and all(high_audit['checks'].values()) and
        high_audit['audit_source_sha256'] == sha(G / 'sem_arch_amplitude4_20261102/audit.py') and
        high_snapshot == dict(rows=high_rows, source=frozen['high_lr_control']) and
        result['high_lr_controls'] == high_rows and len(high_rows) == 2 * len(seeds))
    low_rows, low_meta, low_audits = [], [], []
    low_controls_ok = True
    control_paths = [config['low_lr_control_result']] + config['low_lr_additional_control_results']
    low_controls_ok &= len(control_paths) == len(set(control_paths))
    for name in control_paths:
        path = REPO / name
        low_result = json.loads(path.read_text())
        audit = json.loads((path.parent / 'AUDIT.json').read_text())
        settings = json.loads((path.parent / 'CONFIG_SNAPSHOT.json').read_text())
        chosen = [row for row in low_result['rows'] if row['arm'] == 'continued_base_low_lr' and row['seed'] in seeds]
        low_rows.extend(chosen)
        low_meta.append(dict(file=str(path.relative_to(REPO)), result_sha256=sha(path),
            config_snapshot_sha256=sha(path.parent / 'CONFIG_SNAPSHOT.json'), learning_rate=.0001,
            selected_pairs=[[row['budget'], row['seed']] for row in chosen]))
        low_audits.append(dict(result=str(path.relative_to(REPO)), result_sha256=sha(path),
                              audit_sha256=sha(path.parent / 'AUDIT.json')))
        low_controls_ok &= (audit['status'] == 'PASS_AUDIT' and all(audit['checks'].values()) and
            audit['result_sha256'] == sha(path) and settings['steps'] == 500 and
            settings['backbone_learning_rate'] == .0001 and all(settings[key] == config[key] for key in
            ['batch_size', 'weight_decay', 'physics_weight', 'thresholds', 'subset_seed', 'budgets']))
        if path.parent.parent.parent.name == 'sem_arch_joint_adaptation_20261102':
            low_controls_ok &= audit['audit_source_sha256'] == sha(G / 'sem_arch_joint_adaptation_20261102/audit.py')
    low_controls_ok &= (len(low_rows) == 2 * len(seeds) and
        {(row['budget'], row['seed']) for row in low_rows} == {(budget, seed) for budget in [18, 27] for seed in seeds} and
        result['low_lr_controls'] == low_rows and
        frozen['low_lr_control'] == dict(sources=low_meta, learning_rate=.0001) and
        read_local('LOW_LR_CONTROL_SNAPSHOT.json') == dict(rows=low_rows, source=frozen['low_lr_control']))
    checks['shared_low_lr_controls_independently_audited_exact_pairs_snapshot'] = bool(low_controls_ok)
    circuit_module = load_module('skip_audit_fixed_circuit', PILOT / 'circuit.py')
    circuit = circuit_module.CircuitMaps(epsilon=.001)
    model_module = load_module('skip_audit_initialization_and_gradient', ROOT / 'model.py')
    prior_model = load_module('skip_audit_previous_head', G / 'sem_arch_joint_adaptation_20261102/model.py')
    source_states = {}
    for budget in [18, 27]:
        for seed in seeds:
            source = lineage['sources'][f'{budget}:{seed}']
            source_states[budget, seed] = torch.load(G / source['file'], map_location='cpu', weights_only=True)['segmenter']
    errors = dict(metrics=0., forward=0., probabilities=0., normalization=0., maps=0., fixture_inputs=0., detail_input=0.)
    metadata_ok = True; initialization_ok = True; final_states_ok = True; warmup_ok = True
    counts_ok = True; batches_ok = True; predictions_ok = True; selection_ok = True; fixtures_ok = True
    gradient_ok = True; cache_guard_ok = True; optimizer_ok = True; evidence = []; recomputed_rows = []
    prior_preserved_ok = True; detail_route_ok = True; detail_states_ok = True; detail_gradient_ok = True

    def metric_error(actual, saved):
        for key, value in actual.items():
            errors['metrics'] = max(errors['metrics'], abs(float(value) - float(saved[key])))

    for row in rows:
        budget, seed, arm = row['budget'], row['seed'], row['arm']
        refined = True
        stem = f'b{budget}_{arm}_s{seed}'
        checkpoint = torch.load(folder / 'models' / f'{stem}.pt', map_location='cpu', weights_only=True)
        weights = checkpoint['model']; source = lineage['sources'][f'{budget}:{seed}']
        source_state = source_states[budget, seed]
        backbone = {key[len('backbone.'):]: value for key, value in weights.items()
                    if key.startswith('backbone.')} if refined else weights
        refiner = {key[len('refiner.'):]: value for key, value in weights.items()
                   if key.startswith('refiner.')} if refined else None
        detail = {key[len('detail.'):]: value for key, value in weights.items() if key.startswith('detail.')}
        high = next(item for item in high_rows if item['budget'] == budget and item['seed'] == seed)
        low = next(item for item in low_rows if item['budget'] == budget and item['seed'] == seed)
        metadata_ok &= (checkpoint['settings'] == row and row['candidate'] == 'film_native_detail' and row['steps'] == 500 and
                        row['source_initial'] == source and high['source_initial'] == low['source_initial'] == source and
                        high_frozen['lineage']['sources'][f'{budget}:{seed}'] == source)
        final_states_ok &= (digest(source_state) == source['backbone_sha256'] == row['backbone_before_sha256'] and
                            digest(backbone) == row['backbone_after_sha256'] != row['backbone_before_sha256'])
        expected_count = 21506
        counts_ok &= (row['trainable_parameters'] == row['total_parameters'] == expected_count and
                      sum(value.numel() for value in weights.values()) == expected_count and
                      all(torch.isfinite(value).all().item() for value in weights.values()))
        batches_ok &= expected_batch_digest(budget, seed) == row['batch_sequence_sha256'] == high['batch_sequence_sha256'] == low['batch_sequence_sha256']
        optimizer_ok &= (row['backbone_learning_rate'] == .0001 and
                         row['refiner_learning_rate'] == (.0005 if refined else None) and
                         row['CNN_updates'] == (400 if refined else 500) and
                         row['refiner_updates'] == (500 if refined else 0) and
                         row['warmup_steps'] == (100 if refined else 0) and
                         row['joint_steps'] == (400 if refined else 0) and
                         row['optimizer_groups'] == ([
                             dict(parameters='backbone', learning_rate=.0001, update_steps=[101, 500]),
                             dict(parameters='refiner', learning_rate=.0005, update_steps=[1, 500]),
                             dict(parameters='detail', learning_rate=.0005, update_steps=[1, 500])] if refined else [
                             dict(parameters='backbone', learning_rate=.0001, update_steps=[1, 500])]))
        if refined:
            initial = model_module.make_model(arm, source_state, decoder_seed=seed + 100003)
            initialization_ok &= digest(initial.refiner.state_dict()) == row['decoder_initial_sha256']
            initialization_ok &= digest(refiner) == row['decoder_final_sha256'] != row['decoder_initial_sha256']
            counts_ok &= sum(value.numel() for value in refiner.values()) == 8993
            previous = prior_model.make_model('joint' if arm == 'native_joint' else 'plain',
                                              source_state, decoder_seed=seed + 100003)
            old_head = previous.refiner.state_dict(); new_head = initial.refiner.state_dict()
            prior_preserved_ok &= (new_head['visual.0.weight'].shape == (16, 50, 3, 3) and
                torch.equal(new_head['visual.0.weight'][:, :26], old_head['visual.0.weight']) and
                bool(torch.count_nonzero(new_head['visual.0.weight'][:, 26:]) == 0) and
                all(torch.equal(new_head[key], value) for key, value in old_head.items() if key != 'visual.0.weight'))
            prior_preserved_ok &= bool(torch.count_nonzero(refiner['visual.0.weight'][:, 26:]) > 0)
            detail_route_ok &= row['detail_source'] == ('upsampled_X12' if arm == 'lowres_plain' else 'native48')
            detail_states_ok &= (digest(initial.detail.state_dict()) == row['detail_initial_sha256'] and
                digest(detail) == row['detail_final_sha256'] != row['detail_initial_sha256'] and
                digest(checkpoint['warmup_detail']) == row['detail_after_warmup_sha256'] != row['detail_initial_sha256'])
            counts_ok &= (row['refiner_parameters'] == 8993 and row['detail_parameters'] == 1832 and
                          row['new_parameters'] == 10825 and sum(value.numel() for value in detail.values()) == 1832)
            warmup_ok &= (digest(checkpoint['warmup_backbone']) == row['backbone_after_warmup_sha256'] ==
                          row['backbone_before_sha256'] and
                          all(torch.equal(value, source_state[key]) for key, value in checkpoint['warmup_backbone'].items()) and
                          digest(checkpoint['warmup_refiner']) == row['decoder_after_warmup_sha256'] != row['decoder_initial_sha256'])
            with torch.no_grad():
                identity = initial.forward_details(images[:2], native_images[:2])
                initialization_ok &= torch.equal(identity['logits'], identity['coarse'])
            initial.zero_grad(set_to_none=True)
            initial.train()
            warmup = initial.forward_details(images[:2], native_images[:2])
            warmup['logits'].sum().backward()
            gradient_ok &= (all(parameter.grad is None for parameter in initial.backbone.parameters()) and
                any(parameter.grad is not None and bool(parameter.grad.abs().sum() > 0) for parameter in initial.refiner.parameters()))
            initial.load_state_dict(weights, strict=True)
            initial.set_backbone_trainable(True); initial.zero_grad(set_to_none=True)
            live_inputs = initial.current_inputs(images[:2], native_images[:2])
            live = initial._refine(live_inputs)
            gradient_ok &= (live_inputs['visual'].requires_grad and live_inputs['coarse'].requires_grad and
                            not live_inputs['maps'].requires_grad and not live_inputs['maps_raw'].requires_grad and
                            live_inputs['detail_features'].requires_grad)
            expected_detail_input = (images[:2].repeat_interleave(4, -2).repeat_interleave(4, -1) if arm == 'lowres_plain'
                                     else 5 * (native_images[:2].to(dtype=torch.float32) / 255 - .2))
            detail_route_ok &= (torch.equal(live_inputs['detail_input'], expected_detail_input) and
                torch.equal(live_inputs['visual'][:, 26:], live_inputs['detail_features']))
            grad = torch.autograd.grad(live['logits'].square().mean(), list(initial.backbone.parameters()), retain_graph=True)
            gradient_ok &= all(torch.isfinite(value).all().item() for value in grad) and any(bool(value.abs().sum() > 0) for value in grad)
            detail_grad = torch.autograd.grad(live['logits'].square().mean(), list(initial.detail.parameters()), retain_graph=True)
            detail_gradient_ok &= all(torch.isfinite(value).all().item() for value in detail_grad) and any(bool(value.abs().sum() > 0) for value in detail_grad)
            visual_path = torch.autograd.grad(live['correction'].square().mean(), live_inputs['visual'], retain_graph=True)[0]
            coarse_path = torch.autograd.grad(live['logits'].sum(), live_inputs['coarse'])[0]
            gradient_ok &= (bool(visual_path.abs().sum() > 0) and bool(coarse_path.abs().sum() > 0) and
                            bool(visual_path[:, 26:].abs().sum() > 0))
            initial.train()
            try:
                initial.forward_cached({key: value.detach() for key, value in live_inputs.items()})
            except AssertionError:
                pass
            else:
                cache_guard_ok = False
            evidence.append(dict(budget=budget, seed=seed, arm=arm, maps_detached=True,
                visual_gradient_sum=float(visual_path.abs().sum()), detail_feature_gradient_sum=float(visual_path[:, 26:].abs().sum()),
                detail_parameter_gradient_sum=float(sum(value.abs().sum() for value in detail_grad)),
                coarse_gradient_sum=float(coarse_path.abs().sum()),
                backbone_gradient_sum=float(sum(value.abs().sum() for value in grad))))
        else:
            warmup_ok &= row['backbone_after_warmup_sha256'] is None
            initialization_ok &= row['decoder_initial_sha256'] is None and row['decoder_final_sha256'] is None
        with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
            arrays = {key: archive[key] for key in archive.files}
        variants = VARIANTS if refined else ['actual']
        metadata_ok &= (arrays['variants'].tolist() == variants and arrays['thresholds'].tolist() == config['thresholds'] and
            np.array_equal(arrays['truth'], truth) and np.array_equal(arrays['target'], target) and
            arrays['logits'].shape == (len(variants), 695, 1, 12, 12) and
            arrays['probability'].shape == (len(variants), 695, 12, 12) and
            np.isfinite(arrays['logits']).all() and np.isfinite(arrays['probability']).all())
        logits, fixture_reference = independent_predictions(weights, arm, images, native_images, circuit)
        errors['forward'] = max(errors['forward'], float(np.max(np.abs(logits - arrays['logits']))))
        errors['probabilities'] = max(errors['probabilities'], float(np.max(np.abs(
            torch.tensor(arrays['logits'][:, :, 0]).sigmoid().numpy() - arrays['probability']))))
        with np.load(folder / 'fixtures' / f'{stem}.npz', allow_pickle=False) as archive:
            fixture = {key: archive[key] for key in archive.files}
        fixtures_ok &= (np.array_equal(fixture['x'], images[:16].numpy()) and
                        np.array_equal(fixture['native_uint8'], native_images[:16].numpy()) and fixture['variants'].tolist() == variants)
        errors['forward'] = max(errors['forward'], float(np.max(np.abs(logits[:, :16] - fixture['full_logits']))))
        if refined:
            errors['detail_input'] = max(errors['detail_input'], float(np.max(np.abs(
                fixture_reference['detail_input'] - fixture['detail_input']))))
            for key in ['visual', 'coarse', 'detail_features']:
                errors['fixture_inputs'] = max(errors['fixture_inputs'], float(np.max(np.abs(fixture_reference[key] - fixture[key]))))
            errors['maps'] = max(errors['maps'], float(np.max(np.abs(fixture_reference['maps_raw'] - fixture['maps_raw']))))
            errors['normalization'] = max(errors['normalization'], float(np.max(np.abs(
                normalized_maps(fixture['maps_raw']) - fixture['maps']))))
        all_scores = []
        for index, variant in enumerate(variants):
            scores = []
            for ti, threshold in enumerate(config['thresholds']):
                masks = arrays['probability'][index] >= threshold
                prediction = classify(masks)
                predictions_ok &= np.array_equal(prediction, arrays['predictions'][index, ti])
                predictions_ok &= np.array_equal(np.packbits(masks.reshape(695, 144), axis=1), arrays['packed_masks'][index, ti])
                score = dict(threshold=threshold, mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target))
                scores.append(score); metric_error(score, row['VAL_scores_all_thresholds'][variant][ti])
            all_scores.append(scores)
        winner = selected(all_scores[0]); metric_error(winner, row['selected'])
        selection_ok &= winner['threshold'] == float(arrays['selected_threshold'])
        ti = config['thresholds'].index(winner['threshold'])
        actual_masks = arrays['probability'][0] >= winner['threshold']
        for index, variant in enumerate(variants):
            observation = dict(**all_scores[index][ti],
                mask_flip_fraction=float(np.mean((arrays['probability'][index] >= winner['threshold']) != actual_masks)),
                logit_mean_absolute_difference=float(np.abs(arrays['logits'][index] - arrays['logits'][0]).mean()),
                logit_max_absolute_difference=float(np.abs(arrays['logits'][index] - arrays['logits'][0]).max()))
            metric_error(observation, row['ablations'][variant])
        recomputed_rows.append(dict(budget=budget, seed=seed, arm=arm, selected=winner))
    checks.update(all_saved_metadata_and_exact_control_pairing=bool(metadata_ok),
        all_source_initializations_identity_and_final_head_digests=bool(initialization_ok),
        all_backbones_finite_and_changed_from_exact_source=bool(final_states_ok),
        all_10681_8993_1832_10825_21506_parameter_counts=bool(counts_ok),
        previous_head_weights_exactly_preserved_added_kernels_zero_then_updated=bool(prior_preserved_ok),
        identical_capacity_native_or_upsampled_input_normalization=bool(detail_route_ok) and errors['detail_input'] < 1e-6,
        detail_initial_warmup_final_states_and_500_updates=bool(detail_states_ok),
        dynamic_detail_parameter_and_feature_gradients=bool(detail_gradient_ok),
        saved_step100_backbone_exactly_frozen_and_head_updated=bool(warmup_ok),
        fixed_learning_rates_400_CNN_500_head_updates=bool(optimizer_ok),
        all_500_minibatch_sequences_reconstructed_and_control_paired=bool(batches_ok),
        dynamic_detached_maps_and_live_visual_coarse_backbone_gradients=bool(gradient_ok),
        cached_training_forward_rejected=bool(cache_guard_ok),
        current_CNN_current_maps_functional_forward_parity=errors['forward'] < 1e-4,
        current_fixture_live_CNN_parity=errors['fixture_inputs'] < 1e-4 and bool(fixtures_ok),
        current_physical_map_parity=errors['maps'] < 1e-4,
        independent_float64_normalization_parity=errors['normalization'] < 1e-5,
        sigmoid_probability_parity=errors['probabilities'] < 3e-7,
        all_VAL_classes_masks_thresholds_and_interventions_recomputed=bool(predictions_ok and selection_ok) and errors['metrics'] < 2e-7)
    paired = True
    for budget in [18, 27]:
        for seed in seeds:
            group = [row for row in rows if row['budget'] == budget and row['seed'] == seed]
            refiners = [row for row in group if row['arm'] in ARMS]
            paired &= (len({row['decoder_initial_sha256'] for row in refiners}) == 1 and
                       len({row['detail_initial_sha256'] for row in refiners}) == 1 and
                       len({row['backbone_before_sha256'] for row in group}) == 1 and
                       len({row['batch_sequence_sha256'] for row in group}) == 1)
    checks['plain_joint_initializations_and_all_arm_batches_matched'] = bool(paired)
    gates = independent_gates(recomputed_rows, low_rows, high_rows, config)
    checks['dual_control_architecture_and_physics_gates_recomputed'] = compare_stored_gates(gates, result['gates']) < 2e-7
    replication = {}
    if phase == 'replicate':
        aggregate = read_local('AGGREGATE_RESULT.json')
        previous = ROOT / aggregate['source_trials'][0]
        old = json.loads((previous / 'RESULT.json').read_text())
        old_audit = json.loads((previous / 'AUDIT.json').read_text())
        checks['valid_screen_and_exact_three_seed_aggregation'] = (
            old_audit['status'] == 'PASS_AUDIT' and old_audit['result_sha256'] == sha(previous / 'RESULT.json') and
            old['phase'] == 'screen' and old['seeds'] == [5501] and old['gates']['A_any'] and
            old['signature'] == result['signature'] == aggregate['signature'] and
            aggregate['seeds'] == [5501, 5521, 5557] and aggregate['rows'] == old['rows'] + rows and
            aggregate['high_lr_controls'] == old['high_lr_controls'] + high_rows and
            aggregate['low_lr_controls'] == old['low_lr_controls'] + low_rows and
            len({(row['budget'], row['seed'], row['arm']) for row in aggregate['rows']}) == 18)
        all_gates = independent_gates(old['rows'] + recomputed_rows, old['low_lr_controls'] + low_rows,
                                      old['high_lr_controls'] + high_rows, config)
        checks['all_three_and_new_two_seed_gates_recomputed'] = (
            compare_stored_gates(all_gates, aggregate['gates']) < 2e-7 and
            compare_stored_gates(gates, aggregate['new_seed_gates']) < 2e-7)
        surviving = {arm: all_gates['A_architecture'][arm]['passed'] and gates['A_architecture'][arm]['passed']
                     for arm in ARMS}
        checks['robust_architecture_gate_requires_same_arm_on_both_seed_groups'] = (
            aggregate['robust_architecture_pass'] == any(surviving.values()) and
            aggregate['robust_architecture_by_arm'] == surviving)
        replication = dict(new_two_seeds=gates, all_three_seeds=all_gates,
                           architecture_passes_all_and_new_seeds=surviving)
    checks['all_inputs_unchanged_by_audit'] = all(sha(path) == value for path, value in before.items())
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        scope='INDEPENDENT_CPU_AUDIT_ADAPTIVE_REUSED_TRAIN_VAL_ONLY',
        trial=str(folder.relative_to(ROOT)), phase=phase, seeds=seeds,
        audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        high_lr_result_sha256=sha(high_path), high_lr_audit_sha256=sha(high_path.parent / 'AUDIT.json'),
        low_lr_controls=low_audits, native_data_audit=native_audit,
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        maximum_errors=errors, gradient_evidence=evidence, independent_gates=gates, replication=replication,
        unique_masks_independently_classified=len(_CLASS_CACHE), seconds=time.monotonic() - started,
        caveat='Repeated adaptive VAL development; gates do not confirm TEST superiority, statistical significance, publication novelty, or causal physical-map benefit.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trial', type=Path, help='Completed trial directory, relative to this folder or absolute.')
    parser.add_argument('--data-only', action='store_true', help='Audit native image alignment without model checkpoints.')
    args = parser.parse_args()
    if args.data_only:
        _, _, outcome = audit_native_data()
        destination = ROOT / 'NATIVE_AUDIT.json'
        if destination.exists():
            previous = json.loads(destination.read_text())
            assert previous['native_archive_sha256'] == outcome['native_archive_sha256']
            if previous['audit_source_sha256'] != outcome['audit_source_sha256']:
                archive = ROOT / f"NATIVE_AUDIT_PREVIOUS_{previous['audit_source_sha256'][:12]}.json"
                assert not archive.exists()
                destination.rename(archive)
            else:
                outcome = previous
        if not destination.exists():
            destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
        print(json.dumps(outcome), flush=True)
        assert outcome['status'] == 'PASS_NATIVE_DATA_AUDIT'
        return
    folders = [args.trial if args.trial.is_absolute() else ROOT / args.trial] if args.trial else sorted(
        path.parent for path in (ROOT / 'trials').glob('*/RESULT.json'))
    assert folders, 'No completed development trial exists yet'
    torch.set_num_threads(2)
    outcomes = []
    with threadpool_limits(limits=2):
        for folder in folders:
            destination = folder / 'AUDIT.json'
            if destination.exists():
                previous = json.loads(destination.read_text())
                assert previous['result_sha256'] == sha(folder / 'RESULT.json')
                if previous['audit_source_sha256'] == sha(__file__):
                    outcome = previous
                else:
                    archive = folder / f"AUDIT_PREVIOUS_{previous['audit_source_sha256'][:12]}.json"
                    assert not archive.exists()
                    destination.rename(archive)
                    outcome = audit_trial(folder)
                    destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
            else:
                outcome = audit_trial(folder)
                destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
            outcomes.append(outcome)
            print(json.dumps({key: outcome[key] for key in ['status', 'trial', 'checks_passed', 'checks_total',
                  'maximum_errors', 'independent_gates', 'replication', 'seconds']}, ensure_ascii=False), flush=True)
    assert all(outcome['status'] == 'PASS_AUDIT' for outcome in outcomes)


if __name__ == '__main__':
    main()
