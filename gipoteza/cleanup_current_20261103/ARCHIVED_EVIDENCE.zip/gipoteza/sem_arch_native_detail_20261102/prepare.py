"""Recover exactly the historical1901 TRAIN/VAL native48 crops, never TEST.

No labels or masks are created or changed. PNG reads are restricted to frames
0..7 and frozen TRAIN/VAL coordinates. Every4x4 reduction must reproduce the
existing X12 array bit-for-bit before a new archive may be committed.
"""
from pathlib import Path
import hashlib
import json
import os

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
REPO = G.parent
TRAIN_VAL = G / "sem_architecture_pilot_20261102/TRAIN_VAL.npz"
MANIFEST = G / "sem_scarcity_20261102/DATA_MANIFEST.json"
SOURCES = G / "sem_confirmation_20261028/sources"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    tmp = path.with_suffix(path.suffix + f".{os.getpid()}.partial")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    tmp.replace(path)


def main():
    config = json.loads((ROOT / "CONFIG.json").read_text())
    assert config["candidate"] == "film_native_detail"
    assert config["native_archive"] == "NATIVE_TRAIN_VAL.npz"
    assert config["protocol_sha256"] == sha(ROOT / "PROTOCOL.md")
    archive = ROOT / config["native_archive"]
    lineage_path = ROOT / "NATIVE_LINEAGE.json"
    if archive.exists() or lineage_path.exists():
        assert archive.exists() and lineage_path.exists(), "Incomplete native preparation; do not overwrite"
        lineage = json.loads(lineage_path.read_text())
        assert lineage["archive_sha256"] == sha(archive)
        assert lineage["TRAIN_VAL_sha256"] == sha(TRAIN_VAL)
        assert lineage["prepare_sha256"] == sha(Path(__file__))
        assert lineage["protocol_sha256"] == sha(ROOT / "PROTOCOL.md")
        assert all(sha(REPO / row["file"]) == row["sha256"] for row in lineage["source_files"])
        print(json.dumps(dict(status="VERIFIED_EXISTING_NATIVE_TRAIN_VAL", **lineage)), flush=True)
        return
    records = json.loads(MANIFEST.read_text())["records"][:1901]
    with np.load(TRAIN_VAL, allow_pickle=False) as z:
        # Do not load Y: native preparation is image-only and does not need
        # any dense or weak masks.
        x, roles, frames, labels = (z[key].copy() for key in ["X", "role", "frame", "label"])
    assert x.shape == (1901, 1, 12, 12)
    assert len(records) == 1901 and set(roles) == {"dense", "weak", "val"}
    assert set(frames.tolist()) == set(range(8))
    assert all((row["frame"], row["role"], row["label"]) ==
        (int(frames[i]), str(roles[i]), int(labels[i])) for i, row in enumerate(records))
    native = np.empty((1901, 1, 48, 48), dtype=np.uint8)
    source_files = []
    exact = 0
    maximum = 0.
    for frame in range(8):
        path = SOURCES / f"sem{frame:04}.png"
        image = np.asarray(Image.open(path))
        assert image.shape == (3536, 4096) and image.dtype == np.uint8
        source_files.append(dict(frame=frame, file=str(path.relative_to(REPO)), sha256=sha(path)))
        for index in np.flatnonzero(frames == frame):
            row = records[int(index)]
            y, xx = int(row["y"]), int(row["x"])
            crop = image[y:y + 48, xx:xx + 48]
            assert crop.shape == (48, 48)
            reduced = crop.reshape(12, 4, 12, 4).sum((1, 3)).astype(np.float32) / (16 * 255)
            maximum = max(maximum, float(np.abs(reduced - x[index, 0]).max()))
            assert np.array_equal(reduced, x[index, 0]), f"Native/X12 mismatch row{index}"
            native[index, 0] = crop
            exact += 1
    assert exact == 1901 and maximum == 0.
    arrays = dict(native_uint8=native, row_index=np.arange(1901, dtype=np.int64),
        frame=frames, role=roles, y=np.array([row["y"] for row in records], dtype=np.int64),
        x=np.array([row["x"] for row in records], dtype=np.int64))
    temporary = archive.with_suffix(".npz.partial")
    with temporary.open("wb") as handle:
        np.savez_compressed(handle, **arrays)
    temporary.replace(archive)
    records_sha = hashlib.sha256(json.dumps(records, sort_keys=True,
        separators=(",", ":")).encode()).hexdigest()
    lineage = dict(scope="TRAIN_VAL_ONLY_NATIVE_CROPS_NO_TEST", archive=archive.name,
        archive_sha256=sha(archive), fields=list(arrays), shape=list(native.shape), dtype=str(native.dtype),
        TRAIN_VAL_sha256=sha(TRAIN_VAL), metadata_file=str(MANIFEST.relative_to(REPO)),
        metadata_sha256=sha(MANIFEST), first1901_records_sha256=records_sha,
        source_files=source_files, protocol_sha256=sha(ROOT / "PROTOCOL.md"),
        prepare_sha256=sha(Path(__file__)), exact_4x4_reductions=exact,
        max_absolute_reconstruction_error=maximum,
        crop_rule="source_png[y:y+48,x:x+48] from first1901 inherited records",
        normalization="native:5*(uint8/255-.2);lowres:nearest_x4(5*(X12-.2))",
        labels_and_masks="unchanged original TRAIN_VAL; none stored in native archive")
    save(lineage_path, lineage)
    print(json.dumps(dict(status="PREPARED_NATIVE_TRAIN_VAL", **lineage)), flush=True)


if __name__ == "__main__":
    main()
