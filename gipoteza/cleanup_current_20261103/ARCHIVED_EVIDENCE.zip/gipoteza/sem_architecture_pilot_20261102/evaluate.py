"""One frozen EVAL comparison after all training and VAL threshold selection."""
from pathlib import Path
import csv
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

import train as t
from model import make_model

ROOT=Path(__file__).resolve().parent
ARMS=['base','plain','first_order','independent','joint']
BUDGETS=[18,27]
SEEDS=[5501,5521,5557]
MODES=['calibrated','fixed05']


def save(name,value):
    t.save(ROOT/name,value)


def macro(confusion):
    denominator=confusion.sum(-1)+confusion.sum(-2)
    numerator=2*np.diagonal(confusion,axis1=-2,axis2=-1)
    return np.divide(numerator,denominator,out=np.zeros_like(numerator,dtype=float),where=denominator>0).mean(-1)


def crossed_bootstrap(confusion,seed_ids,frame_ids):
    """Confusion B,S,A,F,9,9; pair both budgets, all arms and all draws."""
    repeats=len(seed_ids)
    output=np.empty((2,5,repeats),dtype=float)
    for b in range(2):
        for start in range(0,repeats,128):
            end=min(start+128,repeats)
            s=seed_ids[start:end];f=frame_ids[start:end]
            selected=confusion[b][s[:,:,None],:,f[:,None,:]]
            assert selected.shape==(end-start,3,8,5,9,9)
            output[b,:,start:end]=macro(selected.sum(2)).mean(1).T
    return output


def bootstrap_fixture():
    """Numerical indexing check on synthetic data, without opening EVAL."""
    rng=np.random.default_rng(1721)
    confusion=rng.integers(0,20,(2,3,5,8,9,9))
    seeds=rng.integers(0,3,(7,3));frames=rng.integers(0,8,(7,8))
    actual=crossed_bootstrap(confusion,seeds,frames);error=0.
    for b in range(2):
        for a in range(5):
            for r in range(7):
                reference=np.mean([macro(confusion[b,s,a,frames[r]].sum(0)) for s in seeds[r]])
                error=max(error,abs(reference-actual[b,a,r]))
    assert error<1e-14
    return float(error)


def main():
    started=time.monotonic()
    assert torch.backends.mps.is_available(), 'Explicit MPS evaluation required'
    assert not (ROOT/'RESULT.json').exists() and not (ROOT/'PREDICTIONS.npz').exists(), 'Do not overwrite frozen TEST evaluation'
    torch.set_num_threads(2);c=t.config()
    assert c['arms']==ARMS and c['budgets']==BUDGETS and c['seeds']==SEEDS
    complete=json.loads((ROOT/'TRAINING_COMPLETE.json').read_text())
    assert complete['status']=='COMPLETE_TRAINING_NO_TEST_OPENED'
    assert complete['models']==30 and complete['updates']==c['total_joint_updates']==15000
    checks=t.verify_frozen()
    assert len(complete['checkpoint_hashes'])==30
    selection=json.loads((ROOT/'SELECTION.json').read_text())
    assert selection['status']=='FROZEN_BEFORE_TEST' and selection['selection_uses_TEST'] is False
    index=json.loads((ROOT/'EVAL_INDEX.json').read_text())
    assert index['status']=='PASS_EVAL_DATA_GATE' and all(index['gates'].values())
    assert t.sha(ROOT/'EVAL.npz')==index['EVAL_sha256']
    fixture_error=bootstrap_fixture()
    # Freeze before the first model sees any EVAL tensor.
    frozen=dict(script_sha256=t.sha(Path(__file__)),
        training_complete_sha256=t.sha(ROOT/'TRAINING_COMPLETE.json'),
        selection_sha256=t.sha(ROOT/'SELECTION.json'),
        frozen_sha256=t.sha(ROOT/'FROZEN.json'),
        protocol_sha256=t.sha(ROOT/'PROTOCOL.md'),config_sha256=t.sha(ROOT/'CONFIG.json'),
        EVAL_sha256=t.sha(ROOT/'EVAL.npz'),evaluation_index_sha256=t.sha(ROOT/'EVAL_INDEX.json'),
        bootstrap_repetitions=10000,bootstrap_seed=281102,
        initial_checkpoints=6,final_checkpoints=30,input_checks=checks,
        primary_budgets=[18,27],primary_controls=ARMS[:-1],
        modes=MODES,bootstrap_fixture_max_error=fixture_error)
    save('EVALUATION_FROZEN.json',frozen)
    with np.load(ROOT/'EVAL.npz',allow_pickle=False) as z:
        x=z['X'];target=z['Y'][:,0].astype(bool);truth=z['label'];frames=z['frame']
    frame_values,gid=np.unique(frames,return_inverse=True)
    assert len(truth)==index['examples']==2048
    assert len(frame_values)==8 and set(frame_values)==set(c['test_frames'])
    n=len(truth)
    predictions=np.empty((2,3,5,2,n),dtype=np.int64)
    packed_masks=np.empty((2,3,5,2,n,18),dtype=np.uint8)
    ious=np.empty((2,3,5,2,n),dtype=np.float64)
    probs_fixture=np.empty((2,3,5,16,1,12,12),dtype=np.float32)
    coarse_fixture=np.empty_like(probs_fixture)
    maps_fixture=np.full((2,3,5,16,2,12,12),np.nan,dtype=np.float32)
    actions_fixture=np.full((2,3,5,16,3,12,12),np.nan,dtype=np.float32)
    confusion=np.zeros((2,3,5,2,8,9,9),dtype=np.int64)
    path_error=np.empty((2,3,5,2),dtype=float)
    rows=[];corrections={};completed=0
    true_presence=np.column_stack((truth//3>0,truth%3>0))
    for b,budget in enumerate(BUDGETS):
        for s,seed in enumerate(SEEDS):
            for a,arm in enumerate(ARMS):
                chosen=selection['chosen'][str(budget)][str(seed)][arm]
                name=f'final_b{budget}_{arm}_s{seed}.pt'
                assert chosen['checkpoint']==name
                payload=torch.load(ROOT/'models'/name,map_location='cpu',weights_only=True)
                assert payload['settings']['budget']==budget and payload['settings']['seed']==seed and payload['settings']['arm']==arm
                assert payload['settings']['threshold']==chosen['threshold']
                net=make_model(arm,epsilon=c['epsilon'],eta=c['eta']).to('mps')
                net.load_state_dict(payload['model'],strict=True);net.eval()
                probabilities=[];correction_abs=0.;correction_max=0.;map_sum=np.zeros(2);map_max=np.zeros(2)
                with torch.inference_mode():
                    for offset in range(0,n,16):
                        batch=torch.tensor(5*(x[offset:offset+16]-.2),device='mps')
                        detail=net.forward_details(batch)
                        p=detail['logits'].sigmoid().cpu().numpy()
                        probabilities.append(p[:,0])
                        delta=detail['correction'].cpu().numpy()
                        correction_abs+=float(np.abs(delta).sum());correction_max=max(correction_max,float(np.abs(delta).max()))
                        if offset==0:
                            probs_fixture[b,s,a]=p[:16]
                            coarse_fixture[b,s,a]=detail['coarse'][:16].sigmoid().cpu().numpy()
                        if detail['maps'] is not None:
                            maps=detail['maps'].cpu().numpy()
                            map_sum+=maps.sum((0,2,3));map_max=np.maximum(map_max,maps.max((0,2,3)))
                            if offset==0:
                                maps_fixture[b,s,a]=maps[:16]
                                actions_fixture[b,s,a]=detail['actions'][:16].cpu().numpy()
                probability=np.concatenate(probabilities)
                assert np.isfinite(probability).all()
                corrections[name]=dict(mean_absolute_logit_correction=correction_abs/(n*144),
                    maximum_absolute_logit_correction=correction_max,
                    conditioning_mean=None if arm=='base' else (map_sum/(n*144)).tolist(),
                    conditioning_max=None if arm=='base' else map_max.tolist())
                for m,threshold in enumerate([chosen['threshold'],.5]):
                    masks=probability>=threshold;prediction=t.hard_classes(masks)
                    predictions[b,s,a,m]=prediction
                    packed_masks[b,s,a,m]=np.packbits(masks.reshape(n,144),axis=1)
                    union=(masks|target).sum((1,2))
                    iou=np.divide((masks&target).sum((1,2)),union,out=np.ones(n),where=union>0)
                    ious[b,s,a,m]=iou
                    presence=np.column_stack((prediction//3>0,prediction%3>0))
                    path_error[b,s,a,m]=float(np.any(presence!=true_presence,axis=1).mean())
                    for f in range(8):
                        keep=gid==f
                        confusion[b,s,a,m,f]=np.bincount(9*truth[keep]+prediction[keep],minlength=81).reshape(9,9)
                    rows.append(dict(budget=budget,seed=seed,arm=arm,mode=MODES[m],threshold=threshold,
                        mask_F1=float(macro(confusion[b,s,a,m].sum(0))),IoU=float(iou.mean()),
                        path_error=float(path_error[b,s,a,m]),checkpoint=name,
                        checkpoint_sha256=complete['checkpoint_hashes'][name]))
                completed+=1
                progress=dict(stage='EVAL_INFERENCE',completed_models=completed,total_models=30,
                    budget=budget,seed=seed,arm=arm,seconds=time.monotonic()-started)
                save('EVALUATION_PROGRESS.json',progress);print(json.dumps(progress),flush=True)
                del net
    saved=dict(predictions=predictions,packed_masks=packed_masks,ious=ious,
        probs_fixture=probs_fixture,coarse_fixture=coarse_fixture,maps_fixture=maps_fixture,
        actions_fixture=actions_fixture,truth=truth,frames=frames,arms=np.array(ARMS),seeds=np.array(SEEDS),
        budgets=np.array(BUDGETS),modes=np.array(MODES),truth_packed=np.packbits(target.reshape(n,144),axis=1),
        local_TEST_indices=np.array(index['local_TEST_indices'],dtype=np.int64))
    np.savez_compressed(ROOT/'PREDICTIONS.npz',**saved)
    with (ROOT/'final_test_results.csv').open('w',newline='') as h:
        writer=csv.DictWriter(h,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    point_per_model=macro(confusion.sum(4)) # B,S,A,M
    metrics={};secondary={}
    for b,budget in enumerate(BUDGETS):
        metrics[str(budget)]={};secondary[str(budget)]={}
        for a,arm in enumerate(ARMS):
            for m,section in enumerate([metrics,secondary]):
                section[str(budget)][arm]=dict(mask_F1=float(point_per_model[b,:,a,m].mean()),
                    IoU=float(ious[b,:,a,m].mean()),path_error=float(path_error[b,:,a,m].mean()),
                    per_seed_mask_F1=point_per_model[b,:,a,m].tolist(),
                    per_seed_IoU=ious[b,:,a,m].mean(1).tolist(),
                    per_seed_path_error=path_error[b,:,a,m].tolist())
    rng=np.random.default_rng(281102)
    seed_ids=rng.integers(0,3,(10000,3));frame_ids=rng.integers(0,8,(10000,8))
    scores=crossed_bootstrap(confusion[:,:,:,0],seed_ids,frame_ids)
    primary_draws=scores.mean(0)
    primary={arm:{key:float(np.mean([metrics[str(b)][arm][key] for b in BUDGETS]))
                   for key in ['mask_F1','IoU','path_error']} for arm in ARMS}
    comparisons={};budget_comparisons={}
    for a,arm in enumerate(ARMS[:-1]):
        distribution=primary_draws[4]-primary_draws[a]
        interval=np.quantile(distribution,[.00625,.99375])
        delta=primary['joint']['mask_F1']-primary[arm]['mask_F1']
        iou_delta=primary['joint']['IoU']-primary[arm]['IoU']
        individual=[metrics[str(b)]['joint']['mask_F1']-metrics[str(b)][arm]['mask_F1'] for b in BUDGETS]
        comparisons[arm]=dict(delta=float(delta),CI98_75=interval.tolist(),
            CI95_nominal=np.quantile(distribution,[.025,.975]).tolist(),IoU_delta=float(iou_delta),
            budget18_27_deltas=individual,gates=dict(gain_at_least_one_pp=bool(delta>=.01),
            positive_multiplicity_adjusted_CI_lower=bool(interval[0]>0),
            both_budget_means_nonnegative=bool(min(individual)>=0),IoU_guard=bool(iou_delta>=-.005)))
        budget_comparisons[arm]={str(b):dict(delta=metrics[str(b)]['joint']['mask_F1']-metrics[str(b)][arm]['mask_F1'],
            CI95_nominal=np.quantile(scores[bi,4]-scores[bi,a],[.025,.975]).tolist(),
            status='Descriptive; not a replacement primary endpoint') for bi,b in enumerate(BUDGETS)}
    passed=all(all(v['gates'].values()) for v in comparisons.values())
    np.savez_compressed(ROOT/'BOOTSTRAP.npz',scores=scores,confusion=confusion[:,:,:,0],
        seed_ids=seed_ids,frame_ids=frame_ids)
    result=dict(status='PASS_PILOT' if passed else 'FAIL_PILOT',
        test_examples=n,test_frames=frame_values.tolist(),test_class_counts=np.bincount(truth,minlength=9).tolist(),
        arms=ARMS,budgets=BUDGETS,seeds=SEEDS,primary_budgets=BUDGETS,primary_controls=ARMS[:-1],
        metrics=metrics,secondary_fixed05=secondary,primary_metrics=primary,joint_minus_control=comparisons,
        budget_comparisons_descriptive=budget_comparisons,correction_statistics=corrections,
        seconds=time.monotonic()-started,analysis_sha256=t.sha(Path(__file__)),
        predictions_sha256=t.sha(ROOT/'PREDICTIONS.npz'),bootstrap_sha256=t.sha(ROOT/'BOOTSTRAP.npz'),
        evaluation_frozen_sha256=t.sha(ROOT/'EVALUATION_FROZEN.json'),
        scope='Exploratory paired500-update refinement of six historical backbones; one fixed dense-subset draw per budget, '
              'three paired seeds, 2048 label-blind fresh-frame patches from one physical IC. Same old loss for all arms. '
              'FAIL does not reject every architecture/training regime; PASS would not establish publication novelty or production-defect recognition.')
    save('RESULT.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
