"""Paired exploratory architecture pilot. TRAIN/VAL only; never opens TEST.

All five architectures start from the same historical backbone for each unit.
Every model is fitted for the same fixed number of updates, and its threshold
is selected on VAL after that final update (no DEV-to-FINAL threshold transfer).
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import time

os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '0'
import numpy as np
import torch
from torch.nn import functional as F
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits

from model import ARMS, make_model, state_digest, architecture_spec

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
OLD = G/'sem_scarcity_20261102'
EXPECTED_TRAIN_VAL = '119cf2f5286067ad06c7e83034516abb0bd2a946383fe4c0987ba7a16fa15ade'
CLASS_CACHE = {}
START = None
COMPLETED = 0


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.partial')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
    tmp.replace(path)


def config():
    c = json.loads((ROOT/'CONFIG.json').read_text())
    assert c['arms'] == ARMS
    assert c['budgets'] == [18, 27]
    assert c['subset_seed'] == 5303
    assert c['seeds'] == [5501, 5521, 5557]
    assert c['physics_weight'] == 1.
    assert c['epsilon'] == .001 and c['eta'] == 2.
    assert c['batch_size'] == 8 and 1 <= c['steps'] <= 500
    return c


def progress(c, **details):
    row = dict(seconds=None if START is None else time.monotonic()-START,
        completed_updates=COMPLETED, total_updates=len(c['budgets'])*len(c['seeds'])*len(ARMS)*c['steps'],
        **details)
    save(ROOT/'PROGRESS.json', row)
    with (ROOT/'progress.jsonl').open('a') as h:
        h.write(json.dumps(row, ensure_ascii=False)+'\n')
    print(json.dumps(row, ensure_ascii=False), flush=True)


def hard_classes(masks):
    from prepare import class_labels
    masks = np.asarray(masks, dtype=bool).reshape(-1, 12, 12)
    keys = [r.tobytes() for r in np.packbits(masks.reshape(len(masks), 144), axis=1)]
    missing = sorted(set(keys)-CLASS_CACHE.keys())
    if missing:
        unique = np.array([np.unpackbits(np.frombuffer(k, dtype=np.uint8)).reshape(12, 12)
                           for k in missing], dtype=bool)
        CLASS_CACHE.update(zip(missing, class_labels(unique).tolist()))
    return np.array([CLASS_CACHE[k] for k in keys], dtype=np.int64)


def prepare_inputs(c):
    assert sha(OLD/'TRAIN_VAL.npz') == EXPECTED_TRAIN_VAL
    if not (ROOT/'TRAIN_VAL.npz').exists():
        shutil.copy2(OLD/'TRAIN_VAL.npz', ROOT/'TRAIN_VAL.npz')
    assert sha(ROOT/'TRAIN_VAL.npz') == EXPECTED_TRAIN_VAL
    inherited = json.loads((OLD/'SUBSETS.json').read_text())
    indices = {str(b): inherited['subsets']['final'][str(b)][str(c['subset_seed'])] for b in c['budgets']}
    subsets = dict(train_val_sha256=EXPECTED_TRAIN_VAL, subset_seed=c['subset_seed'],
                   index_space='global indices in TRAIN_VAL.npz', dense_indices=indices,
                   source_subsets_sha256=sha(OLD/'SUBSETS.json'))
    if (ROOT/'SUBSETS.json').exists():
        assert json.loads((ROOT/'SUBSETS.json').read_text()) == subsets
    else:
        save(ROOT/'SUBSETS.json', subsets)
    (ROOT/'initials').mkdir(exist_ok=True)
    initials = {}
    for b in c['budgets']:
        for seed in c['seeds']:
            name = f'final_b{b}_d{c["subset_seed"]}_soft_s{seed}.pt'
            source = OLD/'models'/name
            target = ROOT/'initials'/name
            if target.exists():
                assert sha(target) == sha(source)
            else:
                shutil.copy2(source, target)
            payload = torch.load(target, map_location='cpu', weights_only=True)
            assert payload['head'] is None and payload['settings']['family'] == 'soft'
            assert payload['settings']['physics_weight'] == c['physics_weight']
            assert payload['settings']['dense_global_indices'] == indices[str(b)]
            initials[f'{b}:{seed}'] = dict(file=str(target.relative_to(ROOT)),
                source=f'../sem_scarcity_20261102/models/{name}', sha256=sha(target),
                backbone_state_sha256=state_digest(payload['segmenter']))
    lineage = dict(status='EXACT_TRAIN_VAL_AND_INITIAL_BACKBONES', initials=initials,
        TRAIN_VAL_sha256=EXPECTED_TRAIN_VAL, SUBSETS_sha256=sha(ROOT/'SUBSETS.json'),
        scope='Historical backbones chosen by fixed seed/budget, not by previous TEST rank; exploratory refinement pilot.')
    if (ROOT/'INITIAL_LINEAGE.json').exists():
        assert json.loads((ROOT/'INITIAL_LINEAGE.json').read_text()) == lineage
    else:
        save(ROOT/'INITIAL_LINEAGE.json', lineage)
    return subsets, lineage


def load_training(device='mps'):
    # Do not replace this archive with DATA.npz: DATA includes held-out TEST.
    with np.load(ROOT/'TRAIN_VAL.npz', allow_pickle=False) as z:
        roles = z['role']; assert set(roles) == {'dense', 'weak', 'val'}
        assert {r:int((roles==r).sum()) for r in set(roles)} == {'dense':54,'weak':1152,'val':695}
        full = {}
        for role in ['dense','weak','val']:
            ids = np.flatnonzero(roles == role)
            full[role] = dict(x=torch.tensor(5*(z['X'][ids]-.2), device=device),
                              label=torch.tensor(z['label'][ids], device=device))
            if role != 'weak':
                full[role]['mask'] = torch.tensor(z['Y'][ids].astype(np.float32), device=device)
            if role == 'dense':
                full[role]['global_indices'] = ids
    assert set(full['weak']) == {'x','label'}
    return full


def subset_training(full, budget, subsets):
    chosen = subsets['dense_indices'][str(budget)]
    lookup = {int(x):i for i,x in enumerate(full['dense']['global_indices'])}
    ids = torch.tensor([lookup[i] for i in chosen], device=full['dense']['x'].device)
    dense = {k:v[ids] for k,v in full['dense'].items() if k != 'global_indices'}
    dense['global_indices'] = chosen
    assert len(dense['x']) == budget
    assert np.array_equal(np.bincount(dense['label'].cpu().numpy(), minlength=9), np.full(9,budget//9))
    return dict(dense=dense, weak=full['weak'], val=full['val'])


def initial_backbone(lineage, budget, seed):
    row = lineage['initials'][f'{budget}:{seed}']
    assert sha(ROOT/row['file']) == row['sha256']
    payload = torch.load(ROOT/row['file'], map_location='cpu', weights_only=True)
    assert state_digest(payload['segmenter']) == row['backbone_state_sha256']
    return payload['segmenter']


def fit(c, arm, budget, seed, initial, data, steps=None, emit=True):
    from physics_adapter import geometry_loss
    global COMPLETED
    steps = c['steps'] if steps is None else steps
    net = make_model(arm, initial, epsilon=c['epsilon'], eta=c['eta'], decoder_seed=seed+100003).to('mps')
    decoder_sha = None if net.actions is None else state_digest(net.actions.state_dict())
    with torch.no_grad():
        first = net.forward_details(data['dense']['x'][:2])
        assert torch.equal(first['logits'], first['coarse']), 'Identity initialization failed'
        assert torch.isfinite(first['logits']).all()
    opt = torch.optim.AdamW(net.parameters(), lr=c['learning_rate'], weight_decay=c['weight_decay'])
    rng = np.random.default_rng(seed+1000)
    batches = hashlib.sha256(); started = time.monotonic()
    for step in range(1, steps+1):
        ai = rng.integers(0, len(data['dense']['x']), c['batch_size'])
        wi = rng.integers(0, len(data['weak']['x']), c['batch_size'])
        batches.update(ai.astype(np.int64).tobytes()); batches.update(wi.astype(np.int64).tobytes())
        ai = torch.tensor(ai, device='mps'); wi = torch.tensor(wi, device='mps')
        opt.zero_grad(set_to_none=True)
        logits = net(data['dense']['x'][ai])
        dense_loss = F.binary_cross_entropy_with_logits(logits, data['dense']['mask'][ai])
        labels = data['weak']['label'][wi]
        direction = torch.stack((labels//3, labels%3), dim=1)
        weak_loss = geometry_loss(net(data['weak']['x'][wi]), direction)
        loss = dense_loss+c['physics_weight']*weak_loss
        assert torch.isfinite(loss), (arm,budget,seed,step)
        loss.backward()
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in net.parameters()), (arm,step,'gradient')
        opt.step(); COMPLETED += 1
        if emit and (step % 25 == 0 or step == steps):
            progress(c, stage='TRAIN', arm=arm, budget=budget, seed=seed, step=step,
                     target_steps=steps, model_seconds=time.monotonic()-started)
    torch.mps.synchronize()
    timing = dict(seconds=time.monotonic()-started, steps=steps, batch_sequence_sha256=batches.hexdigest(),
        initial_decoder_sha256=decoder_sha, initial_backbone_sha256=state_digest(initial),
        parameters=sum(p.numel() for p in net.parameters()),
        changed_backbone=state_digest(net.backbone.state_dict()) != state_digest(initial),
        changed_decoder=False if net.actions is None else state_digest(net.actions.state_dict()) != decoder_sha)
    return net, timing


def evaluate_val(net, data, thresholds):
    net.eval(); probabilities = []
    with torch.inference_mode():
        # Limit the physics tensor graph and CPU solve batch, even for VAL.
        for x in data['x'].split(16):
            probabilities.append(net(x)[:,0].sigmoid().cpu().numpy())
    p = np.concatenate(probabilities)
    truth = data['label'].cpu().numpy(); target = data['mask'][:,0].cpu().numpy().astype(bool)
    rows = []; predictions = []
    for threshold in thresholds:
        masks = p >= threshold; pred = hard_classes(masks)
        union = (masks | target).sum((1,2))
        iou = np.divide((masks & target).sum((1,2)), union, out=np.ones(len(union)), where=union>0)
        rows.append(dict(threshold=threshold, mask_F1=float(f1_score(truth,pred,labels=range(9),average='macro',zero_division=0)),
                         IoU=float(iou.mean())))
        predictions.append(pred)
    net.train()
    return rows, dict(probability=p, truth=truth, target=target, thresholds=np.array(thresholds),
                      predictions=np.array(predictions))


def selection_rank(row):
    return row['mask_F1'], row['IoU'], -abs(row['threshold']-.5), -row['threshold']


def source_hashes():
    names = ['train.py','model.py','smoke.py','circuit.py','physics_adapter.py','prepare.py',
             '../sem_physics_materials/physics_loss_example.py','../sem_confirmation_20261028/prepare.py',
             '../retained_evidence_20261027/SELECTED_SOURCES.zip']
    names += [n for n in ['circuit_check.py','CIRCUIT_CHECK.json'] if (ROOT/n).exists()]
    return {n:sha(ROOT/n) for n in names}


def verify_frozen():
    frozen = json.loads((ROOT/'FROZEN.json').read_text())
    checks = dict(protocol=sha(ROOT/'PROTOCOL.md')==frozen['protocol_sha256'],
        config=sha(ROOT/'CONFIG.json')==frozen['config_sha256'],
        sources=all(sha(ROOT/n)==h for n,h in frozen['source_sha256'].items()),
        train_val=sha(ROOT/'TRAIN_VAL.npz')==frozen['train_val_sha256'],
        subsets=sha(ROOT/'SUBSETS.json')==frozen['subsets_sha256'],
        data_manifest=sha(ROOT/'DATA_MANIFEST.json')==frozen['data_manifest_sha256'],
        evaluation_index=sha(ROOT/'EVAL_INDEX.json')==frozen['evaluation_index_sha256'],
        initial_lineage=sha(ROOT/'INITIAL_LINEAGE.json')==frozen['initial_lineage_sha256'],
        initial_checkpoints=all(sha(ROOT/r['file'])==r['sha256'] for r in frozen['initials'].values()))
    if (ROOT/'TRAINING_COMPLETE.json').exists():
        complete = json.loads((ROOT/'TRAINING_COMPLETE.json').read_text())
        checks.update(checkpoints=all(sha(ROOT/'models'/n)==h for n,h in complete['checkpoint_hashes'].items()),
            selection=sha(ROOT/'SELECTION.json')==complete['selection_sha256'],
            frozen=sha(ROOT/'FROZEN.json')==complete['frozen_sha256'],
            steps=complete['updates']==frozen['planned_updates'],
            models=complete['models']==30)
    if 'protected' in frozen:
        checks['protected_files'] = all(sha(G/n)==h for n,h in frozen['protected'].items())
    assert all(checks.values()),checks
    return checks


def main():
    global START,COMPLETED
    START=time.monotonic();COMPLETED=0
    assert torch.backends.mps.is_available() and os.environ['PYTORCH_ENABLE_MPS_FALLBACK']=='0'
    torch.set_num_threads(2); c=config()
    assert not (ROOT/'FROZEN.json').exists() and not (ROOT/'TRAINING_COMPLETE.json').exists(), 'Do not overwrite or silently resume a frozen run'
    assert c['protocol_sha256']==sha(ROOT/'PROTOCOL.md')
    # JSON-only data gates; neither TEST.npz nor EVAL.npz is opened by training.
    preparation=json.loads((ROOT/'PREPARE_CHECK.json').read_text())
    manifest=json.loads((ROOT/'DATA_MANIFEST.json').read_text())
    evaluation_index=json.loads((ROOT/'EVAL_INDEX.json').read_text())
    assert preparation['status']=='PASS_PREPARE_CHECK' and all(preparation['checks'].values())
    assert manifest['status']=='PASS_DATA_GATE'
    assert evaluation_index['status']=='PASS_EVAL_DATA_GATE' and all(evaluation_index['gates'].values()), 'STOP: fixed evaluation cohort failed its gate'
    smoke=json.loads((ROOT/'SMOKE_CHECK.json').read_text())
    assert smoke['status']=='PASS_SMOKE_CHECK' and all(smoke['checks'].values())
    assert smoke['source_sha256']==source_hashes(), 'Changed numerical code after smoke'
    assert smoke['training_invariants']=={k:c[k] for k in smoke['training_invariants']}, 'Changed architecture/training rules after smoke'
    subsets,lineage=prepare_inputs(c)
    protected=json.loads((ROOT/'PROTECTED_BEFORE.json').read_text()) if (ROOT/'PROTECTED_BEFORE.json').exists() else {}
    assert all(sha(G/n)==h for n,h in protected.items())
    frozen=dict(protocol_sha256=sha(ROOT/'PROTOCOL.md'),config_sha256=sha(ROOT/'CONFIG.json'),
        source_sha256=source_hashes(),train_val_sha256=sha(ROOT/'TRAIN_VAL.npz'),
        data_manifest_sha256=sha(ROOT/'DATA_MANIFEST.json'),evaluation_index_sha256=sha(ROOT/'EVAL_INDEX.json'),
        subsets_sha256=sha(ROOT/'SUBSETS.json'),initial_lineage_sha256=sha(ROOT/'INITIAL_LINEAGE.json'),
        initials=lineage['initials'],planned_updates=len(c['budgets'])*len(c['seeds'])*len(ARMS)*c['steps'],
        protected=protected,architecture=architecture_spec(),MPS=True,fallback='0',
        selection_uses_TEST=False,torch=torch.__version__,numpy=np.__version__)
    save(ROOT/'FROZEN.json',frozen)
    full=load_training(); rows=[];threshold_rows=[]; hashes={};chosen={};pair_checks={}
    (ROOT/'models').mkdir(exist_ok=True);(ROOT/'val_probs').mkdir(exist_ok=True)
    for budget in c['budgets']:
        chosen[str(budget)]={}
        data=subset_training(full,budget,subsets)
        for seed in c['seeds']:
            initial=initial_backbone(lineage,budget,seed);chosen[str(budget)][str(seed)]={}
            unit=[]
            for arm in ARMS:
                net,timing=fit(c,arm,budget,seed,initial,data)
                metrics,arrays=evaluate_val(net,data['val'],c['thresholds'])
                selected=max(metrics,key=selection_rank)
                name=f'final_b{budget}_{arm}_s{seed}.pt'
                row=dict(budget=budget,seed=seed,arm=arm,subset_seed=c['subset_seed'],
                    dense_global_indices=subsets['dense_indices'][str(budget)],
                    source_initial=lineage['initials'][f'{budget}:{seed}'],**timing,**selected)
                path=ROOT/'models'/name;tmp=path.with_suffix('.pt.partial')
                torch.save(dict(model={k:v.detach().cpu() for k,v in net.state_dict().items()},settings=row),tmp);tmp.replace(path)
                hashes[name]=sha(path)
                stem=Path(name).stem;np.savez_compressed(ROOT/'val_probs'/f'{stem}.npz',**arrays)
                rows.append(row);unit.append(row)
                threshold_rows.extend(dict(budget=budget,seed=seed,arm=arm,**m) for m in metrics)
                chosen[str(budget)][str(seed)][arm]=dict(checkpoint=name,**selected)
                save(ROOT/'FINAL_VAL_RESULTS.json',rows);save(ROOT/'VAL_THRESHOLD_RESULTS.json',threshold_rows)
                save(ROOT/'CHECKPOINT_HASHES.json',hashes)
                progress(c,stage='VAL_COMPLETE',budget=budget,seed=seed,arm=arm,completed_models=len(rows),total_models=30)
                del net
            assert len({r['initial_backbone_sha256'] for r in unit})==1
            assert len({r['batch_sequence_sha256'] for r in unit})==1
            assert len({r['initial_decoder_sha256'] for r in unit if r['arm']!='base'})==1
            pair_checks[f'{budget}:{seed}']=dict(common_backbone=True,common_batches=True,common_decoder=True)
    selection=dict(status='FROZEN_BEFORE_TEST',chosen=chosen,selection_uses_TEST=False,
        rule='Per final trained model: VAL MacroF1, IoU, closest0.5, lower threshold; no retraining',
        thresholds=c['thresholds'],VAL_results_sha256=sha(ROOT/'FINAL_VAL_RESULTS.json'),
        VAL_threshold_results_sha256=sha(ROOT/'VAL_THRESHOLD_RESULTS.json'))
    save(ROOT/'SELECTION.json',selection)
    assert len(rows)==30 and len(hashes)==30 and COMPLETED==frozen['planned_updates']
    verify_frozen()
    complete=dict(status='COMPLETE_TRAINING_NO_TEST_OPENED',seconds=time.monotonic()-START,
        updates=COMPLETED,models=len(rows),initial_checkpoint_copies=len(lineage['initials']),
        checkpoint_hashes=hashes,selection_sha256=sha(ROOT/'SELECTION.json'),
        frozen_sha256=sha(ROOT/'FROZEN.json'),pair_checks=pair_checks,
        training_archive_contains_no_TEST=True,weak_object_keys=['x','label'])
    save(ROOT/'TRAINING_COMPLETE.json',complete)
    verify_frozen();progress(c,stage='COMPLETE_TRAINING_NO_TEST_OPENED',completed_models=30,total_models=30)


if __name__=='__main__':
    with threadpool_limits(limits=2):
        main()
