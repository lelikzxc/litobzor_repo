"""Final artifact check, independent of the scientific PASS/FAIL outcome."""
from pathlib import Path
import hashlib
import json
import re
from PIL import Image

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    import train
    result = json.loads((ROOT/'RESULT.json').read_text())
    audit = json.loads((ROOT/'AUDIT.json').read_text())
    report = json.loads((ROOT/'REPORT_MANIFEST.json').read_text())
    ef = json.loads((ROOT/'EVALUATION_FROZEN.json').read_text())
    complete = json.loads((ROOT/'TRAINING_COMPLETE.json').read_text())
    config = json.loads((ROOT/'CONFIG.json').read_text())
    index = json.loads((ROOT/'EVAL_INDEX.json').read_text())
    checks = dict(train.verify_frozen())
    checks.update(
        scientific_status_recorded=result['status'] in ['PASS_PILOT','FAIL_PILOT'],
        audit_pass=audit['status']=='PASS_AUDIT' and all(audit['checks'].values()),
        training_30_models=complete['models']==30 and len(complete['checkpoint_hashes'])==30,
        joint_updates=complete['updates']==15000==config['total_joint_updates'],
        six_initial_copies=complete['initial_checkpoint_copies']==6,
        report_inputs=report['result_sha256']==sha(ROOT/'RESULT.json') and report['audit_sha256']==sha(ROOT/'AUDIT.json'),
        report_outputs=all(sha(ROOT/n)==h for n,h in report['files_sha256'].items()),
        report_script=report['report_script_sha256']==sha(ROOT/'report.py'),
        EVAL_frozen=sha(ROOT/'EVAL.npz')==index['EVAL_sha256'],
        evaluation_script=ef['script_sha256']==result['analysis_sha256']==sha(ROOT/'evaluate.py'),
        evaluation_inputs=ef['selection_sha256']==sha(ROOT/'SELECTION.json') and ef['training_complete_sha256']==sha(ROOT/'TRAINING_COMPLETE.json'),
        evaluation_freeze=result['evaluation_frozen_sha256']==sha(ROOT/'EVALUATION_FROZEN.json'),
        predictions=result['predictions_sha256']==sha(ROOT/'PREDICTIONS.npz'),
        bootstrap=result['bootstrap_sha256']==sha(ROOT/'BOOTSTRAP.npz'))
    missing=[];links=[]
    for name in ['REPORT.md','README.md','PROTOCOL.md']:
        for target in re.findall(r'\]\(([^)]+)\)',(ROOT/name).read_text()):
            if target.startswith(('http:','https:','#')):
                continue
            p=(ROOT/target.split('#')[0]).resolve();links.append(str(p))
            if not p.exists():missing.append(str(p))
    checks['local_document_links']=not missing
    figures=list((ROOT/'figures').glob('*.png'))
    for p in figures:
        with Image.open(p) as im:im.verify()
    checks['scientific_figures_present']=len(figures)>=2
    verification=dict(status='PASS_VERIFICATION' if all(checks.values()) else 'FAIL_VERIFICATION',
        checks=checks,missing_links=missing,local_links_checked=len(links))
    (ROOT/'VERIFICATION.json').write_text(json.dumps(verification,indent=2)+'\n')
    assert all(checks.values()),checks
    final=dict(status='COMPLETE',scientific_status=result['status'],audit_status=audit['status'],
        result_sha256=sha(ROOT/'RESULT.json'),audit_sha256=sha(ROOT/'AUDIT.json'),
        report_manifest_sha256=sha(ROOT/'REPORT_MANIFEST.json'),verification_sha256=sha(ROOT/'VERIFICATION.json'),
        scope='Architecture fine-tuning pilot completed; technical completion does not establish gain or novelty.')
    (ROOT/'COMPLETE.json').write_text(json.dumps(final,indent=2)+'\n')
    print(json.dumps(verification),flush=True)


if __name__=='__main__':main()
