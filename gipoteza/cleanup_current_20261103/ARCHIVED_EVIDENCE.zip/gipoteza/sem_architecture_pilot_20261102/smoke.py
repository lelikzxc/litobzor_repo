"""Technical integration and timing on TRAIN only; not a scientific pilot."""
from pathlib import Path
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

import train as t
from model import ARMS, make_model, state_digest, architecture_spec

ROOT=Path(__file__).resolve().parent
STEPS=20


def main():
    assert torch.backends.mps.is_available(), 'MPS required; no fallback'
    assert not (ROOT/'FROZEN.json').exists(), 'Technical smoke precedes scientific freeze'
    assert not (ROOT/'SMOKE_CHECK.json').exists(), 'Do not silently overwrite technical evidence'
    torch.set_num_threads(2); c=t.config()
    subsets,lineage=t.prepare_inputs(c)
    full=t.load_training()
    data=t.subset_training(full,18,subsets)
    seed=c['seeds'][0];initial=t.initial_backbone(lineage,18,seed)
    checks=dict(weak_has_no_mask=set(data['weak'])=={'x','label'},
        dense18_balanced=np.array_equal(np.bincount(data['dense']['label'].cpu().numpy(),minlength=9),np.full(9,2)),
        weak1152=len(data['weak']['x'])==1152, fallback_disabled=t.os.environ['PYTORCH_ENABLE_MPS_FALLBACK']=='0')
    identities={};decoder_hashes={};timings={}; map_grads={};parity={};changes={}
    x=data['dense']['x'][:2]
    reference=make_model('base',initial,epsilon=c['epsilon'],eta=c['eta'],decoder_seed=seed+100003).to('mps')
    with torch.no_grad(): base=reference(x).detach().cpu()
    for arm in ARMS:
        net=make_model(arm,initial,epsilon=c['epsilon'],eta=c['eta'],decoder_seed=seed+100003).to('mps')
        with torch.no_grad():
            details=net.forward_details(x)
            identities[arm]=float((details['logits'].cpu()-base).abs().max())
            assert identities[arm]==0.
        if arm!='base': decoder_hashes[arm]=state_digest(net.actions.state_dict())
        del net
    checks['all5_exact_identity_initialization']=all(v==0. for v in identities.values())
    checks['all4_equal_decoder_initialization']=len(set(decoder_hashes.values()))==1
    t.START=time.monotonic();t.COMPLETED=0
    for arm in ARMS:
        net,timing=t.fit(c,arm,18,seed,initial,data,steps=STEPS,emit=False)
        net.eval()
        net.zero_grad(set_to_none=True)
        details=net.forward_details(x)
        assert torch.isfinite(details['logits']).all()
        if details['maps'] is not None:
            details['maps'].retain_grad()
        details['logits'].square().mean().backward()
        if arm!='base':
            g=details['maps'].grad
            assert g is not None and torch.isfinite(g).all() and float(g.abs().sum())>0
            map_grads[arm]=float(g.abs().sum().detach().cpu())
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in net.parameters())
        cpu=make_model(arm,epsilon=c['epsilon'],eta=c['eta'],decoder_seed=seed+100003)
        cpu.load_state_dict({k:v.detach().cpu() for k,v in net.state_dict().items()});cpu.eval()
        with torch.inference_mode():
            mps=net(x).detach().cpu(); own=cpu(x.cpu())
        error=float((mps-own).abs().max())
        assert error<1e-4,(arm,error)
        parity[arm]=error
        with torch.inference_mode():
            started=time.monotonic()
            for batch in data['weak']['x'][:64].split(16): net(batch)
            torch.mps.synchronize()
            forward_seconds=time.monotonic()-started
        timings[arm]=dict(**timing,milliseconds_per_step=1000*timing['seconds']/STEPS,
            inference64_seconds=forward_seconds)
        changes[arm]=dict(backbone=timing['changed_backbone'],decoder=timing['changed_decoder'],
            correction_max=float(details['correction'].abs().max().detach().cpu()))
        assert timing['changed_backbone']
        if arm!='base':assert timing['changed_decoder'] and changes[arm]['correction_max']>0
        del net,cpu
    checks.update(all5_finite_training=True,all4_map_channels_receive_gradients=len(map_grads)==4,
        all_models_CPU_MPS_match=max(parity.values())<1e-4,
        all4_decoders_updated=all(changes[a]['decoder'] for a in ARMS if a!='base'),
        all5_backbones_updated=all(v['backbone'] for v in changes.values()),
        technical_updates_match=t.COMPLETED==len(ARMS)*STEPS)
    assert all(checks.values()),checks
    units=len(c['budgets'])*len(c['seeds'])
    predicted=units*c['steps']*sum(v['seconds']/STEPS for v in timings.values())
    val=units*(695/64)*sum(v['inference64_seconds'] for v in timings.values())
    result=dict(status='PASS_SMOKE_CHECK',checks=checks,technical_steps_per_arm=STEPS,
        source_sha256=t.source_hashes(),config_at_smoke_sha256=t.sha(ROOT/'CONFIG.json'),
        training_invariants={k:c[k] for k in ['arms','budgets','seeds','subset_seed','batch_size',
            'learning_rate','weight_decay','physics_weight','epsilon','eta','thresholds']},
        identity_max_errors=identities,initial_decoder_sha256=decoder_hashes,
        CPU_MPS_logit_max_error=parity,map_gradient_L1=map_grads,changes=changes,
        architecture=architecture_spec(),timings=timings,
        estimated_train_seconds_at_config_steps=predicted,
        estimated_VAL_forward_seconds=val,
        estimated_minutes_with_io_and_classification_margin=[(predicted+val)/60+1,(predicted+val)/60+4],
        no_TEST_opened=True,no_scientific_model_saved=True,
        scope='Technical integration/gradient/timing only. No segmentation gain, hypothesis or novelty confirmation.')
    t.save(ROOT/'SMOKE_CHECK.json',result)
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
