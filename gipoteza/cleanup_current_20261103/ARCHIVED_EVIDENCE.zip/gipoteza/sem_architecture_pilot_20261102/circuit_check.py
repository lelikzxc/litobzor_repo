"""Independent CPU/MPS checks and bounded timings, without SEM or training."""
from pathlib import Path
import hashlib
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from circuit import CircuitMaps

ROOT = Path(__file__).resolve().parent


def numpy_system(q):
    n = len(q); pairs = [(y*n+x, yy*n+xx) for y in range(n) for x in range(n)
        for yy, xx in ((y+1, x), (y, x+1)) if yy < n and xx < n]
    src, dst = np.array(pairs).T
    incidence = np.zeros((len(src), n*n))
    incidence[np.arange(len(src)), src] = 1
    incidence[np.arange(len(src)), dst] = -1
    ports = np.array([y*n+x for y in range(n) for x in range(n)
                      if y in [0, n-1] or x in [0, n-1]])
    free = np.setdiff1d(np.arange(n*n), ports)
    c = np.minimum(q.ravel()[src], q.ravel()[dst])
    L = incidence.T @ (c[:, None]*incidence)
    A = L[np.ix_(free, free)]
    C = L[np.ix_(ports, free)]
    voltage = np.zeros((n*n, len(ports)))
    voltage[ports] = np.eye(len(ports))
    voltage[free] = -np.linalg.solve(A, C.T)
    return dict(src=src, dst=dst, incidence=incidence, ports=ports,
                free=free, c=c, L=L, T=incidence @ voltage)


def numpy_response(L, free, ports):
    C = L[np.ix_(ports, free)]
    return L[np.ix_(ports, ports)]-C @ np.linalg.solve(L[np.ix_(free, free)], C.T)


def cpu_checks():
    rng = np.random.default_rng(271102)
    errors = dict(joint_direct=0., independent_direct=0., first_order=0.,
                  normalization=0., D4=0., finite_difference=0., symmetry=0., row_sum=0.)
    records = []; cases = 0
    for n in [8, 12]:
        raw = .025+.95*rng.random((n, n))
        for epsilon in [1e-3, 1e-5]:
            op = CircuitMaps(n, epsilon)
            q = np.clip(raw, epsilon, 1-epsilon)
            syst = numpy_system(q)
            base = numpy_response(syst['L'], syst['free'], syst['ports'])
            full = numpy_system(np.full((n, n), 1-epsilon))
            scale = np.linalg.norm(numpy_response(full['L'], full['free'], full['ports']))
            errors['normalization'] = max(errors['normalization'], abs(scale-float(op._normalizer)))
            values = {mode: op._maps_from_q(torch.tensor(q.reshape(1, -1)), mode).detach().numpy()[0]
                      for mode in op.MODES}
            selected = [0, n//2, n+1, (n//2)*n+n//2, n*n-1]
            for index in selected:
                for channel, target in enumerate([1-epsilon, epsilon]):
                    edited = q.ravel().copy(); edited[index] = target
                    c1 = np.minimum(edited[syst['src']], edited[syst['dst']])
                    dc = c1-syst['c']; active = np.flatnonzero(np.abs(dc) > 1e-15)
                    assert len(active) <= 4
                    L1 = syst['L']+syst['incidence'].T @ (dc[:, None]*syst['incidence'])
                    joint = numpy_response(L1, syst['free'], syst['ports'])-base
                    independent = np.zeros_like(base); first = np.zeros_like(base)
                    for edge in active:
                        inc = syst['incidence'][edge]
                        one = syst['L']+dc[edge]*np.outer(inc, inc)
                        independent += numpy_response(one, syst['free'], syst['ports'])-base
                        first += dc[edge]*np.outer(syst['T'][edge], syst['T'][edge])
                    for key, mode, matrix in [('joint_direct','joint',joint),
                                             ('independent_direct','independent',independent),
                                             ('first_order','first_order',first)]:
                        norm = (np.sqrt(np.linalg.norm(matrix)**2+op.norm_smoothing**2)
                                -op.norm_smoothing)/scale
                        error = abs(norm-values[mode][channel, index])
                        errors[key] = max(errors[key], error)
                        records.append(dict(size=n,epsilon=epsilon,index=index,
                                            mode=mode,channel=channel,error=error))
                    errors['symmetry'] = max(errors['symmetry'],float(np.max(np.abs(base-base.T))))
                    errors['row_sum'] = max(errors['row_sum'],float(np.max(np.abs(base.sum(1)))))
                    cases += 1
            assert values['joint'].min() >= 0 and values['joint'].max() <= 1+1e-8
    op = CircuitMaps(8)
    q = .03+.94*rng.random((8, 8)); z = np.log(q/(1-q))
    original = {m:op(torch.tensor(z)[None,None],m).detach().numpy()[0] for m in op.MODES}
    for reflection in [False, True]:
        for rotation in range(4):
            transformed = np.rot90(np.fliplr(z) if reflection else z, rotation).copy()
            for mode in op.MODES:
                expected = np.rot90(np.flip(original[mode],axis=2) if reflection else original[mode],
                                    rotation,axes=(1,2))
                actual = op(torch.tensor(transformed)[None,None],mode).detach().numpy()[0]
                errors['D4'] = max(errors['D4'],float(np.max(np.abs(expected-actual))))
    weights = torch.tensor(rng.normal(size=(1,2,8,8)))
    gradient_norms = {}
    for mode in op.MODES:
        x = torch.tensor(z[None,None],requires_grad=True)
        output = op(x,mode); loss = (output*weights).sum()
        grad = torch.autograd.grad(loss,x)[0]
        assert torch.isfinite(grad).all() and grad.abs().sum() > 0
        gradient_norms[mode] = float(grad.abs().sum())
        for flat in [0, 13, 35, 63]:
            step = 1e-5
            plus = x.detach().clone(); minus = x.detach().clone()
            plus.reshape(-1)[flat] += step; minus.reshape(-1)[flat] -= step
            numerical = float(((op(plus,mode)*weights).sum()-(op(minus,mode)*weights).sum())/(2*step))
            errors['finite_difference'] = max(errors['finite_difference'],abs(numerical-float(grad.reshape(-1)[flat])))
    # Zero-change channels have a finite gradient: smoothing prevents sqrt(0).
    uniform = torch.zeros((2,1,12,12),requires_grad=True)
    uop = CircuitMaps()
    for mode in uop.MODES:
        y = uop(uniform,mode)
        g = torch.autograd.grad(y.sum(),uniform,retain_graph=True)[0]
        assert torch.isfinite(y).all() and torch.isfinite(g).all()
    assert errors['joint_direct'] < 1e-8 and errors['independent_direct'] < 1e-8
    assert errors['first_order'] < 1e-8 and errors['normalization'] < 1e-9
    assert errors['D4'] < 1e-8 and errors['finite_difference'] < 1e-6
    assert errors['symmetry'] < 1e-8 and errors['row_sum'] < 1e-8
    return dict(status='PASS_CPU_OPERATOR_CHECK',cases=cases,errors=errors,
                gradient_absolute_sums=gradient_norms,records=records)


def mps_checks():
    assert torch.backends.mps.is_available(), 'Actual MPS required; no silent CPU fallback'
    op = CircuitMaps()
    torch.manual_seed(271102)
    x0 = torch.randn((2,1,12,12))*.7
    weights = torch.randn((2,2,12,12))
    errors = {}; timing = {}
    # The operator has no float64 buffers for model.to('mps') to move.
    op.to('mps')
    assert not list(op.buffers()) and not list(op.parameters())
    for mode in op.MODES:
        cpu = x0.clone().requires_grad_(True)
        cy = op(cpu,mode); cg = torch.autograd.grad((cy*weights).sum(),cpu)[0]
        mps = x0.to('mps').requires_grad_(True)
        my = op(mps,mode); mg = torch.autograd.grad((my*weights.to('mps')).sum(),mps)[0]
        pe = float((cy.detach()-my.detach().cpu()).abs().max())
        ge = float((cg-mg.cpu()).abs().max())
        assert pe < 1e-6 and ge < 1e-5
        assert torch.isfinite(my).all() and torch.isfinite(mg).all() and mg.abs().sum() > 0
        errors[mode] = dict(output_max_error=pe,gradient_max_error=ge)
        for batch in [8,16]:
            source = torch.randn((batch,1,12,12)).to('mps')
            for _ in range(2):
                x = source.detach().requires_grad_(True)
                torch.autograd.grad(op(x,mode).sum(),x)
            torch.mps.synchronize(); start = time.perf_counter()
            iterations = 5
            for _ in range(iterations):
                x = source.detach().requires_grad_(True)
                torch.autograd.grad(op(x,mode).sum(),x)
            torch.mps.synchronize()
            timing[f'{mode}_B{batch}'] = dict(iterations=iterations,
                forward_backward_ms=1000*(time.perf_counter()-start)/iterations)
    return dict(status='PASS_MPS_OPERATOR_CHECK',errors=errors,timing=timing,
                scope='Operator and transfers only, no CNN, loss or optimizer timings')


def main():
    started = time.monotonic()
    torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        cpu = cpu_checks()
        print(json.dumps({k:v for k,v in cpu.items() if k!='records'}),flush=True)
        mps = mps_checks()
    result = dict(status='PASS_CIRCUIT_CHECK',cpu=cpu,mps=mps,
        size=12,ports=44,interior=100,epsilon=.001,
        torch_version=torch.__version__,seconds=time.monotonic()-started,
        files_sha256={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                      for name in ['circuit.py','circuit_check.py']},
        scope='Technical operator verification only; no SEM, labels, fitting, novelty or segmentation gain.')
    path = ROOT/'CIRCUIT_CHECK.json'
    assert not path.exists(), 'Refuse overwrite completed technical check'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cpu'}),flush=True)


if __name__=='__main__':
    main()
