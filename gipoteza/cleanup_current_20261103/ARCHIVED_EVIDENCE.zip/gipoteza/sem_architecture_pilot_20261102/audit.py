"""Independent CPU audit of the completed architecture pilot.

This script never trains, selects parameters from TEST, or edits scientific
inputs. Its network construction, confusion statistics, weighted bootstrap and
sparse binary resistor witnesses are independent of the evaluator/trainer.
"""
from pathlib import Path
import ast
import hashlib
import json
import time

import numpy as np
from scipy import ndimage, sparse
from scipy.sparse.linalg import spsolve
import torch
from torch import nn
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
ARMS = ['base','plain','first_order','independent','joint']
BUDGETS = [18,27]
SEEDS = [5501,5521,5557]
MODES = ['calibrated','fixed05']
PRIOR = [G/n for n in ['sem_confirmation_20261028','sem_cldice_confirmation_20261030',
                       'sem_cldice_expansion_20261102','sem_scarcity_20261102']]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT/name).read_text())


def state_digest(state):
    h=hashlib.sha256()
    for key in sorted(state):
        v=state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode());h.update(str(v.dtype).encode());h.update(str(v.shape).encode());h.update(v.tobytes())
    return h.hexdigest()


def macro(cm):
    den=cm.sum(-1)+cm.sum(-2)
    return np.divide(2*np.diagonal(cm,axis1=-2,axis2=-1),den,
                     out=np.zeros_like(den,dtype=float),where=den>0).mean(-1)


def paths(masks):
    masks=np.asarray(masks,dtype=bool)
    structure=np.zeros((3,3,3),dtype=bool)
    structure[1]=ndimage.generate_binary_structure(2,1)
    labels,count=ndimage.label(masks,structure)
    owner=np.zeros(count+1,dtype=int)
    owner[labels]=np.arange(len(masks))[:,None,None]
    result=np.zeros((len(masks),2),dtype=bool)
    for k,(left,right) in enumerate([(labels[:,:,0],labels[:,:,-1]),(labels[:,0,:],labels[:,-1,:])]):
        ids=np.intersect1d(left,right);ids=ids[ids>0]
        result[owner[ids],k]=True
    return result


def sparse_direction(mask):
    """Solve only foreground components spanning both electrodes; no soft floor."""
    mask=np.asarray(mask,dtype=bool);n=len(mask)
    labels,_=ndimage.label(mask,ndimage.generate_binary_structure(2,1))
    spans=np.intersect1d(labels[:,0],labels[:,-1]);spans=spans[spans>0]
    if not len(spans):return 0
    active=np.isin(labels,spans)
    vertices=np.flatnonzero(active.ravel());lookup=np.full(n*n,-1,dtype=int);lookup[vertices]=np.arange(len(vertices))
    row=[];col=[];val=[]
    for v in vertices:
        y,x=divmod(int(v),n)
        for yy,xx in [(y+1,x),(y,x+1)]:
            if yy<n and xx<n and active[yy,xx]:
                a,b=lookup[v],lookup[yy*n+xx]
                row.extend([a,b,a,b]);col.extend([a,b,b,a]);val.extend([1.,1.,-1.,-1.])
    L=sparse.csr_matrix((val,(row,col)),shape=(len(vertices),len(vertices)))
    left=np.flatnonzero(vertices%n==0);right=np.flatnonzero(vertices%n==n-1)
    free=np.setdiff1d(np.arange(len(vertices)),np.r_[left,right])
    voltage=np.zeros(len(vertices));voltage[right]=1
    if len(free):voltage[free]=spsolve(L[free][:,free],-np.asarray(L[free][:,right].sum(1)).ravel())
    current=float(np.asarray(L@voltage)[right].sum())/(n/(n-1))
    assert np.isfinite(current) and current>0
    return 2 if current>=.5-1e-8 else 1


class IndependentNet(nn.Module):
    def __init__(self,arm):
        super().__init__();self.arm=arm
        self.backbone=nn.Sequential(nn.Conv2d(1,24,3,padding=1),nn.GELU(),
            nn.Conv2d(24,24,3,padding=2,dilation=2),nn.GELU(),
            nn.Conv2d(24,24,3,padding=4,dilation=4),nn.GELU(),nn.Conv2d(24,1,1))
        if arm=='base':self.actions=None
        else:
            branches=[]
            for _ in range(3):
                branch=nn.Sequential(nn.Conv2d(28,8,3,padding=1),nn.GELU(),nn.Conv2d(8,1,1))
                nn.init.zeros_(branch[-1].weight);nn.init.zeros_(branch[-1].bias);branches.append(branch)
            self.actions=nn.ModuleList(branches)
        # Circuit identity and gradients are separately checked against direct
        # NumPy solves. Reuse this fixed, hash-frozen operator, not model.py.
        if arm not in ['base','plain']:
            from circuit import CircuitMaps
            self.circuit=CircuitMaps(epsilon=.001)
        else:self.circuit=None

    def forward_details(self,x):
        features=self.backbone[:-1](x);coarse=self.backbone[-1](features)
        if self.arm=='base':return dict(logits=coarse,coarse=coarse,maps=None,actions=None)
        p=coarse.sigmoid()
        maps=torch.cat((p,4*p*(1-p)),1) if self.arm=='plain' else self.circuit(coarse,mode=self.arm)
        inputs=torch.cat((features,coarse,x,maps),1)
        actions=torch.cat([head(inputs) for head in self.actions],1).softmax(1)
        return dict(logits=coarse+2*(actions[:,1:2]-actions[:,2:3]),
                    coarse=coarse,maps=maps,actions=actions)

    def forward(self,x):
        return self.forward_details(x)['logits']


def independent_bootstrap(confusion,seed_ids,frame_ids):
    """Weighted contingency tables, rather than evaluator's indexed sampling."""
    repetitions=len(seed_ids);out=np.empty((2,5,repetitions))
    for start in range(0,repetitions,256):
        end=min(start+256,repetitions)
        fw=np.array([np.bincount(row,minlength=8) for row in frame_ids[start:end]])
        sw=np.array([np.bincount(row,minlength=3) for row in seed_ids[start:end]])
        sampled=np.einsum('rf,bsafij->brsaij',fw,confusion,optimize=True)
        score=macro(sampled)
        out[:,:,start:end]=(score*sw[None,:,:,None]).sum(2).transpose(0,2,1)/3
    return out


def data_checks(c,frozen):
    checks={};manifest=read('DATA_MANIFEST.json');index=read('EVAL_INDEX.json')
    plan=read('SOURCE_PLAN.json')
    checks['config_protocol_hash']=sha(ROOT/'PROTOCOL.md')==c['protocol_sha256']==frozen['protocol_sha256']==manifest['protocol_sha256']
    checks['frozen_sources']=all(sha(ROOT/n)==h for n,h in frozen['source_sha256'].items())
    checks['frozen_config']=sha(ROOT/'CONFIG.json')==frozen['config_sha256']
    checks['archive_hashes']=all(sha(ROOT/(n+'.npz'))==manifest[n+'_sha256'] for n in ['TRAIN_VAL','TEST','DATA'])
    with np.load(ROOT/'TRAIN_VAL.npz',allow_pickle=False) as z:tv={k:z[k] for k in z.files}
    with np.load(ROOT/'TEST.npz',allow_pickle=False) as z:test={k:z[k] for k in z.files}
    with np.load(ROOT/'EVAL.npz',allow_pickle=False) as z:evaluation={k:z[k] for k in z.files}
    checks['exact_historical_TRAIN_VAL']=sha(ROOT/'TRAIN_VAL.npz')==sha(PRIOR[-1]/'TRAIN_VAL.npz')==frozen['train_val_sha256']
    checks['roles_counts_and_frames']=(set(tv['role'])=={'dense','weak','val'} and
        {r:int((tv['role']==r).sum()) for r in set(tv['role'])}=={'dense':54,'weak':1152,'val':695}
        and set(tv['frame'][tv['role']=='val'])=={6,7}
        and set(tv['frame'][np.isin(tv['role'],['dense','weak'])])==set(range(6)))
    subsets=read('SUBSETS.json');old=json.loads((PRIOR[-1]/'SUBSETS.json').read_text())
    checks['same_nested_balanced_dense_subsets']=(subsets['subset_seed']==5303 and
        all(subsets['dense_indices'][str(b)]==old['subsets']['final'][str(b)]['5303'] for b in BUDGETS)
        and set(subsets['dense_indices']['18'])<=set(subsets['dense_indices']['27'])
        and all(np.array_equal(np.bincount(tv['label'][subsets['dense_indices'][str(b)]],minlength=9),np.full(9,b//9)) for b in BUDGETS)
        and sha(ROOT/'SUBSETS.json')==frozen['subsets_sha256'])
    prior_records=[r for folder in PRIOR for r in json.loads((folder/'DATA_MANIFEST.json').read_text())['records']]
    records=manifest['records'];test_records=records[1901:]
    checks['new_TEST_excludes_all_prior_motifs']=all(not {r[k] for r in test_records}&{r[k] for r in prior_records}
        for k in ['canonical_D4','raw_D4_sha256'])
    checks['all_masks_and_raw_motifs_unique']=all(len({r[k] for r in records})==len(records)
        for k in ['canonical_D4','raw_D4_sha256'])
    checks['new_frames_frozen']=set(test['frame'])==set(c['test_frames']) and not set(c['test_frames'])&set(plan['excluded_previous_frames'])
    ids=np.asarray(index['local_TEST_indices'],dtype=int)
    checks['EVAL_hash_and_alignment']=(sha(ROOT/'EVAL.npz')==index['EVAL_sha256'] and
        all(np.array_equal(evaluation[k],test[k][ids]) for k in test)
        and index['records']==[test_records[i] for i in ids]
        and index['global_DATA_indices']==(1901+ids).tolist())
    expected=[]
    for frame in c['test_frames']:
        ranked=sorted((hashlib.sha256((c['evaluation_prefix']+r['canonical_D4']+'/'+r['raw_D4_sha256']).encode()).hexdigest(),i)
                      for i,r in enumerate(test_records) if r['frame']==frame)
        expected.extend(i for _,i in ranked[:256])
    checks['EVAL_label_blind_selection']=ids.tolist()==sorted(expected)
    counts=np.bincount(evaluation['label'],minlength=9)
    checks['EVAL_gates']=(counts.min()>=8 and all(len(set(evaluation['frame'][evaluation['label']==k]))>=3 for k in range(9))
                         and all(index['gates'].values()) and set(evaluation['frame'])==set(c['test_frames']))
    tree=ast.parse((ROOT/'train.py').read_text())
    calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)
           and isinstance(n.func.value,ast.Name) and n.func.value.id=='np' and n.func.attr=='load']
    checks['trainer_only_opens_TRAIN_VAL']=len(calls)==1 and 'TRAIN_VAL.npz' in ast.unparse(calls[0].args[0])
    fit=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fit')
    text=ast.unparse(fit)
    checks['same_old_loss_all_arms']=('dense_loss + c[\'physics_weight\'] * weak_loss' in text and
        'binary_cross_entropy_with_logits' in text and 'geometry_loss(net(data[\'weak\'][\'x\'][wi]), direction)' in text
        and not any(isinstance(n,ast.If) and 'arm' in ast.unparse(n.test) for n in ast.walk(fit)))
    checks['old_physics_adapter_exact']=sha(ROOT/'physics_adapter.py')==sha(PRIOR[-1]/'physics_adapter.py')
    checks['source_hashes_unchanged']=all(sha(ROOT/n)==h for n,h in manifest['sources_sha256'].items())
    return checks,tv,evaluation


def checkpoint_and_selection_checks(c,frozen,complete,tv):
    checks={};lineage=read('INITIAL_LINEAGE.json');subsets=read('SUBSETS.json')
    chosen=read('SELECTION.json');rows=read('FINAL_VAL_RESULTS.json');thresholds=read('VAL_THRESHOLD_RESULTS.json')
    hashes=complete['checkpoint_hashes']
    expected={f'final_b{b}_{a}_s{s}.pt' for b in BUDGETS for s in SEEDS for a in ARMS}
    checks['all30_checkpoint_hashes']=set(hashes)==expected and all(sha(ROOT/'models'/n)==h for n,h in hashes.items())
    checks['training_complete_counts']=complete['updates']==15000 and complete['models']==30 and frozen['planned_updates']==15000 and c['steps']==500
    checks['frozen_completion_and_selection']=(sha(ROOT/'FROZEN.json')==complete['frozen_sha256'] and
        sha(ROOT/'SELECTION.json')==complete['selection_sha256'] and chosen['status']=='FROZEN_BEFORE_TEST'
        and chosen['selection_uses_TEST'] is False)
    checks['initial_lineage_hash']=sha(ROOT/'INITIAL_LINEAGE.json')==frozen['initial_lineage_sha256']
    initial_ok=True;model_ok=True;pair_ok=True;selection_ok=True;val_error=0.;val_fixture_error=0.
    val_ids=np.flatnonzero(tv['role']=='val');truth=tv['label'][val_ids];target=tv['Y'][val_ids,0].astype(bool)
    x=torch.tensor(5*(tv['X'][val_ids[:16]]-.2))
    val_witnesses=[]
    for b in BUDGETS:
        for seed in SEEDS:
            initial=lineage['initials'][f'{b}:{seed}']
            original=ROOT/initial['source']
            initial_ok &= sha(ROOT/initial['file'])==sha(original)==initial['sha256']
            source=torch.load(ROOT/initial['file'],map_location='cpu',weights_only=True)
            initial_ok &= state_digest(source['segmenter'])==initial['backbone_state_sha256']
            unit=[];decoder_hashes=[]
            for arm in ARMS:
                name=f'final_b{b}_{arm}_s{seed}.pt'
                payload=torch.load(ROOT/'models'/name,map_location='cpu',weights_only=True);meta=payload['settings'];unit.append(meta)
                row=next(r for r in rows if r['budget']==b and r['seed']==seed and r['arm']==arm)
                model_ok &= meta==row and meta['steps']==500 and meta['dense_global_indices']==subsets['dense_indices'][str(b)]
                model_ok &= meta['initial_backbone_sha256']==initial['backbone_state_sha256']
                model_ok &= sum(v.numel() for v in payload['model'].values())==(10681 if arm=='base' else 16780)
                model_ok &= all(torch.isfinite(v).all().item() for v in payload['model'].values())
                torch.manual_seed(seed+100003);net=IndependentNet(arm)
                if arm!='base':
                    decoder_hashes.append(meta['initial_decoder_sha256'])
                    model_ok &= state_digest(net.actions.state_dict())==meta['initial_decoder_sha256']
                    final_actions={k[len('actions.'):]:v for k,v in payload['model'].items() if k.startswith('actions.')}
                    model_ok &= state_digest(final_actions)!=meta['initial_decoder_sha256'] and meta['changed_decoder']
                net.load_state_dict(payload['model']);net.eval()
                with torch.inference_mode():own=net(x).sigmoid()[:,0].numpy()
                with np.load(ROOT/'val_probs'/f'final_b{b}_{arm}_s{seed}.npz',allow_pickle=False) as z:
                    p=z['probability'];cached_truth=z['truth'];cached_target=z['target'];pred=z['predictions'];tt=z['thresholds']
                model_ok &= p.shape==(695,12,12) and np.isfinite(p).all() and np.array_equal(cached_truth,truth) and np.array_equal(cached_target,target)
                val_fixture_error=max(val_fixture_error,float(np.max(np.abs(own-p[:16]))))
                obs=[]
                for ti,t in enumerate(c['thresholds']):
                    cm=np.bincount(9*truth+pred[ti],minlength=81).reshape(9,9)
                    masks=p>=t;union=(masks|target).sum((1,2))
                    iou=np.divide((masks&target).sum((1,2)),union,out=np.ones(len(union)),where=union>0).mean()
                    point=dict(threshold=t,mask_F1=float(macro(cm)),IoU=float(iou));obs.append(point)
                    saved=next(r for r in thresholds if r['budget']==b and r['seed']==seed and r['arm']==arm and r['threshold']==t)
                    val_error=max(val_error,abs(point['mask_F1']-saved['mask_F1']),abs(point['IoU']-saved['IoU']))
                    if ti in [0,3,6]:val_witnesses.append((masks[ti%len(masks)],int(pred[ti,ti%len(masks)])))
                winner=max(obs,key=lambda r:(r['mask_F1'],r['IoU'],-abs(r['threshold']-.5),-r['threshold']))
                selected=chosen['chosen'][str(b)][str(seed)][arm]
                selection_ok &= selected['checkpoint']==name and all(abs(winner[k]-selected[k])<1e-12 for k in winner)
                print(json.dumps(dict(stage='AUDIT_VAL',budget=b,seed=seed,arm=arm)),flush=True)
            pair_ok &= len({r['initial_backbone_sha256'] for r in unit})==1 and len({r['batch_sequence_sha256'] for r in unit})==1 and len(set(decoder_hashes))==1
            rng=np.random.default_rng(seed+1000);batch_hash=hashlib.sha256()
            for _ in range(500):
                batch_hash.update(rng.integers(0,b,8).astype(np.int64).tobytes());batch_hash.update(rng.integers(0,1152,8).astype(np.int64).tobytes())
            pair_ok &= all(r['batch_sequence_sha256']==batch_hash.hexdigest() for r in unit)
    checks.update(all6_historical_backbones_exact=bool(initial_ok),all30_models_metadata_and_architecture=bool(model_ok),
        all30_paired_initials_and_batches=bool(pair_ok),all_actual_FINAL_VAL_thresholds_recomputed=bool(selection_ok),
        all210_VAL_metrics_recomputed=val_error<1e-12,VAL_CPU_MPS_fixtures=val_fixture_error<1e-4,
        full_VAL_grid=len(thresholds)==210 and len(rows)==30)
    return checks,chosen,dict(VAL_metric_max_error=val_error,VAL_CPU_MPS_probability_max_error=val_fixture_error),val_witnesses


def statistics_checks(c,result,chosen,evaluation):
    truth=evaluation['label'];target=evaluation['Y'][:,0].astype(bool);frames=evaluation['frame'];n=len(truth)
    fv,gid=np.unique(frames,return_inverse=True);true_paths=paths(target)
    point=np.empty((2,3,5,2));ious_point=np.empty_like(point);path_point=np.empty_like(point)
    confusion=np.zeros((2,3,5,8,9,9),dtype=np.int64)
    checks={};metric_error=0.;iou_error=0.;fixture_error=0.;mask_fixture=True;witnesses=[]
    coarse_error=0.;map_error=0.;action_error=0.;base_empty=True
    with np.load(ROOT/'PREDICTIONS.npz',allow_pickle=False) as z:
        pred=z['predictions'];packed=z['packed_masks'];saved_iou=z['ious'];fixtures=z['probs_fixture']
        coarse_fixtures=z['coarse_fixture'];map_fixtures=z['maps_fixture'];action_fixtures=z['actions_fixture']
        checks['TEST_alignment_and_shapes']=(np.array_equal(z['truth'],truth) and np.array_equal(z['frames'],frames)
            and z['arms'].tolist()==ARMS and z['seeds'].tolist()==SEEDS and z['budgets'].tolist()==BUDGETS
            and z['modes'].tolist()==MODES and pred.shape==(2,3,5,2,n) and packed.shape==(2,3,5,2,n,18)
            and saved_iou.shape==pred.shape and fixtures.shape==(2,3,5,16,1,12,12))
        for bi,b in enumerate(BUDGETS):
            for si,seed in enumerate(SEEDS):
                for ai,arm in enumerate(ARMS):
                    for mi,t in enumerate([chosen['chosen'][str(b)][str(seed)][arm]['threshold'],.5]):
                        masks=np.unpackbits(packed[bi,si,ai,mi],axis=1,count=144).reshape(n,12,12).astype(bool)
                        mask_fixture &= np.array_equal(masks[:16],fixtures[bi,si,ai,:,0]>=t)
                        y=pred[bi,si,ai,mi]
                        cm=np.bincount(9*truth+y,minlength=81).reshape(9,9)
                        point[bi,si,ai,mi]=macro(cm)
                        union=(masks|target).sum((1,2));own_iou=np.divide((masks&target).sum((1,2)),union,out=np.ones(n),where=union>0)
                        ious_point[bi,si,ai,mi]=own_iou.mean();iou_error=max(iou_error,float(np.max(np.abs(own_iou-saved_iou[bi,si,ai,mi]))))
                        path_point[bi,si,ai,mi]=np.any(paths(masks)!=true_paths,axis=1).mean()
                        if mi==0:
                            for f in range(8):
                                ids=gid==f;confusion[bi,si,ai,f]=np.bincount(9*truth[ids]+y[ids],minlength=81).reshape(9,9)
                        for i in [0,n//2,n-1]:witnesses.append((masks[i],int(y[i])))
                    payload=torch.load(ROOT/'models'/f'final_b{b}_{arm}_s{seed}.pt',map_location='cpu',weights_only=True)
                    own=IndependentNet(arm);own.load_state_dict(payload['model']);own.eval()
                    with torch.inference_mode():detail=own.forward_details(torch.tensor(5*(evaluation['X'][:16]-.2)))
                    prob=detail['logits'].sigmoid().numpy()
                    fixture_error=max(fixture_error,float(np.max(np.abs(prob-fixtures[bi,si,ai]))))
                    coarse_error=max(coarse_error,float(np.max(np.abs(detail['coarse'].sigmoid().numpy()-coarse_fixtures[bi,si,ai]))))
                    if arm=='base':
                        base_empty &= np.isnan(map_fixtures[bi,si,ai]).all() and np.isnan(action_fixtures[bi,si,ai]).all()
                    else:
                        map_error=max(map_error,float(np.max(np.abs(detail['maps'].numpy()-map_fixtures[bi,si,ai]))))
                        action_error=max(action_error,float(np.max(np.abs(detail['actions'].numpy()-action_fixtures[bi,si,ai]))))
                    print(json.dumps(dict(stage='AUDIT_TEST',budget=b,seed=seed,arm=arm)),flush=True)
            for ai,arm in enumerate(ARMS):
                for mi,section in enumerate([result['metrics'],result['secondary_fixed05']]):
                    row=section[str(b)][arm]
                    metric_error=max(metric_error,abs(point[bi,:,ai,mi].mean()-row['mask_F1']),
                        float(np.max(np.abs(point[bi,:,ai,mi]-row['per_seed_mask_F1']))),
                        abs(ious_point[bi,:,ai,mi].mean()-row['IoU']),
                        float(np.max(np.abs(ious_point[bi,:,ai,mi]-row['per_seed_IoU']))),
                        abs(path_point[bi,:,ai,mi].mean()-row['path_error']),
                        float(np.max(np.abs(path_point[bi,:,ai,mi]-row['per_seed_path_error']))))
    checks.update(TEST_probability_thresholds_match_masks=bool(mask_fixture),all_TEST_metrics_recomputed=metric_error<2e-7,
        all_per_example_IoU_recomputed=iou_error<2e-7,all30_TEST_CPU_MPS_fixtures=fixture_error<1e-4,
        coarse_maps_and_actions_CPU_MPS_fixtures=coarse_error<1e-4 and map_error<1e-4 and action_error<1e-4 and base_empty)
    with np.load(ROOT/'BOOTSTRAP.npz',allow_pickle=False) as z:
        saved_scores=z['scores'];seed_ids=z['seed_ids'];frame_ids=z['frame_ids']
        checks['all_frame_confusions_recomputed']=np.array_equal(confusion,z['confusion'])
    rng=np.random.default_rng(281102)
    checks['bootstrap_indices_recomputed']=(np.array_equal(seed_ids,rng.integers(0,3,(10000,3))) and
        np.array_equal(frame_ids,rng.integers(0,8,(10000,8))))
    draws=independent_bootstrap(confusion,seed_ids,frame_ids)
    bootstrap_error=float(np.max(np.abs(draws-saved_scores)))
    checks['all10000_bootstrap_repetitions_recomputed']=bootstrap_error<1e-12
    primary=point[:,:,:,0].mean((0,1));primary_iou=ious_point[:,:,:,0].mean((0,1));dist=draws.mean(0)
    primary_path=path_point[:,:,:,0].mean((0,1))
    interval_error=0.;gates_ok=True;gate_pass=[]
    for ai,arm in enumerate(ARMS):
        metric_error=max(metric_error,abs(primary[ai]-result['primary_metrics'][arm]['mask_F1']),
                         abs(primary_iou[ai]-result['primary_metrics'][arm]['IoU']),
                         abs(primary_path[ai]-result['primary_metrics'][arm]['path_error']))
    for ai,arm in enumerate(ARMS[:-1]):
        d=dist[4]-dist[ai];delta=primary[4]-primary[ai]
        ci=np.quantile(d,[.00625,.99375]);ci95=np.quantile(d,[.025,.975]);iou_delta=primary_iou[4]-primary_iou[ai]
        individual=point[:,:,4,0].mean(1)-point[:,:,ai,0].mean(1)
        gates=dict(gain_at_least_one_pp=bool(delta>=.01),positive_multiplicity_adjusted_CI_lower=bool(ci[0]>0),
                   both_budget_means_nonnegative=bool(individual.min()>=0),IoU_guard=bool(iou_delta>=-.005))
        row=result['joint_minus_control'][arm]
        gates_ok &= gates==row['gates'];gate_pass.append(all(gates.values()))
        interval_error=max(interval_error,abs(delta-row['delta']),float(np.max(np.abs(ci-row['CI98_75']))),
            float(np.max(np.abs(ci95-row['CI95_nominal']))),abs(iou_delta-row['IoU_delta']),
            float(np.max(np.abs(individual-row['budget18_27_deltas']))))
        for bi,b in enumerate(BUDGETS):
            saved=result['budget_comparisons_descriptive'][arm][str(b)]
            own_interval=np.quantile(draws[bi,4]-draws[bi,ai],[.025,.975])
            interval_error=max(interval_error,abs(individual[bi]-saved['delta']),
                float(np.max(np.abs(own_interval-saved['CI95_nominal']))))
    checks.update(primary_metric_and_intervals_recomputed=metric_error<2e-7 and interval_error<2e-7,
        scientific_gates_recomputed=bool(gates_ok and result['status']==('PASS_PILOT' if all(gate_pass) else 'FAIL_PILOT')))
    checks['TEST_metadata']=result['test_examples']==n and set(result['test_frames'])==set(fv)
    return checks,dict(TEST_metric_max_error=metric_error,TEST_IoU_max_error=iou_error,
        TEST_CPU_MPS_probability_max_error=fixture_error,bootstrap_max_error=bootstrap_error,
        interval_max_error=interval_error,coarse_fixture_max_error=coarse_error,
        maps_fixture_max_error=map_error,actions_fixture_max_error=action_error),witnesses


def main():
    start=time.monotonic();torch.set_num_threads(2)
    assert not (ROOT/'AUDIT.json').exists(),'Do not overwrite a completed independent audit'
    result=read('RESULT.json');c=read('CONFIG.json');frozen=read('FROZEN.json');complete=read('TRAINING_COMPLETE.json')
    names=['PROTOCOL.md','CONFIG.json','FROZEN.json','TRAINING_COMPLETE.json','SELECTION.json',
        'DATA_MANIFEST.json','EVAL_INDEX.json','TRAIN_VAL.npz','EVAL.npz','RESULT.json',
        'PREDICTIONS.npz','BOOTSTRAP.npz','FINAL_VAL_RESULTS.json','VAL_THRESHOLD_RESULTS.json',
        'INITIAL_LINEAGE.json','SUBSETS.json','evaluate.py','EVALUATION_FROZEN.json']
    before={n:sha(ROOT/n) for n in names}
    with threadpool_limits(limits=2):
        checks,tv,evaluation=data_checks(c,frozen)
        ef=read('EVALUATION_FROZEN.json')
        checks['official_evaluator_frozen_before_TEST']=(ef['script_sha256']==sha(ROOT/'evaluate.py')==result['analysis_sha256']
            and ef['selection_sha256']==sha(ROOT/'SELECTION.json')==complete['selection_sha256']
            and ef['training_complete_sha256']==sha(ROOT/'TRAINING_COMPLETE.json')
            and ef['frozen_sha256']==sha(ROOT/'FROZEN.json')
            and ef['EVAL_sha256']==sha(ROOT/'EVAL.npz')
            and ef['evaluation_index_sha256']==sha(ROOT/'EVAL_INDEX.json')
            and ef['protocol_sha256']==sha(ROOT/'PROTOCOL.md')
            and ef['config_sha256']==sha(ROOT/'CONFIG.json')
            and result['predictions_sha256']==sha(ROOT/'PREDICTIONS.npz')
            and result['bootstrap_sha256']==sha(ROOT/'BOOTSTRAP.npz')
            and result['evaluation_frozen_sha256']==sha(ROOT/'EVALUATION_FROZEN.json'))
        cc,selection,errors,val_witnesses=checkpoint_and_selection_checks(c,frozen,complete,tv);checks.update(cc)
        cc,stats,witnesses=statistics_checks(c,result,selection,evaluation);checks.update(cc);errors.update(stats)
        # Independent sparse Kirchhoff cases include every class and both modes.
        truth=evaluation['label'];target=evaluation['Y'][:,0].astype(bool)
        witnesses+=val_witnesses
        witnesses.extend((target[i],int(truth[i])) for k in range(9) for i in np.flatnonzero(truth==k)[:3])
        mismatches=sum(3*sparse_direction(mask)+sparse_direction(mask.T)!=label for mask,label in witnesses)
        checks['independent_sparse_resistor_class_witnesses']=mismatches==0
        checks['scientific_inputs_unchanged']=before=={n:sha(ROOT/n) for n in names}
        protected=read('PROTECTED_BEFORE.json')
        checks['all882_historical_artifacts_unchanged']=len(protected)==882 and all(sha(G/n)==h for n,h in protected.items())
    output=dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',checks={k:bool(v) for k,v in checks.items()},
        **errors,independent_sparse_class_cases=len(witnesses),sparse_class_mismatches=int(mismatches),
        historical_files=len(protected),input_sha256=before,script_sha256=sha(Path(__file__)),
        seconds=time.monotonic()-start,scope='Independent technical CPU audit; does not alter the scientific PASS/FAIL criterion.')
    (ROOT/'AUDIT.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output),flush=True)
    assert all(checks.values()),{k:v for k,v in checks.items() if not v}


if __name__=='__main__':
    main()
