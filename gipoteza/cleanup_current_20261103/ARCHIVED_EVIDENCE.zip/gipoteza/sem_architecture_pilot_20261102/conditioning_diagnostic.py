"""Exploratory VAL-only intervention test of fixed, already trained decoders.

No fitting, parameter/threshold selection or TEST inference. This diagnostic
cannot change the frozen pilot outcome. Run only after its full pipeline ends.
"""
from pathlib import Path
import hashlib
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from model import make_model
from train import hard_classes

ROOT=Path(__file__).resolve().parent
VARIANTS=['actual','zero_maps','rolled_maps','first_order_maps','independent_maps']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def macro(truth,prediction):
    cm=np.bincount(9*truth+prediction,minlength=81).reshape(9,9)
    den=cm.sum(0)+cm.sum(1)
    return float(np.divide(2*np.diag(cm),den,out=np.zeros(9,dtype=float),where=den>0).mean())


def mask_iou(target,prediction):
    intersection=(target&prediction).sum((1,2));union=(target|prediction).sum((1,2))
    return float(np.divide(intersection,union,out=np.ones(len(union)),where=union>0).mean())


def rms(value):
    return float(np.sqrt(np.mean(np.square(value.astype(np.float64)))))


def map_stats(maps):
    boundary=np.zeros((12,12),dtype=bool)
    boundary[[0,-1],:]=True;boundary[:,[0,-1]]=True
    rows=[]
    for channel in range(2):
        v=maps[:,channel]
        br=rms(v[:,boundary]);ir=rms(v[:,~boundary])
        rows.append(dict(channel=['addition','removal'][channel],minimum=float(v.min()),
            maximum=float(v.max()),mean=float(v.mean()),RMS=rms(v),
            boundary_RMS=br,interior_RMS=ir,
            boundary_over_interior_RMS=None if ir==0 else br/ir,
            exact_zero_fraction=float((v==0).mean())))
    return rows


def decode(net,features,coarse,image,maps):
    inputs=torch.cat((features,coarse,image,maps),dim=1)
    actions=torch.cat([branch(inputs) for branch in net.actions],dim=1).softmax(1)
    return coarse+net.eta*(actions[:,1:2]-actions[:,2:3])


def main():
    start=time.monotonic();torch.set_num_threads(2)
    assert not (ROOT/'CONDITIONING_DIAGNOSTIC.json').exists(),'Refuse overwrite of diagnostic'
    pipeline=json.loads((ROOT/'PIPELINE.json').read_text())
    assert pipeline['status']=='COMPLETE','Wait for primary study completion before diagnostics'
    config=json.loads((ROOT/'CONFIG.json').read_text())
    selection=json.loads((ROOT/'SELECTION.json').read_text())
    complete=json.loads((ROOT/'TRAINING_COMPLETE.json').read_text())
    assert selection['status']=='FROZEN_BEFORE_TEST'
    names=['CONFIG.json','SELECTION.json','TRAINING_COMPLETE.json','FROZEN.json','TRAIN_VAL.npz',
           'model.py','circuit.py','train.py','prepare.py']
    before={n:sha(ROOT/n) for n in names}
    frozen=json.loads((ROOT/'FROZEN.json').read_text())
    assert before['TRAIN_VAL.npz']==frozen['train_val_sha256']
    assert before['SELECTION.json']==complete['selection_sha256']
    assert all(before[n]==frozen['source_sha256'][n] for n in ['model.py','circuit.py','train.py','prepare.py'])
    with np.load(ROOT/'TRAIN_VAL.npz',allow_pickle=False) as z:
        val=np.flatnonzero(z['role']=='val')
        assert len(val)==695 and set(z['frame'][val])=={6,7}
        x=5*(z['X'][val]-.2);target=z['Y'][val,0].astype(bool);truth=z['label'][val]
    rows=[];checkpoint_hashes={}
    with threadpool_limits(limits=2):
        for budget in config['budgets']:
            for seed in config['seeds']:
                arm='joint';chosen=selection['chosen'][str(budget)][str(seed)][arm]
                checkpoint=chosen['checkpoint'];path=ROOT/'models'/checkpoint
                checkpoint_hashes[checkpoint]=sha(path)
                assert checkpoint_hashes[checkpoint]==complete['checkpoint_hashes'][checkpoint]
                payload=torch.load(path,map_location='cpu',weights_only=True)
                net=make_model('joint',epsilon=config['epsilon'],eta=config['eta'])
                net.load_state_dict(payload['model']);net.eval()
                output={v:[] for v in VARIANTS};maps_all={v:[] for v in ['actual','first_order','independent']}
                with torch.inference_mode():
                    for offset in range(0,len(x),16):
                        batch=torch.tensor(x[offset:offset+16])
                        features=net.backbone[:-1](batch);coarse=net.backbone[-1](features)
                        maps=net.circuit(coarse,mode='joint')
                        first=net.circuit(coarse,mode='first_order')
                        independent=net.circuit(coarse,mode='independent')
                        cases=dict(actual=maps,zero_maps=torch.zeros_like(maps),
                            rolled_maps=torch.roll(maps,shifts=(5,5),dims=(-2,-1)),
                            first_order_maps=first,independent_maps=independent)
                        for name,m in cases.items():output[name].append(decode(net,features,coarse,batch,m)[:,0].numpy())
                        maps_all['actual'].append(maps.numpy());maps_all['first_order'].append(first.numpy())
                        maps_all['independent'].append(independent.numpy())
                logits={k:np.concatenate(v) for k,v in output.items()}
                physical={k:np.concatenate(v) for k,v in maps_all.items()}
                threshold=chosen['threshold']
                actual=logits['actual'];actual_mask=torch.from_numpy(actual).sigmoid().numpy()>=threshold
                variant_rows={}
                for name,logit in logits.items():
                    masks=torch.from_numpy(logit).sigmoid().numpy()>=threshold;prediction=hard_classes(masks)
                    difference=logit-actual
                    variant_rows[name]=dict(mask_F1=macro(truth,prediction),IoU=mask_iou(target,masks),
                        mean_absolute_logit_difference=float(np.abs(difference).mean()),
                        maximum_absolute_logit_difference=float(np.abs(difference).max()),
                        RMS_logit_difference=rms(difference),
                        mask_pixel_flip_fraction=float((masks!=actual_mask).mean()),
                        examples_with_any_mask_flip_fraction=float(np.any(masks!=actual_mask,axis=(1,2)).mean()))
                for row in variant_rows.values():
                    row['F1_delta_from_actual']=row['mask_F1']-variant_rows['actual']['mask_F1']
                    row['IoU_delta_from_actual']=row['IoU']-variant_rows['actual']['IoU']
                # Diagnostic re-evaluation uses the frozen selected threshold,
                # never the best intervention or best alternative threshold.
                value=dict(budget=budget,seed=seed,checkpoint=checkpoint,
                    checkpoint_sha256=checkpoint_hashes[checkpoint],threshold_unchanged=threshold,
                    examples=695,frames=[6,7],variants=variant_rows,
                    actual_map_statistics=map_stats(physical['actual']),
                    raw_map_differences={name:dict(mean_absolute=float(np.abs(physical[name]-physical['actual']).mean()),
                        maximum_absolute=float(np.abs(physical[name]-physical['actual']).max()),
                        RMS=rms(physical[name]-physical['actual']),
                        relative_RMS=rms(physical[name]-physical['actual'])/max(rms(physical['actual']),1e-12))
                        for name in ['first_order','independent']})
                # The VAL score of the actual model must reproduce its stored
                # final-model selection score up to CPU/MPS numerical rounding.
                value['actual_CPU_vs_stored_VAL_F1_difference']=value['variants']['actual']['mask_F1']-chosen['mask_F1']
                assert abs(value['actual_CPU_vs_stored_VAL_F1_difference'])<1e-3
                rows.append(value)
                print(json.dumps(dict(stage='VAL_CONDITIONING_DIAGNOSTIC',budget=budget,seed=seed,
                    zero_mean_logit_change=variant_rows['zero_maps']['mean_absolute_logit_difference'],
                    zero_flip_fraction=variant_rows['zero_maps']['mask_pixel_flip_fraction'])),flush=True)
    assert before=={n:sha(ROOT/n) for n in names},'Diagnostic changed frozen study input'
    assert all(sha(ROOT/'models'/n)==h for n,h in checkpoint_hashes.items())
    summary={v:{k:float(np.mean([r['variants'][v][k] for r in rows]))
                for k in ['mask_F1','IoU','mean_absolute_logit_difference','maximum_absolute_logit_difference',
                          'mask_pixel_flip_fraction','F1_delta_from_actual','IoU_delta_from_actual']}
             for v in VARIANTS}
    result=dict(status='COMPLETE_EXPLORATORY_VAL_CONDITIONING_DIAGNOSTIC',models=6,examples_per_model=695,
        summary_equal_weight_models=summary,per_model=rows,input_sha256=before,
        checkpoint_hashes=checkpoint_hashes,script_sha256=sha(Path(__file__)),seconds=time.monotonic()-start,
        unchanged_primary_study_inputs=True,threshold_selection=False,training=False,TEST_arrays_opened=False,
        scope='Post-pilot exploratory VAL-only representation interventions in fixed trained joint decoders. '
              'No threshold retuning, no TEST inference, no change to primary pilot outcome; impacts do not establish generalization.')
    (ROOT/'CONDITIONING_DIAGNOSTIC.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# Использование физических карт обученным декодером', '',
        '**Дополнительная исследовательская диагностика только VAL. Первичный исход пилота не меняется.**','',
        'Шесть окончательных joint-моделей проверены на всех 695 VAL-примерах. '
        'Веса и выбранный для каждой модели порог неизменны. Каналы карт обнуляются, '
        'сдвигаются на (5,5) или заменяются приближёнными физическими картами. '
        'Это вмешательства в фиксированную модель, без переобучения и без нового подбора.', '',
        '| Вариант карт | VAL Macro-F1, % | Δ F1, п.п. | Среднее абсолютное изменение логита | Доля изменившихся пикселей, % |',
        '|---|---:|---:|---:|---:|']
    for name in VARIANTS:
        row=summary[name]
        lines.append(f"| {name} | {100*row['mask_F1']:.3f} | {100*row['F1_delta_from_actual']:+.3f} | "
                     f"{row['mean_absolute_logit_difference']:.6g} | {100*row['mask_pixel_flip_fraction']:.6f} |")
    lines+=['','Числа усреднены с одинаковым весом шести моделей. Это не оценки на TEST '
        'и не интервалы статистической значимости. Отсутствие изменений маски может '
        'означать слабое использование каналов или недостаточную величину воздействия; '
        'оно само по себе не доказывает их бесполезность для любого обучения.', '',
        'Полные различия логитов, границы/центра карт и каждой модели сохранены в '
        '[CONDITIONING_DIAGNOSTIC.json](CONDITIONING_DIAGNOSTIC.json). '
        '[Исполняемый код](conditioning_diagnostic.py).','']
    (ROOT/'CONDITIONING_DIAGNOSTIC.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(dict(status=result['status'],seconds=result['seconds'],summary=summary)),flush=True)


if __name__=='__main__':
    main()
