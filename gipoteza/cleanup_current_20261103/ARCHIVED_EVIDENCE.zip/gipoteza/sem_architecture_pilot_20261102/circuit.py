"""Differentiable, mask-consistent pixel-edit maps for the architecture pilot.

Every boundary pixel is a separate virtual electrical port. No annotation or
class label enters this module. The physics runs on CPU float64, including when
the surrounding convolutional model runs on MPS. Transfers retain autograd.
The fixed CPU constants are deliberately ordinary attributes, not buffers:
``model.to('mps')`` must not move unsupported float64 constants onto MPS.

This is a known low-rank update identity, not a claim of mathematical novelty.
"""
from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class CircuitMaps(nn.Module):
    """Return [addition, removal] DtN-change magnitudes, shape B,2,H,W.

    Modes differ only in their physical response approximation; terminal
    geometry, normalization and output channels are shared.
    """
    MODES = ('first_order', 'independent', 'joint')

    def __init__(self, size: int = 12, epsilon: float = 1e-3,
                 norm_smoothing: float = 1e-12):
        super().__init__()
        assert size >= 3 and 0 < epsilon < .5 and norm_smoothing > 0
        self.size = int(size)
        self.epsilon = float(epsilon)
        self.norm_smoothing = float(norm_smoothing)
        n = self.size; nv = n*n
        pairs = [(y*n+x, yy*n+xx) for y in range(n) for x in range(n)
                 for yy, xx in ((y+1, x), (y, x+1)) if yy < n and xx < n]
        src = torch.tensor([p[0] for p in pairs], dtype=torch.long)
        dst = torch.tensor([p[1] for p in pairs], dtype=torch.long)
        ports = torch.tensor([y*n+x for y in range(n) for x in range(n)
                              if y in (0, n-1) or x in (0, n-1)], dtype=torch.long)
        free = torch.tensor([y*n+x for y in range(1, n-1) for x in range(1, n-1)],
                            dtype=torch.long)
        incident = torch.zeros((nv, 4), dtype=torch.long)
        neighbors = torch.arange(nv)[:, None].expand(nv, 4).clone()
        valid = torch.zeros((nv, 4), dtype=torch.float64)
        for vertex in range(nv):
            edges = torch.nonzero((src == vertex) | (dst == vertex)).flatten()
            incident[vertex, :len(edges)] = edges
            neighbors[vertex, :len(edges)] = torch.where(src[edges] == vertex, dst[edges], src[edges])
            valid[vertex, :len(edges)] = 1
        # Boundary nodes map to a sentinel zero row/column of the padded Green
        # matrix; this includes port-port edges without special-case formulas.
        lookup = torch.full((nv,), len(free), dtype=torch.long)
        lookup[free] = torch.arange(len(free))
        self._cpu = dict(src=src, dst=dst, ports=ports, free=free,
                         incident=incident, neighbors=neighbors, valid=valid,
                         source_free=lookup[src[incident]], destination_free=lookup[dst[incident]],
                         eye4=torch.eye(4, dtype=torch.float64))
        with torch.no_grad():
            full = torch.full((1, nv), 1-self.epsilon, dtype=torch.float64)
            _, _, _, response = self._system(full)
            self._normalizer = torch.linalg.vector_norm(response).detach()
            assert float(self._normalizer) > 0

    def extra_repr(self):
        return (f'size={self.size}, epsilon={self.epsilon}, '
                f'ports={len(self._cpu["ports"])}, physics=cpu_float64')

    def _system(self, q):
        """Grounded Green matrix, edge voltage patterns and full DtN response."""
        g = self._cpu
        src, dst, ports, free = (g[k] for k in ('src', 'dst', 'ports', 'free'))
        batch, nv = q.shape
        conductance = torch.minimum(q[:, src], q[:, dst])
        diagonal = torch.zeros_like(q)
        diagonal = diagonal.scatter_add(1, src[None].expand(batch, -1), conductance)
        diagonal = diagonal.scatter_add(1, dst[None].expand(batch, -1), conductance)
        laplacian = torch.diag_embed(diagonal)
        laplacian[:, src, dst] = -conductance
        laplacian[:, dst, src] = -conductance
        A = laplacian[:, free][:, :, free]
        cross = laplacian[:, ports][:, :, free]
        eye = torch.eye(len(free), dtype=q.dtype).expand(batch, -1, -1)
        inverse = torch.linalg.solve(A, eye)
        inner = -inverse @ cross.transpose(-1, -2)
        voltage = torch.zeros((batch, nv, len(ports)), dtype=q.dtype)
        voltage[:, free] = inner
        voltage[:, ports] = torch.eye(len(ports), dtype=q.dtype)
        edge_voltage = voltage[:, src]-voltage[:, dst]
        response = laplacian[:, ports][:, :, ports]+cross @ inner
        return conductance, inverse, edge_voltage, response

    def _maps_from_q(self, q, mode='joint'):
        """Internal CPU-double implementation, also used by numerical checks."""
        assert mode in self.MODES, mode
        assert q.device.type == 'cpu' and q.dtype == torch.float64
        assert q.ndim == 2 and q.shape[1] == self.size*self.size
        g = self._cpu
        conductance, inverse, edge_voltage, _ = self._system(q)
        valid = g['valid']
        local_voltage = edge_voltage[:, g['incident']]*valid[None, :, :, None]
        gram = local_voltage @ local_voltage.transpose(-1, -2)
        padded_green = F.pad(inverse, (0, 1, 0, 1))
        sf, df = g['source_free'], g['destination_free']
        H = (padded_green[:, sf[:, :, None], sf[:, None, :]]
             -padded_green[:, sf[:, :, None], df[:, None, :]]
             -padded_green[:, df[:, :, None], sf[:, None, :]]
             +padded_green[:, df[:, :, None], df[:, None, :]])
        H = H*valid[None, :, :, None]*valid[None, :, None, :]
        old_c = conductance[:, g['incident']]
        # Since every q already lies in [eps,1-eps], these are the exact
        # min(q_i,q_j) conductances after changing the selected pixel.
        addition = (q[:, g['neighbors']]-old_c)*valid
        removal = (self.epsilon-old_c)*valid
        delta = torch.stack((addition, removal), dim=1)
        if mode == 'first_order':
            K = torch.diag_embed(delta)
        elif mode == 'independent':
            r = torch.diagonal(H, dim1=-2, dim2=-1)
            denominator = 1+delta*r[:, None]
            K = torch.diag_embed(delta/denominator)
        else:
            # (D^-1+H)^-1 == (I+D H)^-1 D, including delta==0.
            middle = g['eye4']+delta.unsqueeze(-1)*H[:, None]
            K = torch.linalg.solve(middle, torch.diag_embed(delta))
            K = .5*(K+K.transpose(-1, -2))
        # ||T K T^T||_F^2 = tr(K G K G), G=T^T T. No B*N*44*44
        # response tensors are materialized for the 144 pixel interventions.
        product = K @ gram[:, None]
        norm_squared = (product*product.transpose(-1, -2)).sum((-1, -2))
        smoothing = self.norm_smoothing
        magnitude = torch.sqrt(norm_squared.clamp_min(0)+smoothing*smoothing)-smoothing
        return magnitude/self._normalizer

    def forward(self, logits, mode='joint'):
        assert logits.ndim == 4 and logits.shape[1:] == (1, self.size, self.size), logits.shape
        assert logits.is_floating_point()
        device, dtype = logits.device, logits.dtype
        # Separate the device and dtype conversions: combined MPS->CPU float64
        # conversion has previously produced unsupported intermediate transfers.
        x = logits.to(device='cpu').to(dtype=torch.float64)
        q = x.sigmoid().reshape(len(x), -1).clamp(self.epsilon, 1-self.epsilon)
        maps = self._maps_from_q(q, mode).reshape(len(x), 2, self.size, self.size)
        return maps.to(dtype=dtype).to(device=device)
