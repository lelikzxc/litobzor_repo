"""Report the frozen CNN architecture pilot; no fitting or selection occurs here."""
from pathlib import Path
import hashlib
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
ARMS = ['base', 'plain', 'first_order', 'independent', 'joint']
BUDGETS = [18, 27]
RUS = {
    'base': 'Исходная CNN',
    'plain': 'CNN + обычный уточнитель',
    'first_order': 'CNN + карты первого порядка',
    'independent': 'CNN + независимые конечные изменения рёбер',
    'joint': 'CNN + совместное изменение пикселя',
}
ENG = {
    'base': 'Base CNN', 'plain': 'CNN + plain refiner',
    'first_order': 'CNN + first-order maps',
    'independent': 'CNN + independent finite edits',
    'joint': 'CNN + joint pixel edits',
}


def read(name):
    return json.loads((ROOT / name).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(name, value):
    path = ROOT / name
    temporary = path.with_suffix(path.suffix + '.partial')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def pct(value):
    return f'{100*value:.2f}'


def pp(value):
    return f'{100*value:+.2f}'


def figures(result, scores):
    folder = ROOT / 'figures'
    folder.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, ax = plt.subplots(figsize=(9, 5))
    for ai, arm in enumerate(ARMS):
        points = 100*np.array([result['metrics'][str(b)][arm]['mask_F1'] for b in BUDGETS])
        interval = 100*np.quantile(scores[:, ai], [.025, .975], axis=1)
        line, = ax.plot(BUDGETS, points, marker='o', lw=2.3 if arm == 'joint' else 1.5,
                        label=ENG[arm])
        ax.fill_between(BUDGETS, interval[0], interval[1], color=line.get_color(), alpha=.075)
    ax.set(xticks=BUDGETS, xlabel='Dense masks (1152 weak labels fixed)',
           ylabel='Mask-derived classification Macro-F1, %',
           title='CNN architecture pilot: 500 additional updates, identical loss')
    ax.grid(alpha=.2)
    ax.legend(fontsize=8, loc='best')
    fig.tight_layout()
    fig.savefig(folder / 'architecture_f1.png', dpi=180)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(9, 4.7))
    for ai, arm in enumerate(ARMS[:-1]):
        row = result['joint_minus_control'][arm]
        lo, hi = 100*np.array(row['CI98_75'])
        ax.plot([lo, hi], [ai, ai], color='C4', lw=2)
        ax.scatter([100*row['delta']], [ai], color='C4', zorder=3)
    ax.axvline(0, color='black', lw=1)
    ax.axvline(1, color='gray', lw=1, ls='--', label='Prespecified gain: 1 pp')
    ax.set(yticks=range(4), yticklabels=[ENG[a] for a in ARMS[:-1]],
           xlabel='Joint-pixel model minus control, percentage points',
           title='Primary mean over 18/27 masks; Bonferroni 98.75% intervals')
    ax.invert_yaxis()
    ax.grid(axis='x', alpha=.2)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(folder / 'primary_comparisons.png', dpi=180)
    plt.close(fig)


def main():
    result = read('RESULT.json')
    audit = read('AUDIT.json')
    complete = read('TRAINING_COMPLETE.json')
    selection = read('SELECTION.json')
    config = read('CONFIG.json')
    index = read('EVAL_INDEX.json')
    manifest = read('DATA_MANIFEST.json')
    assert result['status'] in ['PASS_PILOT', 'FAIL_PILOT']
    assert audit['status'] == 'PASS_AUDIT' and all(audit['checks'].values())
    assert config['arms'] == ARMS and config['budgets'] == BUDGETS
    with np.load(ROOT / 'BOOTSTRAP.npz', allow_pickle=False) as z:
        scores = z['scores']
    assert scores.shape == (2, 5, 10000)
    figures(result, scores)
    best_control = max(ARMS[:-1], key=lambda arm: result['primary_metrics'][arm]['mask_F1'])
    joint = result['primary_metrics']['joint']
    strongest = result['primary_metrics'][best_control]
    descriptive_delta = joint['mask_F1'] - strongest['mask_F1']
    outcome = ('В заранее ограниченном пилоте выполнены все условия совместного '
               'превосходства над четырьмя контролями.' if result['status'] == 'PASS_PILOT' else
               'Заранее установленный критерий совместного превосходства над четырьмя '
               'контролями не выполнен. Причины по каждому сравнению приведены ниже.')
    nchecks = len(audit['checks'])
    lines = [
        '# Малый пилот изменения архитектуры CNN — 2 ноября 2026', '',
        f"**Научный исход: `{result['status']}`. Независимый аудит: `{audit['status']}` "
        f"({nchecks}/{nchecks}).**", '',
        '**Проверяется изменение модели:** к существующей CNN добавлены три обучаемые '
        'свёрточные ветви «сохранить / добавить / удалить». Они работают при обычном '
        'предсказании и уточняют маску металла. Функция потерь одинакова у всех пяти '
        'архитектур; нового лосса в этом опыте нет.', '',
        f"Средний Macro-F1 по 18/27 маскам у полного варианта — **{pct(joint['mask_F1'])}%**; "
        f"у численно лучшего контроля ({RUS[best_control]}) — **{pct(strongest['mask_F1'])}%**, "
        f"разность **{pp(descriptive_delta)} п.п.** Это описательное ранжирование; "
        'основной исход определяется всеми четырьмя заранее заданными сравнениями.', '',
        outcome, '',
        f"Прирост полного варианта относительно исходной CNN — только "
        f"**{pp(result['joint_minus_control']['base']['delta'])} п.п.**, относительно "
        f"лучшего контроля — **{pp(descriptive_delta)} п.п.** Подтверждённого выигрыша нет. "
        f"Ошибка связности составляет {pct(joint['path_error'])}% против "
        f"{pct(result['primary_metrics']['base']['path_error'])}% у исходной CNN; "
        'это точечные оценки, а не доказательство статистического ухудшения.', '',
        'Обучаемый модуль реализован и меняет логиты, однако работа именно '
        'предлагаемого механизма пока не продемонстрирована: последующая '
        'диагностика на VAL показывает крайне слабую зависимость итоговых масок '
        'от физических карт. Диагностика описана отдельно ниже и не меняет '
        'первичный результат TEST.', '',
        '## Что именно изменено в CNN', '',
        '```text',
        'SEM → исходная CNN → признаки и предварительная маска',
        '                          ↓',
        '              две обусловливающие карты',
        '                          ↓',
        '          свёрточные ветви сохранить / добавить / удалить',
        '                          ↓',
        '                     итоговая маска',
        '```', '',
        'Все уточнители имеют **6099 дополнительных обучаемых параметров**: три '
        'ветви Conv3×3(28→8), GELU, Conv1×1(8→1). Вход каждой ветви — 24 признака '
        'исходной CNN, предварительный логит, нормализованное SEM-изображение и две '
        'карты. Всего **16 780 параметров** вместо **10 681** у исходной CNN. '
        'Четыре уточнителя имеют одинаковую ёмкость; меняется источник карт.', '',
        '$$',
        r'a=\operatorname{softmax}(h_{\mathrm{keep}},h_{\mathrm{add}},h_{\mathrm{remove}}),'
        r'\qquad z_1=z_0+2(a_{\mathrm{add}}-a_{\mathrm{remove}}).',
        '$$', '',
        'Нулевая инициализация последних свёрток даёт точное начальное совпадение '
        'с исходной сетью, сохраняя градиенты добавляющей и удаляющей ветвей. '
        'Большое электрическое последствие правки не означает её правильность: '
        'решение обучается по изображению и авторским маскам.', '',
        '| Вариант | Источник двух карт | Параметры |',
        '|---|---|---:|',
        '| Исходная CNN | Уточнителя нет | 10 681 |',
        '| Обычный уточнитель | Вероятность металла и её неопределённость | 16 780 |',
        '| Первый порядок | Линейное приближение электрического отклика | 16 780 |',
        '| Независимые изменения | Сумма конечных изменений отдельных рёбер | 16 780 |',
        '| Совместное изменение пикселя | Точный совместный отклик всех затронутых рёбер | 16 780 |', '',
        r'Физические варианты используют одну сетку $12\times12$, 44 отдельных '
        'граничных виртуальных контакта и 100 внутренних узлов. Проводимости '
        'привязаны к предсказанной маске. Оценки добавления и удаления меняют все '
        'затронутые рёбра одного пикселя. Формула Woodbury известна; новой '
        'математической теоремы и реальных электрических измерений здесь нет.', '',
        'Общий ранее исследованный лосс: BCE на плотных масках плюс регуляризация '
        'проводимости с коэффициентом 1 по тем же 1152 слабым меткам. Он фиксирован '
        'для всех архитектур и не объясняет различия между ними.', '',
        '## Данные и способ обучения', '',
        f"Полный новый TEST: **{manifest['split_counts']['test']:,} участков восьми кадров**. "
        f"Для ограниченной по времени оценки зафиксирован EVAL: **{index['examples']:,} участков**, "
        'по 256 с каждого кадра, выбор по SHA без использования класса. Все девять '
        'классов представлены во всех восьми кадрах. Исключены точные D4-повторы '
        'со всеми четырьмя предыдущими опытами. TRAIN/VAL совпадает с прежним '
        'архивом побайтно.', '',
        '**Это дообучение, а не обучение архитектур с нуля.** Для каждой пары '
        '«18/27 масок × seed» взята одна ранее обученная CNN из опыта дефицита '
        'разметки. Все пять вариантов получают одинаковый исходный сегментатор '
        'и последовательности батчей, все четыре уточнителя — одинаковые начальные '
        'веса. Старые тестовые результаты не использовались для выбора исходных '
        'моделей; их список определён единым правилом.', '',
        'Три seed: 5501, 5521, 5557. Плотные маски взяты из **одного** вложенного '
        'розыгрыша 5303: 2/класс при бюджете 18 и 3/класс при бюджете 27. '
        'Чувствительность к другим розыгрышам разметки в этом пилоте не оценена. '
        'У каждой из 30 моделей — 500 дополнительных шагов, суммарно 15 000 '
        'обновлений. Количество прежних шагов не прибавляется к новым.', '',
        'Порог выбирается на VAL **после полного дообучения каждой итоговой '
        'модели** из одной общей сетки семи значений. Все пороги фиксируются до '
        'тестовых предсказаний. Порог 0,5 публикуется отдельно как вторичный '
        'результат и не заменяет основной после просмотра TEST.', '',
        '## Основной результат', '',
        '| Архитектура | F1: 18 масок, % | F1: 27 масок, % | Среднее F1, % | Среднее IoU, % | Ошибка связности, % |',
        '|---|---:|---:|---:|---:|---:|',
    ]
    for arm in ARMS:
        mean = result['primary_metrics'][arm]
        lines.append(f"| {RUS[arm]} | {pct(result['metrics']['18'][arm]['mask_F1'])} | "
                     f"{pct(result['metrics']['27'][arm]['mask_F1'])} | {pct(mean['mask_F1'])} | "
                     f"{pct(mean['IoU'])} | {pct(mean['path_error'])} |")
    lines += [
        '', '![Качество архитектур](figures/architecture_f1.png)', '',
        'Заливки показывают номинальные 95% интервалы парного crossed bootstrap '
        'по восьми кадрам и трём seed. Классификация вычисляется по итоговой '
        'бинарной маске. Ошибка связности — доля участков с неверным наличием '
        'хотя бы одного из путей слева направо / сверху вниз; это не полная '
        'метрика электрических дефектов и не ESD.', '',
        '| Полный вариант минус контроль | ΔF1, п.п. | 98.75% CI, п.п. | ΔIoU, п.п. | ΔF1: 18 / 27, п.п. | Все условия |',
        '|---|---:|---:|---:|---:|---|',
    ]
    for arm in ARMS[:-1]:
        row = result['joint_minus_control'][arm]
        lo, hi = row['CI98_75']; d18, d27 = row['budget18_27_deltas']
        lines.append(f"| {RUS[arm]} | {pp(row['delta'])} | [{pp(lo)}; {pp(hi)}] | "
                     f"{pp(row['IoU_delta'])} | {pp(d18)} / {pp(d27)} | "
                     f"{'PASS' if all(row['gates'].values()) else 'FAIL'} |")
    lines += [
        '', '![Первичные сравнения](figures/primary_comparisons.png)', '',
        'Основной критерий — равновесное среднее Macro-F1 по 18 и 27 маскам, '
        'усреднённое по трём seed. Для совместного PASS нужны против каждого '
        'из четырёх контролей: прирост не менее 1 п.п., положительная нижняя '
        'граница 98.75% интервала, неотрицательный средний прирост на обоих '
        'бюджетах и потеря IoU не более 0,5 п.п. Интервалы получены из '
        '10 000 парных повторов с поправкой Бонферрони на четыре сравнения.', '',
        'Широкий интервал не доказывает эквивалентность. Улучшение только '
        'относительно исходной CNN не отделяет физический механизм от добавленных '
        'параметров. Улучшение относительно обычного уточнителя, но не относительно '
        'первого порядка или независимых изменений, не подтверждает особую пользу '
        'точного совместного оператора.', '',
        '## Все бюджеты и оба способа выбора порога', '',
        '| Масок | Архитектура | Пороги по трём seed | F1, % | IoU, % | Ошибка связности, % |',
        '|---:|---|---|---:|---:|---:|',
    ]
    for budget in BUDGETS:
        for arm in ARMS:
            thresholds = [selection['chosen'][str(budget)][str(seed)][arm]['threshold'] for seed in config['seeds']]
            for mode, section in [('VAL', result['metrics']), ('0.5', result['secondary_fixed05'])]:
                row = section[str(budget)][arm]
                values = ' / '.join(f'{t:.2f}' for t in thresholds) if mode == 'VAL' else '0.50 / 0.50 / 0.50'
                lines.append(f"| {budget} | {RUS[arm]} ({mode}) | {values} | {pct(row['mask_F1'])} | "
                             f"{pct(row['IoU'])} | {pct(row['path_error'])} |")
    corrections = result.get('correction_statistics', {})
    if corrections:
        lines += ['', '## Действительно ли новый блок меняет предсказание', '',
                  '| Масок | Архитектура | Средняя абсолютная поправка логита | Максимальная поправка |',
                  '|---:|---|---:|---:|']
        for budget in BUDGETS:
            for arm in ARMS:
                obs = [corrections[f'final_b{budget}_{arm}_s{seed}.pt'] for seed in config['seeds']]
                mean = np.mean([x['mean_absolute_logit_correction'] for x in obs])
                maximum = max(x['maximum_absolute_logit_correction'] for x in obs)
                lines.append(f'| {budget} | {RUS[arm]} | {mean:.6f} | {maximum:.6f} |')
        lines += ['', 'Ненулевая поправка свидетельствует о работе блока, но сама по себе '
                  'не означает улучшение маски. Карты последствий рассчитываются по '
                  'предварительной маске; эталонные маски и классы в прямой проход не входят.']
    if (ROOT / 'CONDITIONING_DIAGNOSTIC.json').exists():
        diagnostic = read('CONDITIONING_DIAGNOSTIC.json')
        assert diagnostic['TEST_arrays_opened'] is False and diagnostic['training'] is False
        assert diagnostic['threshold_selection'] is False and diagnostic['unchanged_primary_study_inputs'] is True
        summary = diagnostic['summary_equal_weight_models']
        total_pixels = diagnostic['models'] * diagnostic['examples_per_model'] * 144
        zero_flips = round(summary['zero_maps']['mask_pixel_flip_fraction'] * total_pixels)
        rolled_flips = round(summary['rolled_maps']['mask_pixel_flip_fraction'] * total_pixels)
        relative = [row['raw_map_differences'][mode]['relative_RMS'] for row in diagnostic['per_model']
                    for mode in ['first_order', 'independent']]
        add_ratio = [row['actual_map_statistics'][0]['boundary_over_interior_RMS'] for row in diagnostic['per_model']]
        remove_ratio = [row['actual_map_statistics'][1]['boundary_over_interior_RMS'] for row in diagnostic['per_model']]
        lines += [
            '', '## Дополнительная диагностика: использует ли CNN физические карты', '',
            '**Последующий исследовательский анализ только на VAL.** '
            f"Проверены {diagnostic['models']} фиксированных моделей полного варианта, "
            f"по {diagnostic['examples_per_model']} валидационных примеров. Модели и пороги "
            'не изменялись, нового обучения и обращения к TEST не было.', '',
            f"Обнуление обеих карт изменило **{zero_flips} из {total_pixels:,}** проверенных "
            'бинарных пикселей: Macro-F1 и IoU остались прежними у всех шести моделей. '
            f"Сдвиг карт на (5, 5) изменил **{rolled_flips} из {total_pixels:,}** пикселей "
            'и не изменил Macro-F1. Малые изменения логитов при этом сохраняются.', '',
            'Замена точных совместных карт картами первого порядка либо независимых '
            'рёберных изменений также не изменила бинарные маски, Macro-F1 или IoU. '
            f"При этом относительное RMS-различие самих карт составляет "
            f"{100*min(relative):.1f}–{100*max(relative):.1f}%: операторы не являются "
            'численно одинаковыми.', '',
            f"RMS карт у границы превышает внутреннюю RMS в "
            f"{min(add_ratio):.1f}–{max(add_ratio):.1f} раза для добавления и "
            f"{min(remove_ratio):.1f}–{max(remove_ratio):.1f} раза для удаления. "
            'Такой масштабный дисбаланс является наблюдением, а не доказанной '
            'причиной слабого использования карт.', '',
            '**Интерпретация:** при текущем коротком дообучении декодер в значительной '
            'степени игнорирует физические каналы в решениях о бинарной маске. Это '
            'объяснение согласуется с близостью архитектурных результатов, но не '
            'доказывает эквивалентность операторов или невозможность обучить такой '
            'механизм иначе. Это не новый результат TEST и не основание менять '
            'первичный критерий задним числом.', '',
            '[Отдельный разбор](CONDITIONING_DIAGNOSTIC.md), '
            '[скрипт](conditioning_diagnostic.py), '
            '[полные числа и SHA](CONDITIONING_DIAGNOSTIC.json).',
        ]
    lines += [
        '', '## Аудит и границы вывода', '',
        f"Независимый аудит: **{nchecks}/{nchecks}** проверок. Сохранены шесть исходных "
        'контрольных точек и 30 новых моделей, все VAL-вероятности, выбранные '
        'пороги, тестовые классы и маски, индексы повторной выборки, SHA256 '
        'исходников и данных. Численная проверка оператора и технический '
        'PASS отделены от научного PASS/FAIL.', '',
        f"Дообучение: **{complete['seconds']/60:.2f} мин**. "
        f"Тестовая оценка: **{result.get('seconds', 0)/60:.2f} мин**. "
        'К архитектуре добавлен вычислительный оператор, поэтому увеличение '
        'качества, если оно обнаружено, нельзя автоматически называть бесплатным '
        'по времени инференса. Измерения технического прогона сохранены отдельно.', '',
        r'Текущий масштаб — $12\times12$ после фиксированного уменьшения '
        'SEM-фрагмента. Проверяются геометрия металла и девять производных '
        'геометрических состояний. Это не независимые метки девяти реальных '
        'видов производственного брака, не электрические измерения и не '
        'подтверждение повышения выхода годных.', '',
        'Восемь кадров принадлежат одному физическому кристаллу. Неиспользованные '
        'участки полного TEST сохранены, но относятся к тем же кадрам и не могут '
        'служить новым независимым тестом. Короткое дообучение, три seed и один '
        'розыгрыш плотных масок ограничивают вывод. FAIL в таком скрининге '
        'не опровергает всё семейство возможных архитектур и режимов обучения.', '',
        'Мировая новизна и готовность к публикации этим опытом не устанавливаются. '
        'Формула Woodbury, физические чувствительности и обучаемые уточнители '
        'известны. Кандидат на вклад — конкретное использование согласованных '
        'пиксельных вмешательств внутри CNN-декодера; его границы разобраны '
        'в [повторной проверке литературы](../architecture_novelty_recheck_20261102/NOVELTY_RECHECK.md).', '',
        '## Файлы для воспроизведения', '',
        '- [Протокол](PROTOCOL.md), [конфигурация](CONFIG.json), [подвыборки](SUBSETS.json).',
        '- [Новая модель](model.py), [электрический оператор](circuit.py), [его проверка](circuit_check.py).',
        '- [Подготовка данных](prepare.py), [обучение](train.py), [оценка](evaluate.py), [независимый аудит](audit.py).',
        '- [Все тестовые числа](final_test_results.csv), [полный результат](RESULT.json), [аудит](AUDIT.json).',
        '- [Генератор отчёта](report.py), [манифест тестовой подвыборки](EVAL_INDEX.json).',
        '- [Предыдущий опыт с неизменной архитектурой](../sem_scarcity_20261102/REPORT.md).', '',
    ]
    (ROOT / 'REPORT.md').write_text('\n'.join(lines), encoding='utf-8')
    (ROOT / 'README.md').write_text(
        '# Пилот модификации CNN\n\n'
        f"Завершён: **{result['status']}**, независимый аудит **{audit['status']}**.\n\n"
        '[Отчёт с числами и графиками](REPORT.md). [Протокол](PROTOCOL.md).\n\n'
        'Исследуется изменение модели: три обучаемые свёрточные ветви уточнения '
        'маски, 6099 дополнительных параметров, работающих при инференсе. '
        'Лосс одинаков во всех пяти вариантах.\n\n'
        'Это 500 дополнительных шагов для каждой из 30 моделей от шести '
        'одинаково выбранных ранее обученных CNN, не обучение с нуля. '
        'Тестовая оценка — 2048 участков восьми новых кадров одного кристалла; '
        'полные 13 204 участка сохранены.\n\n'
        'Исходники, все веса, вероятности, предсказания, маски и журналы '
        'сохранены в этой папке. Повторный запуск поверх завершённого '
        'научного опыта запрещён.\n', encoding='utf-8')
    names = ['README.md', 'REPORT.md', 'figures/architecture_f1.png', 'figures/primary_comparisons.png']
    report_manifest = dict(status='COMPLETE_REPORT', result_sha256=sha(ROOT/'RESULT.json'),
        audit_sha256=sha(ROOT/'AUDIT.json'), script_sha256=sha(Path(__file__)),
        report_script_sha256=sha(Path(__file__)),
        files_sha256={name: sha(ROOT/name) for name in names})
    write_json('REPORT_MANIFEST.json', report_manifest)
    print(json.dumps(report_manifest), flush=True)


if __name__ == '__main__':
    main()
