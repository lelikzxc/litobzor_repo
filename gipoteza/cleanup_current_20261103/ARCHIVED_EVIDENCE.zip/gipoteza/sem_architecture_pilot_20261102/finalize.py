"""Persistently finish the authorized study after successful training.

No parameters are selected here. Training, evaluation and audit remain separate
stages with distinct immutable inputs and logs. The driver stops on any error.
"""
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def status(stage, state, **extra):
    record = dict(stage=stage, status=state,
                  updated_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), **extra)
    temporary = ROOT/'PIPELINE.json.partial'
    temporary.write_text(json.dumps(record, indent=2)+'\n')
    temporary.replace(ROOT/'PIPELINE.json')
    print(json.dumps(record), flush=True)


def main():
    assert not (ROOT/'PIPELINE.json').exists(), 'One driver per experiment'
    status('WAIT_TRAINING', 'RUNNING')
    while True:
        path = ROOT/'TRAIN_EXECUTION.json'
        if path.exists():
            try:
                training = json.loads(path.read_text())
            except json.JSONDecodeError:
                time.sleep(1)
                continue
            if training['status'] != 'COMPLETE':
                status('TRAINING', 'FAILED', training=training)
                return 1
            break
        time.sleep(5)
    assert (ROOT/'TRAINING_COMPLETE.json').exists()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='2',
               OMP_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2', PYTORCH_ENABLE_MPS_FALLBACK='0')
    for name in ['evaluate', 'audit', 'report', 'verify']:
        status(name, 'RUNNING')
        code = subprocess.call([sys.executable, '-B', str(ROOT/'run_stage.py'), name],
                               cwd=ROOT.parent.parent, env=env)
        if code != 0:
            status(name, 'FAILED', returncode=code)
            return code
    complete = json.loads((ROOT/'COMPLETE.json').read_text())
    status('ALL', 'COMPLETE', scientific_status=complete['scientific_status'],
           audit_status=complete['audit_status'])
    return 0


if __name__=='__main__':
    sys.exit(main())
