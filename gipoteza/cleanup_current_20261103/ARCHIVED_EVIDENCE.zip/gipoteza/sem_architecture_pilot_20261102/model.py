"""CNN segmentation with an inference-time, three-action mask refiner.

Every refiner has exactly the same trainable architecture. Only the two
conditioning maps differ. Circuit maps are derived from the prediction, never
from ground truth or class labels. No training is launched on import.
"""
from pathlib import Path
import hashlib

import torch
from torch import nn

ARMS = ['base', 'plain', 'first_order', 'independent', 'joint']


def make_backbone():
    return nn.Sequential(
        nn.Conv2d(1, 24, 3, padding=1), nn.GELU(),
        nn.Conv2d(24, 24, 3, padding=2, dilation=2), nn.GELU(),
        nn.Conv2d(24, 24, 3, padding=4, dilation=4), nn.GELU(),
        nn.Conv2d(24, 1, 1),
    )


def action_branch():
    branch = nn.Sequential(nn.Conv2d(28, 8, 3, padding=1), nn.GELU(), nn.Conv2d(8, 1, 1))
    # Equal zero action logits make the logit correction exactly zero. Unlike
    # a zero multiplicative edit gate, add/remove outputs retain gradients.
    nn.init.zeros_(branch[-1].weight)
    nn.init.zeros_(branch[-1].bias)
    return branch


class CircuitSegmenter(nn.Module):
    def __init__(self, arm, epsilon=.001, eta=2.):
        super().__init__()
        assert arm in ARMS, arm
        self.arm = arm
        self.epsilon = float(epsilon)
        self.eta = float(eta)
        assert 0 < self.epsilon < .5 and self.eta > 0
        self.backbone = make_backbone()
        if arm != 'base':
            # Heads are named keep/add/remove, in that fixed order.
            self.actions = nn.ModuleList([action_branch() for _ in range(3)])
        else:
            self.actions = None
        if arm not in ['base', 'plain']:
            from circuit import CircuitMaps
            self.circuit = CircuitMaps(epsilon=self.epsilon)
        else:
            self.circuit = None

    def forward_details(self, x):
        assert x.ndim == 4 and x.shape[1:] == (1, 12, 12), x.shape
        features = self.backbone[:-1](x)
        coarse = self.backbone[-1](features)
        if self.arm == 'base':
            return dict(logits=coarse, coarse=coarse, maps=None, actions=None,
                        correction=torch.zeros_like(coarse))
        probability = coarse.sigmoid()
        if self.arm == 'plain':
            maps = torch.cat((probability, 4*probability*(1-probability)), dim=1)
        else:
            maps = self.circuit(coarse, mode=self.arm)
        assert maps.shape == (len(x), 2, 12, 12), maps.shape
        inputs = torch.cat((features, coarse, x, maps), dim=1)
        action_logits = torch.cat([branch(inputs) for branch in self.actions], dim=1)
        actions = action_logits.softmax(1)
        correction = self.eta*(actions[:, 1:2]-actions[:, 2:3])
        return dict(logits=coarse+correction, coarse=coarse, maps=maps,
                    actions=actions, correction=correction)

    def forward(self, x):
        return self.forward_details(x)['logits']


def make_model(arm, backbone_state=None, *, epsilon=.001, eta=2., decoder_seed=None):
    # The same explicit seed gives the same three action branches across all
    # refiners. The source backbone is loaded after all initialization.
    if decoder_seed is not None:
        torch.manual_seed(decoder_seed)
    net = CircuitSegmenter(arm, epsilon=epsilon, eta=eta)
    if backbone_state is not None:
        net.backbone.load_state_dict(backbone_state, strict=True)
    expected = 10681 if arm == 'base' else 16780
    assert sum(p.numel() for p in net.parameters()) == expected
    return net


def state_digest(state):
    digest = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        digest.update(key.encode()); digest.update(str(value.dtype).encode())
        digest.update(str(value.shape).encode()); digest.update(value.tobytes())
    return digest.hexdigest()


def architecture_spec():
    return dict(backbone_parameters=10681, refiner_parameters=6099,
        total_refined_parameters=16780, actions=['keep', 'add', 'remove'],
        action_branches=3, branch='Conv2d(28,8,3,pad1),GELU,Conv2d(8,1,1)',
        input_channels=['CNN_features24', 'coarse_logit1', 'normalized_SEM1', 'conditioning_maps2'],
        correction='eta*(softmax(action_logits)[add]-softmax(action_logits)[remove])',
        identity_initialization='all three final convolution weights and biases zero',
        plain_maps=['sigmoid(coarse)', '4*p*(1-p)'],
        scope='First_order/independent/joint differ only in the deterministic circuit conditioning maps.')
