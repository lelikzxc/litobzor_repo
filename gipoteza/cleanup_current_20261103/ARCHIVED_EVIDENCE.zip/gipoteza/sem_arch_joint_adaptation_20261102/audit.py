"""Independent CPU audit for joint CNN/FiLM TRAIN/VAL development.

No optimization, external downloads, or TEST/EVAL data access.  Development
gates are not confirmatory tests.  This file is maintained independently of
the model and training runner.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import time

import numpy as np
from scipy import linalg, ndimage
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
PILOT = G / 'sem_architecture_pilot_20261102'
VARIANTS = ['actual', 'zero', 'roll']
COUNTS = {'film': 5537}
ARMS = ['continued_base_low_lr', 'plain', 'joint']
REPO = G.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def digest(state):
    h = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()


def macro_f1(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    denominator = confusion.sum(0) + confusion.sum(1)
    return float(np.divide(2 * np.diag(confusion), denominator,
                           out=np.zeros(9, float), where=denominator > 0).mean())


def mean_iou(masks, target):
    union = (masks | target).sum((-2, -1))
    intersection = (masks & target).sum((-2, -1))
    return float(np.divide(intersection, union, out=np.ones(len(union)),
                           where=union > 0).mean())


def normalized_maps(raw):
    value = np.log1p(100 * np.asarray(raw, dtype=np.float64))
    centered = value - value.mean((-2, -1), keepdims=True)
    return centered / np.sqrt((centered * centered).mean((-2, -1), keepdims=True) + 1e-6)


_DIRECTION_CACHE = {}
_CLASS_CACHE = {}


def direction_class(mask):
    """Independent active-node Cholesky solve of the binary unit-edge graph."""
    mask = np.ascontiguousarray(mask, dtype=bool)
    key = np.packbits(mask).tobytes()
    if key in _DIRECTION_CACHE:
        return _DIRECTION_CACHE[key]
    components, _ = ndimage.label(mask, ndimage.generate_binary_structure(2, 1))
    spanning = np.intersect1d(components[:, 0], components[:, -1])
    spanning = spanning[spanning > 0]
    if not len(spanning):
        answer = 0
    else:
        active = np.isin(components, spanning)
        vertices = np.flatnonzero(active.ravel())
        lookup = np.full(144, -1, dtype=int)
        lookup[vertices] = np.arange(len(vertices))
        laplacian = np.zeros((len(vertices), len(vertices)), dtype=np.float64)
        for vertex in vertices:
            y, x = divmod(int(vertex), 12)
            for yy, xx in [(y + 1, x), (y, x + 1)]:
                if yy < 12 and xx < 12 and active[yy, xx]:
                    a, b = lookup[vertex], lookup[yy * 12 + xx]
                    laplacian[a, a] += 1; laplacian[b, b] += 1
                    laplacian[a, b] -= 1; laplacian[b, a] -= 1
        left = np.flatnonzero(vertices % 12 == 0)
        right = np.flatnonzero(vertices % 12 == 11)
        free = np.setdiff1d(np.arange(len(vertices)), np.r_[left, right])
        potential = np.zeros(len(vertices)); potential[right] = 1
        if len(free):
            potential[free] = linalg.solve(
                laplacian[np.ix_(free, free)],
                -laplacian[np.ix_(free, right)].sum(1), assume_a='pos',
                check_finite=False)
        conductance = float((laplacian[right] @ potential).sum()) / (12 / 11)
        answer = 0 if conductance < 1e-8 else (1 if conductance < .5 - 1e-8 else 2)
    _DIRECTION_CACHE[key] = answer
    return answer


def classify(masks):
    result = []
    for mask in np.asarray(masks, dtype=bool).reshape(-1, 12, 12):
        key = np.packbits(mask).tobytes()
        if key not in _CLASS_CACHE:
            _CLASS_CACHE[key] = 3 * direction_class(mask) + direction_class(mask.T)
        result.append(_CLASS_CACHE[key])
    return np.asarray(result, dtype=np.int64)


def conv(x, state, prefix, padding=0, dilation=1):
    return F.conv2d(x, state[prefix + '.weight'], state[prefix + '.bias'],
                    padding=padding, dilation=dilation)


def independent_backbone(x, state):
    features = x
    for index, dilation in [(0, 1), (2, 2), (4, 4)]:
        features = F.gelu(conv(features, state, str(index), dilation, dilation))
    coarse = conv(features, state, '6')
    return torch.cat((features, coarse, x), 1), coarse


def independent_logits(candidate, state, visual, coarse, maps, intervention='actual'):
    """Functional reconstruction; does not import the candidate model code."""
    if intervention == 'zero':
        maps = torch.zeros_like(maps)
    elif intervention == 'roll':
        maps = torch.roll(maps, (5, 5), (-2, -1))
    if candidate == 'direct':
        residual = conv(F.gelu(conv(torch.cat((visual, maps), 1), state,
                                     'network.0', 1)), state, 'network.2')
    elif candidate == 'split':
        f = F.gelu(conv(visual, state, 'visual.0', 1))
        m = F.gelu(conv(maps, state, 'conditioning.0', 1))
        residual = conv(F.gelu(conv(torch.cat((f, m), 1), state,
                                     'fusion.0')), state, 'fusion.2')
    else:
        features = F.gelu(conv(visual, state, 'visual.0', 1))
        condition = conv(maps, state, 'conditioning', 1)
        if candidate == 'film':
            gamma, beta = condition.chunk(2, 1)
            features = features * (1 + .5 * gamma.tanh()) + .5 * beta.tanh()
        elif candidate == 'gated':
            features = features * (1 + .5 * condition.tanh())
        else:
            raise ValueError(candidate)
        residual = conv(F.gelu(conv(features, state, 'output.0', 1)), state, 'output.2')
    return coarse + 4 * residual.tanh()


def selected(scores):
    return max(scores, key=lambda row: (row['mask_F1'], row['IoU'],
                -abs(row['threshold'] - .5), -row['threshold']))


def gate(delta_f1, delta_iou, config):
    checks = {
        'mean_F1_gain': float(np.mean(delta_f1)) >= config['minimum_mean_F1_gain'],
        'each_budget_guard': min(delta_f1) >= config['minimum_budget_F1_delta'],
        'mean_IoU_guard': float(np.mean(delta_iou)) >= config['minimum_mean_IoU_delta'],
    }
    return {'passed': all(checks.values()), 'checks': checks,
            'mean_F1_delta': float(np.mean(delta_f1)),
            'budget_F1_deltas': list(map(float, delta_f1)),
            'mean_IoU_delta': float(np.mean(delta_iou))}



def independent_gates(rows, high_rows, config):
    """Recompute the two CNN controls and the matched-map comparison."""
    def means(arm):
        return {budget: {metric: float(np.mean([row['selected'][metric] for row in rows
            if row['budget'] == budget and row['arm'] == arm])) for metric in ['mask_F1', 'IoU']}
            for budget in [18, 27]}
    reference = {
        'low_lr': means('continued_base_low_lr'),
        'high_lr': {budget: {metric: float(np.mean([row['selected'][metric] for row in high_rows
            if row['budget'] == budget])) for metric in ['mask_F1', 'IoU']} for budget in [18, 27]},
    }
    values = {arm: means(arm) for arm in ['plain', 'joint']}
    def compare(left, right):
        return gate([left[budget]['mask_F1'] - right[budget]['mask_F1'] for budget in [18, 27]],
                    [left[budget]['IoU'] - right[budget]['IoU'] for budget in [18, 27]], config['gates'])
    architecture = {arm: {name: compare(values[arm], baseline) for name, baseline in reference.items()}
                    for arm in ['plain', 'joint']}
    passes = {arm: all(item['passed'] for item in architecture[arm].values()) for arm in architecture}
    physics = compare(values['joint'], values['plain'])
    physics['joint_architecture_gate'] = passes['joint']
    physics['passed'] &= passes['joint']
    output = {arm: dict(vs_low_lr=architecture[arm]['low_lr'],
                       vs_high_lr=architecture[arm]['high_lr'], passed=passes[arm])
              for arm in ['plain', 'joint']}
    return dict(A_architecture=output, A_any=any(passes.values()), B_physics=physics)


def expected_batch_digest(budget, seed):
    rng = np.random.default_rng(seed + 1000)
    trace = hashlib.sha256()
    for _ in range(500):
        trace.update(rng.integers(0, budget, 8).astype(np.int64).tobytes())
        trace.update(rng.integers(0, 1152, 8).astype(np.int64).tobytes())
    return trace.hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def independent_predictions(weights, arm, images, circuit):
    """Reconstruct current features and detached current maps in CPU batches."""
    backbone = weights if arm == 'continued_base_low_lr' else {
        key[len('backbone.'):]: value for key, value in weights.items() if key.startswith('backbone.')}
    refiner = None if arm == 'continued_base_low_lr' else {
        key[len('refiner.'):]: value for key, value in weights.items() if key.startswith('refiner.')}
    outputs = [[] for _ in VARIANTS]
    fixture = None
    with torch.inference_mode():
        for batch in images.split(16):
            visual, coarse = independent_backbone(batch, backbone)
            if refiner is None:
                logits = [coarse]
                details = dict(visual=visual.numpy(), coarse=coarse.numpy())
            else:
                if arm == 'plain':
                    probability = coarse.sigmoid()
                    raw = torch.cat((probability, 4 * probability * (1 - probability)), 1)
                else:
                    raw = circuit(coarse, mode='joint')
                maps = torch.tensor(normalized_maps(raw.numpy()), dtype=torch.float32)
                logits = [independent_logits('film', refiner, visual, coarse, maps, variant)
                          for variant in VARIANTS]
                details = dict(visual=visual.numpy(), coarse=coarse.numpy(),
                               maps_raw=raw.numpy(), maps=maps.numpy())
            if fixture is None:
                fixture = dict(x=batch.numpy(), **details)
            for index, value in enumerate(logits):
                outputs[index].append(value.numpy())
    logits = np.asarray([np.concatenate(parts) for parts in outputs if parts])
    return logits, fixture


def compare_stored_gates(computed, stored):
    """Compare semantic gate outcomes, permitting only historical key spelling."""
    def canonical(value):
        if isinstance(value, dict):
            names = {'delta': 'mean_F1_delta', 'IoU_delta': 'mean_IoU_delta',
                     'budget_deltas': 'budget_F1_deltas', 'budget_F1_guard': 'each_budget_guard'}
            return {names.get(key, key): canonical(item) for key, item in value.items()
                    if key != 'interpretation'}
        if isinstance(value, list):
            return [canonical(item) for item in value]
        return value
    actual, observed = canonical(computed), canonical(stored)
    def compare(left, right):
        if isinstance(left, dict):
            assert set(left) == set(right), (set(left), set(right))
            return max([compare(left[key], right[key]) for key in left] + [0.])
        if isinstance(left, list):
            assert len(left) == len(right)
            return max([compare(a, b) for a, b in zip(left, right)] + [0.])
        if isinstance(left, bool):
            assert left == right, (left, right)
            return 0.
        return abs(float(left) - float(right))
    return compare(actual, observed)

def audit_trial(folder):
    started = time.monotonic()
    read_local = lambda name: json.loads((folder / name).read_text())
    result, frozen, config = (read_local(name) for name in
                             ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json'])
    monitored = list(folder.glob('*.json')) + list((folder / 'models').glob('*.pt'))
    monitored += [folder / 'PROTOCOL.md', ROOT / 'model.py', ROOT / 'runner.py', PILOT / 'TRAIN_VAL.npz']
    before = {str(path): sha(path) for path in monitored if not path.name.startswith('AUDIT')}
    checks = {}
    checks['development_scope_explicit'] = (
        result['status'] == 'COMPLETE_DEVELOPMENT_TRIAL' and 'VAL' in result['scope'] and
        'no independent confirmation' in result['scope'] and 'no TEST/EVAL' in frozen['scope'])
    checks['frozen_configuration_protocol_and_sources'] = (
        sha(folder / 'FROZEN.json') == result['frozen_sha256'] and
        sha(folder / 'CONFIG_SNAPSHOT.json') == frozen['config_snapshot_sha256'] and
        sha(folder / 'PROTOCOL.md') == frozen['protocol_sha256'] == config['protocol_sha256'] and
        all(sha(ROOT / name) == value for name, value in frozen['source_sha256'].items()) and
        all(sha(folder / 'source' / name) == frozen['source_sha256'][name] for name in ['runner.py', 'model.py']))
    checks['fixed_design_hyperparameters_and_two_controls'] = (
        config['candidate'] == 'film' and config['arms'] == ARMS and config['budgets'] == [18, 27] and
        config['screen_seeds'] == [5501] and config['replication_seeds'] == [5501, 5521, 5557] and
        config['steps'] == 500 and config['warmup_steps'] == 100 and config['batch_size'] == 8 and
        config['backbone_learning_rate'] == .0001 and config['refiner_learning_rate'] == .0005 and
        config['weight_decay'] == .0001 and config['physics_weight'] == 1 and
        config['epsilon'] == .001 and config['eta'] == 4 and config['subset_seed'] == 5303 and
        config['normalization_scale'] == 100 and config['normalization_variance_floor'] == 1e-6 and
        config['thresholds'] == [.3, .4, .45, .5, .55, .6, .7] and
        config['gates'] == dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025,
                               minimum_mean_IoU_delta=-.002))
    tree = ast.parse((folder / 'source' / 'runner.py').read_text())
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    array_reads = [(name, ast.unparse(node)) for name, function in functions.items()
                   for node in ast.walk(function) if isinstance(node, ast.Call) and
                   isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and
                   node.func.value.id == 'np' and node.func.attr == 'load']
    inputs_source = ast.unparse(functions['inputs'])
    checks['runner_array_access_only_TRAIN_VAL_no_weak_masks'] = (
        len(array_reads) == 1 and array_reads[0][0] == 'inputs' and
        "PILOT / 'TRAIN_VAL.npz'" in array_reads[0][1] and
        "if role != 'weak':" in inputs_source)
    fit = functions['fit']; fit_source = ast.unparse(fit)
    loss_assignments = [ast.unparse(node) for node in ast.walk(fit)
                        if isinstance(node, ast.Assign) and any(
                            isinstance(target, ast.Name) and target.id == 'loss' for target in node.targets)]
    checks['exact_old_BCE_plus_geometry_loss_and_live_training_forward'] = (
        loss_assignments == [
            "loss = F.binary_cross_entropy_with_logits(dense, values['dense']['mask'][ai])",
            "loss = loss + c['physics_weight'] * physics.geometry_loss(weak, direction)"] and
        "logits = model(torch.cat((values['dense']['x'][ai], values['weak']['x'][wi])))" in fit_source and
        'forward_cached' not in fit_source and 'precompute' not in fit_source)
    checks['source_100_400_schedule_and_fixed_optimizer_groups'] = (
        "step == c['warmup_steps'] + 1" in fit_source and
        'model.set_backbone_trainable(True)' in fit_source and
        "step <= c['warmup_steps']" in fit_source and
        'all((p.grad is None for p in backbone.parameters()))' in fit_source and
        'all((p.grad is not None and torch.isfinite(p.grad).all() for p in backbone.parameters()))' in fit_source and
        "dict(params=model.backbone.parameters(), lr=c['backbone_learning_rate'])" in fit_source and
        "dict(params=model.refiner.parameters(), lr=c['refiner_learning_rate'])" in fit_source and
        "torch.optim.AdamW(model.parameters(), lr=c['backbone_learning_rate']" in fit_source and
        "range(1, c['steps'] + 1)" in fit_source)
    model_tree = ast.parse((folder / 'source' / 'model.py').read_text())
    current = next(node for node in ast.walk(model_tree) if isinstance(node, ast.FunctionDef) and node.name == 'current_inputs')
    current_source = ast.unparse(current)
    checks['source_current_maps_detached_label_free_live_CNN_paths'] = (
        [argument.arg for argument in current.args.args] == ['self', 'x'] and
        'features = self.backbone[:-1](x)' in current_source and
        'coarse = self.backbone[-1](features)' in current_source and
        'with torch.no_grad():' in current_source and 'detached = coarse.detach()' in current_source and
        "self.circuit(detached, mode='joint')" in current_source and
        "'visual': torch.cat((features, coarse, x), dim=1)" in current_source and
        not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and
                node.func.attr in ['load', 'load_state_dict'] for node in ast.walk(current)))
    lineage = frozen['lineage']; subsets = json.loads((PILOT / 'SUBSETS.json').read_text())
    checks['unchanged_TRAIN_VAL_subsets_and_source_lineage'] = (
        sha(PILOT / 'TRAIN_VAL.npz') == lineage['TRAIN_VAL_sha256'] == subsets['train_val_sha256'] and
        sha(PILOT / 'SUBSETS.json') == lineage['subsets_sha256'] and
        sha(PILOT / 'INITIAL_LINEAGE.json') == lineage['initial_lineage_sha256'] and
        all(sha(G / source['file']) == source['sha256'] for source in lineage['sources'].values()))
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    val = np.flatnonzero(data['role'] == 'val')
    images = torch.tensor(5 * (data['X'][val] - .2))
    truth, target = data['label'][val], data['Y'][val, 0].astype(bool)
    checks['data_roles_frames_and_nested_balanced_subsets'] = (
        {role: int(np.sum(data['role'] == role)) for role in set(data['role'])} ==
        {'dense': 54, 'weak': 1152, 'val': 695} and
        set(data['frame'][val]) == {6, 7} and set(data['frame'][data['role'] != 'val']) == set(range(6)) and
        all(np.array_equal(np.bincount(data['label'][subsets['dense_indices'][str(budget)]], minlength=9),
                           np.full(9, budget // 9)) for budget in [18, 27]) and
        set(subsets['dense_indices']['18']).issubset(subsets['dense_indices']['27']))
    checks['independent_graph_classifier_matches_all_VAL_truth'] = np.array_equal(classify(target), truth)
    phase, seeds = result['phase'], result['seeds']
    expected_seeds = [5501] if phase == 'screen' else [5521, 5557]
    expected_grid = {(budget, seed, arm) for budget in [18, 27] for seed in expected_seeds for arm in ARMS}
    rows = result['rows']
    checks['exact_planned_grid_no_reused_seed_double_count'] = (
        seeds == frozen['seeds'] == expected_seeds and result['candidate'] == frozen['candidate'] == 'film' and
        len(rows) == frozen['models'] == len(expected_grid) and
        {(row['budget'], row['seed'], row['arm']) for row in rows} == expected_grid and
        result['updates'] == frozen['total_updates'] == 500 * len(rows) and
        len(lineage['sources']) == 2 * len(seeds))
    checks['all_checkpoint_file_SHA256'] = len(result['checkpoint_hashes']) == len(rows) and all(
        sha(folder / 'models' / name) == value for name, value in result['checkpoint_hashes'].items())
    high_path = REPO / config['high_lr_control_result']
    high_result = json.loads(high_path.read_text())
    high_audit = json.loads((high_path.parent / 'AUDIT.json').read_text())
    high_frozen = json.loads((high_path.parent / 'FROZEN.json').read_text())
    high_snapshot = read_local('HIGH_LR_CONTROL_SNAPSHOT.json')
    high_rows = [row for row in high_result['rows'] if row['seed'] in seeds]
    checks['shared_high_lr_control_independently_audited_and_exact_snapshot'] = (
        high_path.resolve() == (G / 'sem_arch_iterative_20261102/baseline_control/RESULT.json').resolve() and
        sha(high_path) == frozen['high_lr_control']['result_sha256'] == high_audit['result_sha256'] and
        sha(high_path.parent / 'CONFIG_SNAPSHOT.json') == frozen['high_lr_control']['config_snapshot_sha256'] and
        high_audit['status'] == 'PASS_AUDIT' and all(high_audit['checks'].values()) and
        high_audit['audit_source_sha256'] == sha(G / 'sem_arch_amplitude4_20261102/audit.py') and
        high_snapshot == dict(rows=high_rows, source=frozen['high_lr_control']) and
        result['high_lr_controls'] == high_rows and len(high_rows) == 2 * len(seeds))
    circuit_module = load_module('joint_audit_fixed_circuit', PILOT / 'circuit.py')
    circuit = circuit_module.CircuitMaps(epsilon=.001)
    model_module = load_module('joint_audit_initialization_and_gradient', ROOT / 'model.py')
    source_states = {}
    for budget in [18, 27]:
        for seed in seeds:
            source = lineage['sources'][f'{budget}:{seed}']
            source_states[budget, seed] = torch.load(G / source['file'], map_location='cpu', weights_only=True)['segmenter']
    errors = dict(metrics=0., forward=0., probabilities=0., normalization=0., maps=0., fixture_inputs=0.)
    metadata_ok = True; initialization_ok = True; final_states_ok = True; warmup_ok = True
    counts_ok = True; batches_ok = True; predictions_ok = True; selection_ok = True; fixtures_ok = True
    gradient_ok = True; cache_guard_ok = True; optimizer_ok = True; evidence = []; recomputed_rows = []

    def metric_error(actual, saved):
        for key, value in actual.items():
            errors['metrics'] = max(errors['metrics'], abs(float(value) - float(saved[key])))

    for row in rows:
        budget, seed, arm = row['budget'], row['seed'], row['arm']
        refined = arm != 'continued_base_low_lr'
        stem = f'b{budget}_{arm}_s{seed}'
        checkpoint = torch.load(folder / 'models' / f'{stem}.pt', map_location='cpu', weights_only=True)
        weights = checkpoint['model']; source = lineage['sources'][f'{budget}:{seed}']
        source_state = source_states[budget, seed]
        backbone = {key[len('backbone.'):]: value for key, value in weights.items()
                    if key.startswith('backbone.')} if refined else weights
        refiner = {key[len('refiner.'):]: value for key, value in weights.items()
                   if key.startswith('refiner.')} if refined else None
        high = next(item for item in high_rows if item['budget'] == budget and item['seed'] == seed)
        metadata_ok &= (checkpoint['settings'] == row and row['candidate'] == 'film' and row['steps'] == 500 and
                        row['source_initial'] == source and high['source_initial'] == source and
                        high_frozen['lineage']['sources'][f'{budget}:{seed}'] == source)
        final_states_ok &= (digest(source_state) == source['backbone_sha256'] == row['backbone_before_sha256'] and
                            digest(backbone) == row['backbone_after_sha256'] != row['backbone_before_sha256'])
        expected_count = 16218 if refined else 10681
        counts_ok &= (row['trainable_parameters'] == row['total_parameters'] == expected_count and
                      sum(value.numel() for value in weights.values()) == expected_count and
                      all(torch.isfinite(value).all().item() for value in weights.values()))
        batches_ok &= expected_batch_digest(budget, seed) == row['batch_sequence_sha256'] == high['batch_sequence_sha256']
        optimizer_ok &= (row['backbone_learning_rate'] == .0001 and
                         row['refiner_learning_rate'] == (.0005 if refined else None) and
                         row['CNN_updates'] == (400 if refined else 500) and
                         row['refiner_updates'] == (500 if refined else 0) and
                         row['warmup_steps'] == (100 if refined else 0) and
                         row['joint_steps'] == (400 if refined else 0) and
                         row['optimizer_groups'] == ([
                             dict(parameters='backbone', learning_rate=.0001, update_steps=[101, 500]),
                             dict(parameters='refiner', learning_rate=.0005, update_steps=[1, 500])] if refined else [
                             dict(parameters='backbone', learning_rate=.0001, update_steps=[1, 500])]))
        if refined:
            initial = model_module.make_model(arm, source_state, decoder_seed=seed + 100003)
            initialization_ok &= digest(initial.refiner.state_dict()) == row['decoder_initial_sha256']
            initialization_ok &= digest(refiner) == row['decoder_final_sha256'] != row['decoder_initial_sha256']
            counts_ok &= sum(value.numel() for value in refiner.values()) == 5537
            warmup_ok &= (digest(checkpoint['warmup_backbone']) == row['backbone_after_warmup_sha256'] ==
                          row['backbone_before_sha256'] and
                          all(torch.equal(value, source_state[key]) for key, value in checkpoint['warmup_backbone'].items()) and
                          digest(checkpoint['warmup_refiner']) == row['decoder_after_warmup_sha256'] != row['decoder_initial_sha256'])
            with torch.no_grad():
                identity = initial.forward_details(images[:2])
                initialization_ok &= torch.equal(identity['logits'], identity['coarse'])
            initial.zero_grad(set_to_none=True)
            initial.train()
            warmup = initial.forward_details(images[:2])
            warmup['logits'].sum().backward()
            gradient_ok &= (all(parameter.grad is None for parameter in initial.backbone.parameters()) and
                any(parameter.grad is not None and bool(parameter.grad.abs().sum() > 0) for parameter in initial.refiner.parameters()))
            initial.load_state_dict(weights, strict=True)
            initial.set_backbone_trainable(True); initial.zero_grad(set_to_none=True)
            live_inputs = initial.current_inputs(images[:2])
            live = initial._refine(live_inputs)
            gradient_ok &= (live_inputs['visual'].requires_grad and live_inputs['coarse'].requires_grad and
                            not live_inputs['maps'].requires_grad and not live_inputs['maps_raw'].requires_grad)
            grad = torch.autograd.grad(live['logits'].square().mean(), list(initial.backbone.parameters()), retain_graph=True)
            gradient_ok &= all(torch.isfinite(value).all().item() for value in grad) and any(bool(value.abs().sum() > 0) for value in grad)
            visual_path = torch.autograd.grad(live['correction'].square().mean(), live_inputs['visual'], retain_graph=True)[0]
            coarse_path = torch.autograd.grad(live['logits'].sum(), live_inputs['coarse'])[0]
            gradient_ok &= (bool(visual_path.abs().sum() > 0) and bool(coarse_path.abs().sum() > 0))
            initial.train()
            try:
                initial.forward_cached({key: value.detach() for key, value in live_inputs.items()})
            except AssertionError:
                pass
            else:
                cache_guard_ok = False
            evidence.append(dict(budget=budget, seed=seed, arm=arm, maps_detached=True,
                visual_gradient_sum=float(visual_path.abs().sum()), coarse_gradient_sum=float(coarse_path.abs().sum()),
                backbone_gradient_sum=float(sum(value.abs().sum() for value in grad))))
        else:
            warmup_ok &= row['backbone_after_warmup_sha256'] is None
            initialization_ok &= row['decoder_initial_sha256'] is None and row['decoder_final_sha256'] is None
        with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
            arrays = {key: archive[key] for key in archive.files}
        variants = VARIANTS if refined else ['actual']
        metadata_ok &= (arrays['variants'].tolist() == variants and arrays['thresholds'].tolist() == config['thresholds'] and
            np.array_equal(arrays['truth'], truth) and np.array_equal(arrays['target'], target) and
            arrays['logits'].shape == (len(variants), 695, 1, 12, 12) and
            arrays['probability'].shape == (len(variants), 695, 12, 12) and
            np.isfinite(arrays['logits']).all() and np.isfinite(arrays['probability']).all())
        logits, fixture_reference = independent_predictions(weights, arm, images, circuit)
        errors['forward'] = max(errors['forward'], float(np.max(np.abs(logits - arrays['logits']))))
        errors['probabilities'] = max(errors['probabilities'], float(np.max(np.abs(
            torch.tensor(arrays['logits'][:, :, 0]).sigmoid().numpy() - arrays['probability']))))
        with np.load(folder / 'fixtures' / f'{stem}.npz', allow_pickle=False) as archive:
            fixture = {key: archive[key] for key in archive.files}
        fixtures_ok &= np.array_equal(fixture['x'], images[:16].numpy()) and fixture['variants'].tolist() == variants
        errors['forward'] = max(errors['forward'], float(np.max(np.abs(logits[:, :16] - fixture['full_logits']))))
        if refined:
            for key in ['visual', 'coarse']:
                errors['fixture_inputs'] = max(errors['fixture_inputs'], float(np.max(np.abs(fixture_reference[key] - fixture[key]))))
            errors['maps'] = max(errors['maps'], float(np.max(np.abs(fixture_reference['maps_raw'] - fixture['maps_raw']))))
            errors['normalization'] = max(errors['normalization'], float(np.max(np.abs(
                normalized_maps(fixture['maps_raw']) - fixture['maps']))))
        all_scores = []
        for index, variant in enumerate(variants):
            scores = []
            for ti, threshold in enumerate(config['thresholds']):
                masks = arrays['probability'][index] >= threshold
                prediction = classify(masks)
                predictions_ok &= np.array_equal(prediction, arrays['predictions'][index, ti])
                predictions_ok &= np.array_equal(np.packbits(masks.reshape(695, 144), axis=1), arrays['packed_masks'][index, ti])
                score = dict(threshold=threshold, mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target))
                scores.append(score); metric_error(score, row['VAL_scores_all_thresholds'][variant][ti])
            all_scores.append(scores)
        winner = selected(all_scores[0]); metric_error(winner, row['selected'])
        selection_ok &= winner['threshold'] == float(arrays['selected_threshold'])
        ti = config['thresholds'].index(winner['threshold'])
        actual_masks = arrays['probability'][0] >= winner['threshold']
        for index, variant in enumerate(variants):
            observation = dict(**all_scores[index][ti],
                mask_flip_fraction=float(np.mean((arrays['probability'][index] >= winner['threshold']) != actual_masks)),
                logit_mean_absolute_difference=float(np.abs(arrays['logits'][index] - arrays['logits'][0]).mean()),
                logit_max_absolute_difference=float(np.abs(arrays['logits'][index] - arrays['logits'][0]).max()))
            metric_error(observation, row['ablations'][variant])
        recomputed_rows.append(dict(budget=budget, seed=seed, arm=arm, selected=winner))
    checks.update(all_saved_metadata_and_exact_control_pairing=bool(metadata_ok),
        all_source_initializations_identity_and_final_head_digests=bool(initialization_ok),
        all_backbones_finite_and_changed_from_exact_source=bool(final_states_ok),
        all_10681_5537_16218_parameter_counts=bool(counts_ok),
        saved_step100_backbone_exactly_frozen_and_head_updated=bool(warmup_ok),
        fixed_learning_rates_400_CNN_500_head_updates=bool(optimizer_ok),
        all_500_minibatch_sequences_reconstructed_and_control_paired=bool(batches_ok),
        dynamic_detached_maps_and_live_visual_coarse_backbone_gradients=bool(gradient_ok),
        cached_training_forward_rejected=bool(cache_guard_ok),
        current_CNN_current_maps_functional_forward_parity=errors['forward'] < 1e-4,
        current_fixture_live_CNN_parity=errors['fixture_inputs'] < 1e-4 and bool(fixtures_ok),
        current_physical_map_parity=errors['maps'] < 1e-4,
        independent_float64_normalization_parity=errors['normalization'] < 1e-5,
        sigmoid_probability_parity=errors['probabilities'] < 3e-7,
        all_VAL_classes_masks_thresholds_and_interventions_recomputed=bool(predictions_ok and selection_ok) and errors['metrics'] < 2e-7)
    paired = True
    for budget in [18, 27]:
        for seed in seeds:
            group = [row for row in rows if row['budget'] == budget and row['seed'] == seed]
            refiners = [row for row in group if row['arm'] in ['plain', 'joint']]
            paired &= (len({row['decoder_initial_sha256'] for row in refiners}) == 1 and
                       len({row['backbone_before_sha256'] for row in group}) == 1 and
                       len({row['batch_sequence_sha256'] for row in group}) == 1)
    checks['plain_joint_initializations_and_all_arm_batches_matched'] = bool(paired)
    gates = independent_gates(recomputed_rows, high_rows, config)
    checks['dual_control_architecture_and_physics_gates_recomputed'] = compare_stored_gates(gates, result['gates']) < 2e-7
    replication = {}
    if phase == 'replicate':
        aggregate = read_local('AGGREGATE_RESULT.json')
        previous = ROOT / aggregate['source_trials'][0]
        old = json.loads((previous / 'RESULT.json').read_text())
        old_audit = json.loads((previous / 'AUDIT.json').read_text())
        checks['valid_screen_and_exact_three_seed_aggregation'] = (
            old_audit['status'] == 'PASS_AUDIT' and old_audit['result_sha256'] == sha(previous / 'RESULT.json') and
            old['phase'] == 'screen' and old['seeds'] == [5501] and old['gates']['A_any'] and
            old['signature'] == result['signature'] == aggregate['signature'] and
            aggregate['seeds'] == [5501, 5521, 5557] and aggregate['rows'] == old['rows'] + rows and
            aggregate['high_lr_controls'] == old['high_lr_controls'] + high_rows and
            len({(row['budget'], row['seed'], row['arm']) for row in aggregate['rows']}) == 18)
        all_gates = independent_gates(old['rows'] + recomputed_rows, old['high_lr_controls'] + high_rows, config)
        checks['all_three_and_new_two_seed_gates_recomputed'] = (
            compare_stored_gates(all_gates, aggregate['gates']) < 2e-7 and
            compare_stored_gates(gates, aggregate['new_seed_gates']) < 2e-7)
        surviving = {arm: all_gates['A_architecture'][arm]['passed'] and gates['A_architecture'][arm]['passed']
                     for arm in ['plain', 'joint']}
        checks['robust_architecture_gate_requires_same_arm_on_both_seed_groups'] = (
            aggregate['robust_architecture_pass'] == any(surviving.values()))
        replication = dict(new_two_seeds=gates, all_three_seeds=all_gates,
                           architecture_passes_all_and_new_seeds=surviving)
    checks['all_inputs_unchanged_by_audit'] = all(sha(path) == value for path, value in before.items())
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        scope='INDEPENDENT_CPU_AUDIT_ADAPTIVE_REUSED_TRAIN_VAL_ONLY',
        trial=str(folder.relative_to(ROOT)), phase=phase, seeds=seeds,
        audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        high_lr_result_sha256=sha(high_path), high_lr_audit_sha256=sha(high_path.parent / 'AUDIT.json'),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        maximum_errors=errors, gradient_evidence=evidence, independent_gates=gates, replication=replication,
        unique_masks_independently_classified=len(_CLASS_CACHE), seconds=time.monotonic() - started,
        caveat='Repeated adaptive VAL development; gates do not confirm TEST superiority, statistical significance, publication novelty, or causal physical-map benefit.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trial', type=Path, help='Completed trial directory, relative to this folder or absolute.')
    args = parser.parse_args()
    folders = [args.trial if args.trial.is_absolute() else ROOT / args.trial] if args.trial else sorted(
        path.parent for path in (ROOT / 'trials').glob('*/RESULT.json'))
    assert folders, 'No completed development trial exists yet'
    torch.set_num_threads(2)
    outcomes = []
    with threadpool_limits(limits=2):
        for folder in folders:
            destination = folder / 'AUDIT.json'
            if destination.exists():
                previous = json.loads(destination.read_text())
                assert previous['result_sha256'] == sha(folder / 'RESULT.json')
                if previous['audit_source_sha256'] == sha(__file__):
                    outcome = previous
                else:
                    archive = folder / f"AUDIT_PREVIOUS_{previous['audit_source_sha256'][:12]}.json"
                    assert not archive.exists()
                    destination.rename(archive)
                    outcome = audit_trial(folder)
                    destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
            else:
                outcome = audit_trial(folder)
                destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
            outcomes.append(outcome)
            print(json.dumps({key: outcome[key] for key in ['status', 'trial', 'checks_passed', 'checks_total',
                  'maximum_errors', 'independent_gates', 'replication', 'seconds']}, ensure_ascii=False), flush=True)
    assert all(outcome['status'] == 'PASS_AUDIT' for outcome in outcomes)


if __name__ == '__main__':
    main()
