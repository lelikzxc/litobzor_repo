"""Independent provenance and frozen C4 confirmation audit.

Data mode reads fresh source images/labels only after the fixed SOURCE_PLAN.
Evaluation mode requires frozen SELECTION and completed predictions. No fits.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import re
import time
import zipfile
import zlib
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, ImageDraw
from scipy import linalg, ndimage
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
REPO = G.parent
PILOT = G / 'sem_architecture_pilot_20261102'
_DIRECTION_CACHE = {}
_CLASS_CACHE = {}
FRAMES = [137, 227, 111, 135, 213, 265, 205, 82]
PRIOR = ['sem_confirmation_20261028', 'sem_cldice_confirmation_20261030',
         'sem_cldice_expansion_20261102', 'sem_scarcity_20261102', 'sem_architecture_pilot_20261102']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def digest(state):
    h = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()

def macro_f1(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    denominator = confusion.sum(0) + confusion.sum(1)
    return float(np.divide(2 * np.diag(confusion), denominator,
                           out=np.zeros(9, float), where=denominator > 0).mean())

def mean_iou(masks, target):
    union = (masks | target).sum((-2, -1))
    intersection = (masks & target).sum((-2, -1))
    return float(np.divide(intersection, union, out=np.ones(len(union)),
                           where=union > 0).mean())

def direction_class(mask):
    """Independent active-node Cholesky solve of the binary unit-edge graph."""
    mask = np.ascontiguousarray(mask, dtype=bool)
    key = np.packbits(mask).tobytes()
    if key in _DIRECTION_CACHE:
        return _DIRECTION_CACHE[key]
    components, _ = ndimage.label(mask, ndimage.generate_binary_structure(2, 1))
    spanning = np.intersect1d(components[:, 0], components[:, -1])
    spanning = spanning[spanning > 0]
    if not len(spanning):
        answer = 0
    else:
        active = np.isin(components, spanning)
        vertices = np.flatnonzero(active.ravel())
        lookup = np.full(144, -1, dtype=int)
        lookup[vertices] = np.arange(len(vertices))
        laplacian = np.zeros((len(vertices), len(vertices)), dtype=np.float64)
        for vertex in vertices:
            y, x = divmod(int(vertex), 12)
            for yy, xx in [(y + 1, x), (y, x + 1)]:
                if yy < 12 and xx < 12 and active[yy, xx]:
                    a, b = lookup[vertex], lookup[yy * 12 + xx]
                    laplacian[a, a] += 1; laplacian[b, b] += 1
                    laplacian[a, b] -= 1; laplacian[b, a] -= 1
        left = np.flatnonzero(vertices % 12 == 0)
        right = np.flatnonzero(vertices % 12 == 11)
        free = np.setdiff1d(np.arange(len(vertices)), np.r_[left, right])
        potential = np.zeros(len(vertices)); potential[right] = 1
        if len(free):
            potential[free] = linalg.solve(
                laplacian[np.ix_(free, free)],
                -laplacian[np.ix_(free, right)].sum(1), assume_a='pos',
                check_finite=False)
        conductance = float((laplacian[right] @ potential).sum()) / (12 / 11)
        answer = 0 if conductance < 1e-8 else (1 if conductance < .5 - 1e-8 else 2)
    _DIRECTION_CACHE[key] = answer
    return answer

def classify(masks):
    result = []
    for mask in np.asarray(masks, dtype=bool).reshape(-1, 12, 12):
        key = np.packbits(mask).tobytes()
        if key not in _CLASS_CACHE:
            _CLASS_CACHE[key] = 3 * direction_class(mask) + direction_class(mask.T)
        result.append(_CLASS_CACHE[key])
    return np.asarray(result, dtype=np.int64)

def conv(x, state, prefix, padding=0, dilation=1):
    return F.conv2d(x, state[prefix + '.weight'], state[prefix + '.bias'],
                    padding=padding, dilation=dilation)

def independent_backbone(x, state):
    features = x
    for index, dilation in [(0, 1), (2, 2), (4, 4)]:
        features = F.gelu(conv(features, state, str(index), dilation, dilation))
    coarse = conv(features, state, '6')
    return torch.cat((features, coarse, x), 1), coarse

def independent_transform(value, rotation, reflection=False):
    result = torch.rot90(value, int(rotation), (-2, -1))
    return result.flip(-1) if reflection else result

def independent_inverse(value, rotation, reflection=False):
    result = value.flip(-1) if reflection else value
    return torch.rot90(result, -int(rotation), (-2, -1))

def independent_pool(images, state, group):
    """Average inverse probability maps, never logits or scalar class labels."""
    elements = [(rotation, reflection) for reflection in ([False] if group == 'C4' else [False, True])
                for rotation in range(4)]
    restored = []
    for rotation, reflection in elements:
        # Canonical strides prevent CPU convolution choosing different rounding
        # paths for pixel-identical rotations represented by different views.
        transformed = independent_transform(images, rotation, reflection).contiguous()
        logits = independent_backbone(transformed, state)[1]
        restored.append(independent_inverse(logits.sigmoid(), rotation, reflection))
    return torch.stack(restored).mean(0), torch.stack(restored)

def canonical_d4(value, raw=False):
    variants = [np.rot90(value, k) for k in range(4)]
    variants += [item[:, ::-1] for item in variants]
    if raw:
        return hashlib.sha256(min(item.astype('<u2').tobytes() for item in variants)).hexdigest()
    return min(np.packbits(item.reshape(-1)).tobytes() for item in variants).hex()


def audit_data():
    start = time.monotonic()
    read = lambda name: json.loads((ROOT / name).read_text())
    config, plan, manifest, index = (read(name) for name in ['CONFIG.json', 'SOURCE_PLAN.json', 'DATA_MANIFEST.json', 'EVAL_INDEX.json'])
    checks = {}
    lock = read('MODEL_LOCK.json')
    checks['C4_weights_and_VAL_thresholds_locked_before_fresh_download'] = (
        lock['status'] == 'MODEL_LOCK_BEFORE_NEW_FRAME_DOWNLOAD' and lock['fresh_images_present'] is False and
        lock['group'] == 'C4' and lock['protocol_sha256'] == plan['protocol_sha256'] and
        lock['config_sha256'] == plan['config_sha256'] and lock['source_plan_sha256'] == sha(ROOT / 'SOURCE_PLAN.json') and
        lock['source_model_code_sha256'] == sha(G / 'sem_arch_orbit_pool_20261102/model.py') and
        len(lock['rows']) == 24 and lock['weights'] == 12)
    checks['protocol_config_prepare_and_all_data_source_hashes_frozen'] = (
        plan['status'] == 'FROZEN_FRESH_DATA_PLAN' and
        sha(ROOT / 'PROTOCOL.md') == config['protocol_sha256'] == plan['protocol_sha256'] == manifest['protocol_sha256'] == index['protocol_sha256'] and
        sha(ROOT / 'CONFIG.json') == plan['config_sha256'] == manifest['config_sha256'] and
        sha(ROOT / 'prepare.py') == plan['prepare_script_sha256'] == manifest['prepare_script_sha256'] == index['prepare_script_sha256'] and
        sha(ROOT / 'SOURCE_PLAN.json') == manifest['source_plan_sha256'] == index['source_plan_sha256'] and
        sha(ROOT / 'TEST.npz') == manifest['TEST_sha256'] == index['TEST_sha256'] and
        sha(ROOT / 'EVAL.npz') == index['EVAL_sha256'] and
        all(sha(ROOT / name) == value for name, value in manifest['sources_sha256'].items()))
    downloaded = read('DOWNLOAD.json')
    expected_files = {f'sources/{prefix}{frame:04}.{suffix}' for frame in FRAMES for prefix, suffix in [('sem', 'png'), ('label', 'svg')]}
    source_files_ok = (downloaded['status'] == 'COMPLETE' and downloaded['source_plan_sha256'] == sha(ROOT / 'SOURCE_PLAN.json') and
        len(downloaded['files']) == 8 and {row['frame'] for row in downloaded['files']} == set(FRAMES) and
        set(manifest['sources_sha256']) == expected_files and
        all(sha(G / 'shared_data/ic_sem_m2' / name) == value for name, value in plan['shared_sha256'].items()))
    for row in downloaded['files']:
        raw = (ROOT / row['file']).read_bytes()
        source_files_ok &= (row['file'] == f"sources/sem{row['frame']:04}.png" and len(raw) == row['bytes'] and
                            hashlib.sha256(raw).hexdigest() == row['sha256'] and zlib.crc32(raw) == row['crc32'])
    with zipfile.ZipFile(G / 'shared_data/ic_sem_m2/labels.zip') as archive:
        for frame in FRAMES:
            source_files_ok &= archive.read(f'dataset/labels/m2/label{frame:04}.svg') == (ROOT / 'sources' / f'label{frame:04}.svg').read_bytes()
    checks['exact8_download_PNG_SHA_CRC_and_frozen_label_archive_members'] = bool(source_files_ok)
    old_path = G / plan['exclusion_source_file']; old = json.loads(old_path.read_text())
    excluded = set(old['excluded_previous_frames']) | set(old['test'])
    listing_path = G / plan['archive_listing_file']; listing = json.loads(listing_path.read_text())
    available = [int(match.group(1)) for row in listing if (match := re.fullmatch(r'dataset/sems/m2/sem(\d+)\.png', row['name']))]
    eligible = sorted([frame for frame in available if frame not in excluded],
        key=lambda frame: hashlib.sha256(('SEM-ORBIT-C4-CONFIRM-20261102/' + str(frame)).encode()).hexdigest())
    checks['independent86_frame_exclusion_and_first8_hash_ranking'] = (
        sha(old_path) == plan['exclusion_source_sha256'] and sha(listing_path) == plan['archive_listing_sha256'] and
        len(available) == len(set(available)) == 321 and len(excluded) == plan['excluded_frame_count'] == 86 and
        len(old['excluded_previous_frames']) == 78 and len(old['test']) == 8 and
        sorted(excluded) == plan['excluded_previous_frames'] and eligible[:8] == FRAMES == plan['test_frames'] == config['test_frames'] and
        not set(FRAMES) & excluded)
    expected_prior = {f'{name}/DATA_MANIFEST.json' for name in PRIOR}
    prior_records = []
    for name in expected_prior:
        path = G / name
        prior_records.extend(json.loads(path.read_text())['records'])
    prior_mask = {row['canonical_D4'] for row in prior_records}; prior_raw = {row['raw_D4_sha256'] for row in prior_records}
    checks['all_five_prior_manifests_unchanged_exact_dedup_union'] = (
        set(plan['prior_manifests_sha256']) == expected_prior and manifest['prior_manifests_sha256'] == plan['prior_manifests_sha256'] and
        all(sha(G / name) == value for name, value in plan['prior_manifests_sha256'].items()) and
        manifest['prior_union_unique_counts'] == dict(mask=len(prior_mask), raw=len(prior_raw)))
    with np.load(ROOT / 'TEST.npz', allow_pickle=False) as archive:
        test = {key: archive[key] for key in archive.files}
    with np.load(ROOT / 'EVAL.npz', allow_pickle=False) as archive:
        evaluation = {key: archive[key] for key in archive.files}
    records = manifest['records']; ids = np.asarray(index['local_TEST_indices'], dtype=np.int64)
    checks['new_only_TEST_records_roles_frames_and_exact_EVAL_subset'] = (
        set(test) == set(evaluation) == {'X', 'Y', 'label', 'role', 'frame'} and len(records) == manifest['examples'] == len(test['X']) and
        set(test['frame']) == set(FRAMES) and set(test['role']) == {'test'} and
        all([row[key] for row in records] == test[key].tolist() for key in ['frame', 'role', 'label']) and
        len(ids) == len(set(ids.tolist())) == index['examples'] == 2048 and
        all(np.array_equal(evaluation[key], test[key][ids]) for key in test) and index['records'] == [records[int(i)] for i in ids] and
        manifest['no_TRAIN_VAL_or_combined_archive'] and manifest['no_models_loaded'] and
        not any((ROOT / name).exists() for name in ['TRAIN_VAL.npz', 'DATA.npz']))
    masks = {row['canonical_D4'] for row in records}; raw = {row['raw_D4_sha256'] for row in records}
    checks['all_new_mask_and_raw_D4_keys_unique_and_exclude_all_five_priors'] = (
        len(masks) == len(raw) == len(records) and not masks & prior_mask and not raw & prior_raw)
    canonical_ok = True
    for i, row in enumerate(records):
        sums = np.rint(test['X'][i, 0] * (16 * 255)).astype(np.uint16)
        canonical_ok &= (canonical_d4(test['Y'][i, 0].astype(bool)) == row['canonical_D4'] and canonical_d4(sums, raw=True) == row['raw_D4_sha256'])
    checks['all_saved_mask_and_raw_D4_keys_independently_reconstructed'] = bool(canonical_ok)
    ranked = []
    for frame in FRAMES:
        candidates = [i for i, row in enumerate(records) if row['frame'] == frame]
        candidates.sort(key=lambda i: hashlib.sha256(('SEM-ORBIT-C4-EVAL-20261102/' + records[i]['raw_D4_sha256']).encode()).hexdigest())
        ranked.extend(candidates[:256])
    checks['raw_image_only_EVAL_hash_ranking_exact256_each_frame_no_resampling'] = (
        ids.tolist() == sorted(ranked) and index['label_blind_selection'] and index['mask_not_used_in_ranking'] and
        index['replacement_on_gate_failure'] is False and all(int(np.sum(evaluation['frame'] == frame)) == 256 for frame in FRAMES))
    counts = np.bincount(evaluation['label'], minlength=9)
    class_frames = {str(c): sorted(set(evaluation['frame'][evaluation['label'] == c].tolist())) for c in range(9)}
    gates = dict(exactly_2048=len(ids) == 2048, exactly_256_each_frame=all(int(np.sum(evaluation['frame'] == frame)) == 256 for frame in FRAMES),
        min_8_each_class=bool(counts.min() >= 8), min_3_frames_each_class=all(len(value) >= 3 for value in class_frames.values()))
    checks['independent_fixed_data_gates_all2048_truth_labels_and_class_frames'] = (
        index['status'] == 'PASS_EVAL_DATA_GATE' and gates == index['gates'] and all(gates.values()) and
        counts.tolist() == index['class_counts'] and class_frames == index['class_frames'] and
        np.array_equal(classify(evaluation['Y'][:, 0].astype(bool)), evaluation['label']))
    native_exact = True; mask_exact = True; maximum = 0.
    for frame in FRAMES:
        pixels = np.asarray(Image.open(ROOT / 'sources' / f'sem{frame:04}.png'))
        native_exact &= pixels.shape == (3536, 4096) and pixels.dtype == np.uint8
        canvas = Image.new('L', (pixels.shape[1], pixels.shape[0])); draw = ImageDraw.Draw(canvas)
        for element in ET.parse(ROOT / 'sources' / f'label{frame:04}.svg').iter():
            assert 'transform' not in element.attrib
            if element.tag.endswith('}path'):
                data = element.attrib['d']; assert set(re.findall('[A-Za-z]', data)) <= set('MLZz')
                points = [(int(x), int(y)) for x, y in re.findall(r'[ML](\d+),(\d+) ', data)]
                assert len(points) >= 3; draw.polygon(points, fill=1)
        label_pixels = np.asarray(canvas)
        for i in np.flatnonzero(evaluation['frame'] == frame):
            row = index['records'][int(i)]; y, x = row['y'], row['x']
            crop = pixels[y:y + 48, x:x + 48]
            reduced = crop.reshape(12, 4, 12, 4).sum((1, 3)).astype(np.float32) / (16 * 255)
            native_exact &= np.array_equal(reduced, evaluation['X'][i, 0]); maximum = max(maximum, float(np.abs(reduced - evaluation['X'][i, 0]).max()))
            binary = label_pixels[y:y + 48, x:x + 48].reshape(12, 4, 12, 4).mean((1, 3)) >= .5
            mask_exact &= np.array_equal(binary, evaluation['Y'][i, 0].astype(bool))
    checks['all2048_native_PNG_4x4_means_bit_exact_and_SVG_majority_masks_exact'] = bool(native_exact and mask_exact) and maximum == 0.
    source_tree = ast.parse((ROOT / 'prepare.py').read_text())
    ranking = next(node for node in source_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'evaluation_subset')
    sorting = [ast.unparse(node) for node in ast.walk(ranking) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'sort']
    checks['preparer_no_model_import_and_ranking_AST_uses_only_raw_image_key'] = (
        len(sorting) == 1 and 'raw_D4_sha256' in sorting[0] and 'label' not in sorting[0] and 'canonical_D4' not in sorting[0] and
        not any(isinstance(node, (ast.Import, ast.ImportFrom)) and 'model' in ast.unparse(node) for node in ast.walk(source_tree)))
    inputs = [ROOT / name for name in ['CONFIG.json', 'PROTOCOL.md', 'SOURCE_PLAN.json', 'DATA_MANIFEST.json', 'EVAL_INDEX.json', 'EVAL.npz', 'TEST.npz', 'prepare.py']]
    return dict(status='PASS_DATA_AUDIT' if all(checks.values()) else 'FAIL_DATA_AUDIT',
        scope='INDEPENDENT_FRESH_DATA_PROVENANCE_AUDIT_NO_MODELS', checks=checks,
        checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        audit_source_sha256=sha(__file__), source_sha256={str(path): sha(path) for path in inputs},
        EVAL_sha256=sha(ROOT / 'EVAL.npz'), TEST_sha256=sha(ROOT / 'TEST.npz'),
        maximum_native_reconstruction_error=maximum, fresh_frames=FRAMES, EVAL_examples=2048,
        class_counts=counts.tolist(), class_frames=class_frames, seconds=time.monotonic() - start)

def macro_confusion(matrix):
    denominator = matrix.sum(-1) + matrix.sum(-2)
    numerator = 2 * np.diagonal(matrix, axis1=-2, axis2=-1)
    return np.divide(numerator, denominator, out=np.zeros_like(numerator, dtype=float), where=denominator > 0).mean(-1)


def numeric_comparison(actual, observed):
    if isinstance(actual, dict):
        assert set(actual) == set(observed), (set(actual), set(observed))
        return max([numeric_comparison(value, observed[key]) for key, value in actual.items()] + [0.])
    if isinstance(actual, list):
        assert len(actual) == len(observed)
        return max([numeric_comparison(a, b) for a, b in zip(actual, observed)] + [0.])
    if isinstance(actual, bool):
        assert actual == observed, (actual, observed)
        return 0.
    return abs(float(actual) - float(observed))


def audit_evaluation():
    start = time.monotonic()
    read = lambda name: json.loads((ROOT / name).read_text())
    result, frozen, selection, config, lock = (read(name) for name in
        ['RESULT.json', 'EVALUATION_FROZEN.json', 'SELECTION.json', 'CONFIG.json', 'MODEL_LOCK.json'])
    checks = {}
    before = {str(path): sha(path) for path in [ROOT / name for name in
        ['RESULT.json', 'EVALUATION_FROZEN.json', 'SELECTION.json', 'MODEL_LOCK.json', 'PREDICTIONS.npz', 'BOOTSTRAP.npz', 'EVAL.npz']]}
    checks['frozen_selection_code_and_all_evaluation_inputs_unchanged'] = (
        frozen['status'] == 'FROZEN_BEFORE_FIRST_TEST_PREDICTION' and
        sha(ROOT / 'SELECTION.json') == result['selection_sha256'] == frozen['selection_sha256'] and
        sha(ROOT / 'EVALUATION_FROZEN.json') == result['evaluation_frozen_sha256'] and
        sha(ROOT / 'evaluate.py') == result['analysis_sha256'] == selection['evaluation_script_sha256'] == frozen['evaluation_script_sha256'] and
        sha(ROOT / 'PREDICTIONS.npz') == result['predictions_sha256'] and sha(ROOT / 'BOOTSTRAP.npz') == result['bootstrap_sha256'] and
        all(sha(path) == value for path, value in frozen['input_sha256'].items()) and
        all(sha(path) == value for path, value in selection['code_sha256'].items()) and
        selection['protocol_sha256'] == config['protocol_sha256'] == sha(ROOT / 'PROTOCOL.md') and
        selection['config_sha256'] == sha(ROOT / 'CONFIG.json') and selection['model_lock_sha256'] == sha(ROOT / 'MODEL_LOCK.json'))
    data_audit = read('DATA_AUDIT.json')
    checks['independent_data_audit_passed_before_frozen_predictions'] = (
        data_audit['status'] == 'PASS_DATA_AUDIT' and all(data_audit['checks'].values()) and
        data_audit['EVAL_sha256'] == sha(ROOT / 'EVAL.npz') and
        frozen['input_sha256'][str(ROOT / 'DATA_AUDIT.json')] == sha(ROOT / 'DATA_AUDIT.json'))
    checks['fixed_C4_primary_secondary_and_10000_crossed_bootstrap_protocol'] = (
        selection['status'] == 'FROZEN_BEFORE_NEW_IMAGE_DOWNLOAD_AND_PREDICTIONS' and selection['fresh_images_present'] is False and
        selection['group'] == config['group'] == 'C4' and selection['rows'] == lock['rows'] and
        selection['modes'] == ['primary_fine', 'secondary_seven'] and selection['source_lr'] == ['high_lr', 'low_lr'] and
        selection['budgets'] == [18, 27] and selection['seeds'] == [5501, 5521, 5557] and selection['arms'] == ['identity', 'C4'] and
        result['bootstrap_repeats'] == config['bootstrap_repeats'] == selection['bootstrap_repeats'] == 10000 and
        result['bootstrap_seed'] == config['bootstrap_seed'] == selection['bootstrap_seed'] == 202611026 and
        result['CI_quantiles'] == config['CI_quantiles'] == [.0125, .9875] and
        config['gates'] == selection['gates'] == dict(minimum_mean_F1_gain=.01, minimum_budget_F1_gain=0., minimum_mean_IoU_delta=-.002))
    old = G / 'sem_arch_orbit_pool_20261102'
    fine_path = old / 'threshold_diagnostic/RESULT.json'
    fine = json.loads(fine_path.read_text())
    aggregate_paths = list((old / 'trials').glob('C4_replicate_*/AGGREGATE_RESULT.json')); assert len(aggregate_paths) == 1
    aggregate = json.loads(aggregate_paths[0].read_text())
    unit = lambda row: (row['source_lr'], row['budget'], row['seed'], row['arm'])
    fine_rows = {unit(row): row for row in fine['rows']}; prior_rows = {unit(row): row for row in aggregate['rows']}
    expected = {(family, budget, seed, arm) for family in ['high_lr', 'low_lr'] for budget in [18, 27]
                for seed in [5501, 5521, 5557] for arm in ['identity', 'C4']}
    checks['all24_thresholds_and_sources_exact_locked_VAL_calibration_not_new_TEST_selection'] = (
        len(selection['rows']) == 24 and {unit(row) for row in selection['rows']} == expected and
        selection['fine_threshold_result_sha256'] == lock['fine_threshold_result_sha256'] == sha(fine_path) and
        selection['source_aggregate_sha256'] == lock['source_aggregate_sha256'] == sha(aggregate_paths[0]) and
        all(row['primary_fine_threshold'] == fine_rows[unit(row)]['selected']['threshold'] and
            row['secondary_seven_threshold'] == prior_rows[unit(row)]['selected']['threshold'] and
            row['source'] == prior_rows[unit(row)]['source'] for row in selection['rows']))
    with np.load(ROOT / 'EVAL.npz', allow_pickle=False) as archive:
        x = torch.tensor(5 * (archive['X'] - .2)); truth = archive['label']; target = archive['Y'][:, 0].astype(bool); frames = archive['frame']
    with np.load(ROOT / 'PREDICTIONS.npz', allow_pickle=False) as archive:
        saved = {key: archive[key] for key in archive.files}
    with np.load(ROOT / 'BOOTSTRAP.npz', allow_pickle=False) as archive:
        bootstrap = {key: archive[key] for key in archive.files}
    frame_values, frame_ids = np.unique(frames, return_inverse=True)
    checks['prediction_tensor_axes_same2048_examples_and_frames'] = (
        len(truth) == result['test_examples'] == 2048 and set(frame_values) == set(FRAMES) and result['test_frames'] == frame_values.tolist() and
        saved['probability'].shape == (2, 2, 3, 2, 2048, 12, 12) and saved['aligned_C4'].shape == (2, 2, 3, 4, 2048, 12, 12) and
        saved['confusion'].shape == (2, 2, 2, 3, 2, 8, 9, 9) and saved['IoU'].shape == (2, 2, 2, 3, 2, 2048) and
        saved['modes'].tolist() == ['primary_fine', 'secondary_seven'] and saved['source_lr'].tolist() == ['high_lr', 'low_lr'] and
        saved['budgets'].tolist() == [18, 27] and saved['seeds'].tolist() == [5501, 5521, 5557] and saved['arms'].tolist() == ['identity', 'C4'] and
        np.array_equal(saved['truth'], truth) and np.array_equal(saved['target'], target) and np.array_equal(saved['frames'], frames) and
        np.array_equal(saved['frame_values'], frame_values) and np.array_equal(saved['frame_ids'], frame_ids) and
        np.array_equal(saved['source_indices'], np.asarray(read('EVAL_INDEX.json')['local_TEST_indices'])) and
        np.array_equal(saved['normalized_fixture_x'], x[:16].numpy()) and
        np.isfinite(saved['probability']).all() and np.isfinite(saved['aligned_C4']).all() and
        saved['probability'].min() >= 0 and saved['probability'].max() <= 1)
    refs = {unit(row): row for row in selection['rows']}
    actual_rows = {unit(row): row for row in result['rows']}
    checks['exact24_evaluation_routes_zero_fits_and_parameters'] = (
        set(actual_rows) == expected and len(result['rows']) == 24 and result['source_model_count'] == 12 and
        result['evaluated_routes'] == 24 and result['fit_count'] == result['optimizer_updates'] == 0 and result['historical_unique_training_fits'] == 56)
    errors = dict(probability=0., aligned=0., metrics=0., IoU=0., bootstrap=0., analysis=0.)
    sources_ok = True; class_ok = True; packed_ok = True; threshold_ok = True; cost_ok = True
    confusion = np.zeros((2, 2, 2, 3, 2, 8, 9, 9), dtype=np.int64)
    ious = np.empty((2, 2, 2, 3, 2, 2048), dtype=np.float64)
    for f, family in enumerate(['high_lr', 'low_lr']):
        for b, budget in enumerate([18, 27]):
            for s, seed in enumerate([5501, 5521, 5557]):
                ref = refs[family, budget, seed, 'identity']['source']
                sources_ok &= ref == refs[family, budget, seed, 'C4']['source']
                for file_key, hash_key in [('checkpoint_file', 'checkpoint_sha256'), ('control_result_file', 'control_result_sha256'),
                                           ('source_audit_file', 'source_audit_sha256'), ('config_snapshot_file', 'config_snapshot_sha256')]:
                    sources_ok &= sha(REPO / ref[file_key]) == ref[hash_key]
                payload = torch.load(REPO / ref['checkpoint_file'], map_location='cpu', weights_only=True)
                state = payload['model']
                sources_ok &= (digest(state) == ref['backbone_state_sha256'] and sum(value.numel() for value in state.values()) == 10681 and
                               all(torch.isfinite(value).all().item() for value in state.values()))
                with torch.inference_mode():
                    identity_parts = []; orbit_parts = []; aligned_parts = []
                    for batch in x.split(16):
                        identity_parts.append(independent_backbone(batch.contiguous(), state)[1].sigmoid().numpy()[:, 0])
                        pooled, aligned = independent_pool(batch, state, 'C4')
                        orbit_parts.append(pooled.numpy()[:, 0]); aligned_parts.append(aligned.numpy()[:, :, 0])
                expected_prob = [np.concatenate(identity_parts), np.concatenate(orbit_parts)]
                expected_aligned = np.concatenate(aligned_parts, axis=1)
                errors['aligned'] = max(errors['aligned'], float(np.max(np.abs(expected_aligned - saved['aligned_C4'][f, b, s]))))
                sources_ok &= float(np.max(np.abs(saved['aligned_C4'][f, b, s].mean(0) - saved['probability'][f, b, s, 1]))) < 3e-7
                for a, arm in enumerate(['identity', 'C4']):
                    row = actual_rows[family, budget, seed, arm]
                    cost_ok &= (row['source'] == ref and row['parameters'] == 10681 and row['fit_count'] == row['optimizer_updates'] == 0 and
                        row['forward_passes_per_image'] == (1 if a == 0 else 4) and row['evaluated_images'] == 2048 and
                        row['scored_forward_examples'] == 2048 * (1 if a == 0 else 4) and row['forward_seconds'] > 0)
                    probability = saved['probability'][f, b, s, a]
                    errors['probability'] = max(errors['probability'], float(np.max(np.abs(expected_prob[a] - probability))))
                    for m, mode in enumerate(['primary_fine', 'secondary_seven']):
                        threshold = refs[family, budget, seed, arm]['primary_fine_threshold' if m == 0 else 'secondary_seven_threshold']
                        threshold_ok &= threshold == float(saved['thresholds'][m, f, b, s, a]) == row['metrics'][mode]['threshold']
                        masks = probability >= threshold; prediction = classify(masks)
                        class_ok &= np.array_equal(prediction, saved['mask_predictions'][m, f, b, s, a])
                        packed_ok &= np.array_equal(np.packbits(masks.reshape(2048, 144), axis=1), saved['packed_masks'][m, f, b, s, a])
                        for frame_index in range(8):
                            chosen = frame_ids == frame_index
                            confusion[m, f, b, s, a, frame_index] = np.bincount(9 * truth[chosen] + prediction[chosen], minlength=81).reshape(9, 9)
                        union = (masks | target).sum((1, 2)); intersection = (masks & target).sum((1, 2))
                        ious[m, f, b, s, a] = np.divide(intersection, union, out=np.ones(2048), where=union > 0)
                        for name, value in dict(mask_F1=macro_f1(truth, prediction), IoU=float(ious[m, f, b, s, a].mean())).items():
                            errors['metrics'] = max(errors['metrics'], abs(value - row['metrics'][mode][name]))
    checks.update(all12_source_checkpoints_frozen_finite_and_exact_shared_CNNs=bool(sources_ok),
        independent_functional_CNN_C4_all2048_probability_parity=errors['probability'] < 1e-5 and errors['aligned'] < 1e-5,
        all48_frozen_threshold_masks_classes_and_metric_rows_recomputed=bool(class_ok and packed_ok and threshold_ok) and errors['metrics'] < 2e-7,
        all24_inference_costs_and_zero_training_rows=bool(cost_ok))
    errors['IoU'] = float(np.max(np.abs(ious - saved['IoU'])))
    checks['all_per_image_IoUs_and_frame_confusions_independently_recomputed'] = (
        errors['IoU'] < 2e-7 and np.array_equal(confusion, saved['confusion']) and np.array_equal(confusion, bootstrap['confusion']))
    points = macro_confusion(confusion.sum(5))
    rng = np.random.default_rng(202611026)
    seed_ids = rng.integers(0, 3, (10000, 3)); sampled_frames = rng.integers(0, 8, (10000, 8))
    checks['same10000_seed_then_frame_indices_exact_paired_all_comparisons'] = (
        np.array_equal(seed_ids, bootstrap['seed_ids']) and np.array_equal(sampled_frames, bootstrap['frame_ids']) and
        bootstrap['CI_quantiles'].tolist() == [.0125, .9875])
    # Independent implementation: weight each original frame first, compute F1
    # for each original seed, then select seed indices. The evaluator instead
    # directly gathers crossed seed/frame tables before computing F1.
    frame_weights = np.eye(8, dtype=np.int64)[sampled_frames].sum(1)
    scores = np.empty((2, 2, 2, 2, 10000), dtype=np.float64)
    for m in range(2):
        for f in range(2):
            for b in range(2):
                for a in range(2):
                    weighted = np.einsum('rf,sfij->rsij', frame_weights, confusion[m, f, b, :, a], optimize=True)
                    seed_F1 = macro_confusion(weighted)
                    scores[m, f, b, a] = np.take_along_axis(seed_F1, seed_ids, axis=1).mean(1)
    family_scores = scores.mean(2); deltas = family_scores[:, :, 1] - family_scores[:, :, 0]
    errors['bootstrap'] = max(float(np.max(np.abs(scores - bootstrap['scores']))),
        float(np.max(np.abs(family_scores - bootstrap['family_scores']))), float(np.max(np.abs(deltas - bootstrap['deltas']))),
        float(np.max(np.abs(points - bootstrap['point_per_seed_budget']))))
    checks['independent_weighted_frame_then_seed_bootstrap_all10000_scores'] = errors['bootstrap'] < 2e-12
    analyses = {}
    for m, mode in enumerate(['primary_fine', 'secondary_seven']):
        families = {}
        for f, family in enumerate(['high_lr', 'low_lr']):
            identity = float(points[m, f, :, :, 0].mean()); orbit = float(points[m, f, :, :, 1].mean())
            delta = orbit - identity; budget_deltas = (points[m, f, :, :, 1] - points[m, f, :, :, 0]).mean(1).tolist()
            iou_delta = float((ious[m, f, :, :, 1] - ious[m, f, :, :, 0]).mean())
            ci = np.quantile(deltas[m, f], [.0125, .9875], method='linear').tolist()
            criteria = dict(mean_gain_at_least_one_pp=delta >= .01, positive_CI_lower=ci[0] > 0,
                            each_budget_nonnegative=min(budget_deltas) >= 0, IoU_guard=iou_delta >= -.002)
            families[family] = dict(identity=dict(mask_F1=identity, IoU=float(ious[m, f, :, :, 0].mean())),
                C4=dict(mask_F1=orbit, IoU=float(ious[m, f, :, :, 1].mean())), delta=delta, CI97_5=ci, IoU_delta=iou_delta,
                budget_deltas=budget_deltas, per_seed_deltas=(points[m, f, :, :, 1] - points[m, f, :, :, 0]).mean(0).tolist(),
                checks=criteria, passed=all(criteria.values()))
        analyses[mode] = dict(by_source_lr=families, passed_both_source_families=all(item['passed'] for item in families.values()))
    errors['analysis'] = numeric_comparison(analyses, result['analyses'])
    checks['all_CIs_Bonferroni_family_gates_and_primary_status_recomputed'] = (
        errors['analysis'] < 2e-12 and result['primary_mode'] == 'primary_fine' and result['secondary_mode'] == 'secondary_seven' and
        result['status'] == ('PASS_PILOT' if analyses['primary_fine']['passed_both_source_families'] else 'FAIL_PILOT'))
    checks['all_frozen_inputs_and_predictions_unchanged_by_audit'] = (
        all(sha(path) == value for path, value in before.items()) and all(sha(path) == value for path, value in frozen['input_sha256'].items()))
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        scope='INDEPENDENT_CPU_FROZEN_FRESH_SAME_IC_C4_CONFIRMATION_AUDIT', audit_source_sha256=sha(__file__),
        result_sha256=sha(ROOT / 'RESULT.json'), checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        maximum_errors=errors, independent_analyses=analyses, pilot_status=result['status'], seconds=time.monotonic() - start,
        caveat='Eight fresh fields of the same IC, not independent chips; frozen two-family pilot with97.5% CIs, no method-novelty claim or new training.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', action='store_true')
    parser.add_argument('--evaluation', action='store_true')
    args = parser.parse_args()
    torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        if args.data:
            destination = ROOT / 'DATA_AUDIT.json'
            assert not destination.exists(), 'Immutable data audit already exists'
            outcome = audit_data()
        else:
            assert args.evaluation, 'Choose --data or --evaluation'
            destination = ROOT / 'AUDIT.json'
            assert not destination.exists(), 'Immutable evaluation audit already exists'
            outcome = audit_evaluation()
    # NumPy comparisons yield scalar bools; serialize their Python values.
    scalar = lambda value: value.item()
    destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False, default=scalar) + '\n')
    print(json.dumps(outcome, ensure_ascii=False, default=scalar), flush=True)
    assert outcome['status'] in ['PASS_DATA_AUDIT', 'PASS_AUDIT']


if __name__ == '__main__':
    main()
