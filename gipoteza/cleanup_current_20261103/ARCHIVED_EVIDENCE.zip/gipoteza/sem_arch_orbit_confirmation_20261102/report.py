"""Create the frozen fresh-frame confirmation report from saved outputs only."""
from pathlib import Path
import datetime
import hashlib
import json
import os

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "sem_arch_orbit_pool_20261102"


def read(path, default=None):
    return json.loads(Path(path).read_text()) if Path(path).exists() else default


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rel(path):
    return Path(os.path.relpath(path, ROOT)).as_posix()


def pct(value):
    return f"{100 * value:.2f}"


def pp(value):
    return f"{100 * value:+.2f}"


def passed(value):
    return "PASS" if value else "FAIL"


def figure(result):
    path = ROOT / "figures" / "fresh_confirmation.png"
    path.parent.mkdir(exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.8))
    families = ["high_lr", "low_lr"];x = np.arange(2)
    primary = result["analyses"]["primary_fine"]["by_source_lr"]
    for offset, arm, label, color in [(-.17, "identity", "identity, 1 CNN pass", "#777777"),
                                     (.17, "C4", "C4, 4 CNN passes", "#3c78a8")]:
        values = [100 * primary[family][arm]["mask_F1"] for family in families]
        bars = axes[0].bar(x + offset, values, .32, label=label, color=color)
        axes[0].bar_label(bars, fmt="%.2f", padding=3, fontsize=8)
    axes[0].set_ylim(0, min(100, max(bar.get_height() for bar in axes[0].patches) + 8))
    axes[0].set_ylabel("New-frame Macro-F1, %")
    axes[0].set_title("Primary frozen fine-VAL thresholds")
    axes[0].legend(fontsize=8, loc="lower left")
    for offset, mode, label, color, marker in [(-.08, "primary_fine", "Primary: fine-VAL thresholds", "#3c78a8", "o"),
                                               (.08, "secondary_seven", "Secondary: seven-VAL thresholds", "#b25a43", "D")]:
        rows = result["analyses"][mode]["by_source_lr"]
        values = np.array([100 * rows[family]["delta"] for family in families])
        limits = np.array([[100 * value for value in rows[family]["CI97_5"]] for family in families])
        # Percentile intervals can exclude the point estimate. Draw interval
        # endpoints directly instead of assuming nonnegative errorbar lengths.
        axes[1].vlines(x + offset, limits[:, 0], limits[:, 1], color=color, lw=1.5)
        axes[1].scatter(x + offset, values, color=color, marker=marker, label=label, s=45)
        axes[1].scatter(np.repeat(x + offset, 2), limits.reshape(-1), marker="_", color=color)
    axes[1].axhline(0, color="black", lw=.8)
    axes[1].axhline(1, color="gray", ls="--", lw=.8, label="Minimum mean gain: +1 pp")
    axes[1].set_ylabel("C4 − identity, percentage points")
    axes[1].set_title("Paired frame/seed bootstrap: 97.5% intervals")
    axes[1].legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.15))
    for axis in axes:
        axis.set_xticks(x, ["source CNN lr=0.0005", "source CNN lr=0.0001"])
        axis.set_xlim(-.55, 1.55)
    fig.suptitle("Eight fixed new fields of view from the same IC", fontsize=11)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def build():
    config = read(ROOT / "CONFIG.json")
    selection = read(ROOT / "SELECTION.json")
    result = read(ROOT / "RESULT.json")
    audit = read(ROOT / "AUDIT.json")
    data_audit = read(ROOT / "DATA_AUDIT.json")
    synthetic = read(ROOT / "BOOTSTRAP_SYNTHETIC_CHECK.json")
    image = None
    text = ["# Отложенная проверка C4 на новых SEM-кадрах", "",
            "Зафиксированная модель — ансамбль предсказаний одной CNN по четырём поворотам с общими весами. "
            "10 681 параметр, прежние BCE+geometry_loss, новых обучений нет. C4 требует **4 прохода CNN вместо 1**. "
            "Первичны пороги из прежней плотной VAL-сетки; прежние семь порогов — заранее заданная вторичная оценка.", ""]
    if result:
        assert result["selection_sha256"] == sha(ROOT / "SELECTION.json")
        assert result["analysis_sha256"] == sha(ROOT / "evaluate.py")
        assert result["predictions_sha256"] == sha(ROOT / "PREDICTIONS.npz")
        assert result["bootstrap_sha256"] == sha(ROOT / "BOOTSTRAP.npz")
        image = figure(result)
        text += [f"**Первичный исход: {result['status']}.** Проверено {result['test_examples']} фиксированных участков "
                 f"из {len(result['test_frames'])} новых кадров: {result['test_frames']}. "
                 "Обе семьи весов должны пройти все условия; вторичный результат не заменяет первичный.", ""]
    else:
        text += ["Модель и пороги зафиксированы; завершённый RESULT.json новой проверки пока отсутствует. "
                 "Вывод о первичном исходе ещё не сделан.", ""]
    if selection:
        text += [f"[SELECTION.json](SELECTION.json) зафиксирован до новых изображений и предсказаний, "
                 f"SHA-256 `{sha(ROOT / 'SELECTION.json')}`. "
                 "Он связывает 12 CNN-checkpoint и 24 пары первичных/вторичных порогов с SHA кода оценки "
                 "и [MODEL_LOCK.json](MODEL_LOCK.json). Identity/C4 каждой пары используют точно одни веса.", ""]
    text += ["## Заранее заданный критерий", "",
             "По каждой из двух семей весов требуется: средний ΔMacro-F1 ≥1 п.п., нижняя граница "
             "97,5%-интервала >0, ΔF1 каждого бюджета 18/27 ≥0, средний ΔIoU ≥−0,2 п.п. "
             "PASS_PILOT требует выполнения всего для обеих семей. Интервалы используют 10 000 парных "
             "crossed-bootstrap повторов по 8 кадрам и 3 seed; seed 202611026. "
             "Одни индексы используются для обеих моделей, семей весов, бюджетов и калибровок. "
             "F1 вычисляется отдельно для каждого выбранного seed/бюджета на пересэмплированных кадрах, "
             "потом усредняется по seed и бюджетам. Границы [0,0125; 0,9875] учитывают два сравнения по Бонферрони.", ""]
    if result:
        for mode, label in [("primary_fine", "Первичная: фиксированная плотная VAL-калибровка"),
                            ("secondary_seven", "Вторичная: фиксированная семиточечная VAL-калибровка")]:
            text += [f"## {label}", "",
                     "| Семья весов | Identity F1, % | C4 F1, % | ΔF1, п.п. | 97,5% интервал ΔF1, п.п. | ΔF1 бюджеты 18 / 27, п.п. | ΔIoU, п.п. | Критерий |",
                     "|---|---:|---:|---:|---|---|---:|---|"]
            analysis = result["analyses"][mode]
            for family, row in analysis["by_source_lr"].items():
                text.append(f"| {family} | {pct(row['identity']['mask_F1'])} | {pct(row['C4']['mask_F1'])} | {pp(row['delta'])} | "
                            f"[{pp(row['CI97_5'][0])}; {pp(row['CI97_5'][1])}] | "
                            f"{' / '.join(pp(value) for value in row['budget_deltas'])} | {pp(row['IoU_delta'])} | {passed(row['passed'])} |")
            text += ["", f"Обе семьи: **{passed(analysis['passed_both_source_families'])}**.", ""]
            descriptions = dict(mean_gain_at_least_one_pp="средний прирост F1 ≥1 п.п.",
                positive_CI_lower="положительная нижняя граница интервала", each_budget_nonnegative="неотрицательный прирост обоих бюджетов",
                IoU_guard="ограничение потери IoU")
            for family, row in analysis["by_source_lr"].items():
                failed = [descriptions[name] for name, value in row["checks"].items() if not value]
                if failed:
                    text += [f"{family}: не пройдены условия — {', '.join(failed)}. "
                             "Положительное среднее само по себе не заменяет полный критерий пилота.", ""]
        text += ["![Первичные F1 и парные интервалы](figures/fresh_confirmation.png)", "",
                 "Интервалы относятся к заранее заданному пересэмплированию кадров/seed одного изделия. "
                 "Разброс плотных розыгрышей не оценивается: использован один розыгрыш 5303.", "",
                 "## Все фиксированные пары", "",
                 "| Семья | Бюджет | Seed | Пороги primary identity / C4 | Primary identity F1, % | Primary C4 F1, % | ΔF1 primary, п.п. | ΔF1 secondary, п.п. |",
                 "|---|---:|---:|---|---:|---:|---:|---:|"]
        rows = {(row['source_lr'], row['budget'], row['seed'], row['arm']): row for row in result["rows"]}
        for family in ["high_lr", "low_lr"]:
            for budget in [18, 27]:
                for seed in [5501, 5521, 5557]:
                    identity, pooled = rows[family, budget, seed, "identity"], rows[family, budget, seed, "C4"]
                    p0, p1 = identity["metrics"]["primary_fine"], pooled["metrics"]["primary_fine"]
                    secondary = pooled["metrics"]["secondary_seven"]["mask_F1"] - identity["metrics"]["secondary_seven"]["mask_F1"]
                    text.append(f"| {family} | {budget} | {seed} | {p0['threshold']:.2f} / {p1['threshold']:.2f} | "
                                f"{pct(p0['mask_F1'])} | {pct(p1['mask_F1'])} | {pp(p1['mask_F1'] - p0['mask_F1'])} | {pp(secondary)} |")
        text += ["", "## Стоимость и сохранённые артефакты", "",
                 "| Режим | Проходов / изображение | Среднее время прямого прохода по 2048 участкам, с |",
                 "|---|---:|---:|"]
        for arm, passes in [("identity", 1), ("C4", 4)]:
            values = [row["forward_seconds"] for row in result["rows"] if row["arm"] == arm]
            text.append(f"| {arm} | {passes} | {np.mean(values):.4f} |")
        text += ["", f"Полное время оценки и статистики: {result['seconds']:.2f} с. "
                 "12 исходных моделей, 24 маршрута предсказания; обе калибровки используют одни вероятности. "
                 "Новых обучений 0; прежних уникальных обучений по поиску и контролям 56.", "",
                 "[PREDICTIONS.npz](PREDICTIONS.npz) хранит все вероятности, выровненные C4-ответы, "
                 "упакованные маски, классы, IoU и confusion по кадрам. "
                 "[BOOTSTRAP.npz](BOOTSTRAP.npz) хранит общие seed/frame-индексы, "
                 "все оценки/разности повторов и confusion. "
                 "[RESULT.json](RESULT.json) и [EVALUATION_FROZEN.json](EVALUATION_FROZEN.json) фиксируют исход и SHA.", ""]
    text += ["## Данные и техническая проверка", "",
             "По 256 участков каждого из 8 новых кадров, всего 2048; выбор до модели по SHA только интенсивностей. "
             "Кадры исключены из 86 ранее использованных. Точные D4-повторы изображений/масок удалены "
             "по пяти прежним манифестам и внутри нового набора. Требуются ≥8 примеров и ≥3 кадров каждого класса. "
             "[SOURCE_PLAN.json](SOURCE_PLAN.json), [DATA_MANIFEST.json](DATA_MANIFEST.json), "
             "[EVAL_INDEX.json](EVAL_INDEX.json). Маски нужны для оценки и проверки дублей; новых обучений нет.", ""]
    for label, name, item in [("Данные", "DATA_AUDIT.json", data_audit), ("Оценка и bootstrap", "AUDIT.json", audit)]:
        text += [(f"{label}: `{item.get('status', 'см. файл')}`, "
                  f"{item.get('checks_passed', 'см. файл')} / {item.get('checks_total', 'см. файл')}. "
                  f"[{name}]({name})." if item else f"{label}: итоговый независимый аудит ещё не сохранён."), ""]
    if synthetic:
        text += [f"Синтетическая проверка bootstrap без новых данных: `{synthetic['status']}`, "
                 f"ошибка {synthetic['maximum_error']:.3g}; она различает усреднение F1 по seed и ошибочное "
                 "предварительное объединение seed-confusion. "
                 "[BOOTSTRAP_SYNTHETIC_CHECK.json](BOOTSTRAP_SYNTHETIC_CHECK.json).", ""]
    text += ["## Предел вывода и предыдущий поиск", "",
             "Это новые поля съёмки **той же одной ИС**. Девять классов получены геометрическим readout из маски, "
             "а не являются экспертной типологией дефектов или измеренными электрическими состояниями. "
             "Участки одного кадра зависимы; точное удаление дублей не исключает все близкие поля съёмки. "
             "Пилот не устанавливает перенос между изделиями и не доказывает новизну широко известного "
             "принципа симметризации или уровень Q1. Отрицательный первичный исход сохраняется без смены критерия.", "",
             f"[Все предыдущие архитектурные попытки, отрицательные варианты и 56 обучений]({rel(OLD / 'REPORT.md')}). "
             "Выбор C4 на старой VAL был адаптивным; исходный скрининг и расширение не объявляются независимыми тестами.", "",
             "[PROTOCOL.md](PROTOCOL.md) · [CONFIG.json](CONFIG.json) · [SELECTION.json](SELECTION.json) · "
             "[evaluate.py](evaluate.py) · [audit.py](audit.py).", ""]
    (ROOT / "REPORT.md").write_text("\n".join(text))
    status = result["status"] if result else "результат ещё не сохранён"
    (ROOT / "README.md").write_text(
        "# Отложенная проверка C4-CNN\n\n"
        f"Первичный исход: **{status}**. Фиксированные12 CNN, первичные пороги старой плотной VAL-сетки, "
        "2048 участков8 новых кадров той же ИС. C4 требует4 прохода вместо1; новых обучений нет.\n\n"
        "[Отчёт](REPORT.md) · [Протокол до данных](PROTOCOL.md) · [Модели и пороги](SELECTION.json) · [Результат](RESULT.json).\n\n"
        "Парный crossed-bootstrap10000 по кадрам/seed, две семьи весов,97,5%-интервалы. "
        "Вторичная семиточечная калибровка не заменяет первичный исход. Перенос между изделиями и новизна не установлены.\n")
    names = ["CONFIG.json", "PROTOCOL.md", "MODEL_LOCK.json", "SOURCE_PLAN.json", "SELECTION.json", "EVALUATION_FROZEN.json",
             "DATA_MANIFEST.json", "EVAL_INDEX.json", "DATA_AUDIT.json", "AUDIT.json", "RESULT.json", "BOOTSTRAP.npz",
             "PREDICTIONS.npz", "BOOTSTRAP_SYNTHETIC_CHECK.json", "evaluate.py"]
    outputs = [ROOT / "REPORT.md", ROOT / "README.md"] + ([image] if image else [])
    manifest = dict(status="REPORT_GENERATED", UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope="FIXED_NEW_FIELDS_SAME_IC_PILOT", report_script_sha256=sha(Path(__file__)),
        primary_status=status, new_training_fits=0, historical_unique_training_fits=56,
        scientific_inputs_sha256={name: sha(ROOT / name) for name in names if (ROOT / name).exists()},
        outputs_sha256={rel(path): sha(path) for path in outputs})
    (ROOT / "REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
