"""Physically anchored corrective class-head development on old TRAIN/VAL.

Head training receives only image-derived caches and existing class labels.
Dense/weak masks do not enter the training loader or optimizer. Frozen mask
IoU is an unchanged source diagnostic, separate from direct class performance.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import shutil
import sys
import time
import traceback

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "0"
import numpy as np
import torch
from torch.nn import functional as F
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits
from model import (ARMS, CLASS_SWAP, G0, VIEW_FIELDS, architecture_spec,
                   context_from_mu, make_model, slice_cache, state_digest)

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
G = ROOT.parent
PILOT = G / "sem_architecture_pilot_20261102"
ORBIT = G / "sem_arch_orbit_pool_20261102"
FAMILIES = ["high_lr", "low_lr"]
MASK_CONTROLS = ["uniform_frozen", "uniform_adapted", "single_adapted"]
CONTROL_ARMS = MASK_CONTROLS + ["fixed_softordinal"]
START = None


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


old_model = sys.modules.get("model")
sys.modules["model"] = module("class_readout_original_orbit_model", ORBIT / "model.py")
try:
    orbit = module("class_readout_original_orbit_utilities", ORBIT / "runner.py")
finally:
    if old_model is None: del sys.modules["model"]
    else: sys.modules["model"] = old_model


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value): return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
def save(path, value): orbit.save(path, value)
def resolve(path): return Path(path) if Path(path).is_absolute() else REPO / path


def configuration(path):
    c = json.loads(path.read_text())
    assert c["candidate"] == "C4_anchored_readout" and c["fitted_arms"] == ARMS and c["evaluation_arms"] == ARMS
    assert c["budgets"] == [18, 27] and c["screen_seeds"] == [5501] and c["replication_seeds"] == [5501, 5521, 5557]
    assert c["subset_seed"] == 5303 and c["steps"] == 1000 and c["batch_size"] == 32
    assert c["head_learning_rate"] == .001 and c["weight_decay"] == .0001
    assert c["head_seed_offset"] == 200003 and c["batch_seed_offset"] == 1000
    assert c["equivariance_tolerance"] == 1e-6
    assert c["gates"]["minimum_mean_F1_gain"] == .005 and c["gates"]["minimum_budget_F1_delta"] == -.0025
    assert c["protocol_sha256"] == sha(ROOT / "PROTOCOL.md")
    return c


def source_hashes():
    names = ["model.py", "runner.py", "../sem_arch_directional_readout_20261102/model.py",
        "../sem_arch_directional_readout_20261102/runner.py", "../sem_arch_classification_readout_20261102/model.py",
        "../sem_arch_classification_readout_20261102/runner.py", "../sem_arch_orbit_pool_20261102/model.py", "../sem_arch_orbit_pool_20261102/runner.py",
        "../sem_architecture_pilot_20261102/model.py", "../sem_architecture_pilot_20261102/physics_adapter.py",
        "../sem_physics_materials/physics_loss_example.py", "../sem_architecture_pilot_20261102/prepare.py",
        "../sem_confirmation_20261028/prepare.py", "../retained_evidence_20261027/SELECTED_SOURCES.zip"]
    return {name: sha(ROOT / name) for name in names}


def append_ledger(event):
    with (ROOT / ".ledger.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX); path = ROOT / "LEDGER.json"
        ledger = json.loads(path.read_text()) if path.exists() else dict(version=1, scope="OLD_TRAIN_VAL_CLASSIFICATION_ONLY", events=[])
        ledger["events"].append(dict(event, index=len(ledger["events"]), UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        save(path, ledger); fcntl.flock(lock, fcntl.LOCK_UN)


def inputs(c, seeds, device):
    subsets = json.loads((PILOT / "SUBSETS.json").read_text())
    initial = json.loads((PILOT / "INITIAL_LINEAGE.json").read_text())
    assert sha(PILOT / "TRAIN_VAL.npz") == subsets["train_val_sha256"] == initial["TRAIN_VAL_sha256"]
    with np.load(PILOT / "TRAIN_VAL.npz", allow_pickle=False) as archive:
        # No dense/weak masks are requested. Y is indexed only for VAL's
        # unchanged source-mask diagnostic, never passed to fit().
        x, labels, roles, frames = [archive[key].copy() for key in ["X", "label", "role", "frame"]]
        vi = np.flatnonzero(roles == "val")
        val_mask = archive["Y"][vi].astype(np.float32)
    assert set(roles) == {"dense", "weak", "val"}
    weak = np.flatnonzero(roles == "weak"); data = {}
    for budget in c["budgets"]:
        dense = np.array(subsets["dense_indices"][str(budget)], dtype=np.int64)
        ids = np.concatenate((dense, weak))
        assert len(ids) == budget + 1152 and len(set(ids.tolist())) == len(ids)
        assert np.array_equal(np.bincount(labels[ids], minlength=9), np.full(9, 128 + budget // 9))
        data[budget] = dict(train=dict(x=torch.tensor(5 * (x[ids] - .2), device=device),
            label=torch.tensor(labels[ids], device=device), indices=ids.tolist(), roles=roles[ids].tolist()),
            val=dict(x=torch.tensor(5 * (x[vi] - .2), device=device), label=torch.tensor(labels[vi], device=device),
                mask=torch.tensor(val_mask, device=device), indices=vi.tolist()))
    source_grid = json.loads((ORBIT / "CONFIG.json").read_text())["thresholds"]
    refs, states = orbit.sources(dict(c, thresholds=source_grid), seeds)
    return data, refs, states, dict(TRAIN_VAL_sha256=sha(PILOT / "TRAIN_VAL.npz"), subsets_sha256=sha(PILOT / "SUBSETS.json"),
        initial_lineage_sha256=sha(PILOT / "INITIAL_LINEAGE.json"), training_inputs=["X", "class_label"],
        training_masks_present=False, val_mask_diagnostic_only=True, source_control_thresholds=source_grid)


def controls(c, seeds, refs):
    rows, provenance, mask_predictions, frozen_probabilities = [], [], {}, {}
    for name in c["prior_stage7_results"] + c.get("prior_stage7_additional_results", []):
        path = resolve(name); result = json.loads(path.read_text()); audit = path.parent / "AUDIT.json"
        assert result["status"] == "COMPLETE_DEVELOPMENT_TRIAL" and json.loads(audit.read_text())["status"] == "PASS_AUDIT"
        cfg_path = path.parent / "CONFIG_SNAPSHOT.json"; cfg = json.loads(cfg_path.read_text())
        assert cfg["steps"] == 500 and cfg["backbone_learning_rate"] == .0001 and cfg["subset_seed"] == c["subset_seed"]
        assert cfg["thresholds"] == [round(.1 + .01 * i, 2) for i in range(81)]
        for old in result["rows"]:
            if old["seed"] not in seeds or old["arm"] not in MASK_CONTROLS: continue
            unit = old["source_lr"], old["budget"], old["seed"]
            ref = next(ref for ref in refs if (ref["source_lr"], ref["budget"], ref["seed"]) == unit)
            assert old["source"] == ref
            filename = f'{unit[0]}_b{unit[1]}_s{unit[2]}_{old["arm"]}'
            probability_file = path.parent / "val_probs" / f"{filename}.npz"
            reference = dict(result_file=str(path.relative_to(REPO)), result_sha256=sha(path), audit_file=str(audit.relative_to(REPO)),
                audit_sha256=sha(audit), val_probability_file=str(probability_file.relative_to(REPO)), val_probability_sha256=sha(probability_file))
            if old["fit_count"]:
                checkpoint = path.parent / "models" / f"{filename}.pt"
                assert sha(checkpoint) == result["checkpoint_hashes"][checkpoint.name]
                reference.update(checkpoint_file=str(checkpoint.relative_to(REPO)), checkpoint_sha256=sha(checkpoint))
            with np.load(probability_file, allow_pickle=False) as archive:
                thresholds = archive["thresholds"].tolist(); ti = thresholds.index(old["selected"]["threshold"])
                prediction = archive["predictions"][0, ti].copy()
                truth = archive["truth"].copy()
                frozen_probability = archive["probability"][0].copy() if old["arm"] == "uniform_frozen" else None
            score = float(f1_score(truth, prediction, labels=range(9), average="macro", zero_division=0))
            assert abs(score - old["selected"]["mask_F1"]) < 1e-12
            if old["arm"] == "uniform_frozen":
                mask_predictions[unit] = prediction
                frozen_probabilities[unit] = frozen_probability
            rows.append(dict(source_lr=unit[0], budget=unit[1], seed=unit[2], arm=old["arm"], class_F1=score,
                frozen_mask_IoU=old["selected"]["IoU"], mask_threshold=old["selected"]["threshold"],
                prediction_pipeline="class_of_frozen_thresholded_segmentation_mask", source=ref, control_ref=reference, reused=True))
        provenance.append(dict(result_file=str(path.relative_to(REPO)), result_sha256=sha(path), audit_file=str(audit.relative_to(REPO)), audit_sha256=sha(audit)))
    expected = {(ref["source_lr"], ref["budget"], ref["seed"], arm) for ref in refs for arm in MASK_CONTROLS}
    assert len(rows) == len(expected) and {(v["source_lr"], v["budget"], v["seed"], v["arm"]) for v in rows} == expected
    return rows, provenance, mask_predictions, frozen_probabilities


def make(c, arm, state, seed, device):
    return make_model(arm, state, head_seed=seed + c["head_seed_offset"]).to(device)


@torch.no_grad()
def cached_inputs(model, values, ref):
    cache = {}; size = 0
    for role, data in values.items():
        output = {}
        for start in range(0, len(data["x"]), 16):
            part = model.precompute(data["x"][start:start + 16])
            if not output:
                for key, value in part.items():
                    shape = list(value.shape); shape[1 if key in VIEW_FIELDS else 0] = len(data["x"])
                    output[key] = torch.empty(shape, dtype=value.dtype, device=value.device)
            for key, value in part.items():
                if key in VIEW_FIELDS: output[key][:, start:start + value.shape[1]].copy_(value)
                else: output[key][start:start + len(value)].copy_(value)
        assert all(not value.requires_grad and torch.isfinite(value).all() for value in output.values())
        cache[role] = output; size += sum(v.numel() * v.element_size() for v in output.values())
    assert size <= 120 * 1024 ** 2
    return cache, dict(ephemeral=True, persisted=False, image_only=True, context_label_free=True, bytes=size,
        maximum_bytes=120 * 1024 ** 2, source_state_sha256=ref["backbone_state_sha256"],
        indices={role: data["indices"] for role, data in values.items()}, keys=list(cache["train"]))


def fit(c, model, train, cache, ref, trial, counter):
    assert "mask" not in train
    before = state_digest(model.backbone.state_dict()); head_before = state_digest(model.head.state_dict())
    params = list(model.head.parameters()); optimizer = torch.optim.AdamW(params, lr=c["head_learning_rate"], weight_decay=c["weight_decay"])
    rng = np.random.default_rng(ref["seed"] + c["batch_seed_offset"]); batches = hashlib.sha256(); started = time.monotonic(); model.train()
    for step in range(1, c["steps"] + 1):
        ids = rng.integers(0, len(train["label"]), c["batch_size"]); batches.update(ids.astype(np.int64).tobytes())
        ids = torch.tensor(ids, device="mps"); optimizer.zero_grad(set_to_none=True)
        result = model.forward_cached(slice_cache(cache, ids))
        # Negative log of pooled canonical class probabilities is ordinary CE.
        loss = F.nll_loss(result["log_probability"], train["label"][ids])
        assert torch.isfinite(loss); loss.backward()
        assert all(p.grad is None for p in model.backbone.parameters())
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in params)
        assert any(float(p.grad.abs().sum()) > 0 for p in params)
        optimizer.step(); counter[0] += 1
        if step % 100 == 0:
            progress = dict(stage="ANCHORED_CLASSIFICATION_TRAIN_VAL", trial=trial.name, source_lr=ref["source_lr"], budget=ref["budget"],
                seed=ref["seed"], arm=model.arm, step=step, target_steps=1000, class_CE=float(loss.detach().cpu()),
                completed_updates=counter[0], seconds=time.monotonic() - START)
            save(trial / "PROGRESS.json", progress); save(ROOT / "PROGRESS.json", progress)
            with (trial / "progress.jsonl").open("a") as handle: handle.write(json.dumps(progress) + "\n")
            print(json.dumps(progress), flush=True)
    torch.mps.synchronize(); after = state_digest(model.backbone.state_dict()); head_after = state_digest(model.head.state_dict())
    assert before == after and head_before != head_after
    return dict(steps=1000, optimizer_updates=1000, fit_count=1, trainable_parameters=sum(p.numel() for p in params),
        head_seed=ref["seed"] + c["head_seed_offset"], learning_rate=c["head_learning_rate"], weight_decay=c["weight_decay"],
        backbone_before_sha256=before, backbone_after_sha256=after, head_initial_sha256=head_before, head_final_sha256=head_after,
        training_examples=len(train["label"]), training_class_counts=torch.bincount(train["label"], minlength=9).cpu().tolist(),
        batch_sequence_sha256=batches.hexdigest(), training_masks_used=False, seconds=time.monotonic() - started)


def class_metrics(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    return dict(class_F1=float(f1_score(truth, prediction, labels=range(9), average="macro", zero_division=0)),
                accuracy=float(np.mean(truth == prediction)), confusion=confusion.tolist())


@torch.no_grad()
def evaluate(model, values, cache, frozen_prediction):
    model.eval(); results = []
    for start in range(0, len(values["x"]), 16): results.append(model.forward_cached(slice_cache(cache, slice(start, start + 16))))
    probability = torch.cat([v["probability"] for v in results]).cpu().numpy()
    log_probability = torch.cat([v["log_probability"] for v in results]).cpu().numpy()
    prediction = probability.argmax(1); truth = values["label"].cpu().numpy()
    metrics = class_metrics(truth, prediction)
    return dict(**metrics, prediction_pipeline="direct_learned_class_probability_argmax", no_class_threshold=True,
        class_mask_disagreement_fraction=float(np.mean(prediction != frozen_prediction))), dict(probability=probability,
        log_probability=log_probability, prediction=prediction, truth=truth,
        per_view_logits=torch.cat([v["per_view_logits"] for v in results], dim=1).cpu().numpy(),
        directional_logits=torch.cat([v["directional_logits"] for v in results], dim=1).cpu().numpy(),
        directional_log_probability=torch.cat([v["directional_log_probability"] for v in results], dim=1).cpu().numpy(),
        prior_threshold_logits=torch.cat([v["prior_threshold_logits"] for v in results], dim=1).cpu().numpy(),
        threshold_corrections=torch.cat([v["threshold_corrections"] for v in results], dim=1).cpu().numpy(),
        corrected_threshold_logits=torch.cat([v["corrected_threshold_logits"] for v in results], dim=1).cpu().numpy(),
        aligned_log_probability=torch.cat([v["aligned_log_probability"] for v in results], dim=1).cpu().numpy(),
        frozen_mask_class=frozen_prediction, frozen_mask_probability=cache["uniform_probability"].cpu().numpy())


@torch.no_grad()
def technical_fixture(c, model, x, cache):
    model.eval(); result = model.forward_details(x)
    transformed = torch.stack([model.forward_details(torch.rot90(x, k, (-2, -1)))["probability"] for k in range(4)])
    restored = torch.stack([value[:, CLASS_SWAP] if k % 2 else value for k, value in enumerate(transformed)])
    error = float((restored - result["probability"][None]).abs().max().cpu()); assert error <= c["equivariance_tolerance"], (model.arm, error)
    cached = model.forward_cached(cache); parity = float((cached["probability"] - result["probability"]).abs().max().cpu()); assert parity < 1e-5
    arrays = dict(x=x.cpu().numpy(), probability=result["probability"].cpu().numpy(), transformed_probability=transformed.cpu().numpy(),
        restored_class_probability=restored.cpu().numpy(), class_swap=np.array(CLASS_SWAP),
        **{key: tensor.cpu().numpy() for key, tensor in cache.items() if key != "x"})
    arrays.update({key: result[key].cpu().numpy() for key in ["per_view_logits", "directional_logits",
        "directional_log_probability", "per_view_log_probability", "aligned_log_probability", "context",
        "prior_threshold_logits", "threshold_corrections", "corrected_threshold_logits"]})
    return arrays, dict(class_C4_covariance_max_error=error, cache_full_max_error=parity)


def comparisons(rows, controls_rows, c):
    all_rows = rows + controls_rows; arms = ARMS + CONTROL_ARMS
    means = {lr: {b: {arm: float(np.mean([row["class_F1"] for row in all_rows if row["source_lr"] == lr and row["budget"] == b and row["arm"] == arm]))
        for arm in arms} for b in c["budgets"]} for lr in FAMILIES}
    def compare(lr, left, right):
        deltas = [means[lr][b][left] - means[lr][b][right] for b in c["budgets"]]; gain = float(np.mean(deltas))
        checks = dict(mean_F1_gain=gain >= c["gates"]["minimum_mean_F1_gain"], budget_F1_guard=min(deltas) >= c["gates"]["minimum_budget_F1_delta"])
        return dict(delta=gain, budget_deltas=deltas, checks=checks, passed=all(checks.values()))
    pipeline = {}
    for arm in ARMS:
        family = {}
        for lr in FAMILIES:
            values = {"vs_" + baseline: compare(lr, arm, baseline) for baseline in CONTROL_ARMS}
            values["passed"] = all(v["passed"] for v in values.values()); family[lr] = values
        pipeline[arm] = dict(by_source_lr=family, passed=all(v["passed"] for v in family.values()))
    physical = {lr: compare(lr, "physics_cnn", "visual_cnn") for lr in FAMILIES}
    for table in [physical]:
        for lr, value in table.items():
            value["physics_cnn_pipeline_gate"] = pipeline["physics_cnn"]["by_source_lr"][lr]["passed"]
            value["passed"] = bool(value["passed"] and value["physics_cnn_pipeline_gate"])
    spatial = {}
    for cnn in ["visual_cnn", "physics_cnn"]:
        family = {}
        for lr in FAMILIES:
            mlp = compare(lr, cnn, "physics_mlp"); calibration = compare(lr, cnn, "calibrator")
            a_pass = pipeline[cnn]["by_source_lr"][lr]["passed"]
            family[lr] = dict(vs_physics_mlp=mlp, vs_calibrator=calibration, pipeline_gate=a_pass,
                passed=bool(a_pass and mlp["passed"] and calibration["passed"]))
        spatial[cnn] = dict(by_source_lr=family, passed=all(v["passed"] for v in family.values()))
    return dict(A_pipeline=pipeline, A_any=any(v["passed"] for v in pipeline.values()),
        B_physics=dict(by_source_lr=physical, passed=all(v["passed"] for v in physical.values())),
        C_spatial=spatial, CNN_SUCCESS=any(v["passed"] for v in spatial.values()),
        interpretation="Allarms sharephysicalanchor; B testsadditionalconditioning; CNNsuccessneedsAandgainoverMLP/calibrator"), means


def signature(c):
    return digest(dict(configuration={k: v for k, v in c.items() if k != "prior_stage7_additional_results"}, source_sha256=source_hashes(),
                       TRAIN_VAL_sha256=sha(PILOT / "TRAIN_VAL.npz")))


def previous_screen(expected):
    found = []
    for path in (ROOT / "trials").glob("*/RESULT.json"):
        row = json.loads(path.read_text())
        if row["phase"] == "screen" and row["signature"] == expected and row["status"] == "COMPLETE_CLASSIFICATION_DEVELOPMENT": found.append((path, row))
    assert len(found) == 1 and found[0][1]["gates"]["CNN_SUCCESS"], "Only an audited CNN_SUCCESS permits newseed expansion"
    audit_path = found[0][0].parent / "AUDIT.json"
    audit = json.loads(audit_path.read_text())
    assert audit["status"] == "PASS_AUDIT" and all(audit["checks"].values()), "Independent screen audit must pass before replication"
    return found[0]


@torch.no_grad()
def anchor_diagnostics(cache):
    a = 4 * cache["physical_context"]
    pairs = a.reshape(4, len(cache["x"]), 2, 2)
    scores = torch.stack((torch.zeros_like(pairs[..., 0]), pairs[..., 0], pairs[..., 0] + pairs[..., 1]), dim=-1)
    log_directional = scores.log_softmax(-1)
    joint = (log_directional[:, :, 0, :, None] + log_directional[:, :, 1, None, :]).reshape(4, len(cache["x"]), 9)
    aligned = torch.stack([p[:, CLASS_SWAP] if k % 2 else p for k, p in enumerate(joint)])
    log_probability = torch.logsumexp(aligned, 0) - math.log(4)
    probability = log_probability.exp(); prediction = probability.argmax(1)
    g = cache["conductance"]
    bins = (g >= G0).long() + (g >= .5).long(); inclusive = 3 * bins[:, 0] + bins[:, 1]
    exact_tie = ((g == G0) | (g == .5)).any(1)
    top = scores[0].topk(2, dim=-1).values
    # Distinguish exact mathematical threshold ties from finite-float score
    # ties/near-ties; this tolerance classifies a diagnostic, never selects a
    # threshold, model, or gate. Default class argmax remains unchanged.
    near_tie = ((top[..., 0] - top[..., 1]).abs() <= 1e-6).any(1)
    difference = prediction != inclusive
    non_tie_parity = bool(torch.all(~difference | near_tie))
    assert non_tie_parity, "Anchored scores disagree with fixed bins away from score ties"
    diagnostics = dict(examples=len(g), initial_class_difference_count=int(difference.sum().cpu()),
        exact_conductance_tie_examples=int(exact_tie.sum().cpu()), score_or_rounding_tie_examples=int(near_tie.sum().cpu()),
        differences_at_exact_conductance_ties=int((difference & exact_tie).sum().cpu()),
        differences_at_score_or_rounding_ties=int((difference & near_tie).sum().cpu()),
        non_tie_class_parity=non_tie_parity, score_tie_diagnostic_tolerance=1e-6,
        head_tie_rule="ordinaryargmax choosesfirstclass", fixed_rule="g>=g0 andg>=.5 remainsinclusive")
    return dict(probability=probability, log_probability=log_probability, prediction=prediction,
        fixed_prediction=inclusive, prior_threshold_logits=a, directional_logits=scores,
        exact_tie=exact_tie, score_or_rounding_tie=near_tie), diagnostics


def preflight(c):
    data, refs, states, lineage = inputs(c, [5501], "cpu"); baseline, provenance, mask_prediction, frozen_probability = controls(c, [5501], refs)
    state = states["high_lr", 18, 5501]; x = data[18]["train"]["x"][:2]; y = data[18]["train"]["label"][:2]
    hashes, evidence, initial_probabilities = [], [], []
    for arm in ARMS:
        net = make(c, arm, state, 5501, "cpu"); cache = net.precompute(x); result = net.forward_cached(cache)
        if arm in ["visual_cnn", "physics_cnn"]: hashes.append(state_digest(net.head.state_dict()))
        anchored, initial_diagnostic = anchor_diagnostics(cache)
        assert torch.count_nonzero(result["threshold_corrections"]) == 0
        assert torch.equal(result["corrected_threshold_logits"], result["prior_threshold_logits"])
        assert torch.equal(result["directional_logits"], anchored["directional_logits"])
        assert torch.equal(result["probability"], anchored["probability"])
        initial_probabilities.append(result["probability"].detach().clone())
        assert all(not value.requires_grad for value in cache.values())
        assert torch.allclose(result["probability"].sum(1), torch.ones(len(x)), atol=3e-7, rtol=0)
        directional = result["directional_log_probability"].exp()
        joint = result["per_view_log_probability"].exp().reshape(4, len(x), 3, 3)
        assert result["per_view_logits"].shape == (4, len(x), 6)
        assert torch.allclose(joint.sum(-1), directional[:, :, 0], atol=3e-7, rtol=0)
        assert torch.allclose(joint.sum(-2), directional[:, :, 1], atol=3e-7, rtol=0)
        loss = F.nll_loss(result["log_probability"], y); loss.backward()
        assert all(p.grad is None for p in net.backbone.parameters())
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in net.head.parameters())
        assert any(float(p.grad.abs().sum()) > 0 for p in net.head.parameters())
        if arm != "calibrator":
            final = net.head[-1] if arm == "physics_mlp" else net.head.classifier
            assert float(final.weight.grad.abs().sum()) > 0
            hidden_parameters = (list(net.head[0].parameters()) if arm == "physics_mlp" else
                list(net.head.conv1.parameters()) + list(net.head.film.parameters()) + list(net.head.conv2.parameters()))
            assert all(p.grad is not None and torch.count_nonzero(p.grad) == 0 for p in hidden_parameters)
            with torch.no_grad():
                final.weight.copy_(torch.linspace(-.01, .01, final.weight.numel()).reshape_as(final.weight))
        else:
            assert torch.count_nonzero(net.head.u) == torch.count_nonzero(net.head.v) == 0
            with torch.no_grad():
                net.head.u.copy_(torch.linspace(-.02, .02, 4)); net.head.v.copy_(torch.linspace(-.01, .01, 4))
        net.zero_grad(set_to_none=True)
        active = net.forward_cached(cache); F.nll_loss(active["log_probability"], y).backward()
        if arm != "calibrator": assert any(float(p.grad.abs().sum()) > 0 for p in hidden_parameters)
        assert all(p.grad is None for p in net.backbone.parameters())
        fixture, technical = technical_fixture(c, net, x, cache)
        fixture.update({"active_head_" + key.replace(".", "_"): value.detach().cpu().numpy() for key, value in net.head.state_dict().items()})
        np.savez_compressed(ROOT / f"TECHNICAL_COVARIANCE_{arm}.npz", **fixture)
        evidence.append(dict(arm=arm, parameters=net.parameter_counts(), finite_CE=float(loss.detach()),
            exact_anchor_score_and_probability_initialization=True, initial_anchor_diagnostics=initial_diagnostic,
            first_hidden_gradient_zero_expected=arm != "calibrator", active_head_gradient_verified=True, **technical))
    assert len(set(hashes)) == 1
    assert all(torch.equal(p, initial_probabilities[0]) for p in initial_probabilities)
    result = dict(status="PASS_PREFLIGHT", rows=evidence, matched_CNN_initialization=True, class_C4_covariance=True,
        directional_logit_order=["LR0", "LR1", "LR2", "TB0", "TB1", "TB2"],
        correction_order=["LRdelta0", "LRdelta1", "TBdelta0", "TBdelta1"],
        all4_arms_exact_same_prior=True, zero_residual_exact=True, calibrator_initial_identity=True,
        per_view_joint_is_outer_product=True, final_view_mixture_not_assumed_factorized=True,
        class_rotation_swap=CLASS_SWAP, source_backbone_frozen=True, context_label_free=True, no_training_masks=True,
        softordinal_g0=G0, softordinal_ties="g>=g0 and g>=.5", controls=len(baseline), control_sources=provenance,
        source_sha256=source_hashes(), lineage=lineage, optimizer_updates=0)
    save(ROOT / "PREFLIGHT.json", result); print(json.dumps(result), flush=True)


def run(c, phase, config_path):
    global START
    START = time.monotonic(); assert torch.backends.mps.is_available() and os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] == "0"
    seeds = c["screen_seeds"] if phase == "screen" else [s for s in c["replication_seeds"] if s not in c["screen_seeds"]]
    expected = signature(c); inherited = previous_screen(expected) if phase == "replicate" else None
    data, refs, states, lineage = inputs(c, seeds, "mps"); old_controls, control_sources, frozen_predictions, frozen_probabilities = controls(c, seeds, refs)
    trial_id = f'anchored_{phase}_s{"-".join(map(str,seeds))}_{digest(source_hashes())[:10]}'
    trial = ROOT / "trials" / trial_id; assert not trial.exists(), "Immutable trial exists; no overwrite or implicitresume"
    for folder in [trial, trial / "models", trial / "val_probs", trial / "fixtures", trial / "source", trial / "control_probs"]: folder.mkdir(parents=True, exist_ok=False)
    hashes = source_hashes(); save(trial / "CONFIG_SNAPSHOT.json", c); shutil.copy2(ROOT / "PROTOCOL.md", trial / "PROTOCOL.md")
    for name in ["model.py", "runner.py"]: shutil.copy2(ROOT / name, trial / "source" / name)
    frozen = dict(candidate=c["candidate"], phase=phase, seeds=seeds, signature=expected, source_sha256=hashes, sources=refs,
        lineage=lineage, architecture=architecture_spec(), protocol_sha256=sha(ROOT / "PROTOCOL.md"), config_sha256=sha(config_path),
        control_sources=control_sources, prior_stage_links=c["prior_stage_links"], fitted_models=len(ARMS) * len(refs),
        total_updates=c["steps"] * len(ARMS) * len(refs), evaluation_rows=len(ARMS) * len(refs),
        masks_used_for_head_training=False, mask_output_unchanged=True, fresh_confirmation_access=False,
        success_definition="CNN_SUCCESS only, notMLP/calibrator pipelineA")
    save(trial / "FROZEN.json", frozen); save(trial / "REUSED_CONTROLS.json", old_controls)
    append_ledger(dict(status="RUNNING", trial=trial_id, phase=phase, signature=expected))
    rows, all_controls, checkpoints, counter, initial_diagnostics = [], list(old_controls), {}, [0], []
    try:
        for ref in refs:
            unit = ref["source_lr"], ref["budget"], ref["seed"]; values = data[ref["budget"]]
            builder = make(c, "visual_cnn", states[unit], ref["seed"], "mps"); cache, cache_meta = cached_inputs(builder, values, ref); del builder
            assert np.array_equal(cache["val"]["uniform_probability"].cpu().numpy(), frozen_probabilities[unit]), "Frozen maskprobability changed"
            initial_prior, initial_diagnostic = anchor_diagnostics(cache["val"])
            initial_diagnostics.append(dict(source_lr=unit[0], budget=unit[1], seed=unit[2], **initial_diagnostic))
            np.savez_compressed(trial / "control_probs" / f'{unit[0]}_b{unit[1]}_s{unit[2]}_initial_anchor.npz',
                **{key: value.detach().cpu().numpy() for key, value in initial_prior.items()})
            save(trial / "INITIAL_PRIOR_DIAGNOSTICS.json", initial_diagnostics)
            truth = values["val"]["label"].cpu().numpy(); g = cache["val"]["conductance"].cpu().numpy()
            bins = (g >= G0).astype(np.int64) + (g >= .5).astype(np.int64); soft_prediction = 3 * bins[:, 0] + bins[:, 1]
            soft_metrics = class_metrics(truth, soft_prediction)
            uniform_control = next(row for row in old_controls if (row["source_lr"], row["budget"], row["seed"], row["arm"]) == (*unit, "uniform_frozen"))
            # Masks are unchanged and not class-head outputs. Verify the old
            # diagnostic using the exact frozen source probability and theta.
            threshold = uniform_control["mask_threshold"]; mask = cache["val"]["uniform_probability"][:, 0].cpu().numpy() >= threshold
            target = values["val"]["mask"][:, 0].cpu().numpy().astype(bool); union = (mask | target).sum((1, 2))
            iou = float(np.divide((mask & target).sum((1, 2)), union, out=np.ones(len(mask)), where=union > 0).mean())
            assert abs(iou - uniform_control["frozen_mask_IoU"]) < 2e-7
            assert np.array_equal(orbit.hard_classes(mask), frozen_predictions[unit])
            soft_row = dict(source_lr=unit[0], budget=unit[1], seed=unit[2], arm="fixed_softordinal", **soft_metrics,
                prediction_pipeline="fixed_positive_softconductance_bins", source=ref, g0=G0, upper_threshold=.5,
                threshold_rule="inclusive>=", fit_count=0, optimizer_updates=0, frozen_mask_IoU=iou, mask_output_unchanged=True)
            all_controls.append(soft_row)
            np.savez_compressed(trial / "control_probs" / f'{unit[0]}_b{unit[1]}_s{unit[2]}_fixed_softordinal.npz',
                probability=np.eye(9, dtype=np.float32)[soft_prediction], prediction=soft_prediction, truth=truth, conductance=g,
                physical_context=cache["val"]["physical_context"].cpu().numpy(), uniform_probability=cache["val"]["uniform_probability"].cpu().numpy())
            paired = []
            for arm in ARMS:
                net = make(c, arm, states[unit], ref["seed"], "mps")
                with torch.no_grad():
                    initialized = net.forward_cached(slice_cache(cache["val"], slice(0, 16)))
                    assert torch.count_nonzero(initialized["threshold_corrections"]) == 0
                    assert torch.equal(initialized["probability"], initial_prior["probability"][:16])
                timing = fit(c, net, values["train"], cache["train"], ref, trial, counter)
                evaluation, arrays = evaluate(net, values["val"], cache["val"], frozen_predictions[unit])
                fixture, technical = technical_fixture(c, net, values["val"]["x"][:16], slice_cache(cache["val"], slice(0, 16)))
                row = dict(source_lr=unit[0], budget=unit[1], seed=unit[2], arm=arm, source=ref, **timing, **evaluation, **technical,
                    parameters=net.parameter_counts(), cache=cache_meta, frozen_mask_IoU=iou, mask_output_unchanged=True,
                    frozen_mask_probability_bit_exact=True,
                    initial_anchor_probability_bit_exact=True, initial_anchor_diagnostics=initial_diagnostic,
                    CNN_passes_per_image=4, segmentation_output="unchangeduniformC4", classification_output="learned9classargmax")
                name = f'{unit[0]}_b{unit[1]}_s{unit[2]}_{arm}'; path = trial / "models" / f"{name}.pt"; tmp = path.with_suffix(".pt.partial")
                torch.save(dict(model={key: value.detach().cpu() for key, value in net.state_dict().items()}, settings=row), tmp); tmp.replace(path)
                checkpoints[path.name] = sha(path); np.savez_compressed(trial / "val_probs" / f"{name}.npz", **arrays)
                np.savez_compressed(trial / "fixtures" / f"{name}.npz", **fixture)
                rows.append(row); paired.append(row); save(trial / "PARTIAL_RESULTS.json", rows); save(trial / "CHECKPOINT_HASHES.json", checkpoints)
                del net
            assert len({row["batch_sequence_sha256"] for row in paired}) == 1
            assert paired[0]["head_initial_sha256"] == paired[1]["head_initial_sha256"]
            save(trial / "CONTROL_RESULTS.json", all_controls); del cache
        assert counter[0] == c["steps"] * len(ARMS) * len(refs)
        assert all(sha(ROOT / name) == value for name, value in hashes.items())
        assert sha(config_path) == frozen["config_sha256"] and sha(ROOT / "PROTOCOL.md") == frozen["protocol_sha256"]
        for old in old_controls:
            for key, value in old["control_ref"].items():
                if key.endswith("_file"): assert sha(REPO / value) == old["control_ref"][key[:-5] + "_sha256"]
        gates, means = comparisons(rows, all_controls, c)
        result = dict(status="COMPLETE_CLASSIFICATION_DEVELOPMENT", candidate=c["candidate"], phase=phase, seeds=seeds, signature=expected,
            rows=rows, controls=all_controls, control_sources=control_sources, gates=gates, means=means, fitted_models=len(ARMS) * len(refs),
            updates=counter[0], evaluation_rows=len(rows), reused_mask_control_rows=len(old_controls), fixed_softordinal_rows=len(refs),
            checkpoint_hashes=checkpoints, frozen_sha256=sha(trial / "FROZEN.json"), seconds=time.monotonic() - START,
            initial_prior_diagnostics=initial_diagnostics,
            scope="Anchored correction CE; CNN success requires gain over MLP/calibration; no segmentation gain or independent TEST")
        save(trial / "RESULT.json", result); aggregate = None
        if inherited is not None:
            old_path, old = inherited; all_rows, all_control_rows = old["rows"] + rows, old["controls"] + all_controls
            ag, am = comparisons(all_rows, all_control_rows, c)
            robust = {arm: bool(ag["A_pipeline"][arm]["passed"] and gates["A_pipeline"][arm]["passed"]) for arm in ARMS}
            robust_spatial = {arm: bool(ag["C_spatial"][arm]["passed"] and gates["C_spatial"][arm]["passed"])
                              for arm in ["visual_cnn", "physics_cnn"]}
            aggregate = dict(status="COMPLETE_REUSED_VAL_CLASSIFICATION_REPLICATION", rows=all_rows, controls=all_control_rows, gates=ag, means=am,
                new_seed_gates=gates, robust_pipeline_by_arm=robust, robust_pipeline_pass=any(robust.values()), seeds=c["replication_seeds"],
                robust_physics_pass=bool(ag["B_physics"]["passed"] and gates["B_physics"]["passed"]),
                robust_spatial_by_arm=robust_spatial, robust_CNN_SUCCESS=any(robust_spatial.values()),
                source_trials=[str(old_path.parent.relative_to(ROOT)), str(trial.relative_to(ROOT))])
            save(trial / "AGGREGATE_RESULT.json", aggregate)
        summary = dict(status=result["status"], trial=str(trial.relative_to(ROOT)), phase=phase, result_sha256=sha(trial / "RESULT.json"),
            gates=aggregate["gates"] if aggregate else gates, means=aggregate["means"] if aggregate else means)
        append_ledger(summary); save(ROOT / "LATEST_RESULT.json", summary); print(json.dumps(summary), flush=True)
    except BaseException as error:
        failure = dict(status="FAILED", trial=trial_id, phase=phase, error=str(error), error_type=type(error).__name__, traceback=traceback.format_exc())
        save(trial / "FAILURE.json", failure); append_ledger(failure); raise


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--phase", choices=["screen", "replicate"], default="screen")
    parser.add_argument("--config", type=Path, default=ROOT / "CONFIG.json"); parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args(); c = configuration(args.config); torch.set_num_threads(2)
    if args.preflight: preflight(c)
    else: run(c, args.phase, args.config)


if __name__ == "__main__":
    with threadpool_limits(limits=2): main()
