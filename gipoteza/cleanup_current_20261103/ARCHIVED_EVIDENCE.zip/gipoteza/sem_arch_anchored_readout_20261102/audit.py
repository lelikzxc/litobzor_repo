"""Independent CPU audit of anchored ordinal C4 classification heads.

Old TRAIN/VAL only; no fresh confirmation access, fitting or model updates.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import time

import numpy as np
from scipy import linalg, ndimage
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
REPO = G.parent
PILOT = G / 'sem_architecture_pilot_20261102'
_DIRECTION_CACHE = {}
_CLASS_CACHE = {}
ARMS = ['visual_cnn', 'physics_cnn', 'physics_mlp', 'calibrator']
CLASS_SWAP = [0, 3, 6, 1, 4, 7, 2, 5, 8]
G0 = .5 / (143 * (12 / 11))

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def digest(state):
    h = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()

def macro_f1(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    denominator = confusion.sum(0) + confusion.sum(1)
    return float(np.divide(2 * np.diag(confusion), denominator,
                           out=np.zeros(9, float), where=denominator > 0).mean())

def mean_iou(masks, target):
    union = (masks | target).sum((-2, -1))
    intersection = (masks & target).sum((-2, -1))
    return float(np.divide(intersection, union, out=np.ones(len(union)),
                           where=union > 0).mean())

def direction_class(mask):
    """Independent active-node Cholesky solve of the binary unit-edge graph."""
    mask = np.ascontiguousarray(mask, dtype=bool)
    key = np.packbits(mask).tobytes()
    if key in _DIRECTION_CACHE:
        return _DIRECTION_CACHE[key]
    components, _ = ndimage.label(mask, ndimage.generate_binary_structure(2, 1))
    spanning = np.intersect1d(components[:, 0], components[:, -1])
    spanning = spanning[spanning > 0]
    if not len(spanning):
        answer = 0
    else:
        active = np.isin(components, spanning)
        vertices = np.flatnonzero(active.ravel())
        lookup = np.full(144, -1, dtype=int)
        lookup[vertices] = np.arange(len(vertices))
        laplacian = np.zeros((len(vertices), len(vertices)), dtype=np.float64)
        for vertex in vertices:
            y, x = divmod(int(vertex), 12)
            for yy, xx in [(y + 1, x), (y, x + 1)]:
                if yy < 12 and xx < 12 and active[yy, xx]:
                    a, b = lookup[vertex], lookup[yy * 12 + xx]
                    laplacian[a, a] += 1; laplacian[b, b] += 1
                    laplacian[a, b] -= 1; laplacian[b, a] -= 1
        left = np.flatnonzero(vertices % 12 == 0)
        right = np.flatnonzero(vertices % 12 == 11)
        free = np.setdiff1d(np.arange(len(vertices)), np.r_[left, right])
        potential = np.zeros(len(vertices)); potential[right] = 1
        if len(free):
            potential[free] = linalg.solve(
                laplacian[np.ix_(free, free)],
                -laplacian[np.ix_(free, right)].sum(1), assume_a='pos',
                check_finite=False)
        conductance = float((laplacian[right] @ potential).sum()) / (12 / 11)
        answer = 0 if conductance < 1e-8 else (1 if conductance < .5 - 1e-8 else 2)
    _DIRECTION_CACHE[key] = answer
    return answer

def classify(masks):
    result = []
    for mask in np.asarray(masks, dtype=bool).reshape(-1, 12, 12):
        key = np.packbits(mask).tobytes()
        if key not in _CLASS_CACHE:
            _CLASS_CACHE[key] = 3 * direction_class(mask) + direction_class(mask.T)
        result.append(_CLASS_CACHE[key])
    return np.asarray(result, dtype=np.int64)

def conv(x, state, prefix, padding=0, dilation=1):
    return F.conv2d(x, state[prefix + '.weight'], state[prefix + '.bias'],
                    padding=padding, dilation=dilation)

def independent_backbone(x, state):
    features = x
    for index, dilation in [(0, 1), (2, 2), (4, 4)]:
        features = F.gelu(conv(features, state, str(index), dilation, dilation))
    coarse = conv(features, state, '6')
    return torch.cat((features, coarse, x), 1), coarse

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def independent_soft_direction(probability):
    """Dense CPU64 nodal solve; no import of the context implementation."""
    q = np.clip(np.asarray(probability, dtype=np.float64).reshape(-1, 144), 1e-5, 1 - 1e-5)
    vertices = np.arange(144).reshape(12, 12)
    pairs = [(int(vertices[y, x]), int(vertices[yy, xx])) for y in range(12) for x in range(12)
             for yy, xx in [(y + 1, x), (y, x + 1)] if yy < 12 and xx < 12]
    src = np.array([a for a, _ in pairs]); dst = np.array([b for _, b in pairs])
    free = vertices[:, 1:-1].ravel(); right = vertices[:, -1]
    values = []
    for image in q:
        weight = np.minimum(image[src], image[dst]); laplacian = np.zeros((144, 144), dtype=np.float64)
        np.add.at(laplacian, (src, src), weight); np.add.at(laplacian, (dst, dst), weight)
        laplacian[src, dst] = -weight; laplacian[dst, src] = -weight
        matrix = laplacian[np.ix_(free, free)]; rhs = -laplacian[np.ix_(free, right)].sum(1)
        voltage = linalg.cho_solve(linalg.cho_factor(matrix, lower=True, check_finite=False), rhs, check_finite=False)
        current = laplacian[np.ix_(right, right)].sum() - rhs @ voltage
        values.append(max(current / (12 / 11), 1e-8))
    return np.asarray(values)


def independent_context(mu):
    probability = np.asarray(mu, dtype=np.float64).reshape(-1, 12, 12)
    sharpened = probability ** 4 / (probability ** 4 + (1 - probability) ** 4)
    conductance = np.stack((independent_soft_direction(sharpened), independent_soft_direction(sharpened.transpose(0, 2, 1))), 1)
    ordinal = np.stack((4 * (np.log(conductance) - np.log(G0)), 40 * (conductance - .5)), -1).reshape(-1, 4)
    physical = np.tanh(ordinal / 4)
    visual = np.stack((probability[:, :, [0, -1]].mean((1, 2)), probability[:, [0, -1], :].mean((1, 2)),
                       probability.mean((1, 2)), (4 * probability * (1 - probability)).mean((1, 2))), 1)
    fixed = 3 * ((conductance[:, 0] >= G0).astype(int) + (conductance[:, 0] >= .5).astype(int))
    fixed += (conductance[:, 1] >= G0).astype(int) + (conductance[:, 1] >= .5).astype(int)
    return dict(g=conductance, ordinal_logits=ordinal, physics_context=physical, visual_context=2 * visual - 1, fixed_softordinal=fixed)


def training_batches(budget, seed):
    rng = np.random.default_rng(seed + 1000); result = hashlib.sha256()
    for _ in range(1000):
        result.update(rng.integers(0, budget + 1152, 32).astype(np.int64).tobytes())
    return result.hexdigest()
def reference_cache(images, backbone):
    features, logits, aligned_probabilities = [], [], []
    with torch.inference_mode():
        for rotation in range(4):
            transformed = torch.rot90(images, rotation, (-2, -1)).contiguous()
            visual, z = independent_backbone(transformed, backbone)
            features.append(visual[:, :24]); logits.append(z)
            aligned_probabilities.append(torch.rot90(z, -rotation, (-2, -1)))
        mu = torch.stack(aligned_probabilities).sigmoid().mean(0)
    context = independent_context(mu.numpy())
    physics = torch.tensor(context['physics_context'], dtype=torch.float32)
    visual = torch.tensor(context['visual_context'], dtype=torch.float32)
    return dict(x=images, view_features=torch.stack(features), view_logits=torch.stack(logits), uniform_probability=mu,
        physical_context=torch.stack([physics[:, [2, 3, 0, 1]] if k % 2 else physics for k in range(4)]),
        visual_context=torch.stack([visual[:, [1, 0, 2, 3]] if k % 2 else visual for k in range(4)]),
        conductance=context['g'], ordinal_logits=context['ordinal_logits'], fixed_softordinal=context['fixed_softordinal'])


def reference_head(cache, arm, head):
    n = len(cache['x']); context = cache['visual_context'] if arm == 'visual_cnn' else cache['physical_context']
    prior = 4 * cache['physical_context']
    if arm == 'calibrator':
        corrected = head['u'].exp() * prior + head['v']
        correction = corrected - prior
    elif arm == 'physics_mlp':
        values = context.reshape(4 * n, 4)
        correction = F.linear(F.gelu(F.linear(values, head['0.weight'], head['0.bias'])), head['2.weight'], head['2.bias']).reshape(4, n, 4)
        corrected = prior + correction
    else:
        inputs = torch.stack([torch.cat((cache['view_features'][k], torch.rot90(cache['uniform_probability'], k, (-2, -1)),
            torch.rot90(cache['x'], k, (-2, -1))), 1) for k in range(4)]).reshape(4 * n, 26, 12, 12)
        features = F.gelu(F.conv2d(inputs, head['conv1.weight'], head['conv1.bias'], padding=1))
        gamma, beta = F.linear(context.reshape(4 * n, 4), head['film.weight'], head['film.bias']).chunk(2, 1)
        features = features * (1 + .5 * gamma.tanh()[:, :, None, None]) + .5 * beta.tanh()[:, :, None, None]
        features = F.gelu(F.conv2d(features, head['conv2.weight'], head['conv2.bias'], padding=1))
        correction = F.linear(F.adaptive_avg_pool2d(features, (3, 3)).flatten(1), head['classifier.weight'], head['classifier.bias']).reshape(4, n, 4)
        corrected = prior + correction
    threshold = corrected.reshape(4, n, 2, 2)
    directional_logits = torch.stack((torch.zeros_like(threshold[..., 0]), threshold[..., 0], threshold[..., 0] + threshold[..., 1]), -1)
    logits = directional_logits.flatten(2)
    directional_log_probability = directional_logits.log_softmax(-1)
    per_view = (directional_log_probability[:, :, 0, :, None] + directional_log_probability[:, :, 1, None, :]).reshape(4, n, 9)
    aligned = torch.stack([value[:, CLASS_SWAP] if k % 2 else value for k, value in enumerate(per_view)])
    log_probability = torch.logsumexp(aligned, 0) - np.log(4.)
    return dict(per_view_logits=logits, directional_logits=directional_logits, directional_log_probability=directional_log_probability,
                per_view_log_probability=per_view, aligned_log_probability=aligned, log_probability=log_probability, probability=log_probability.exp(),
                prior_threshold_logits=prior, threshold_corrections=correction, corrected_threshold_logits=corrected)


def gate(delta, config):
    tests = dict(mean_F1_gain=float(np.mean(delta)) >= config['minimum_mean_F1_gain'], budget_F1_guard=min(delta) >= config['minimum_budget_F1_delta'])
    return dict(delta=float(np.mean(delta)), budget_deltas=list(map(float, delta)), checks=tests, passed=all(tests.values()))


def recompute_gates(rows, controls, config):
    merged = rows + controls
    def compare(family, left, right):
        means = lambda arm, budget: float(np.mean([row['class_F1'] for row in merged if row['source_lr'] == family and row['budget'] == budget and row['arm'] == arm]))
        return gate([means(left, budget) - means(right, budget) for budget in [18, 27]], config['gates'])
    pipeline = {}
    for arm in ARMS:
        families = {}
        for family in ['high_lr', 'low_lr']:
            tests = {'vs_' + baseline: compare(family, arm, baseline) for baseline in ['uniform_frozen', 'uniform_adapted', 'single_adapted', 'fixed_softordinal']}
            tests['passed'] = all(value['passed'] for value in tests.values()); families[family] = tests
        pipeline[arm] = dict(by_source_lr=families, passed=all(value['passed'] for value in families.values()))
    physical = {}; spatial = {}
    for family in ['high_lr', 'low_lr']:
        item = compare(family, 'physics_cnn', 'visual_cnn')
        item['physics_cnn_pipeline_gate'] = pipeline['physics_cnn']['by_source_lr'][family]['passed']
        item['passed'] &= item['physics_cnn_pipeline_gate']; physical[family] = item
    for cnn in ['visual_cnn', 'physics_cnn']:
        families = {}
        for family in ['high_lr', 'low_lr']:
            mlp = compare(family, cnn, 'physics_mlp'); calibration = compare(family, cnn, 'calibrator')
            pipeline_pass = pipeline[cnn]['by_source_lr'][family]['passed']
            families[family] = dict(vs_physics_mlp=mlp, vs_calibrator=calibration, pipeline_gate=pipeline_pass,
                passed=bool(pipeline_pass and mlp['passed'] and calibration['passed']))
        spatial[cnn] = dict(by_source_lr=families, passed=all(value['passed'] for value in families.values()))
    return dict(A_pipeline=pipeline, A_any=any(value['passed'] for value in pipeline.values()),
        B_physics=dict(by_source_lr=physical, passed=all(value['passed'] for value in physical.values())),
        C_spatial=spatial, CNN_SUCCESS=any(value['passed'] for value in spatial.values()))


def numeric_compare(actual, observed):
    if isinstance(actual, dict):
        assert set(actual) == set(observed)
        return max([numeric_compare(value, observed[key]) for key, value in actual.items()] + [0.])
    if isinstance(actual, list):
        assert len(actual) == len(observed)
        return max([numeric_compare(a, b) for a, b in zip(actual, observed)] + [0.])
    if isinstance(actual, bool):
        assert actual == observed
        return 0.
    return abs(float(actual) - float(observed))
def audit_probe(config, model_module, backbone, images, truth, target):
    preflight = json.loads((ROOT / 'PREFLIGHT.json').read_text())
    checks = {}; errors = dict(probability=0., logits=0., context=0., conductance=0., covariance=0.,
        directional_joint=0., joint_marginals=0., wrong_pooling_witness=0., anchor=0., correction_equation=0.)
    semantic = True
    for k in range(4):
        rotated_class = classify(np.rot90(target, k, (-2, -1)))
        expected = np.asarray(CLASS_SWAP)[truth] if k % 2 else truth
        semantic &= np.array_equal(rotated_class, expected)
    checks['independent_hard_mask_LR_TB_nine_class_rotation_semantics'] = bool(semantic)
    checks['frozen_preflight_sources_and_nontraining_scope'] = (preflight['status'] == 'PASS_PREFLIGHT' and preflight['optimizer_updates'] == 0 and
        preflight['class_rotation_swap'] == CLASS_SWAP and all(sha(ROOT / key) == value for key, value in preflight['source_sha256'].items()))
    shared = []; source_gradients = True; initial_ok = True; active = True; factorization_ok = True; parameter_change_ok = True
    first_gradient_evidence = {}; active_gradient_evidence = {}; initial_probabilities = []
    previous_model = load_module('directional_architecture_reference_only', G / 'sem_arch_directional_readout_20261102/model.py')
    reference = reference_cache(images, backbone)
    for arm in ARMS:
        net = model_module.make_model(arm, backbone, head_seed=205504)
        source_cache = net.precompute(images)
        initial = net.forward_cached(source_cache)
        initial_probabilities.append(initial['probability'].detach())
        initial_ok &= (torch.equal(initial['prior_threshold_logits'], 4 * source_cache['physical_context']) and
            torch.count_nonzero(initial['threshold_corrections']).item() == 0 and
            torch.equal(initial['corrected_threshold_logits'], initial['prior_threshold_logits']))
        if arm in ['visual_cnn', 'physics_cnn']: shared.append(digest(net.head.state_dict()))
        current_count = sum(value.numel() for value in net.head.parameters())
        if arm == 'calibrator':
            parameter_change_ok &= current_count == 8 and set(net.head.state_dict()) == {'u', 'v'} and all(torch.count_nonzero(v).item() == 0 for v in net.head.state_dict().values())
        else:
            previous = previous_model.make_model(arm, backbone, head_seed=205504)
            old_count = sum(value.numel() for value in previous.head.parameters())
            parameter_change_ok &= (old_count, current_count, old_count - current_count) == ((358, 292, 66) if arm == 'physics_mlp' else (5518, 5372, 146))
            old_state, new_state = previous.head.state_dict(), net.head.state_dict()
            final_prefix = '2.' if arm == 'physics_mlp' else 'classifier.'
            parameter_change_ok &= all(torch.equal(value, new_state[key]) for key, value in old_state.items() if not key.startswith(final_prefix))
            initial_ok &= all(torch.count_nonzero(v).item() == 0 for key, v in new_state.items() if key.startswith(final_prefix))
        F.nll_loss(initial['log_probability'], torch.tensor([0, 8])).backward()
        gradients = {key: float(parameter.grad.abs().sum()) for key, parameter in net.head.named_parameters()}
        first_gradient_evidence[arm] = gradients
        source_gradients &= (all(parameter.grad is None for parameter in net.backbone.parameters()) and
            all(parameter.grad is not None and torch.isfinite(parameter.grad).all().item() for parameter in net.head.parameters()) and
            all(not value.requires_grad for value in source_cache.values()))
        if arm != 'calibrator':
            final_prefix = '2.' if arm == 'physics_mlp' else 'classifier.'
            source_gradients &= all(value > 0 if key.startswith(final_prefix) else value == 0 for key, value in gradients.items())
        else: source_gradients &= all(value > 0 for value in gradients.values())
        # A separate deterministic nonzero final-layer probe makes covariance
        # and hidden-gradient checks sensitive to each learned correction path.
        generator = torch.Generator().manual_seed(9503)
        with torch.no_grad():
            if arm == 'calibrator':
                net.head.u.copy_(torch.randn(4, generator=generator) * .1)
                net.head.v.copy_(torch.randn(4, generator=generator) * .1)
            else:
                final = net.head[-1] if arm == 'physics_mlp' else net.head.classifier
                final.weight.copy_(torch.randn(final.weight.shape, generator=generator) * .03)
                final.bias.copy_(torch.randn(final.bias.shape, generator=generator) * .02)
        net.zero_grad(set_to_none=True)
        output = net.forward_cached(source_cache)
        F.nll_loss(output['log_probability'], torch.tensor([0, 8])).backward()
        active_gradient_evidence[arm] = {key: float(parameter.grad.abs().sum()) for key, parameter in net.head.named_parameters()}
        source_gradients &= all(parameter.grad is not None and torch.isfinite(parameter.grad).all().item() and parameter.grad.abs().sum().item() > 0 for parameter in net.head.parameters())
        source_gradients &= all(parameter.grad is None for parameter in net.backbone.parameters())
        active &= float(output['threshold_corrections'].detach().abs().max()) > 1e-5
        with torch.inference_mode():
            reconstructed = reference_head(reference, arm, net.head.state_dict())
            transformed = torch.stack([net.forward_details(torch.rot90(images, k, (-2, -1)))['probability'] for k in range(4)])
            restored = torch.stack([value[:, CLASS_SWAP] if k % 2 else value for k, value in enumerate(transformed)])
        errors['probability'] = max(errors['probability'], float((reconstructed['probability'] - output['probability'].detach()).abs().max()))
        errors['logits'] = max(errors['logits'], float((reconstructed['per_view_logits'] - output['per_view_logits'].detach()).abs().max()))
        errors['covariance'] = max(errors['covariance'], float((restored - output['probability'].detach()[None]).abs().max()))
        errors['conductance'] = max(errors['conductance'], float(np.max(np.abs(reference['conductance'] - source_cache['conductance'].numpy()))))
        context_name = 'visual_context' if arm == 'visual_cnn' else 'physical_context'
        errors['context'] = max(errors['context'], float((reference[context_name] - source_cache[context_name]).abs().max()))
        with np.load(ROOT / f'TECHNICAL_COVARIANCE_{arm}.npz', allow_pickle=False) as archive:
            fixture = {key: archive[key] for key in archive.files}
        active &= np.array_equal(fixture['x'], images.numpy())
        fixture_head = {key: torch.tensor(fixture['active_head_' + key.replace('.', '_')]) for key in net.head.state_dict()}
        with torch.inference_mode(): fixture_reference = reference_head(reference, arm, fixture_head)
        errors['probability'] = max(errors['probability'], float(np.max(np.abs(fixture_reference['probability'].numpy() - fixture['probability']))))
        errors['logits'] = max(errors['logits'], float(np.max(np.abs(fixture_reference['per_view_logits'].numpy() - fixture['per_view_logits']))))
        directional = torch.tensor(fixture['directional_logits'])
        factorization_ok &= directional.shape == (4, len(images), 2, 3) and np.array_equal(directional.numpy(), fixture['per_view_logits'].reshape(4, len(images), 2, 3))
        corrected = torch.tensor(fixture['corrected_threshold_logits']).reshape(4, len(images), 2, 2)
        expected_direction = torch.stack((torch.zeros_like(corrected[..., 0]), corrected[..., 0], corrected[..., 0] + corrected[..., 1]), -1)
        errors['anchor'] = max(errors['anchor'], float(np.max(np.abs(fixture['prior_threshold_logits'] - 4 * fixture['physical_context']))))
        errors['correction_equation'] = max(errors['correction_equation'], float((directional - expected_direction).abs().max()),
            float(np.max(np.abs(fixture['corrected_threshold_logits'] - fixture['prior_threshold_logits'] - fixture['threshold_corrections']))))
        dlog = directional.log_softmax(-1)
        joint = (dlog[:, :, 0, :, None] + dlog[:, :, 1, None, :]).reshape(4, len(images), 9)
        errors['directional_joint'] = max(errors['directional_joint'], float(np.max(np.abs(joint.numpy() - fixture['per_view_log_probability']))))
        joint_matrix = joint.exp().reshape(4, len(images), 3, 3)
        errors['joint_marginals'] = max(errors['joint_marginals'], float((joint_matrix.sum(-1) - dlog[:, :, 0].exp()).abs().max()),
            float((joint_matrix.sum(-2) - dlog[:, :, 1].exp()).abs().max()))
        canonical_marginals = torch.stack([value.flip(-2) if k % 2 else value for k, value in enumerate(dlog.exp())]).mean(0)
        wrong = (canonical_marginals[:, 0, :, None] * canonical_marginals[:, 1, None, :]).reshape(len(images), 9)
        correct = torch.stack([value[:, CLASS_SWAP] if k % 2 else value for k, value in enumerate(joint.exp())]).mean(0)
        factorization_ok &= float((correct.sum(1) - 1).abs().max()) < 8 * np.finfo(np.float32).eps
        errors['wrong_pooling_witness'] = max(errors['wrong_pooling_witness'], float((wrong - correct).abs().max()))
        errors['directional_joint'] = max(errors['directional_joint'], float(np.max(np.abs(correct.numpy() - fixture['probability']))))
        saved_restored = np.stack([p[:, CLASS_SWAP] if k % 2 else p for k, p in enumerate(fixture['transformed_probability'])])
        errors['covariance'] = max(errors['covariance'], float(np.max(np.abs(saved_restored - fixture['probability'][None]))))
        active &= np.array_equal(saved_restored, fixture['restored_class_probability']) and fixture['class_swap'].tolist() == CLASS_SWAP
    initial_ok &= all(torch.equal(initial_probabilities[0], value) for value in initial_probabilities[1:])
    # At exact g0/.5 the cumulative-score argmax chooses the first tied bin;
    # the fixed predictor uses >= and chooses the upper bin. Test both rules.
    conductance = np.array([.99 * G0, G0, 1.01 * G0, .49, .5, .51])
    ordinal = np.stack((4 * np.log(conductance / G0), 40 * (conductance - .5)), -1)
    anchor = 4 * np.tanh(ordinal / 4)
    scores = np.stack((np.zeros(len(anchor)), anchor[:, 0], anchor.sum(1)), -1)
    anchored_bins = scores.argmax(1); inclusive_bins = (conductance >= G0).astype(int) + (conductance >= .5).astype(int)
    tie_evidence = dict(conductance=conductance.tolist(), anchored_argmax_bins=anchored_bins.tolist(),
        fixed_inclusive_bins=inclusive_bins.tolist(), differences=np.flatnonzero(anchored_bins != inclusive_bins).tolist())
    checks['exact_zero_residual_and_identity_calibrator_common_anchor_initialization'] = bool(initial_ok)
    checks['5372_CNN_heads_matched_and_active_correction_paths_nontrivial'] = len(set(shared)) == 1 and bool(active)
    checks['independent_raw_view_class_forward_and_context_probes'] = errors['probability'] < 1e-5 and errors['logits'] < 1e-4 and errors['context'] < 1e-4 and errors['conductance'] < 1e-6
    checks['active_class_covariance_correct_permutation_not_invariance'] = errors['covariance'] <= 1e-6
    checks['expected_first_zero_hidden_gradients_and_active_hidden_gradients_frozen_body'] = bool(source_gradients)
    checks['final_threshold_output_reduces_CNN146_MLP66_parameters_and_calibrator8'] = bool(parameter_change_ok)
    checks['anchored_cumulative_scores_directional_outer_product_joint_before_pool'] = bool(factorization_ok) and errors['directional_joint'] < 1e-6 and errors['joint_marginals'] < 1e-6 and errors['anchor'] == 0 and errors['correction_equation'] < 1e-6 and errors['wrong_pooling_witness'] > 1e-6
    checks['explicit_argmax_vs_inclusive_fixed_predictor_ties_at_g0_and_half'] = np.array_equal(anchored_bins, [0, 0, 1, 1, 1, 2]) and np.array_equal(inclusive_bins, [0, 1, 1, 1, 2, 2])
    # Own active heads supplement saved fixtures; their nonzero corrections
    # make view pooling sensitive even if a saved zero-anchor fixture factorizes.
    return checks, dict(**errors, first_gradient_L1=first_gradient_evidence, active_gradient_L1=active_gradient_evidence, tie_fixture=tie_evidence)
def audit_rounding_capture():
    report = json.loads((ROOT / 'MPS_ROUNDING_CAPTURE.json').read_text())
    with np.load(ROOT / 'MPS_ROUNDING_CAPTURE.npz', allow_pickle=False) as archive:
        values = {key: archive[key] for key in archive.files}
    with np.load(ROOT / report['source_file'], allow_pickle=False) as archive:
        source = {key: archive[key] for key in archive.files}
    failed = ROOT / Path(report['source_file']).parts[0] / Path(report['source_file']).parts[1]
    frozen = json.loads((failed / 'FROZEN.json').read_text())
    code = (ROOT / 'capture_mps_rounding.py').read_text()
    score = torch.tensor(values['scores'], dtype=torch.float64)
    directional = score.log_softmax(-1)
    joint = (directional[:, :, 0, :, None] + directional[:, :, 1, None, :]).reshape(4, 695, 9)
    aligned = torch.stack([p[:, CLASS_SWAP] if k % 2 else p for k, p in enumerate(joint)])
    log_probability = torch.logsumexp(aligned, 0) - np.log(4.)
    delta = float(np.max(np.abs(values['full_probability'][:16] - values['small_probability'])))
    log_delta = float(np.max(np.abs(values['full_log_probability'][:16] - values['small_log_probability'])))
    full_error = float(np.max(np.abs(log_probability.exp().numpy() - values['full_probability'])))
    small_error = float(np.max(np.abs(log_probability.exp().numpy()[:16] - values['small_probability'])))
    valid = (report['status'] == 'PASS_NUMERICAL_REPRODUCTION' and report['fitted_models'] == report['optimizer_updates'] == 0 and
        report['device'] == 'mps' and report['dtype'] == 'float32' and report['full_batch'] == 695 and report['small_batch'] == 16 and
        sha(ROOT / report['source_file']) == report['source_sha256'] and sha(ROOT / 'capture_mps_rounding.py') == report['script_sha256'] and
        sha(ROOT / 'model.py') == frozen['source_sha256']['model.py'] and sha(ROOT / 'runner.py') == frozen['source_sha256']['runner.py'] and
        values['scores'].shape == (4, 695, 2, 3) and values['full_probability'].shape == (695, 9) and values['small_probability'].shape == (16, 9) and
        np.array_equal(values['scores'], source['directional_logits']) and np.array_equal(values['full_probability'], source['probability']) and
        report['input_scores_identical'] and report['full_reproduces_saved_probability_bit_exact'] and
        delta == report['probability_max_abs_difference'] and log_delta == report['log_probability_max_abs_difference'] and
        report['predictions_identical'] and np.array_equal(values['full_probability'][:16].argmax(1), values['small_probability'].argmax(1)) and
        delta <= report['existing_eight_epsilon_absolute_probability_bound'] == 8 * np.finfo(np.float32).eps and
        max(full_error, small_error) < 8 * np.finfo(np.float32).eps and
        not any(isinstance(node, ast.Attribute) and node.attr in ['step', 'backward', 'load_state_dict'] for node in ast.walk(ast.parse(code))))
    return bool(valid), dict(probability_delta=delta, log_probability_delta=log_delta, CPU_float64_full_probability=full_error,
        CPU_float64_small_probability=small_error, capsule_sha256=sha(ROOT / 'MPS_ROUNDING_CAPTURE.npz'),
        explanation='Same exact scores, MPSbatch695vs16 rounding only; first16classargmax identical, zero optimizerupdates, model/runner unchanged.')


def json_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def audit_recovery(folder, result, frozen):
    checks = {}; recovery = frozen['recovery']; proof = json.loads((folder / 'RECOVERY_PROOF.json').read_text())
    failed = ROOT / recovery['failed_trial']; old_frozen = json.loads((failed / 'FROZEN.json').read_text())
    old_rows = json.loads((failed / 'PARTIAL_RESULTS.json').read_text()); failure = json.loads((failed / 'FAILURE.json').read_text())
    inventory = {str(path.relative_to(ROOT)): dict(sha256=sha(path), bytes=path.stat().st_size)
        for path in sorted(failed.rglob('*')) if path.is_file()}
    protected = recovery['preserved_original_sha256']
    checks['original_failed_trial_all_bytes_and_all_sources_config_protocol_preserved'] = (
        failure['status'] == 'FAILED' and failure['error_type'] == 'AssertionError' and 'torch.equal(initialized' in failure['traceback'] and
        not (failed / 'RESULT.json').exists() and recovery == result['recovery'] == json.loads((folder / 'RECOVERY_MANIFEST.json').read_text()) and
        inventory == recovery['failed_inventory'] and json_digest(inventory) == recovery['failed_inventory_sha256'] and
        recovery['original_source_sha256'] == old_frozen['source_sha256'] and
        all(sha(ROOT / name) == value for name, value in recovery['original_source_sha256'].items()) and
        all(sha(ROOT / name) == value for name, value in protected.items()) and
        (failed / 'CONFIG_SNAPSHOT.json').read_bytes() == (folder / 'CONFIG_SNAPSHOT.json').read_bytes() and
        (failed / 'PROTOCOL.md').read_bytes() == (folder / 'PROTOCOL.md').read_bytes() and
        recovery['rounding_capture_sha256'] == sha(ROOT / recovery['rounding_capture_file']) and
        recovery['rounding_capture_arrays_sha256'] == sha(ROOT / recovery['rounding_capture_arrays_file']))
    key = lambda row: (row['source_lr'], row['budget'], row['seed'], row['arm'])
    by_key = {key(row): row for row in result['rows']}
    expected_old = {('high_lr', budget, 5501, arm) for budget in [18, 27] for arm in ARMS}
    inherited_ok = len(old_rows) == len(recovery['inherited_rows']) == 8 and {key(row) for row in old_rows} == expected_old
    for item in recovery['inherited_rows']:
        unit = tuple(item['row_key']); old = next(row for row in old_rows if key(row) == unit)
        inherited_ok &= old == by_key[unit] and item['row_sha256'] == json_digest(old)
        for subdir, artifact in item['artifacts'].items():
            origin = ROOT / artifact['file']; inherited = folder / subdir / origin.name
            inherited_ok &= origin.is_relative_to(failed) and sha(origin) == sha(inherited) == artifact['sha256']
        for ending in ['initial_anchor', 'fixed_softordinal']:
            filename = f'{unit[0]}_b{unit[1]}_s{unit[2]}_{ending}.npz'
            inherited_ok &= (failed / 'control_probs' / filename).read_bytes() == (folder / 'control_probs' / filename).read_bytes()
    checks['all_eight_inherited_rows_checkpoints_probabilities_fixtures_prior_and_control_bytes_exact'] = bool(inherited_ok)
    counters_ok = all(recovery[name] == value for name, value in dict(inherited_models=8, inherited_updates=8000,
        actual_new_models=8, actual_new_updates=8000, total_unique_models=16, total_unique_updates=16000).items())
    counters_ok &= all(frozen[name] == value for name, value in dict(actual_new_fitted_models=8, actual_new_updates=8000,
        inherited_fitted_models=8, inherited_updates=8000, fitted_models=16, total_updates=16000).items())
    counters_ok &= all(result[name] == value for name, value in dict(actual_new_fits=8, actual_new_updates=8000,
        inherited_fits=8, inherited_updates=8000, fitted_models=16, total_unique_models=16, updates=16000).items())
    counters_ok &= all(proof[name] == value for name, value in dict(high_lr_fits_reexecuted=0, actual_new_fits=8, actual_new_updates=8000,
        inherited_fits=8, inherited_updates=8000, total_unique_models=16, total_unique_updates=16000).items())
    counters_ok &= (proof['status'] == 'PASS_APPEND_ONLY_RECOVERY_PROOF' and sha(folder / 'RECOVERY_PROOF.json') == result['recovery_proof_sha256'] and
        result['row_provenance'] == proof['row_provenance'] and len(proof['row_provenance']) == 16 and
        {tuple(item['row_key']) for item in proof['row_provenance']} == set(by_key))
    for item in proof['row_provenance']:
        unit = tuple(item['row_key']); row = by_key[unit]
        counters_ok &= (item['source_row_sha256'] == json_digest(row) and
            item['origin'] == ('inherited_completed_fit' if unit in expected_old else 'new_low_lr_fit') and
            item['source_trial'] == (recovery['failed_trial'] if unit in expected_old else str(folder.relative_to(ROOT))))
    checks['exact_sixteen_unique_fits_eight_inherited_eight_new_and_updates8000plus8000'] = bool(counters_ok)
    code = (folder / 'source' / 'recovery.py').read_text(); tree = ast.parse(code); source = ast.unparse(tree)
    reused = ['inputs', 'controls', 'cached_inputs', 'fit', 'evaluate', 'technical_fixture', 'comparisons', 'anchor_diagnostics']
    unchanged = (sha(ROOT / recovery['recovery_source_file']) == recovery['recovery_source_sha256'] == sha(folder / 'source' / 'recovery.py') and
        all('r.' + name + '(' in source for name in reused) and "if ref['source_lr'] != 'low_lr':\n                continue" in source and
        not any(isinstance(node, ast.Attribute) and node.attr in ['backward', 'step', 'AdamW'] for node in ast.walk(tree)) and
        not any(isinstance(node, (ast.Assign, ast.AnnAssign)) and any(isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name) and target.value.id == 'r' and target.attr in reused for target in (node.targets if isinstance(node, ast.Assign) else [node.target])) for node in ast.walk(tree)))
    checks['recovery_reuses_immutable_original_scientific_functions_and_trains_only_low_lr'] = bool(unchanged and recovery['scientific_model_loss_data_batch_gates_unchanged'] and proof['original_model_loss_data_optimizer_batches_gates_reused'])
    layout_ok = len(proof['initialization_layout_proofs']) == 8
    layout_units = set(); max_probability_error = max_relative_log_error = max_float64_error = 0.
    for item in proof['initialization_layout_proofs']:
        unit = key(item); layout_units.add(unit); row = by_key[unit]
        layout_ok &= row['initial_anchor_comparison_layout'] == 'same16' and row['initial_anchor_layout_proof'] == {k: v for k, v in item.items() if k not in ['source_lr', 'budget', 'seed', 'arm']}
        layout_ok &= sha(folder / item['evidence_file']) == item['evidence_sha256']
        with np.load(folder / item['evidence_file'], allow_pickle=False) as archive:
            evidence = {key: archive[key] for key in archive.files}
        with np.load(folder / 'control_probs' / f'{unit[0]}_b{unit[1]}_s{unit[2]}_initial_anchor.npz', allow_pickle=False) as archive:
            prior = {key: archive[key] for key in archive.files}
        for name in ['probability', 'log_probability', 'directional_logits']:
            layout_ok &= np.array_equal(evidence['same16_anchor_' + name], evidence['initialized16_' + name])
        layout_ok &= (np.count_nonzero(evidence['initialized16_corrections']) == 0 and
            np.array_equal(evidence['full695_probability'], prior['probability']) and np.array_equal(evidence['full695_log_probability'], prior['log_probability']) and
            np.array_equal(evidence['same16_anchor_directional_logits'], prior['directional_logits'][:, :16]))
        error = float(np.max(np.abs(evidence['full695_probability'][:16] - evidence['same16_anchor_probability'])))
        relative = float(np.max(np.abs(evidence['full695_log_probability'][:16] - evidence['same16_anchor_log_probability']) / np.maximum(1., np.abs(evidence['full695_log_probability'][:16]))))
        max_probability_error = max(max_probability_error, error); max_relative_log_error = max(max_relative_log_error, relative)
        layout_ok &= error == item['cross_layout_probability_error'] and relative == item['cross_layout_log_probability_relative_error'] and max(error, relative) <= item['existing_float32_eight_epsilon_bound'] == 8 * np.finfo(np.float32).eps
        score = torch.tensor(evidence['same16_anchor_directional_logits'], dtype=torch.float64)
        direction = score.log_softmax(-1); joint = (direction[:, :, 0, :, None] + direction[:, :, 1, None, :]).reshape(4, 16, 9)
        aligned = torch.stack([p[:, CLASS_SWAP] if k % 2 else p for k, p in enumerate(joint)])
        reference = (torch.logsumexp(aligned, 0) - np.log(4.)).exp().numpy()
        float64_error = float(np.max(np.abs(reference - evidence['same16_anchor_probability'])))
        max_float64_error = max(max_float64_error, float64_error); layout_ok &= float64_error < 8 * np.finfo(np.float32).eps
        old_prior_path = failed / 'control_probs' / f'{unit[0]}_b{unit[1]}_s{unit[2]}_initial_anchor.npz'
        if old_prior_path.exists():
            with np.load(old_prior_path, allow_pickle=False) as archive:
                layout_ok &= item['original_failed_full695_probability_reproduced'] is True and np.array_equal(archive['probability'], evidence['full695_probability'])
        else: layout_ok &= item['original_failed_full695_probability_reproduced'] is None
    layout_ok &= layout_units == {('low_lr', budget, 5501, arm) for budget in [18, 27] for arm in ARMS}
    checks['all_eight_new_heads_same16_exact_initial_scores_logP_probability_and_separate_cross695_rounding'] = bool(layout_ok)
    return checks, dict(failed_trial=recovery['failed_trial'], failed_inventory_sha256=json_digest(inventory),
        inherited_fits=8, new_fits=8, total_unique_fits=16, inherited_updates=8000, new_updates=8000,
        cross_layout_probability_error=max_probability_error, cross_layout_log_probability_relative_error=max_relative_log_error,
        same16_CPU_float64_probability_error=max_float64_error)


def audit_trial(folder):
    started = time.monotonic(); read = lambda name: json.loads((folder / name).read_text())
    result, frozen, config = (read(name) for name in ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json'])
    before = {str(path): sha(path) for path in [folder / 'RESULT.json', folder / 'FROZEN.json', folder / 'CONFIG_SNAPSHOT.json', folder / 'PROTOCOL.md',
        ROOT / 'model.py', ROOT / 'runner.py', PILOT / 'TRAIN_VAL.npz']}
    before.update({str(ROOT / name): sha(ROOT / name) for name in frozen['source_sha256']})
    checks = {}
    checks['frozen_direct_classification_scope_and_unchanged_sources_protocol'] = (
        result['status'] == 'COMPLETE_CLASSIFICATION_DEVELOPMENT' and frozen['fresh_confirmation_access'] is False and
        frozen['masks_used_for_head_training'] is False and frozen['mask_output_unchanged'] and
        frozen['success_definition'] == 'CNN_SUCCESS only, notMLP/calibrator pipelineA' and
        sha(folder / 'FROZEN.json') == result['frozen_sha256'] and sha(folder / 'PROTOCOL.md') == config['protocol_sha256'] == frozen['protocol_sha256'] and
        sha(folder / 'CONFIG_SNAPSHOT.json') == frozen['config_sha256'] and
        all(sha(ROOT / key) == value for key, value in frozen['source_sha256'].items()) and
        all(sha(folder / 'source' / name) == frozen['source_sha256'][name] for name in ['model.py', 'runner.py']))
    checks['fixed_class_only_1000step_CE_design_and_F1_gates'] = (
        config['candidate'] == 'C4_anchored_readout' and config['fitted_arms'] == config['evaluation_arms'] == ARMS and
        config['source_lr'] == ['high_lr', 'low_lr'] and config['budgets'] == [18, 27] and config['screen_seeds'] == [5501] and config['replication_seeds'] == [5501, 5521, 5557] and
        config['steps'] == 1000 and config['batch_size'] == 32 and config['head_learning_rate'] == .001 and config['weight_decay'] == .0001 and
        config['head_seed_offset'] == 200003 and config['batch_seed_offset'] == 1000 and config['subset_seed'] == 5303 and
        config['technical_seed'] == 9503 and config['equivariance_tolerance'] == 1e-6 and
        config['gates'] == dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025))
    tree = ast.parse((folder / 'source' / 'runner.py').read_text())
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    input_source, fit_source = ast.unparse(functions['inputs']), ast.unparse(functions['fit'])
    checks['replication_requires_CNN_spatial_success_and_independent_audit'] = (
        "found[0][1]['gates']['CNN_SUCCESS']" in ast.unparse(functions['previous_screen']) and
        "audit['status'] == 'PASS_AUDIT'" in ast.unparse(functions['previous_screen']))
    checks['training_inputs_only_images_classes_Y_val_indices_only_and_no_train_mask'] = (
        "['X', 'label', 'role', 'frame']" in input_source and "val_mask = archive['Y'][vi].astype(np.float32)" in input_source and
        "assert 'mask' not in train" in fit_source and "train['mask']" not in fit_source and
        "loss = F.nll_loss(result['log_probability'], train['label'][ids])" in fit_source and
        'params = list(model.head.parameters())' in fit_source and 'all((p.grad is None for p in model.backbone.parameters()))' in fit_source)
    model_tree = ast.parse((folder / 'source' / 'model.py').read_text()); model_source = ast.unparse(model_tree)
    context_function = next(node for node in model_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'context_from_mu')
    flat_tree = ast.parse((G / 'sem_arch_classification_readout_20261102/model.py').read_text())
    current_functions = {node.name: ast.unparse(node) for node in ast.walk(model_tree) if isinstance(node, ast.FunctionDef)}
    flat_functions = {node.name: ast.unparse(node) for node in ast.walk(flat_tree) if isinstance(node, ast.FunctionDef)}
    checks['source_context_and_frozen_orbit_precompute_unchanged_from_previous_readout'] = all(current_functions[name] == flat_functions[name] for name in ['context_from_mu', 'visual_context', 'precompute'])
    checks['prediction_only_context_no_labels_fixed_old_g0_and_correct_label_permutation'] = (
        [arg.arg for arg in context_function.args.args] == ['mu'] and
        'fourth = mu.pow(4)' in ast.unparse(context_function) and 'torch.tanh(ordinal / 4)' in ast.unparse(context_function) and
        'CLASS_SWAP = [0, 3, 6, 1, 4, 7, 2, 5, 8]' in model_source and 'CONTEXT_SWAP = [2, 3, 0, 1]' in model_source and
        "features.append(f)" in model_source and 'torch.rot90(mu, k, (-2, -1))' in model_source and
        'log_probability = torch.logsumexp(aligned, dim=0) - math.log(4)' in model_source)
    lineage = frozen['lineage']; subsets = json.loads((PILOT / 'SUBSETS.json').read_text())
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    val = np.flatnonzero(data['role'] == 'val'); images = torch.tensor(5 * (data['X'][val] - .2))
    truth, target = data['label'][val], data['Y'][val, 0].astype(bool)
    checks['unchanged_TRAIN_VAL_subsets_balanced_class_training_and_val_truth'] = (
        sha(PILOT / 'TRAIN_VAL.npz') == lineage['TRAIN_VAL_sha256'] == subsets['train_val_sha256'] and
        sha(PILOT / 'SUBSETS.json') == lineage['subsets_sha256'] and sha(PILOT / 'INITIAL_LINEAGE.json') == lineage['initial_lineage_sha256'] and
        lineage['training_masks_present'] is False and lineage['val_mask_diagnostic_only'] and
        lineage['training_inputs'] == ['X', 'class_label'] and len(val) == 695 and set(data['frame'][val]) == {6, 7} and
        np.array_equal(classify(target), truth) and all(np.array_equal(np.bincount(data['label'][np.concatenate((subsets['dense_indices'][str(b)], np.flatnonzero(data['role'] == 'weak')))], minlength=9), np.full(9, 128 + b // 9)) for b in [18, 27]))
    seeds = [5501] if result['phase'] == 'screen' else [5521, 5557]
    refs, rows, controls = frozen['sources'], result['rows'], result['controls']
    units = {(family, budget, seed) for family in ['high_lr', 'low_lr'] for budget in [18, 27] for seed in seeds}
    checks['exact_16_head_and_four_control_per_unit_grids'] = (
        result['seeds'] == frozen['seeds'] == seeds and {(r['source_lr'], r['budget'], r['seed']) for r in refs} == units and len(refs) == len(units) and
        len(rows) == result['evaluation_rows'] == frozen['evaluation_rows'] == 4 * len(units) and
        {(r['source_lr'], r['budget'], r['seed'], r['arm']) for r in rows} == {(*unit, arm) for unit in units for arm in ARMS} and
        result['fitted_models'] == frozen['fitted_models'] == 4 * len(units) and result['updates'] == frozen['total_updates'] == 4000 * len(units) and
        result['reused_mask_control_rows'] == 3 * len(units) and result['fixed_softordinal_rows'] == len(units) and len(controls) == 4 * len(units))
    old_controls = [row for row in controls if row['arm'] != 'fixed_softordinal']
    checks['reused_control_snapshot_exact'] = read('REUSED_CONTROLS.json') == old_controls and read('CONTROL_RESULTS.json') == controls
    control_ok = True; control_error = 0.; old_masks = {}; old_probabilities = {}; control_recomputed = []
    for row in old_controls:
        reference = row['control_ref']
        for key, value in reference.items():
            if key.endswith('_file'):
                control_ok &= sha(REPO / value) == reference[key[:-5] + '_sha256']; before[str(REPO / value)] = sha(REPO / value)
        old_result = json.loads((REPO / reference['result_file']).read_text()); old_audit = json.loads((REPO / reference['audit_file']).read_text())
        old_row = next(item for item in old_result['rows'] if (item['source_lr'], item['budget'], item['seed'], item['arm']) == (row['source_lr'], row['budget'], row['seed'], row['arm']))
        control_ok &= (old_audit['status'] == 'PASS_AUDIT' and old_audit['result_sha256'] == sha(REPO / reference['result_file']) and row['source'] == old_row['source'] and
            row['mask_threshold'] == old_row['selected']['threshold'] and row['prediction_pipeline'] == 'class_of_frozen_thresholded_segmentation_mask')
        with np.load(REPO / reference['val_probability_file'], allow_pickle=False) as archive:
            p = archive['probability'][0]
            control_ok &= np.array_equal(archive['truth'], truth) and np.array_equal(archive['target'], target)
        masks = p[:, 0] >= row['mask_threshold']; pred = classify(masks)
        value = macro_f1(truth, pred); iou = mean_iou(masks, target)
        control_error = max(control_error, abs(value - row['class_F1']), abs(iou - row['frozen_mask_IoU']))
        control_recomputed.append(dict(source_lr=row['source_lr'], budget=row['budget'], seed=row['seed'], arm=row['arm'], class_F1=value))
        if row['arm'] == 'uniform_frozen':
            unit = row['source_lr'], row['budget'], row['seed']; old_masks[unit] = pred; old_probabilities[unit] = p.copy()
    checks['all_reused_mask_readout_thresholds_probabilities_classes_and_IoUs'] = bool(control_ok) and control_error < 2e-7
    checks['all_new_checkpoint_file_SHA256'] = len(result['checkpoint_hashes']) == len(rows) and all(sha(folder / 'models' / name) == value for name, value in result['checkpoint_hashes'].items())
    states = {}; source_ok = True; probe_state = None
    for ref in refs:
        for file_key, hash_key in [('checkpoint_file', 'checkpoint_sha256'), ('control_result_file', 'control_result_sha256'), ('source_audit_file', 'source_audit_sha256'), ('config_snapshot_file', 'config_snapshot_sha256')]:
            source_ok &= sha(REPO / ref[file_key]) == ref[hash_key]
        unit = ref['source_lr'], ref['budget'], ref['seed']; state = torch.load(REPO / ref['checkpoint_file'], map_location='cpu', weights_only=True)['model']; states[unit] = state
        source_ok &= digest(state) == ref['backbone_state_sha256'] and sum(v.numel() for v in state.values()) == 10681
        if probe_state is None and ref['source_lr'] == 'high_lr':
            old_path = REPO / ref['control_result_file']; old_result = json.loads(old_path.read_text()); path = old_path.parent / 'models/base_b18_s5501.pt'
            source_ok &= sha(path) == old_result['checkpoint_hashes'][path.name]; probe_state = torch.load(path, map_location='cpu', weights_only=True)['model']
    checks['all_frozen_source_CNN_provenance_and_no_new_encoder_weights'] = bool(source_ok)
    model_module = load_module('class_readout_audit_model', ROOT / 'model.py')
    ids = np.concatenate((subsets['dense_indices']['18'], np.flatnonzero(data['role'] == 'weak')))[:2]
    probe_checks, probe_errors = audit_probe(config, model_module, probe_state, torch.tensor(5 * (data['X'][ids] - .2)), truth, target)
    checks.update(probe_checks)
    rounding_ok, rounding_evidence = audit_rounding_capture()
    checks['failed_cross_batch_assertion_direct_MPS_capsule_and_CPU_float64_proof'] = rounding_ok
    metadata_ok = frozen_ok = counts_ok = initial_ok = batches_ok = cache_ok = classes_ok = mask_ok = covariance_ok = directional_ok = anchor_ok = True
    errors = dict(class_probability=0., view_logits=0., log_probability=0., log_probability_relative=0., canonical_probability=0., metrics=0., context=0., conductance=0.,
                  visual_context=0., source_features=0., frozen_mask_probability=0., frozen_mask_IoU=0., covariance=0., control_metrics=control_error,
                  anchor_probability=0., anchor_log_probability_relative=0., anchor_float64_probability=0., anchor_float64_log_probability_relative=0., anchored_score_equation=0., threshold_forward=0.)
    recomputed = []; anchor_comparisons = []
    initial_diagnostics = read('INITIAL_PRIOR_DIAGNOSTICS.json')
    anchor_ok &= initial_diagnostics == result['initial_prior_diagnostics'] and len(initial_diagnostics) == len(refs)
    for ref in refs:
        unit = ref['source_lr'], ref['budget'], ref['seed']; family, budget, seed = unit; state = states[unit]
        cache = reference_cache(images, state)
        soft_row = next(row for row in controls if (row['source_lr'], row['budget'], row['seed'], row['arm']) == (*unit, 'fixed_softordinal'))
        with np.load(folder / 'control_probs' / f'{family}_b{budget}_s{seed}_fixed_softordinal.npz', allow_pickle=False) as archive:
            soft = {key: archive[key] for key in archive.files}
        g = soft['conductance']; bins = (g >= G0).astype(np.int64) + (g >= .5).astype(np.int64); soft_pred = 3 * bins[:, 0] + bins[:, 1]
        errors['conductance'] = max(errors['conductance'], float(np.max(np.abs(cache['conductance'] - g))))
        mask_ok &= (np.array_equal(soft['truth'], truth) and np.array_equal(soft['prediction'], soft_pred) and np.array_equal(soft['probability'], np.eye(9, dtype=np.float32)[soft_pred]) and
            np.array_equal(soft['uniform_probability'], old_probabilities[unit]) and soft_row['g0'] == G0 and soft_row['upper_threshold'] == .5 and soft_row['threshold_rule'] == 'inclusive>=')
        soft_value = macro_f1(truth, soft_pred); errors['control_metrics'] = max(errors['control_metrics'], abs(soft_value - soft_row['class_F1']))
        control_recomputed.append(dict(source_lr=family, budget=budget, seed=seed, arm='fixed_softordinal', class_F1=soft_value))
        with np.load(folder / 'control_probs' / f'{family}_b{budget}_s{seed}_initial_anchor.npz', allow_pickle=False) as archive:
            prior = {key: archive[key] for key in archive.files}
        physical = torch.tensor(soft['physical_context']); a = 4 * physical
        pair = a.reshape(4, len(truth), 2, 2)
        score = torch.stack((torch.zeros_like(pair[..., 0]), pair[..., 0], pair[..., 0] + pair[..., 1]), -1)
        directional = score.log_softmax(-1)
        joint = (directional[:, :, 0, :, None] + directional[:, :, 1, None, :]).reshape(4, len(truth), 9)
        aligned_prior = torch.stack([p[:, CLASS_SWAP] if k % 2 else p for k, p in enumerate(joint)])
        log_prior = torch.logsumexp(aligned_prior, 0) - np.log(4.)
        errors['anchor_probability'] = max(errors['anchor_probability'], float(np.max(np.abs(log_prior.exp().numpy() - prior['probability']))))
        errors['anchor_log_probability_relative'] = max(errors['anchor_log_probability_relative'], float(np.max(np.abs(log_prior.numpy() - prior['log_probability']) / np.maximum(1., np.abs(prior['log_probability'])))))
        pair64 = a.double().reshape(4, len(truth), 2, 2)
        score64 = torch.stack((torch.zeros_like(pair64[..., 0]), pair64[..., 0], pair64[..., 0] + pair64[..., 1]), -1)
        direction64 = score64.log_softmax(-1)
        joint64 = (direction64[:, :, 0, :, None] + direction64[:, :, 1, None, :]).reshape(4, len(truth), 9)
        aligned64 = torch.stack([p[:, CLASS_SWAP] if k % 2 else p for k, p in enumerate(joint64)])
        log64 = torch.logsumexp(aligned64, 0) - np.log(4.)
        errors['anchor_float64_probability'] = max(errors['anchor_float64_probability'], float(np.max(np.abs(log64.exp().numpy() - prior['probability']))))
        errors['anchor_float64_log_probability_relative'] = max(errors['anchor_float64_log_probability_relative'], float(np.max(np.abs(log64.numpy() - prior['log_probability']) / np.maximum(1., np.abs(prior['log_probability'])))))
        pred_prior = prior['probability'].argmax(1)
        exact_tie = ((torch.tensor(g) == G0) | (torch.tensor(g) == .5)).any(1).numpy()
        sorted_scores = np.sort(score[0].numpy(), axis=-1)
        near_tie = ((sorted_scores[..., -1] - sorted_scores[..., -2]) <= 1e-6).any(1)
        difference = pred_prior != soft_pred
        diagnostic = dict(examples=len(g), initial_class_difference_count=int(difference.sum()),
            exact_conductance_tie_examples=int(exact_tie.sum()), score_or_rounding_tie_examples=int(near_tie.sum()),
            differences_at_exact_conductance_ties=int((difference & exact_tie).sum()),
            differences_at_score_or_rounding_ties=int((difference & near_tie).sum()),
            non_tie_class_parity=bool(np.all(~difference | near_tie)), score_tie_diagnostic_tolerance=1e-6,
            head_tie_rule='ordinaryargmax choosesfirstclass', fixed_rule='g>=g0 andg>=.5 remainsinclusive')
        reported_diagnostic = next(item for item in initial_diagnostics if (item['source_lr'], item['budget'], item['seed']) == unit)
        anchor_ok &= (reported_diagnostic == dict(source_lr=family, budget=budget, seed=seed, **diagnostic) and
            np.array_equal(prior['prediction'], pred_prior) and np.array_equal(prior['fixed_prediction'], soft_pred) and
            np.array_equal(prior['exact_tie'], exact_tie) and np.array_equal(prior['score_or_rounding_tie'], near_tie) and
            np.array_equal(prior['directional_logits'], score.numpy()) and np.array_equal(prior['prior_threshold_logits'], a.numpy()) and
            diagnostic['non_tie_class_parity'] and np.array_equal(log_prior.exp().numpy().argmax(1)[~near_tie], pred_prior[~near_tie]))
        anchor_comparisons.append(dict(source_lr=family, budget=budget, seed=seed, anchor_class_F1=macro_f1(truth, pred_prior),
            fixed_softordinal_class_F1=soft_value, **diagnostic))
        for arm in ARMS:
            row = next(item for item in rows if (item['source_lr'], item['budget'], item['seed'], item['arm']) == (*unit, arm))
            stem = f'{family}_b{budget}_s{seed}_{arm}'; payload = torch.load(folder / 'models' / f'{stem}.pt', map_location='cpu', weights_only=True); weights = payload['model']
            backbone = {key[9:]: value for key, value in weights.items() if key.startswith('backbone.')}; head = {key[5:]: value for key, value in weights.items() if key.startswith('head.')}
            head_count = 8 if arm == 'calibrator' else (292 if arm == 'physics_mlp' else 5372)
            metadata_ok &= (payload['settings'] == row and row['source'] == ref and row['steps'] == row['optimizer_updates'] == 1000 and row['fit_count'] == 1 and
                row['trainable_parameters'] == head_count and row['learning_rate'] == .001 and row['weight_decay'] == .0001 and row['head_seed'] == seed + 200003 and
                row['initial_anchor_probability_bit_exact'] and row['initial_anchor_diagnostics'] == diagnostic and
                row['training_masks_used'] is False and row['training_examples'] == budget + 1152 and row['training_class_counts'] == [128 + budget // 9] * 9)
            counts_ok &= (row['parameters'] == dict(backbone=10681, head=head_count, trainable=head_count, total=10681 + head_count) and
                sum(v.numel() for v in head.values()) == head_count and sum(v.numel() for v in weights.values()) == 10681 + head_count and
                all(torch.isfinite(v).all().item() for v in weights.values()))
            frozen_ok &= row['backbone_before_sha256'] == row['backbone_after_sha256'] == ref['backbone_state_sha256'] == digest(backbone) and all(torch.equal(v, state[key]) for key, v in backbone.items())
            initial = model_module.make_model(arm, state, head_seed=seed + 200003)
            initial_ok &= digest(initial.head.state_dict()) == row['head_initial_sha256'] and digest(head) == row['head_final_sha256'] != row['head_initial_sha256']
            batches_ok &= row['batch_sequence_sha256'] == training_batches(budget, seed)
            meta = row['cache']; train_ids = np.concatenate((subsets['dense_indices'][str(budget)], np.flatnonzero(data['role'] == 'weak'))).tolist()
            cache_ok &= (meta['ephemeral'] and not meta['persisted'] and meta['image_only'] and meta['context_label_free'] and meta['bytes'] <= meta['maximum_bytes'] == 120 * 1024 ** 2 and
                meta['source_state_sha256'] == ref['backbone_state_sha256'] and meta['indices'] == dict(train=train_ids, val=val.tolist()))
            with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
                saved = {key: archive[key] for key in archive.files}
            metadata_ok &= (saved['probability'].shape == (695, 9) and saved['per_view_logits'].shape == (4, 695, 6) and np.isfinite(saved['probability']).all() and
                np.array_equal(saved['truth'], truth) and saved['probability'].min() >= 0 and saved['probability'].max() <= 1 and
                float(np.max(np.abs(saved['probability'].sum(1) - 1))) < 1e-6)
            with torch.inference_mode(): output = reference_head(cache, arm, head)
            errors['class_probability'] = max(errors['class_probability'], float(np.max(np.abs(output['probability'].numpy() - saved['probability']))))
            errors['view_logits'] = max(errors['view_logits'], float(np.max(np.abs(output['per_view_logits'].numpy() - saved['per_view_logits']))))
            direction_logits = torch.tensor(saved['per_view_logits']).reshape(4, 695, 2, 3)
            direction_log_probability = direction_logits.log_softmax(-1)
            directional_ok &= np.array_equal(direction_logits.numpy(), saved['directional_logits']) and saved['directional_log_probability'].shape == (4, 695, 2, 3)
            prior_b = saved['prior_threshold_logits']; delta_b = saved['threshold_corrections']; corrected_b = saved['corrected_threshold_logits']
            pair_b = corrected_b.reshape(4, 695, 2, 2)
            score_b = np.stack((np.zeros_like(pair_b[..., 0]), pair_b[..., 0], pair_b[..., 0] + pair_b[..., 1]), -1)
            errors['anchored_score_equation'] = max(errors['anchored_score_equation'], float(np.max(np.abs(corrected_b - (prior_b + delta_b)))),
                float(np.max(np.abs(score_b - saved['directional_logits']))))
            anchor_ok &= np.array_equal(prior_b, a.numpy())
            errors['threshold_forward'] = max(errors['threshold_forward'], float(np.max(np.abs(output['corrected_threshold_logits'].numpy() - corrected_b))))
            log_views = (direction_log_probability[:, :, 0, :, None] + direction_log_probability[:, :, 1, None, :]).reshape(4, 695, 9)
            aligned = torch.stack([p[:, CLASS_SWAP] if k % 2 else p for k, p in enumerate(log_views)])
            log_probability = torch.logsumexp(aligned, 0) - np.log(4.)
            errors['log_probability'] = max(errors['log_probability'], float(np.max(np.abs(log_probability.numpy() - saved['log_probability']))),
                float(np.max(np.abs(aligned.numpy() - saved['aligned_log_probability']))))
            errors['log_probability_relative'] = max(errors['log_probability_relative'],
                float(np.max(np.abs(direction_log_probability.numpy() - saved['directional_log_probability']) / np.maximum(1., np.abs(saved['directional_log_probability'])))),
                float(np.max(np.abs(log_probability.numpy() - saved['log_probability']) / np.maximum(1., np.abs(saved['log_probability'])))),
                float(np.max(np.abs(aligned.numpy() - saved['aligned_log_probability']) / np.maximum(1., np.abs(saved['aligned_log_probability'])))))
            errors['canonical_probability'] = max(errors['canonical_probability'], float(np.max(np.abs(log_probability.exp().numpy() - saved['probability']))))
            prediction = saved['probability'].argmax(1); confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
            classes_ok &= np.array_equal(prediction, saved['prediction']) and confusion.tolist() == row['confusion']
            metric = macro_f1(truth, prediction)
            errors['metrics'] = max(errors['metrics'], abs(metric - row['class_F1']), abs(float(np.mean(prediction == truth)) - row['accuracy']),
                abs(float(np.mean(prediction != old_masks[unit])) - row['class_mask_disagreement_fraction']))
            mask_ok &= (np.array_equal(saved['frozen_mask_class'], old_masks[unit]) and np.array_equal(saved['frozen_mask_probability'], old_probabilities[unit]) and
                np.array_equal(saved['frozen_mask_probability'], soft['uniform_probability']) and row['mask_output_unchanged'] and row['frozen_mask_probability_bit_exact'] and
                row['segmentation_output'] == 'unchangeduniformC4' and row['classification_output'] == 'learned9classargmax')
            mask_control = next(item for item in old_controls if (item['source_lr'], item['budget'], item['seed'], item['arm']) == (*unit, 'uniform_frozen'))
            fixed_mask = saved['frozen_mask_probability'][:, 0] >= mask_control['mask_threshold']; iou = mean_iou(fixed_mask, target)
            errors['frozen_mask_IoU'] = max(errors['frozen_mask_IoU'], abs(iou - row['frozen_mask_IoU']), abs(iou - mask_control['frozen_mask_IoU']))
            with np.load(folder / 'fixtures' / f'{stem}.npz', allow_pickle=False) as archive:
                fixture = {key: archive[key] for key in archive.files}
            covariance_ok &= np.array_equal(fixture['x'], images[:16].numpy()) and fixture['class_swap'].tolist() == CLASS_SWAP
            restored = np.stack([p[:, CLASS_SWAP] if k % 2 else p for k, p in enumerate(fixture['transformed_probability'])])
            covariance = float(np.max(np.abs(restored - fixture['probability'][None])))
            covariance_ok &= (covariance <= 1e-6 and abs(covariance - row['class_C4_covariance_max_error']) < 1e-10 and
                np.array_equal(restored, fixture['restored_class_probability']) and np.array_equal(fixture['probability'], saved['probability'][:16]))
            errors['covariance'] = max(errors['covariance'], covariance)
            errors['source_features'] = max(errors['source_features'], float(np.max(np.abs(cache['view_features'][:, :16].numpy() - fixture['view_features']))))
            errors['conductance'] = max(errors['conductance'], float(np.max(np.abs(cache['conductance'][:16] - fixture['conductance']))))
            name = 'visual_context' if arm == 'visual_cnn' else 'physical_context'
            errors['context'] = max(errors['context'], float(np.max(np.abs(cache[name][:, :16].numpy() - fixture['context']))))
            visual = fixture['visual_context']; physical = fixture['physical_context']
            covariance_ok &= (np.max(np.abs(visual)) <= 1 and np.max(np.abs(physical)) <= 1 and
                np.array_equal(physical[1], physical[0][:, [2, 3, 0, 1]]) and np.array_equal(physical[2], physical[0]) and
                np.array_equal(physical[3], physical[1]))
            # Reconstruct context from exactly the saved source μ as a separate
            # solver check, avoiding conflating CPU/MPS encoder roundoff.
            exact_context = independent_context(fixture['uniform_probability'])
            errors['conductance'] = max(errors['conductance'], float(np.max(np.abs(exact_context['g'] - fixture['conductance']))))
            for k in range(4):
                expected_visual = exact_context['visual_context'][:, [1, 0, 2, 3]] if k % 2 else exact_context['visual_context']
                errors['visual_context'] = max(errors['visual_context'], float(np.max(np.abs(expected_visual - fixture['visual_context'][k]))))
            recomputed.append(dict(source_lr=family, budget=budget, seed=seed, arm=arm, class_F1=metric))
    checks['initial_anchor_probabilities_explicit_fixed_rule_ties_and_all_cumulative_corrections'] = bool(anchor_ok) and errors['anchor_probability'] < 8 * np.finfo(np.float32).eps and errors['anchor_log_probability_relative'] < 8 * np.finfo(np.float32).eps and errors['anchor_float64_probability'] < 8 * np.finfo(np.float32).eps and errors['anchor_float64_log_probability_relative'] < 8 * np.finfo(np.float32).eps and errors['anchored_score_equation'] < 1e-6 and errors['threshold_forward'] < 1e-3
    checks.update(all5372_292_8_counts_optimizer_metadata_and_frozen_encoder_states=bool(metadata_ok and counts_ok and frozen_ok),
        all_fresh_head_initial_and_final_digests=bool(initial_ok), all1000_uniform_class_only_batch_sequences=bool(batches_ok),
        ephemeral_image_only_context_caches_and_balanced_training_indices=bool(cache_ok),
        independent_full_rotated_CNN_MLP_calibrator_class_probability_forward=errors['class_probability'] < 1e-4 and errors['view_logits'] < 1e-3,
        stable_canonical_logmean_softmax_and_all_class_metrics=bool(classes_ok and directional_ok) and errors['log_probability_relative'] < 8 * np.finfo(np.float32).eps and errors['canonical_probability'] < 8 * np.finfo(np.float32).eps and errors['metrics'] < 2e-7,
        fixed_softordinal_is_prediction_only_and_all_control_metrics_exact=errors['control_metrics'] < 2e-7,
        exact_frozen_mask_probability_classes_IoU_and_head_mask_disagreement=bool(mask_ok) and errors['frozen_mask_IoU'] < 2e-7,
        independent_soft_conductance_visual_stats_and_odd_context_swap=bool(covariance_ok) and errors['conductance'] < 1e-5 and errors['context'] < 2e-4 and errors['visual_context'] < 1e-6 and errors['source_features'] < 1e-4)
    paired = True
    for unit in units:
        group = [row for row in rows if (row['source_lr'], row['budget'], row['seed']) == unit]
        cnn = [row for row in group if row['arm'] in ['visual_cnn', 'physics_cnn']]
        paired &= len({r['head_initial_sha256'] for r in cnn}) == 1 and len({r['batch_sequence_sha256'] for r in group}) == 1
    checks['matched_CNN_initialization_and_all_four_head_batches'] = bool(paired)
    means = {family: {str(budget): {arm: float(np.mean([row['class_F1'] for row in recomputed + control_recomputed
        if row['source_lr'] == family and row['budget'] == budget and row['arm'] == arm]))
        for arm in ARMS + ['uniform_frozen', 'uniform_adapted', 'single_adapted', 'fixed_softordinal']}
        for budget in [18, 27]} for family in ['high_lr', 'low_lr']}
    checks['all_reported_family_budget_arm_F1_means_independently_recomputed'] = numeric_compare(means, result['means']) < 2e-7
    gates = recompute_gates(recomputed, control_recomputed, config)
    stored = {key: value for key, value in result['gates'].items() if key != 'interpretation'}
    checks['strict_four_readout_A_physical_B_spatial_C_and_CNN_success_recomputed'] = numeric_compare(gates, stored) < 2e-7
    replication = {}
    if result['phase'] == 'replicate':
        aggregate = read('AGGREGATE_RESULT.json'); previous = ROOT / aggregate['source_trials'][0]
        old = json.loads((previous / 'RESULT.json').read_text()); old_audit = json.loads((previous / 'AUDIT.json').read_text())
        checks['valid_screen_and_exact_three_seed_aggregation'] = old_audit['status'] == 'PASS_AUDIT' and old_audit['result_sha256'] == sha(previous / 'RESULT.json') and old['gates']['CNN_SUCCESS'] and old['seeds'] == [5501] and aggregate['rows'] == old['rows'] + rows and aggregate['controls'] == old['controls'] + controls
        all_gates = recompute_gates(old['rows'] + recomputed, old['controls'] + control_recomputed, config)
        robust = {arm: gates['A_pipeline'][arm]['passed'] and all_gates['A_pipeline'][arm]['passed'] for arm in ARMS}
        checks['new_two_all_three_and_robust_pipeline_gates_recomputed'] = numeric_compare(all_gates, {key: value for key, value in aggregate['gates'].items() if key != 'interpretation'}) < 2e-7 and numeric_compare(gates, {key: value for key, value in aggregate['new_seed_gates'].items() if key != 'interpretation'}) < 2e-7 and aggregate['robust_pipeline_by_arm'] == robust and aggregate['robust_pipeline_pass'] == any(robust.values())
        robust_spatial = {arm: gates['C_spatial'][arm]['passed'] and all_gates['C_spatial'][arm]['passed'] for arm in ['visual_cnn', 'physics_cnn']}
        checks['robust_new_two_and_all_three_spatial_CNN_success_and_physics'] = (aggregate['robust_spatial_by_arm'] == robust_spatial and
            aggregate['robust_CNN_SUCCESS'] == any(robust_spatial.values()) and
            aggregate['robust_physics_pass'] == (gates['B_physics']['passed'] and all_gates['B_physics']['passed']))
        replication = dict(new_two_seeds=gates, all_three_seeds=all_gates)
    recovery_evidence = {}
    if 'recovery' in frozen:
        recovery_checks, recovery_evidence = audit_recovery(folder, result, frozen)
        checks.update(recovery_checks)
    checks['all_frozen_source_control_and_TRAIN_VAL_artifacts_unchanged'] = all(sha(path) == value for path, value in before.items())
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT', scope='INDEPENDENT_CPU_DIRECT_CLASS_READOUT_OLD_TRAIN_VAL_ONLY',
        trial=str(folder.relative_to(ROOT)), audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks), maximum_errors=errors,
        probe_errors=probe_errors, MPS_rounding_reproduction=rounding_evidence, recovery=recovery_evidence, initial_anchor_comparisons=anchor_comparisons, independent_gates=gates, replication=replication, seconds=time.monotonic() - started,
        numerical_tolerances=dict(log_probability_relative=8 * float(np.finfo(np.float32).eps), canonical_probability=8 * float(np.finfo(np.float32).eps), class_covariance=1e-6),
        numerical_note='Log-domain parity uses an8-float32-epsilon relative budget plus an independent probability-space check. Anchor corrections form cumulative directional scores and each joint9 distribution before C4 pooling. Exact threshold ties have explicit argmax/inclusive-rule diagnostics; no scientific thresholds are changed.',
        caveat='Classification supervision and readout changed; encoder masks/IoU did not. Old VAL only, no access to fresh C4 confirmation or novelty claim.')


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--trial', type=Path); args = parser.parse_args()
    folders = [args.trial if args.trial.is_absolute() else ROOT / args.trial] if args.trial else sorted(path.parent for path in (ROOT / 'trials').glob('*/RESULT.json'))
    assert folders, 'No completed trial'; torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        for folder in folders:
            destination = folder / 'AUDIT.json'
            if destination.exists():
                previous = json.loads(destination.read_text()); assert previous['result_sha256'] == sha(folder / 'RESULT.json')
                if previous['audit_source_sha256'] == sha(__file__): outcome = previous
                else:
                    archive = folder / f"AUDIT_PREVIOUS_{previous['audit_source_sha256'][:12]}.json"; assert not archive.exists(); destination.rename(archive); outcome = audit_trial(folder)
            else: outcome = audit_trial(folder)
            if not destination.exists(): destination.write_text(json.dumps(outcome, indent=2, ensure_ascii=False, default=lambda value: value.item()) + '\n')
            print(json.dumps({key: outcome[key] for key in ['status', 'trial', 'checks_passed', 'checks_total', 'maximum_errors', 'probe_errors', 'independent_gates', 'replication', 'seconds']}, ensure_ascii=False, default=lambda value: value.item()), flush=True)
            assert outcome['status'] == 'PASS_AUDIT'


if __name__ == '__main__': main()
