"""No-fit reproduction of the failed cross-batch initialization assertion."""
from pathlib import Path
import hashlib
import json
import math
import os

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'trials/anchored_screen_s5501_128a2db5f3/control_probs/low_lr_b18_s5501_initial_anchor.npz'
SWAP = [0, 3, 6, 1, 4, 7, 2, 5, 8]


def prediction(scores):
    lp = scores.log_softmax(-1)
    joint = (lp[:, :, 0, :, None] + lp[:, :, 1, None, :]).reshape(4, len(scores[0]), 9)
    aligned = torch.stack([v[:, SWAP] if k % 2 else v for k, v in enumerate(joint)])
    result = torch.logsumexp(aligned, 0) - math.log(4)
    return result, result.exp()


def main():
    assert torch.backends.mps.is_available()
    assert os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] == '0'
    assert not (ROOT / 'MPS_ROUNDING_CAPTURE.json').exists()
    with np.load(SOURCE) as data:
        saved = np.array(data['probability'], copy=True)
        scores = np.array(data['directional_logits'], copy=True)
    tensor = torch.tensor(scores, device='mps')
    with torch.no_grad():
        full_log, full = prediction(tensor)
        small_log, small = prediction(tensor[:, :16].contiguous())
    full = full.cpu().numpy(); small = small.cpu().numpy()
    full_log = full_log.cpu().numpy(); small_log = small_log.cpu().numpy()
    delta = float(np.max(np.abs(full[:16] - small)))
    bound = float(8 * np.finfo(np.float32).eps)
    result = dict(status='PASS_NUMERICAL_REPRODUCTION', fitted_models=0, optimizer_updates=0,
        source_file=str(SOURCE.relative_to(ROOT)), source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        device='mps', dtype='float32', full_batch=695, small_batch=16,
        input_scores_identical=True, full_reproduces_saved_probability_bit_exact=bool(np.array_equal(full, saved)),
        probability_max_abs_difference=delta,
        log_probability_max_abs_difference=float(np.max(np.abs(full_log[:16] - small_log))),
        predictions_identical=bool(np.array_equal(full[:16].argmax(-1), small.argmax(-1))),
        existing_eight_epsilon_absolute_probability_bound=bound,
        scope='Numerical diagnostic only; no training, data, algorithm or quality criterion changed.')
    assert delta <= bound and result['predictions_identical']
    np.savez_compressed(ROOT / 'MPS_ROUNDING_CAPTURE.npz', scores=scores,
        full_probability=full, small_probability=small,
        full_log_probability=full_log, small_log_probability=small_log)
    (ROOT / 'MPS_ROUNDING_CAPTURE.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
