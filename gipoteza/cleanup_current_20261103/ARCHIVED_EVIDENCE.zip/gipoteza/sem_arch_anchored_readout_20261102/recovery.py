"""Append-only recovery of eight unstarted low-lr anchored-head fits.

Original model/runner/config/protocol and every failed-trial byte are protected.
All scientific functions are imported unchanged. The only numerical correction
compares initialization with the anchor at the same16-example layout; the
full695-versus16 rounding is captured separately under the existing8eps bound.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import time
import traceback

import numpy as np
import torch
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
DEFAULT_FAILED = ROOT / "trials/anchored_screen_s5501_128a2db5f3"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


old_model = sys.modules.get("model")
sys.modules["model"] = load_module("anchored_recovery_original_model", ROOT / "model.py")
try:
    r = load_module("anchored_recovery_original_runner", ROOT / "runner.py")
finally:
    if old_model is None: del sys.modules["model"]
    else: sys.modules["model"] = old_model


def read(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value): r.save(path, value)


def inventory(folder):
    return {str(path.relative_to(ROOT)): dict(sha256=sha(path), bytes=path.stat().st_size)
            for path in sorted(folder.rglob("*")) if path.is_file()}


def row_key(row):
    return row["source_lr"], row["budget"], row["seed"], row["arm"]


def validate_failed(c, failed):
    assert failed.resolve().parent == (ROOT / "trials").resolve()
    failure, frozen = read(failed / "FAILURE.json"), read(failed / "FROZEN.json")
    assert failure["status"] == "FAILED" and failure["error_type"] == "AssertionError"
    assert "torch.equal(initialized" in failure["traceback"]
    assert not (failed / "RESULT.json").exists()
    assert frozen["signature"] == r.signature(c)
    assert frozen["source_sha256"] == r.source_hashes()
    assert read(failed / "CONFIG_SNAPSHOT.json") == c
    assert sha(failed / "PROTOCOL.md") == sha(ROOT / "PROTOCOL.md")
    assert all(sha(ROOT / name) == value for name, value in frozen["source_sha256"].items())
    rows = read(failed / "PARTIAL_RESULTS.json")
    assert len(rows) == 8 and {row_key(row) for row in rows} == {
        ("high_lr", budget, 5501, arm) for budget in c["budgets"] for arm in r.ARMS}
    hashes = read(failed / "CHECKPOINT_HASHES.json")
    inherited = []
    for row in rows:
        assert row["steps"] == row["optimizer_updates"] == 1000 and row["fit_count"] == 1
        name = f'{row["source_lr"]}_b{row["budget"]}_s{row["seed"]}_{row["arm"]}'
        artifacts = {}
        for subdir, suffix in [("models", ".pt"), ("val_probs", ".npz"), ("fixtures", ".npz")]:
            path = failed / subdir / (name + suffix)
            assert path.is_file()
            artifacts[subdir] = dict(file=str(path.relative_to(ROOT)), sha256=sha(path))
        assert artifacts["models"]["sha256"] == hashes[name + ".pt"]
        payload = torch.load(ROOT / artifacts["models"]["file"], map_location="cpu", weights_only=True)
        assert payload["settings"] == row
        weights = payload["model"]
        head = {key[len("head."):]: value for key, value in weights.items() if key.startswith("head.")}
        backbone = {key[len("backbone."):]: value for key, value in weights.items() if key.startswith("backbone.")}
        assert r.state_digest(head) == row["head_final_sha256"]
        assert r.state_digest(backbone) == row["backbone_after_sha256"] == row["backbone_before_sha256"]
        inherited.append(dict(row_key=list(row_key(row)), row_sha256=r.digest(row), artifacts=artifacts))
    capture = read(ROOT / "MPS_ROUNDING_CAPTURE.json")
    assert capture["status"] == "PASS_NUMERICAL_REPRODUCTION"
    assert capture["fitted_models"] == capture["optimizer_updates"] == 0
    assert capture["input_scores_identical"] and capture["full_reproduces_saved_probability_bit_exact"] and capture["predictions_identical"]
    assert sha(ROOT / capture["source_file"]) == capture["source_sha256"]
    assert sha(ROOT / "capture_mps_rounding.py") == capture["script_sha256"]
    assert capture["probability_max_abs_difference"] <= 8 * np.finfo(np.float32).eps
    protected = {name: sha(ROOT / name) for name in ["model.py", "runner.py", "CONFIG.json", "PROTOCOL.md",
        "MPS_ROUNDING_CAPTURE.json", "MPS_ROUNDING_CAPTURE.npz", "capture_mps_rounding.py"]}
    return rows, inherited, frozen, inventory(failed), protected


def preflight(c, failed):
    rows, inherited, frozen, files, protected = validate_failed(c, failed)
    with np.load(ROOT / "MPS_ROUNDING_CAPTURE.npz", allow_pickle=False) as z:
        probability_error = float(np.max(np.abs(z["full_probability"][:16] - z["small_probability"])))
        relative_log_error = float(np.max(np.abs(z["full_log_probability"][:16] - z["small_log_probability"])
            / np.maximum(1., np.abs(z["full_log_probability"][:16]))))
        assert probability_error <= 8 * np.finfo(np.float32).eps and relative_log_error <= 8 * np.finfo(np.float32).eps
    proof = dict(status="PASS_RECOVERY_PREFLIGHT", failed_trial=str(failed.relative_to(ROOT)),
        inherited_models=8, inherited_updates=8000, new_models_planned=8, new_updates_planned=8000,
        total_unique_models=16, total_unique_updates=16000, inherited_rows=inherited,
        failed_inventory_sha256=r.digest(files), protected_sha256=protected,
        recovery_source_sha256=sha(Path(__file__)), original_source_sha256=frozen["source_sha256"],
        existing_probability_tolerance=8 * float(np.finfo(np.float32).eps),
        captured_cross_layout_probability_error=probability_error, captured_cross_layout_relative_log_error=relative_log_error,
        scientific_functions_reused=["inputs", "controls", "cached_inputs", "fit", "evaluate", "technical_fixture", "comparisons", "anchor_diagnostics"],
        optimizer_updates=0, historical_files_modified=False)
    save(ROOT / "RECOVERY_PREFLIGHT.json", proof); print(json.dumps(proof), flush=True)


def copy_inherited(failed, trial, rows, inherited):
    for manifest in inherited:
        for subdir, artifact in manifest["artifacts"].items():
            source = ROOT / artifact["file"]; target = trial / subdir / source.name
            shutil.copy2(source, target); assert sha(target) == artifact["sha256"]
    for budget in [18, 27]:
        for ending in ["initial_anchor", "fixed_softordinal"]:
            filename = f"high_lr_b{budget}_s5501_{ending}.npz"
            shutil.copy2(failed / "control_probs" / filename, trial / "control_probs" / filename)


@torch.no_grad()
def initialization_proof(model, cache, full_prior, trial, unit, original_failed):
    small_cache = r.slice_cache(cache, slice(0, 16))
    small_prior, _ = r.anchor_diagnostics(small_cache)
    initialized = model.forward_cached(small_cache)
    assert torch.count_nonzero(initialized["threshold_corrections"]) == 0
    assert torch.equal(initialized["corrected_threshold_logits"], initialized["prior_threshold_logits"])
    assert torch.equal(initialized["directional_logits"], small_prior["directional_logits"])
    assert torch.equal(initialized["log_probability"], small_prior["log_probability"])
    assert torch.equal(initialized["probability"], small_prior["probability"])
    probability_error = float((full_prior["probability"][:16] - small_prior["probability"]).abs().max().cpu())
    relative_log_error = float(((full_prior["log_probability"][:16] - small_prior["log_probability"]).abs()
                               / full_prior["log_probability"][:16].abs().clamp_min(1)).max().cpu())
    bound = 8 * float(np.finfo(np.float32).eps)
    assert probability_error <= bound and relative_log_error <= bound
    filename = f'{unit[0]}_b{unit[1]}_s{unit[2]}_{model.arm}_initialization_layout_proof.npz'
    old_path = original_failed / "control_probs" / f'{unit[0]}_b{unit[1]}_s{unit[2]}_initial_anchor.npz'
    old_full_exact = None
    if old_path.is_file():
        with np.load(old_path, allow_pickle=False) as z:
            old_full_exact = bool(np.array_equal(z["probability"], full_prior["probability"].cpu().numpy()))
        assert old_full_exact
    arrays = dict(full695_probability=full_prior["probability"].cpu().numpy(),
        full695_log_probability=full_prior["log_probability"].cpu().numpy(),
        same16_anchor_probability=small_prior["probability"].cpu().numpy(),
        same16_anchor_log_probability=small_prior["log_probability"].cpu().numpy(),
        same16_anchor_directional_logits=small_prior["directional_logits"].cpu().numpy(),
        initialized16_probability=initialized["probability"].cpu().numpy(),
        initialized16_log_probability=initialized["log_probability"].cpu().numpy(),
        initialized16_directional_logits=initialized["directional_logits"].cpu().numpy(),
        initialized16_corrections=initialized["threshold_corrections"].cpu().numpy())
    np.savez_compressed(trial / "evidence" / filename, **arrays)
    return dict(same16_score_probability_log_probability_bit_exact=True,
        cross_layout_probability_error=probability_error, cross_layout_log_probability_relative_error=relative_log_error,
        existing_float32_eight_epsilon_bound=bound, original_failed_full695_probability_reproduced=old_full_exact,
        evidence_file="evidence/" + filename, evidence_sha256=sha(trial / "evidence" / filename))


def run(c, failed):
    assert torch.backends.mps.is_available() and r.os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] == "0"
    started = time.monotonic(); inherited_rows, inherited, old_frozen, failed_files, protected = validate_failed(c, failed)
    data, refs, states, lineage = r.inputs(c, [5501], "mps")
    base_controls, control_sources, frozen_predictions, frozen_probabilities = r.controls(c, [5501], refs)
    previous_controls = read(failed / "CONTROL_RESULTS.json")
    assert [row for row in previous_controls if row["arm"] in r.MASK_CONTROLS] == base_controls
    inherited_soft = [row for row in previous_controls if row["arm"] == "fixed_softordinal" and row["source_lr"] == "high_lr"]
    assert len(inherited_soft) == 2
    all_controls = list(base_controls) + inherited_soft
    initial_diagnostics = [row for row in read(failed / "INITIAL_PRIOR_DIAGNOSTICS.json") if row["source_lr"] == "high_lr"]
    assert len(initial_diagnostics) == 2
    trial_id = f'anchored_screen_s5501_recovery_{sha(Path(__file__))[:10]}'
    trial = ROOT / "trials" / trial_id; assert not trial.exists(), "Recovery trial is immutable; no overwrite or optimizerresume"
    for folder in [trial, trial / "models", trial / "val_probs", trial / "fixtures", trial / "source", trial / "control_probs", trial / "evidence"]:
        folder.mkdir(parents=True, exist_ok=False)
    for name in ["model.py", "runner.py", "recovery.py"]: shutil.copy2(ROOT / name, trial / "source" / name)
    shutil.copy2(ROOT / "PROTOCOL.md", trial / "PROTOCOL.md"); save(trial / "CONFIG_SNAPSHOT.json", c)
    copy_inherited(failed, trial, inherited_rows, inherited)
    original_sources = r.source_hashes(); source_hashes = dict(original_sources, **{"recovery.py": sha(Path(__file__))})
    recovery = dict(failed_trial=str(failed.relative_to(ROOT)), failed_inventory=failed_files,
        failed_inventory_sha256=r.digest(failed_files), inherited_rows=inherited,
        inherited_models=8, inherited_updates=8000, actual_new_models=8, actual_new_updates=8000,
        total_unique_models=16, total_unique_updates=16000,
        preserved_original_sha256=protected, original_source_sha256=original_sources,
        recovery_source_file="recovery.py", recovery_source_sha256=sha(Path(__file__)),
        rounding_capture_file="MPS_ROUNDING_CAPTURE.json", rounding_capture_sha256=sha(ROOT / "MPS_ROUNDING_CAPTURE.json"),
        rounding_capture_arrays_file="MPS_ROUNDING_CAPTURE.npz", rounding_capture_arrays_sha256=sha(ROOT / "MPS_ROUNDING_CAPTURE.npz"),
        numerical_only_change="compare exact zero correction, scores and probabilities using same16layout; recordcross695rounding",
        scientific_model_loss_data_batch_gates_unchanged=True)
    frozen = dict(old_frozen, source_sha256=source_hashes, sources=refs, lineage=lineage,
        config_sha256=sha(ROOT / "CONFIG.json"), control_sources=control_sources, recovery=recovery,
        fitted_models=16, total_updates=16000, evaluation_rows=16, actual_new_fitted_models=8,
        actual_new_updates=8000, inherited_fitted_models=8, inherited_updates=8000)
    save(trial / "FROZEN.json", frozen); save(trial / "RECOVERY_MANIFEST.json", recovery)
    save(trial / "REUSED_CONTROLS.json", base_controls)
    r.append_ledger(dict(status="RUNNING_RECOVERY", trial=trial_id, phase="screen", failed_trial=recovery["failed_trial"],
        signature=old_frozen["signature"], inherited_models=8, actual_new_models_planned=8))
    rows = list(inherited_rows); checkpoints = dict(read(failed / "CHECKPOINT_HASHES.json")); counter = [8000]
    row_provenance = [dict(row_key=list(row_key(row)), origin="inherited_completed_fit", source_trial=recovery["failed_trial"],
                           source_row_sha256=r.digest(row)) for row in inherited_rows]
    save(trial / "PARTIAL_RESULTS.json", rows); save(trial / "CHECKPOINT_HASHES.json", checkpoints)
    r.START = started
    layout_proofs = []
    try:
        for ref in refs:
            if ref["source_lr"] != "low_lr": continue
            unit = ref["source_lr"], ref["budget"], ref["seed"]; values = data[ref["budget"]]
            builder = r.make(c, "visual_cnn", states[unit], ref["seed"], "mps")
            cache, cache_meta = r.cached_inputs(builder, values, ref); del builder
            assert np.array_equal(cache["val"]["uniform_probability"].cpu().numpy(), frozen_probabilities[unit])
            initial_prior, initial_diagnostic = r.anchor_diagnostics(cache["val"])
            initial_diagnostics.append(dict(source_lr=unit[0], budget=unit[1], seed=unit[2], **initial_diagnostic))
            np.savez_compressed(trial / "control_probs" / f'{unit[0]}_b{unit[1]}_s{unit[2]}_initial_anchor.npz',
                **{key: value.detach().cpu().numpy() for key, value in initial_prior.items()})
            save(trial / "INITIAL_PRIOR_DIAGNOSTICS.json", initial_diagnostics)
            truth = values["val"]["label"].cpu().numpy(); g = cache["val"]["conductance"].cpu().numpy()
            bins = (g >= r.G0).astype(np.int64) + (g >= .5).astype(np.int64); soft_prediction = 3 * bins[:, 0] + bins[:, 1]
            uniform = next(row for row in base_controls if (row["source_lr"], row["budget"], row["seed"], row["arm"]) == (*unit, "uniform_frozen"))
            threshold = uniform["mask_threshold"]; mask = cache["val"]["uniform_probability"][:, 0].cpu().numpy() >= threshold
            target = values["val"]["mask"][:, 0].cpu().numpy().astype(bool); union = (mask | target).sum((1, 2))
            iou = float(np.divide((mask & target).sum((1, 2)), union, out=np.ones(len(mask)), where=union > 0).mean())
            assert abs(iou - uniform["frozen_mask_IoU"]) < 2e-7 and np.array_equal(r.orbit.hard_classes(mask), frozen_predictions[unit])
            all_controls.append(dict(source_lr=unit[0], budget=unit[1], seed=unit[2], arm="fixed_softordinal",
                **r.class_metrics(truth, soft_prediction), prediction_pipeline="fixed_positive_softconductance_bins", source=ref,
                g0=r.G0, upper_threshold=.5, threshold_rule="inclusive>=", fit_count=0, optimizer_updates=0,
                frozen_mask_IoU=iou, mask_output_unchanged=True))
            np.savez_compressed(trial / "control_probs" / f'{unit[0]}_b{unit[1]}_s{unit[2]}_fixed_softordinal.npz',
                probability=np.eye(9, dtype=np.float32)[soft_prediction], prediction=soft_prediction, truth=truth, conductance=g,
                physical_context=cache["val"]["physical_context"].cpu().numpy(), uniform_probability=cache["val"]["uniform_probability"].cpu().numpy())
            paired = []
            for arm in r.ARMS:
                net = r.make(c, arm, states[unit], ref["seed"], "mps")
                layout = initialization_proof(net, cache["val"], initial_prior, trial, unit, failed)
                layout_proofs.append(dict(source_lr=unit[0], budget=unit[1], seed=unit[2], arm=arm, **layout))
                timing = r.fit(c, net, values["train"], cache["train"], ref, trial, counter)
                evaluation, arrays = r.evaluate(net, values["val"], cache["val"], frozen_predictions[unit])
                fixture, technical = r.technical_fixture(c, net, values["val"]["x"][:16], r.slice_cache(cache["val"], slice(0, 16)))
                row = dict(source_lr=unit[0], budget=unit[1], seed=unit[2], arm=arm, source=ref, **timing, **evaluation, **technical,
                    parameters=net.parameter_counts(), cache=cache_meta, frozen_mask_IoU=iou, mask_output_unchanged=True,
                    frozen_mask_probability_bit_exact=True, initial_anchor_probability_bit_exact=True,
                    initial_anchor_comparison_layout="same16", initial_anchor_layout_proof=layout,
                    initial_anchor_diagnostics=initial_diagnostic, CNN_passes_per_image=4,
                    segmentation_output="unchangeduniformC4", classification_output="learned9classargmax")
                name = f'{unit[0]}_b{unit[1]}_s{unit[2]}_{arm}'; path = trial / "models" / f"{name}.pt"; temp = path.with_suffix(".pt.partial")
                torch.save(dict(model={key: value.detach().cpu() for key, value in net.state_dict().items()}, settings=row), temp); temp.replace(path)
                checkpoints[path.name] = sha(path); np.savez_compressed(trial / "val_probs" / f"{name}.npz", **arrays)
                np.savez_compressed(trial / "fixtures" / f"{name}.npz", **fixture)
                rows.append(row); paired.append(row)
                row_provenance.append(dict(row_key=list(row_key(row)), origin="new_low_lr_fit", source_trial=str(trial.relative_to(ROOT)),
                                           source_row_sha256=r.digest(row)))
                save(trial / "PARTIAL_RESULTS.json", rows); save(trial / "CHECKPOINT_HASHES.json", checkpoints)
                save(trial / "RECOVERY_PROGRESS.json", dict(inherited_fits=8, completed_new_fits=len(rows) - 8,
                    inherited_updates=8000, actual_new_updates=counter[0] - 8000, total_unique_updates=counter[0]))
                del net
            assert len({row["batch_sequence_sha256"] for row in paired}) == 1
            assert paired[0]["head_initial_sha256"] == paired[1]["head_initial_sha256"]
            save(trial / "CONTROL_RESULTS.json", all_controls); del cache
        assert len(rows) == 16 and counter[0] == 16000 and len(checkpoints) == 16
        assert len({row_key(row) for row in rows}) == 16
        assert inventory(failed) == failed_files
        assert all(sha(ROOT / name) == value for name, value in protected.items())
        assert all(sha(ROOT / name) == value for name, value in source_hashes.items())
        for manifest in inherited:
            for subdir, artifact in manifest["artifacts"].items():
                assert sha(trial / subdir / Path(artifact["file"]).name) == artifact["sha256"]
        gates, means = r.comparisons(rows, all_controls, c)
        proof = dict(status="PASS_APPEND_ONLY_RECOVERY_PROOF", failed_trial_inventory_unchanged=True,
            all_original_source_config_protocol_and_capture_hashes_unchanged=True, all8inherited_artifacts_byte_exact=True,
            high_lr_fits_reexecuted=0, actual_new_fits=8, actual_new_updates=8000, inherited_fits=8, inherited_updates=8000,
            total_unique_models=16, total_unique_updates=16000, row_provenance=row_provenance,
            initialization_layout_proofs=layout_proofs, numerical_change_only=True,
            original_model_loss_data_optimizer_batches_gates_reused=True)
        save(trial / "RECOVERY_PROOF.json", proof)
        result = dict(status="COMPLETE_CLASSIFICATION_DEVELOPMENT", candidate=c["candidate"], phase="screen", seeds=[5501],
            signature=old_frozen["signature"], rows=rows, controls=all_controls, control_sources=control_sources,
            gates=gates, means=means, fitted_models=16, total_unique_models=16, updates=16000, evaluation_rows=16,
            actual_new_fits=8, actual_new_updates=8000, inherited_fits=8, inherited_updates=8000,
            row_provenance=row_provenance, reused_mask_control_rows=len(base_controls), fixed_softordinal_rows=4,
            checkpoint_hashes=checkpoints, frozen_sha256=sha(trial / "FROZEN.json"), seconds=time.monotonic() - started,
            initial_prior_diagnostics=initial_diagnostics, recovery=recovery,
            recovery_proof_sha256=sha(trial / "RECOVERY_PROOF.json"),
            scope="Append-only numerical recovery;8originalhighLRfits plus8newlowLRfits;scientificmodelandgatesunchanged")
        save(trial / "RESULT.json", result)
        summary = dict(status=result["status"], trial=str(trial.relative_to(ROOT)), phase="screen", result_sha256=sha(trial / "RESULT.json"),
            gates=gates, means=means, actual_new_fits=8, inherited_fits=8, total_unique_models=16)
        r.append_ledger(summary); save(ROOT / "LATEST_RESULT.json", summary); print(json.dumps(summary), flush=True)
    except BaseException as error:
        failure = dict(status="FAILED_RECOVERY", trial=trial_id, error=str(error), error_type=type(error).__name__, traceback=traceback.format_exc())
        save(trial / "FAILURE.json", failure); r.append_ledger(failure); raise


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--failed-trial", type=Path, default=DEFAULT_FAILED)
    parser.add_argument("--preflight", action="store_true"); args = parser.parse_args()
    c = r.configuration(ROOT / "CONFIG.json"); torch.set_num_threads(2)
    if args.preflight: preflight(c, args.failed_trial)
    else: run(c, args.failed_trial)


if __name__ == "__main__":
    with threadpool_limits(limits=2): main()
