"""Report anchored class corrections and separate CNN success from calibration."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PRIOR = ROOT.parent / "sem_arch_directional_readout_20261102"
HELPER = ROOT.parent / "sem_arch_joint_adaptation_20261102" / "report.py"
spec = importlib.util.spec_from_file_location("anchored_report_helpers", HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
read, sha, rel = helpers.read, helpers.sha, helpers.rel
discover, actual_rows, views = helpers.discover, helpers.actual_rows, helpers.views
pct, pp, passed = helpers.percent, helpers.pp, helpers.passed
plt, np = helpers.plt, helpers.np
ARMS = ["visual_cnn", "physics_cnn", "physics_mlp", "calibrator"]
CNNS = ["visual_cnn", "physics_cnn"]
SIZES = dict(visual_cnn=5372, physics_cnn=5372, physics_mlp=292, calibrator=8)
CONTROLS = ["uniform_frozen", "uniform_adapted", "single_adapted", "fixed_softordinal"]
FAMILIES = ["high_lr", "low_lr"]
COLORS = dict(visual_cnn="#3c78a8", physics_cnn="#b25a43", physics_mlp="#4d8d63", calibrator="#8d6cab")


def row_key(row):
    return row["source_lr"], row["budget"], row["seed"], row["arm"]


def digest(row):
    return hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest()


def distinct_executions(trials):
    """Count an inherited fit at its original trial, preserving every run."""
    executions = {}; records = 0; inherited_references = 0
    for trial in trials:
        rows = trial["result"]["rows"] if trial["result"] else trial["partial"]
        provenance = {tuple(item["row_key"]): item for item in (trial["result"] or {}).get("row_provenance", [])}
        recovery = trial["frozen"].get("recovery", {})
        inherited = {tuple(item["row_key"]): item for item in recovery.get("inherited_rows", [])}
        if provenance:
            assert len(provenance) == len(rows)
        for row in rows:
            records += 1;k = row_key(row);origin = trial["path"]
            if k in provenance:
                record = provenance[k]
                assert digest(row) == record["source_row_sha256"]
                origin = (ROOT / record["source_trial"]).resolve()
            elif k in inherited:
                assert digest(row) == inherited[k]["row_sha256"]
                origin = (ROOT / recovery["failed_trial"]).resolve()
            assert origin.is_relative_to(ROOT / "trials")
            if origin != trial["path"]:
                inherited_references += 1
                original = read(origin / "RESULT.json")
                original_rows = original["rows"] if original else read(origin / "PARTIAL_RESULTS.json", [])
                matches = [item for item in original_rows if row_key(item) == k]
                assert len(matches) == 1 and matches[0] == row
            execution = (str(origin), k)
            if execution in executions:
                assert executions[execution] == row
            else:
                executions[execution] = row
    return executions, records, inherited_references


def avg(rows, arm, field="class_F1"):
    return float(np.mean([row[field] for row in rows if row["arm"] == arm]))


def verify(result):
    units = {(row["source_lr"], row["budget"], row["seed"]) for row in result["rows"]}
    rows = {(row["source_lr"], row["budget"], row["seed"], row["arm"]): row for row in result["rows"]}
    controls = {(row["source_lr"], row["budget"], row["seed"], row["arm"]): row for row in result["controls"]}
    assert len(rows) == len(result["rows"]) == 4 * len(units)
    assert len(controls) == len(result["controls"]) == 4 * len(units)
    for key in units:
        heads = [rows[key + (arm,)] for arm in ARMS];old = [controls[key + (arm,)] for arm in CONTROLS]
        source = heads[0]["source"]
        assert all(row["source"] == source for row in heads + old)
        assert len({row["batch_sequence_sha256"] for row in heads}) == 1
        assert heads[0]["head_initial_sha256"] == heads[1]["head_initial_sha256"]
        assert all(row["initial_anchor_diagnostics"] == heads[0]["initial_anchor_diagnostics"] for row in heads)
        assert len({row["frozen_mask_IoU"] for row in heads}) == 1
        for row in heads:
            assert row["fit_count"] == 1 and row["steps"] == row["optimizer_updates"] == 1000
            assert row["trainable_parameters"] == row["parameters"]["trainable"] == SIZES[row["arm"]]
            assert row["parameters"]["total"] == 10681 + SIZES[row["arm"]]
            assert row["backbone_before_sha256"] == row["backbone_after_sha256"] == source["backbone_state_sha256"]
            assert row["head_initial_sha256"] != row["head_final_sha256"]
            assert row["training_masks_used"] is False and sum(row["training_class_counts"]) == row["training_examples"]
            assert row["mask_output_unchanged"] and row["frozen_mask_probability_bit_exact"]
            assert row["initial_anchor_probability_bit_exact"] and row["no_class_threshold"]
            assert row["prediction_pipeline"] == "direct_learned_class_probability_argmax"
            assert abs(row["frozen_mask_IoU"] - controls[key + ("uniform_frozen",)]["frozen_mask_IoU"]) < 2e-7
        for row in old:
            if row["arm"] == "fixed_softordinal":
                assert row["fit_count"] == row["optimizer_updates"] == 0
            else:
                assert row["reused"] is True
                for name, path in row["control_ref"].items():
                    if name.endswith("_file"):
                        assert sha(REPO / path) == row["control_ref"][name[:-5] + "_sha256"]


def figure(result_views):
    if not result_views:
        return None
    path = ROOT / "figures" / "anchored_classification.png"
    path.parent.mkdir(exist_ok=True)
    points = [(label, family, result) for label, result in result_views for family in FAMILIES]
    x = np.arange(len(points));fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    for offset, arm in zip([-.24, -.08, .08, .24], ARMS):
        values = [100 * avg([row for row in result["rows"] if row["source_lr"] == family], arm) for _, family, result in points]
        axes[0, 0].bar(x + offset, values, .15, label=arm, color=COLORS[arm])
        gains = [100 * min(result["gates"]["A_pipeline"][arm]["by_source_lr"][family][f"vs_{control}"]["delta"] for control in CONTROLS)
                 for _, family, result in points]
        axes[0, 1].scatter(x + offset, gains, color=COLORS[arm], label=arm, s=45)
    axes[0, 0].set_ylim(0, 100);axes[0, 0].set_ylabel("Classification Macro-F1, %")
    axes[0, 0].set_title("All four heads share the same physical anchor")
    axes[0, 0].legend(fontsize=8, loc="lower left")
    axes[0, 1].set_title("A_pipeline: smallest mean gain over four fixed readouts")
    axes[0, 1].set_ylabel("Classification F1 gain, percentage points")
    axes[0, 1].legend(fontsize=8)
    for offset, cnn, control, marker in [(-.24, "visual_cnn", "physics_mlp", "o"),
                                        (-.08, "visual_cnn", "calibrator", "x"),
                                        (.08, "physics_cnn", "physics_mlp", "o"),
                                        (.24, "physics_cnn", "calibrator", "x")]:
        values = [100 * result["gates"]["C_spatial"][cnn]["by_source_lr"][family][f"vs_{control}"]["delta"]
                  for _, family, result in points]
        axes[1, 0].scatter(x + offset, values, color=COLORS[cnn], marker=marker, s=45, label=f"{cnn} − {control}")
    axes[1, 0].set_title("C_spatial requires A and gains over both learned controls")
    axes[1, 0].set_ylabel("Classification F1 difference, percentage points")
    axes[1, 0].legend(fontsize=8)
    bvalues = [100 * result["gates"]["B_physics"]["by_source_lr"][family]["delta"] for _, family, result in points]
    axes[1, 1].scatter(x, bvalues, color=COLORS["physics_cnn"], s=50)
    axes[1, 1].set_title("B: additional physical versus visual conditioning")
    axes[1, 1].set_ylabel("Physics CNN − visual CNN, percentage points")
    for axis in axes.flat:
        axis.set_xticks(x, [f"{label}\n{family}" for label, family, _ in points]);axis.set_xlim(-.6, len(points) - .4)
    for axis in [axes[0, 1], axes[1, 0], axes[1, 1]]:
        axis.axhline(0, color="black", lw=.8);axis.axhline(.5, color="gray", ls="--", lw=.8)
    fig.suptitle("Anchored class corrections on reused VAL; segmentation remains unchanged", fontsize=11)
    fig.tight_layout();fig.savefig(path, dpi=180, bbox_inches="tight");plt.close(fig)
    return path


def build():
    config = read(ROOT / "CONFIG.json");trials = discover(ROOT)
    complete = [trial for trial in trials if trial["result"]];failures = [trial for trial in trials if trial["failure"]]
    pending = [trial for trial in trials if not trial["result"] and not trial["failure"]]
    execution_rows, row_records, inherited_references = distinct_executions(trials)
    rows = list(execution_rows.values())
    fits = sum(row["fit_count"] for row in rows);updates = sum(row["optimizer_updates"] for row in rows)
    prior_manifest = read(PRIOR / "REPORT_MANIFEST.json");prior_fits = prior_manifest["linked_stage_unique_completed_fits"]
    known = {(PRIOR / path).resolve() for path in prior_manifest["scientific_inputs_sha256"] if path.endswith(".pt")}
    referenced = {(REPO / row["control_ref"]["checkpoint_file"]).resolve() for trial in complete for row in trial["result"]["controls"]
                  if "control_ref" in row and "checkpoint_file" in row["control_ref"]}
    extras = referenced - known;unique_fits = prior_fits + fits + len(extras)
    result_views = [("screen" if result.get("phase") == "screen" else label, result) for label, result in views(trials)]
    for trial in complete:
        assert trial["result"]["frozen_sha256"] == sha(trial["path"] / "FROZEN.json")
        assert not trial["frozen"]["masks_used_for_head_training"] and not trial["frozen"]["fresh_confirmation_access"]
        verify(trial["result"])
        if trial["result"].get("recovery"):
            result = trial["result"]
            assert result["recovery_proof_sha256"] == sha(trial["path"] / "RECOVERY_PROOF.json")
            assert result["actual_new_fits"] + result["inherited_fits"] == result["total_unique_models"] == 16
            assert result["actual_new_updates"] + result["inherited_updates"] == result["updates"] == 16000
        if trial["aggregate"]:
            verify(trial["aggregate"])
    image = figure(result_views)
    text = ["# Обучаемая CNN-поправка к общему физическому readout", "",
            "У всех четырёх вариантов один физический anchor `a=4·tanh(old_ordinal_logits/4)`. "
            "CNN/MLP предсказывают четыре поправки `δ`, итог `b=a+δ`. Для каждого направления "
            "три score равны `[0,b0,b0+b1]`. Их softmax дают совместное внешнее произведение внутри вида; "
            "после LR/TB-перестановки при нечётном повороте усредняются четыре распределения. "
            "Итоговая каноническая смесь не обязана факторизоваться. Класс — argmax9.", "",
            "Visual_cnn и physics_cnn имеют по **5 372** обучаемых параметра, всего 16 053 с замороженной "
            "CNN 10 681. Обе головы используют Conv3×3(26→16), FiLM от четырёх скаляров, "
            "Conv3×3(16→8), AvgPool3×3 и Linear(72→4). Последний слой нулевой. "
            "Physics_mlp: Linear(4→32), GELU, Linear(32→4), **292** параметра, всего 10 973. "
            "Calibrator: `b=exp(u)·a+v`, **8** параметров, всего 10 689; `u=v=0` при старте. "
            "Все варианты начинают с одного точно заданного soft-prior.", "",
            "**Общий anchor физический и у visual_cnn.** Поэтому B сравнивает дополнительное "
            "физическое FiLM-conditioning с визуальными статистиками поверх общего anchor. "
            "Это не абляция наличия всей физики. MLP и calibrator — обученные непространственные "
            "контроли того же anchor. C_spatial проверяет добавочную пользу CNN относительно обоих; "
            "число параметров и доступ к пространственным признакам при этом различаются.", "",
            "## Общий надзор и независимые критерии", "",
            "Все четыре readout обучаются обычной CE итоговых девяти канонических вероятностей: "
            "1 000 шагов AdamW, lr=0,001, weight_decay=0,0001, batch32. Прежние классы доступны "
            "одинаково всем головам; TRAIN — dense18/27 и 1152 weak, 1170/1179 примеров. "
            "Пиксельные маски не входят в оптимизатор. Encoder заморожен и ранее обучен "
            "с BCE+geometry_loss. Новая исследуемая функция потерь не предлагается. "
            "C4-сегментация, маски и IoU побайтно проверяются отдельно от классового argmax.", "",
            "A_pipeline каждого readout требует среднего ΔF1 ≥0,5 п.п. и ΔF1 каждого бюджета ≥−0,25 п.п. "
            "против всех четырёх прежних readout: uniform_frozen, uniform_adapted, single_adapted, "
            "fixed_softordinal; отдельно high_lr/low_lr. A против фиксированного правила включает "
            "дополнительный классовый надзор и не является чистой атрибуцией эффекта слоя.", "",
            "B: physics_cnn против visual_cnn, с обязательным A physics_cnn. "
            "C_spatial каждой CNN требует её A и тех же приростов над **обоими** обученными "
            "physics_mlp и calibrator в обеих LR-семьях. **CNN_SUCCESS** — хотя бы одна CNN "
            "прошла C_spatial. Прохождение A только MLP или calibrator не является успехом CNN. "
            "Новые seed разрешены лишь после независимого аудита PASS и CNN_SUCCESS; "
            "на расширении нужны одновременно все три и новые два seed.", "",
            "У голов фиксированный argmax без отдельной VAL-калибровки решений; старые масочные "
            "контроли имеют пороги, выбранные по Macro-F1 на VAL. Поэтому отрицательный исход "
            "относится к этому протоколу сравнения, а не доказывает бесполезность всех возможных "
            "калибровок свободных голов. Между четырьмя обучаемыми readout CE, батчи и политика "
            "argmax общие.", "",
            f"Начато попыток {len(trials)}, завершено {len(complete)}, технических ошибок {len(failures)}, "
            f"незавершённых {len(pending)}. Новых обучений **{fits}**, обновлений {updates:,}. "
            f"Прежних обучений {prior_fits}, новых внешних контролей {len(extras)}; "
            f"уникальных обучений вместе **{unique_fits}**. Ссылки на контроли и агрегаты повторно не считаются.", ""]
    recoveries = [trial for trial in complete if trial["result"].get("recovery")]
    if recoveries:
        capture_path = ROOT / "MPS_ROUNDING_CAPTURE.json";capture = read(capture_path)
        text += ["## Сохранённая техническая остановка и восстановление", "",
                 "Первая попытка закончилась AssertionError перед первым low-LR обучением: "
                 "сравнивались вероятности полного батча695 и отдельного батча16 с требованием побайтного равенства. "
                 "Она успела сохранить 8 high-LR обучений и 8000 обновлений. "
                 "Исходная попытка, FAILURE, model.py/runner.py, веса и вероятности сохранены.", "",
                 f"[MPS_ROUNDING_CAPTURE.json](MPS_ROUNDING_CAPTURE.json): одинаковые score и воспроизведение "
                 f"полного сохранённого массива; разность probability {capture['probability_max_abs_difference']:.8g}, "
                 f"log-probability {capture['log_probability_max_abs_difference']:.8g}; argmax одинаков. "
                 "Это воспроизведённое float32-округление при разном размере батча, "
                 "а не ошибка обучения или изменение критерия качества.", ""]
        for trial in recoveries:
            result = trial["result"]
            text += [f"Восстановление [{trial['path'].name}]({rel(trial['path'] / 'RECOVERY_MANIFEST.json', ROOT)}) "
                     f"унаследовало {result['inherited_fits']} high-LR обучений по SHA и выполнило "
                     f"{result['actual_new_fits']} новых low-LR обучений. "
                     "Новый recovery.py сравнивает инициализацию при одинаковом layout16, "
                     "записывая разность с695 в прежнем бюджете8ε: абсолютном для probability "
                     "и относительном для log-probability. "
                     "Обучающие функции, данные, параметры оптимизатора, батчи и A/B/C_spatial не менялись. "
                     f"[RECOVERY_PROOF.json]({rel(trial['path'] / 'RECOVERY_PROOF.json', ROOT)}) "
                     "проверяет неизменность прежних артефактов и отсутствие повторного high-LR fit.", ""]
        text += [f"Итоговые таблицы используют полный результат16 моделей. "
                 f"Учёт включает {fits} различных выполненных обучений и {inherited_references} ссылок "
                 "на уже выполненные обучения; эти ссылки не добавляются к числу fit. "
                 "Обе записи запуска относятся к одной архитектуре и одним критериям, "
                 "восстановление не объявляется новой научной гипотезой.", ""]
    for label, result in result_views:
        gates = result["gates"]
        text += [f"## {label}: seed {result['seeds']}", "",
                 f"**CNN_SUCCESS: {passed(gates['CNN_SUCCESS'])}.** "
                 f"C_spatial visual_cnn {passed(gates['C_spatial']['visual_cnn']['passed'])}; "
                 f"physics_cnn {passed(gates['C_spatial']['physics_cnn']['passed'])}. "
                 f"B дополнительного conditioning {passed(gates['B_physics']['passed'])}.", "",
                 "| Семья | Visual CNN F1, % | Physics CNN F1, % | Physics MLP F1, % | Calibrator F1, % | A visual / physics / MLP / calib | C visual / physics |",
                 "|---|---:|---:|---:|---:|---|---|"]
        for family in FAMILIES:
            selected = [row for row in result["rows"] if row["source_lr"] == family]
            values = " | ".join(pct(avg(selected, arm)) for arm in ARMS)
            outcomes = " / ".join(passed(gates["A_pipeline"][arm]["by_source_lr"][family]["passed"]) for arm in ARMS)
            spatial = " / ".join(passed(gates["C_spatial"][arm]["by_source_lr"][family]["passed"]) for arm in CNNS)
            text.append(f"| {family} | {values} | {outcomes} | {spatial} |")
        text += ["", "| Семья | Frozen readout F1, % | C4-adapted F1, % | Single-adapted F1, % | Fixed softordinal F1, % |",
                 "|---|---:|---:|---:|---:|"]
        for family in FAMILIES:
            selected = [row for row in result["controls"] if row["source_lr"] == family]
            text.append(f"| {family} | " + " | ".join(pct(avg(selected, arm)) for arm in CONTROLS) + " |")
        text += ["", "| Семья | Голова | Неизменный IoU маски, % | Class/mask несогласие, % |", "|---|---|---:|---:|"]
        for family in FAMILIES:
            selected = [row for row in result["rows"] if row["source_lr"] == family]
            for arm in ARMS:
                text.append(f"| {family} | {arm} | {pct(avg(selected, arm, 'frozen_mask_IoU'))} | {pct(avg(selected, arm, 'class_mask_disagreement_fraction'))} |")
        text.append("")
        if result.get("phase") == "screen" and not gates["CNN_SUCCESS"]:
            text += ["Заранее заданное условие расширения CNN по seed не выполнено. "
                     "Положительный A непространственного readout, если он есть, это условие не заменяет.", ""]
    if not result_views:
        text += ["Завершённого результата пока нет; вывод о CNN_SUCCESS не сделан.", ""]
    if image:
        text += ["![Отдельные pipeline, spatial и conditioning сравнения](figures/anchored_classification.png)", "",
                 "Минимум A взят по четырём фиксированным readout. C_spatial дополнительно требует A. "
                 "Пунктир +0,5 п.п. относится к среднему приросту; бюджетные ограничения сохранены в таблицах. "
                 "Это точечные результаты многократно использованной VAL, без независимых интервалов подтверждения.", ""]
    text += ["## Инициализация anchor и равенства", "",
             "Нулевая поправка всех голов даёт один и тот же soft-prior побайтно. "
             "Его argmax не объявляется тождественным hard fixed_softordinal: прежнее правило использует "
             "`g>=g0` и `g>=0.5`, голова сохраняет обычный argmax с первым индексом при равенстве. "
             "Пороговые совпадения и score/rounding ties диагностируются отдельно. Допуск 1e−6 "
             "используется только для обозначения близкого score-tie, без смены порогов, классов или критериев.", ""]
    for trial in complete:
        result = trial["result"]
        text += [f"[INITIAL_PRIOR_DIAGNOSTICS.json]({rel(trial['path'] / 'INITIAL_PRIOR_DIAGNOSTICS.json', ROOT)}):", "",
                 "| Семья | Бюджет | Seed | Примеров | Начальных class-различий | Exact g-ties | Score/rounding ties | Проверенная parity вне ties |",
                 "|---|---:|---:|---:|---:|---:|---:|---|"]
        for item in result["initial_prior_diagnostics"]:
            text.append(f"| {item['source_lr']} | {item['budget']} | {item['seed']} | {item['examples']} | "
                        f"{item['initial_class_difference_count']} | {item['exact_conductance_tie_examples']} | "
                        f"{item['score_or_rounding_tie_examples']} | {passed(item['non_tie_class_parity'])} |")
        text.append("")
    text += ["## Все сохранённые попытки", ""]
    for trial in trials:
        path = trial["path"]
        text += [f"### {path.name}", "", f"[FROZEN.json]({rel(path / 'FROZEN.json', ROOT)}).", ""]
        if not trial["result"]:
            if trial["failure"]:
                error = trial["failure"]
                text += [f"Техническая ошибка `{error.get('error_type', 'см. файл')}`: "
                         f"{str(error.get('error', '')).replace(chr(10), ' ')}. "
                         f"[FAILURE.json]({rel(path / 'FAILURE.json', ROOT)}). Технический исход отделён от критерия качества.", ""]
            else:
                text += ["Попытка начата; итогового результата пока нет.", ""]
            text += [f"Сохранённых обучений {len(trial['partial'])}.", ""];continue
        result = trial["result"]
        execution_note = (f"в результате {result['fitted_models']} моделей: {result['inherited_fits']} унаследованы, "
                          f"{result['actual_new_fits']} обучены здесь; новых обновлений {result['actual_new_updates']:,}; "
                          if result.get("recovery") else
                          f"обучений {result['fitted_models']}, обновлений {result['updates']:,}; ")
        text += [f"`{result['status']}`; {result['phase']}; seed {result['seeds']}; "
                 f"{execution_note}"
                 f"{result['seconds']:.2f} с. [RESULT.json]({rel(path / 'RESULT.json', ROOT)}), "
                 f"SHA-256 `{sha(path / 'RESULT.json')}`.", "",
                 "| Семья | Бюджет | Seed | Голова | Параметров | Class F1, % | Accuracy, % | Неизменный IoU, % | Class/mask несогласие, % |",
                 "|---|---:|---:|---|---:|---:|---:|---:|---:|"]
        for row in result["rows"]:
            text.append(f"| {row['source_lr']} | {row['budget']} | {row['seed']} | {row['arm']} | {row['trainable_parameters']} | "
                        f"{pct(row['class_F1'])} | {pct(row['accuracy'])} | {pct(row['frozen_mask_IoU'])} | {pct(row['class_mask_disagreement_fraction'])} |")
        text.append("");gate_results = [("только эта попытка", result)]
        if trial["aggregate"]:
            gate_results.append(("все три seed", trial["aggregate"]))
            text += [f"[AGGREGATE_RESULT.json]({rel(path / 'AGGREGATE_RESULT.json', ROOT)}) объединяет "
                     "исходный скрининг и новые seed, без повторного учёта обучений.", ""]
        for label, item in gate_results:
            text += [f"**{label}: {item['seeds']}**", "",
                     "| Семья | Сравнение | ΔF1, п.п. | ΔF1 бюджеты 18 / 27, п.п. | Критерий |", "|---|---|---:|---|---|"]
            for family in FAMILIES:
                comparisons = [(f"A_pipeline {arm} − {control}", item["gates"]["A_pipeline"][arm]["by_source_lr"][family][f"vs_{control}"])
                               for arm in ARMS for control in CONTROLS]
                comparisons.append(("B дополнительного context: physics_cnn − visual_cnn, с A", item["gates"]["B_physics"]["by_source_lr"][family]))
                for cnn in CNNS:
                    comparisons += [(f"C_spatial {cnn} − {control}, с A", item["gates"]["C_spatial"][cnn]["by_source_lr"][family][f"vs_{control}"])
                                    for control in ["physics_mlp", "calibrator"]]
                for name, gate in comparisons:
                    text.append(f"| {family} | {name} | {pp(gate['delta'])} | "
                                f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
            text.append("")
        if trial["aggregate"]:
            aggregate = trial["aggregate"]
            robust = {cnn: aggregate["gates"]["C_spatial"][cnn]["passed"] and result["gates"]["C_spatial"][cnn]["passed"] for cnn in CNNS}
            text += ["Одновременно все три и новые два seed: " + "; ".join(f"C_spatial {cnn} {passed(robust[cnn])}" for cnn in CNNS) +
                     f"; robust CNN_SUCCESS {passed(any(robust.values()))}.", ""]
        audit = trial["audit"]
        text += [(f"Независимый CPU-аудит: `{audit.get('status', 'см. файл')}`, "
                  f"{audit.get('checks_passed', 'см. файл')} / {audit.get('checks_total', 'см. файл')}. "
                  f"[AUDIT.json]({rel(path / 'AUDIT.json', ROOT)})." if audit else "Итоговый аудит ещё не сохранён."), ""]
        if audit and audit.get("numerical_note"):
            text += [f"Примечание аудита: {audit['numerical_note']}", ""]
        for old_path in sorted(path.glob("AUDIT_PREVIOUS_*.json")):
            text += [f"Предыдущий аудит [{old_path.name}]({rel(old_path, ROOT)}): `{read(old_path).get('status', 'см. файл')}`. "
                     "Исходные обучения сохранены.", ""]
    text += ["## Пределы вывода", "",
             "Это старые TRAIN/VAL, без нового закрытого результата для anchored-модели. "
             "Классы производны от SVG-масок и не являются экспертной типологией дефектов или измеренным "
             "электрическим состоянием. Физический anchor вычислен из предсказания. Class-argmax может "
             "не совпасть с классом неизменной маски; классификационный прирост не является ростом сегментации. "
             "Технический PASS отделён от A/B/C_spatial и CNN_SUCCESS.", "",
             f"[Вся предыдущая серия, {prior_fits} обучений и сохранённые отрицательные исходы]({rel(PRIOR / 'REPORT.md', ROOT)}). "
             "Цепочка сохраняет исход FAIL_PILOT прежнего равномерного C4 на восьми новых полях той же ИС. "
             "Он не переопределяется как проверка новой головы. Для выбранного нового CNN потребуется "
             "отдельное закрытое подтверждение. Известные anchor/residual/C4-принципы не объявляются "
             "новым открытием; перенос между изделиями и готовность для Q1 не установлены.", "",
             "[PROTOCOL.md](PROTOCOL.md) · [CONFIG.json](CONFIG.json) · [LEDGER.json](LEDGER.json) · "
             "[model.py](model.py) · [runner.py](runner.py) · [audit.py](audit.py).", ""]
    (ROOT / "REPORT.md").write_text("\n".join(text))
    success = result_views[-1][1]["gates"]["CNN_SUCCESS"] if result_views else None
    (ROOT / "README.md").write_text(
        "# Общий физический anchor и обучаемые классовые поправки\n\n"
        "Четыре головы начинают с общего физического soft-prior. CNN5372, MLP292 и calibrator8 "
        "обучаются одной CE; маска/IoU заморожены. B проверяет дополнительное conditioning, "
        "а не наличие физики. CNN_SUCCESS требует A и победы CNN над обоими обученными непространственными контролями.\n\n"
        f"CNN_SUCCESS: **{passed(success) if success is not None else 'результата ещё нет'}**. "
        f"Завершено попыток {len(complete)}, технических ошибок {len(failures)}, новых обучений {fits}; "
        f"уникальных обучений с прежними {unique_fits}. Инициализационные ties показаны отдельно; "
        "паритет soft-prior с inclusive hard-rule без проверки не утверждается.\n\n"
        "[Отчёт](REPORT.md) · [Протокол](PROTOCOL.md) · [Конфигурация](CONFIG.json) · [Журнал](LEDGER.json). "
        "Только прежняя TRAIN/VAL; независимого подтверждения новой головы нет.\n\n"
        "```bash\n.venv/bin/python -B gipoteza/sem_arch_anchored_readout_20261102/report.py\n```\n")
    inputs = [HELPER, PRIOR / "REPORT_MANIFEST.json", PRIOR / "REPORT.md"]
    inputs += [ROOT / name for name in ["recovery.py", "RECOVERY_PREFLIGHT.json", "MPS_ROUNDING_CAPTURE.json",
               "MPS_ROUNDING_CAPTURE.npz", "capture_mps_rounding.py"] if (ROOT / name).exists()]
    inputs += [ROOT / name for name in ["CONFIG.json", "PROTOCOL.md", "LEDGER.json"] if (ROOT / name).exists()]
    for trial in trials:
        inputs += [trial["path"] / name for name in ["FROZEN.json", "RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json",
                   "PARTIAL_RESULTS.json", "AUDIT.json", "CONFIG_SNAPSHOT.json", "REUSED_CONTROLS.json", "CONTROL_RESULTS.json", "INITIAL_PRIOR_DIAGNOSTICS.json",
                   "RECOVERY_MANIFEST.json", "RECOVERY_PROOF.json"]
                   if (trial["path"] / name).exists()]
        inputs += sorted(trial["path"].glob("AUDIT_PREVIOUS_*.json"))
    for trial in complete:
        if trial["result"].get("recovery"):
            inputs += [ROOT / name for name in trial["result"]["recovery"]["failed_inventory"]]
        for row in trial["result"]["controls"]:
            if "control_ref" in row:
                inputs += [REPO / path for name, path in row["control_ref"].items() if name.endswith("_file")]
    outputs = [ROOT / "REPORT.md", ROOT / "README.md"] + ([image] if image else [])
    manifest = dict(status="REPORT_GENERATED", UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope="ADAPTIVE_OLD_TRAIN_VAL_COMMON_ANCHOR_CLASSIFICATION", report_script_sha256=sha(Path(__file__)),
        shared_report_helper_sha256=sha(HELPER), trial_count=len(trials), completed_trials=len(complete), failed_trials=len(failures),
        architecture_candidate_count=1, recovery_run_count=len(recoveries),
        pending_trials=len(pending), actual_completed_fits=fits, completed_head_updates=updates,
        prior_unique_completed_fits=prior_fits, extra_control_fits=len(extras), linked_stage_unique_completed_fits=unique_fits,
        evaluation_rows=len(rows), saved_row_records=row_records, inherited_fit_references=inherited_references,
        unique_execution_origins={f"{rel(origin, ROOT)}:{list(k)}": digest(row) for (origin, k), row in execution_rows.items()},
        CNN_SUCCESS=success, classification_output="anchored_argmax9", segmentation_unchanged=True,
        all_heads_share_physical_anchor=True, B_scope="Additional conditioning beyond common physical anchor",
        hard_rule_initial_parity_assumed=False, CNN_success_requires_MLP_and_calibrator=True,
        scientific_inputs_sha256={rel(path, ROOT): sha(path) for path in inputs}, outputs_sha256={rel(path, ROOT): sha(path) for path in outputs})
    (ROOT / "REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
