"""Independent CPU audit of the frozen-backbone TRAIN/VAL development run.

No optimization or TEST access. Recomputes normalization, cached/full forward
fixtures, all VAL scores, fixed-threshold intervention effects and lineage.
"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import sys
import time

import numpy as np
import torch
from torch import nn
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parent
G=ROOT.parent
PILOT=G/'sem_architecture_pilot_20261102'
ARMS=['plain','independent','joint','raw_joint']
VARIANTS=['actual','zero','roll']


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):return json.loads((ROOT/name).read_text())


def state_digest(state):
    h=hashlib.sha256()
    for key in sorted(state):
        v=state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode());h.update(str(v.dtype).encode());h.update(str(v.shape).encode());h.update(v.tobytes())
    return h.hexdigest()


def macro(truth,prediction):
    cm=np.bincount(9*truth+prediction,minlength=81).reshape(9,9)
    den=cm.sum(0)+cm.sum(1)
    return float(np.divide(2*np.diag(cm),den,out=np.zeros(9,dtype=float),where=den>0).mean())


def normalize_numpy(raw):
    value=np.log1p(100*raw.astype(np.float64))
    centered=value-value.mean((-2,-1),keepdims=True)
    return centered/np.sqrt(np.mean(centered*centered,axis=(-2,-1),keepdims=True)+1e-6)


class IndependentModel(nn.Module):
    def __init__(self,arm):
        super().__init__();self.arm=arm
        self.backbone=nn.Sequential(nn.Conv2d(1,24,3,padding=1),nn.GELU(),
            nn.Conv2d(24,24,3,padding=2,dilation=2),nn.GELU(),
            nn.Conv2d(24,24,3,padding=4,dilation=4),nn.GELU(),nn.Conv2d(24,1,1))
        branches=[]
        for _ in range(3):
            branch=nn.Sequential(nn.Conv2d(28,8,3,padding=1),nn.GELU(),nn.Conv2d(8,1,1))
            nn.init.zeros_(branch[-1].weight);nn.init.zeros_(branch[-1].bias);branches.append(branch)
        self.actions=nn.ModuleList(branches)
        for p in self.backbone.parameters():p.requires_grad_(False)
        if arm!='plain':
            spec=importlib.util.spec_from_file_location('conditioning_independent_circuit',PILOT/'circuit.py')
            circuit=importlib.util.module_from_spec(spec);spec.loader.exec_module(circuit)
            self.circuit=circuit.CircuitMaps(epsilon=.001)
        else:self.circuit=None

    def cached(self,inputs,variant):
        values=inputs.clone()
        if variant=='zero':values[:,-2:]=0
        if variant=='roll':values[:,-2:]=torch.roll(values[:,-2:],shifts=(5,5),dims=(-2,-1))
        action=torch.cat([branch(values) for branch in self.actions],1).softmax(1)
        return values[:,24:25]+2*(action[:,1:2]-action[:,2:3])

    def full_inputs(self,x):
        features=self.backbone[:-1](x);coarse=self.backbone[-1](features)
        if self.arm=='plain':
            p=coarse.sigmoid();raw=torch.cat((p,4*p*(1-p)),1)
        else:raw=self.circuit(coarse,mode='joint' if self.arm=='raw_joint' else self.arm)
        normalized=raw if self.arm=='raw_joint' else torch.from_numpy(normalize_numpy(raw.detach().numpy())).float()
        return torch.cat((features,coarse,x,normalized),1),raw


def main():
    start=time.monotonic();torch.set_num_threads(2)
    assert not (ROOT/'AUDIT.json').exists(),'Refuse overwrite completed audit'
    c=read('CONFIG.json');frozen=read('FROZEN.json');result=read('RESULT.json')
    names=['CONFIG.json','PROTOCOL.md','FROZEN.json','RESULT.json','CHECKPOINT_HASHES.json',
           'model.py','run.py','../sem_architecture_pilot_20261102/audit.py']
    before={n:sha(ROOT/n) for n in names};checks={}
    checks['development_scope_not_confirmatory']=(c['scope']=='DEVELOPMENT_VAL_ONLY' and
        result['status']=='COMPLETE_TRAIN_VAL_DIAGNOSTIC' and 'TEST' in result['scope'])
    checks['protocol_and_config_frozen']=(sha(ROOT/'CONFIG.json')==frozen['config_sha256'] and
        sha(ROOT/'PROTOCOL.md')==c['protocol_sha256']==frozen['protocol_sha256'] and
        sha(ROOT/'FROZEN.json')==result['frozen_sha256'])
    checks['all_sources_frozen']=all(sha(ROOT/n)==h for n,h in frozen['source_sha256'].items())
    checks['planned_eight_models_and_updates']=(result['models']==frozen['planned_models']==8 and
        result['updates']==frozen['planned_updates']==c['total_updates']==4000 and
        result['technical_updates']==12 and c['steps']==500 and c['arms']==ARMS)
    tree=ast.parse((ROOT/'run.py').read_text())
    loads=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)
           and isinstance(n.func.value,ast.Name) and n.func.value.id=='np' and n.func.attr=='load']
    checks['runner_loads_only_TRAIN_VAL']=len(loads)==1 and 'TRAIN_VAL.npz' in ast.unparse(loads[0].args[0])
    fit=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fit')
    fit_text=ast.unparse(fit)
    checks['all_arms_same_old_loss']=('dense_loss + c[\'physics_weight\'] * physics.geometry_loss(weak, directions)' in fit_text
        and 'binary_cross_entropy_with_logits' in fit_text and c['physics_weight']==1.)
    checks['heads_only_optimizer_code']=('[p for p in model.parameters() if p.requires_grad]' in fit_text and
        'all((p.grad is None for p in model.backbone.parameters()))' in fit_text)
    cache_node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='cache')
    cache_text=ast.unparse(cache_node)
    checks['weak_cached_optimizer_object_has_no_mask']=any(isinstance(n,ast.If) and
        ast.unparse(n.test)=="role != 'weak'" and "result[role]['mask']" in ast.unparse(n)
        for n in ast.walk(cache_node))
    with np.load(PILOT/'TRAIN_VAL.npz',allow_pickle=False) as z:tv={k:z[k] for k in z.files}
    lineage=frozen['lineage'];subsets=json.loads((PILOT/'SUBSETS.json').read_text())
    checks['exact_TRAIN_VAL_and_subsets']=(sha(PILOT/'TRAIN_VAL.npz')==lineage['TRAIN_VAL_sha256']
        and sha(PILOT/'SUBSETS.json')==lineage['subsets_sha256']
        and {r:int((tv['role']==r).sum()) for r in set(tv['role'])}=={'dense':54,'weak':1152,'val':695})
    val=np.flatnonzero(tv['role']=='val');truth=tv['label'][val];target=tv['Y'][val,0].astype(bool)
    checks['VAL_has_only_frames6_7']=len(val)==695 and set(tv['frame'][val])=={6,7}
    rows=result['rows'];hashes=result['checkpoint_hashes']
    checks['all8_checkpoint_hashes']=(len(hashes)==8 and hashes==read('CHECKPOINT_HASHES.json') and
        all(sha(ROOT/'models'/n)==h for n,h in hashes.items()))
    checks['source_initials_unchanged']=(len(lineage['sources'])==2 and
        all(sha(G/v['file'])==v['sha256'] for v in lineage['sources'].values()))
    norm_error=0.;metric_error=0.;fixture_error=0.;CPU_MPS_input_error=0.;raw_map_error=0.;probability_error=0.
    selection_ok=True;frozen_weights=True;metadata_ok=True;cache_roles_ok=True;model_shapes=True
    sparse_cases=[];decoder_initials=[];initial_backbone_states={};batch_hashes={};fixture_hashes={}
    for budget in [18,27]:
        source=lineage['sources'][str(budget)]
        payload=torch.load(G/source['file'],map_location='cpu',weights_only=True)
        initial_backbone_states[budget]=payload['segmenter']
        frozen_weights &= state_digest(payload['segmenter'])==source['backbone_sha256']
    with threadpool_limits(limits=2):
        for row in rows:
            budget=row['budget'];arm=row['arm'];stem=f'b{budget}_{arm}_s5501'
            payload=torch.load(ROOT/'models'/f'{stem}.pt',map_location='cpu',weights_only=True)
            metadata_ok &= payload['settings']==row and row['steps']==500 and row['seed']==5501
            state=payload['model']
            backbone={k[len('network.backbone.'):]:v for k,v in state.items() if k.startswith('network.backbone.')}
            decoder={k[len('network.actions.'):]:v for k,v in state.items() if k.startswith('network.actions.')}
            frozen_weights &= all(torch.equal(backbone[k],v) for k,v in initial_backbone_states[budget].items())
            frozen_weights &= row['backbone_before_sha256']==row['backbone_after_sha256']==lineage['sources'][str(budget)]['backbone_sha256']
            model_shapes &= sum(v.numel() for v in state.values())==16780 and sum(v.numel() for v in decoder.values())==6099
            model_shapes &= all(torch.isfinite(v).all().item() for v in state.values())
            metadata_ok &= row['trainable_parameters']==6099 and row['total_parameters']==16780
            torch.manual_seed(105504);net=IndependentModel(arm)
            decoder_initials.append(row['decoder_initial_sha256'])
            metadata_ok &= state_digest(net.actions.state_dict())==row['decoder_initial_sha256']
            metadata_ok &= state_digest(decoder)==row['decoder_final_sha256']!=row['decoder_initial_sha256']
            net.backbone.load_state_dict(backbone);net.actions.load_state_dict(decoder);net.eval()
            model_shapes &= sum(p.numel() for p in net.parameters() if p.requires_grad)==6099
            batch_hashes.setdefault(budget,[]).append(row['batch_sequence_sha256'])
            cache_roles_ok &= set(row['cache'])=={'dense','weak','val'}
            cache_roles_ok &= all(row['cache'][role]['examples']==n for role,n in [('dense',budget),('weak',1152),('val',695)])
            with np.load(ROOT/'fixtures'/f'{stem}.npz',allow_pickle=False) as z:
                fx={k:z[k] for k in z.files}
            fixture_hashes[f'fixtures/{stem}.npz']=sha(ROOT/'fixtures'/f'{stem}.npz')
            expected_maps=fx['raw_maps'] if arm=='raw_joint' else normalize_numpy(fx['raw_maps'])
            norm_error=max(norm_error,float(np.max(np.abs(expected_maps-fx['cached_inputs'][:,-2:]))))
            with torch.inference_mode():
                full_inputs,raw=net.full_inputs(torch.tensor(fx['x']))
                CPU_MPS_input_error=max(CPU_MPS_input_error,float(np.max(np.abs(full_inputs.numpy()-fx['cached_inputs']))))
                raw_map_error=max(raw_map_error,float(np.max(np.abs(raw.numpy()-fx['raw_maps']))))
                for v,variant in enumerate(VARIANTS):
                    cache_logits=net.cached(torch.tensor(fx['cached_inputs']),variant).numpy()
                    full_logits=net.cached(full_inputs,variant).numpy()
                    fixture_error=max(fixture_error,float(np.max(np.abs(cache_logits-fx['full_logits'][v]))),
                                      float(np.max(np.abs(full_logits-fx['full_logits'][v]))))
            with np.load(ROOT/'val_probs'/f'{stem}.npz',allow_pickle=False) as z:vp={k:z[k] for k in z.files}
            fixture_hashes[f'val_probs/{stem}.npz']=sha(ROOT/'val_probs'/f'{stem}.npz')
            metadata_ok &= (np.array_equal(vp['truth'],truth) and np.array_equal(vp['target'],target)
                and vp['variants'].tolist()==VARIANTS and vp['thresholds'].tolist()==c['thresholds']
                and vp['probability'].shape==(3,695,12,12) and vp['logits'].shape==(3,695,1,12,12))
            np_sigmoid=torch.from_numpy(vp['logits'][:,:,0]).sigmoid().numpy()
            probability_error=max(probability_error,float(np.max(np.abs(np_sigmoid-vp['probability']))))
            scores=[]
            for vi,variant in enumerate(VARIANTS):
                observed=[]
                for ti,t in enumerate(c['thresholds']):
                    masks=vp['probability'][vi]>=t
                    packed=np.packbits(masks.reshape(695,144),axis=1)
                    metadata_ok &= np.array_equal(packed,vp['packed_masks'][vi,ti])
                    pred=vp['predictions'][vi,ti]
                    union=(masks|target).sum((1,2))
                    iou=float(np.divide((masks&target).sum((1,2)),union,out=np.ones(695),where=union>0).mean())
                    score=dict(threshold=t,mask_F1=macro(truth,pred),IoU=iou);observed.append(score)
                    saved=row['VAL_scores_all_thresholds'][variant][ti]
                    metric_error=max(metric_error,max(abs(score[k]-saved[k]) for k in score))
                    for i in [0,347,694]:sparse_cases.append((masks[i],int(pred[i])))
                scores.append(observed)
            chosen=max(scores[0],key=lambda x:(x['mask_F1'],x['IoU'],-abs(x['threshold']-.5),-x['threshold']))
            selection_ok &= all(abs(chosen[k]-row['selected'][k])<1e-12 for k in chosen)
            selection_ok &= float(vp['selected_threshold'])==chosen['threshold']
            ti=c['thresholds'].index(chosen['threshold']);actual_masks=vp['probability'][0]>=chosen['threshold']
            for vi,variant in enumerate(VARIANTS):
                saved=row['ablations'][variant];delta=vp['logits'][vi]-vp['logits'][0]
                own=dict(**scores[vi][ti],mask_flip_fraction=float(np.mean((vp['probability'][vi]>=chosen['threshold'])!=actual_masks)),
                    logit_mean_absolute_difference=float(np.abs(delta).mean()),logit_max_absolute_difference=float(np.abs(delta).max()))
                metric_error=max(metric_error,max(abs(own[k]-saved[k]) for k in own))
            print(json.dumps(dict(stage='AUDIT_CONDITIONING_FIX',budget=budget,arm=arm)),flush=True)
        # Independent sparse solver is a standalone validated function from the
        # primary pilot audit, not the classifier used by run.py.
        spec=importlib.util.spec_from_file_location('conditioning_sparse_witness',PILOT/'audit.py')
        sparse_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(sparse_module)
        mismatches=sum(3*sparse_module.sparse_direction(mask)+sparse_module.sparse_direction(mask.T)!=label for mask,label in sparse_cases)
    checks['same6099_heads_and_frozen10681_backbones']=bool(model_shapes and frozen_weights)
    checks['all_model_metadata_and_cache_roles']=bool(metadata_ok and cache_roles_ok)
    checks['same_initial_decoder_all8']=len(set(decoder_initials))==1
    batch_ok=True
    for budget,values in batch_hashes.items():
        rng=np.random.default_rng(6501);h=hashlib.sha256()
        for _ in range(500):
            h.update(rng.integers(0,budget,8).astype(np.int64).tobytes());h.update(rng.integers(0,1152,8).astype(np.int64).tobytes())
        batch_ok &= len(set(values))==1 and values[0]==h.hexdigest()
    checks['all_pairs_batch_streams_recomputed']=bool(batch_ok)
    checks['normalization_exact_from_cached_raw']=norm_error<1e-4
    checks['CPU_MPS_normalized_input_fixtures']=CPU_MPS_input_error<1e-3
    checks['CPU_MPS_raw_map_fixtures']=raw_map_error<1e-4
    checks['cache_and_full_nonzero_head_fixtures']=fixture_error<1e-3 and all(max(r['cache_full_max_errors'].values())<1e-5 for r in rows)
    checks['all168_VAL_scores_and_intervention_metrics_recomputed']=metric_error<2e-6
    checks['stored_probability_matches_saved_logits']=probability_error<2e-6
    checks['actual_only_threshold_selection']=bool(selection_ok)
    checks['independent_sparse_classes']=mismatches==0
    checks['audit_changed_no_scientific_files']=(before=={n:sha(ROOT/n) for n in names} and
        all(sha(ROOT/n)==h for n,h in fixture_hashes.items()))
    checks['old_sources_still_unchanged']=all(sha(ROOT/n)==h for n,h in frozen['source_sha256'].items())
    output=dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        checks={k:bool(v) for k,v in checks.items()},normalization_max_error=norm_error,
        VAL_metric_max_error=metric_error,CPU_MPS_cached_input_max_error=CPU_MPS_input_error,
        CPU_MPS_raw_map_max_error=raw_map_error,cache_full_logit_fixture_max_error=fixture_error,
        saved_probability_max_error=probability_error,
        sparse_witness_cases=len(sparse_cases),sparse_witness_mismatches=int(mismatches),
        input_sha256=before,fixture_sha256=fixture_hashes,script_sha256=sha(Path(__file__)),
        seconds=time.monotonic()-start,scope='Technical audit of DEVELOPMENT_VAL_ONLY; no new TEST or performance confirmation.')
    (ROOT/'AUDIT.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output),flush=True)
    lines=['# Независимый аудит этапа нормализации карт','',
        f"**{output['status']}**: {sum(checks.values())}/{len(checks)} проверок.",'',
        'Это технический аудит разработки на повторно используемой VAL, '
        'без нового TEST и без подтверждения преимущества метода.','',
        '- Восемь моделей, по 500 обновлений только action-ветвей; 4000 основных и 12 технических обновлений.',
        '- Два исходных backbone проверены побайтно на уровне тензоров; во всех моделях они неизменны.',
        '- По 6099 обучаемых параметров, одинаковые начальные головы и парные батчи.',
        '- Независимо пересчитаны нормализация, 168 VAL-оценок и вмешательства при фиксированном actual-пороге.',
        '- Проверены непустые выходы кешированного и полного прямого проходов после обучения.',
        f"- Нормализация: максимальное отличие {norm_error:.3g}; выходные логиты CPU/MPS: {fixture_error:.3g}.",
        f"- Оценки VAL и вмешательств: максимальное отличие {metric_error:.3g}.",
        f"- Независимые sparse-Kirchhoff случаи: {len(sparse_cases)}, несовпадений {mismatches}.",'',
        'Полные условия и SHA: [AUDIT.json](AUDIT.json). [Код аудита](audit.py).','']
    (ROOT/'AUDIT.md').write_text('\n'.join(lines),encoding='utf-8')
    assert all(checks.values()),{k:v for k,v in checks.items() if not v}


if __name__=='__main__':main()
