"""Report a TRAIN/VAL-only development diagnostic; never open TEST inputs."""
from pathlib import Path
import hashlib
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
ARMS = ['plain', 'independent', 'joint', 'raw_joint']
NAMES = {'plain': 'Обычные карты, нормированные',
         'independent': 'Независимые изменения, нормированные',
         'joint': 'Совместное изменение, нормированное',
         'raw_joint': 'Совместное изменение, исходный масштаб'}
SHORT = ['Plain norm', 'Independent norm', 'Joint norm', 'Joint raw']


def read(name):
    return json.loads((ROOT/name).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def number(value):
    return f'{int(value):,}'.replace(',', '\u202f')


def percent(value):
    return f'{100*value:.3f}'


def difference(value):
    return f'{100*value:+.3f}'


def main():
    result = read('RESULT.json')
    config = read('CONFIG.json')
    assert result['status'] == 'COMPLETE_TRAIN_VAL_DIAGNOSTIC'
    assert result['models'] == 8 and result['updates'] == 4000
    assert config['scope'] == 'DEVELOPMENT_VAL_ONLY'
    rows = result['rows']
    table = {(row['budget'], row['arm']): row for row in rows}
    assert len(table) == 8
    audit = read('AUDIT.json') if (ROOT/'AUDIT.json').exists() else None
    audit_note = (f"Технический аудит: `{audit['status']}`."
                  if audit is not None else 'Технический аудит ещё не завершён на момент генерации отчёта.')
    samples = 695
    total_pixels = samples*144
    assert all(row['cache']['val']['examples'] == samples for row in rows)
    pixel_changes = {(b, arm, v): round(table[b, arm]['ablations'][v]['mask_flip_fraction']*total_pixels)
                     for b in [18, 27] for arm in ARMS for v in ['zero', 'roll']}
    joint_zero = [pixel_changes[b, 'joint', 'zero'] for b in [18, 27]]
    raw_zero = [pixel_changes[b, 'raw_joint', 'zero'] for b in [18, 27]]
    operator_equal_f1 = all(table[b, 'joint']['selected']['mask_F1'] ==
                            table[b, 'independent']['selected']['mask_F1'] for b in [18, 27])
    backbone_ok = all(row['backbone_before_sha256'] == row['backbone_after_sha256'] for row in rows)
    parity_error = max(max(row['cache_full_max_errors'].values()) for row in rows)

    folder = ROOT/'figures'
    folder.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.5))
    positions = np.arange(4)
    for i, budget in enumerate([18, 27]):
        color = f'C{i}'
        f1 = [100*table[budget, arm]['selected']['mask_F1'] for arm in ARMS]
        iou = [100*table[budget, arm]['selected']['IoU'] for arm in ARMS]
        axes[0, 0].plot(positions, f1, marker='o', color=color, label=f'{budget} dense masks')
        axes[0, 1].plot(positions, iou, marker='o', color=color, label=f'{budget} dense masks')
        for ax, variant in zip(axes[1], ['zero', 'roll']):
            ax.bar(positions+(i-.5)*.35, [pixel_changes[budget, arm, variant] for arm in ARMS],
                   width=.35, color=color, label=f'{budget} dense masks')
    axes[0, 0].set_title('Actual VAL Macro-F1')
    axes[0, 0].set_ylabel('%')
    axes[0, 1].set_title('Actual VAL IoU')
    axes[0, 1].set_ylabel('%')
    axes[1, 0].set_title('Changed binary pixels after zeroing maps')
    axes[1, 1].set_title('Changed binary pixels after rolling maps (5,5)')
    for ax in axes[1]:
        ax.set_ylabel(f'Count out of {total_pixels:,} per model')
    for ax in axes.ravel():
        ax.set_xticks(positions, SHORT, rotation=12)
        ax.grid(axis='y', alpha=.2)
        ax.legend(fontsize=8)
    fig.suptitle('DEVELOPMENT: reused TRAIN/VAL, one seed, frozen backbone; no TEST', fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, .95))
    fig.savefig(folder/'conditioning_development.png', dpi=180)
    plt.close(fig)

    lines = ['# Использование карт CNN-декодером: разработка только на TRAIN/VAL', '',
        '**Статус: DEVELOPMENT_VAL_ONLY. Нового подтверждающего TEST и научного PASS здесь нет.**', '',
        audit_note, '',
        f"После нормализации обнуление совместных карт меняет {joint_zero[0]} и {joint_zero[1]} "
        f"пикселей при 18/27 масках против {raw_zero[0]} и {raw_zero[1]} без нормализации "
        f"из {number(total_pixels)} пикселей каждой модели. Следовательно, зависимость "
        'бинарных решений от физических каналов появилась и стала заметнее. '
        '**Зависимость от карт не означает полезность карт.**', '',
        ('У нормированных joint и independent итоговый VAL Macro-F1 совпал на обоих бюджетах. '
         'Таким образом, преимущество точного совместного оператора над независимыми '
         'изменениями этим этапом не показано.' if operator_equal_f1 else
         'Числа joint и independent приведены полностью ниже; это оценки на повторно '
         'используемой VAL, а не независимое подтверждение различия.'), '',
        '## Что изменили и что осталось общим', '',
        'Сегментатор содержит прежнюю CNN на 10 681 параметр и три свёрточные '
        'action-ветви на 6099 параметров; всего 16 780. Теперь **CNN-backbone полностью '
        'заморожен**, обучаются только action-ветви. Все восемь моделей начинают '
        'с двух одинаково выбранных исходных сегментаторов предыдущего опыта '
        'дефицита разметки, не с уже дообученных моделей первого архитектурного пилота.', '',
        'Нормализация каждого условного канала каждой картинки:', '',
        '$$',
        r'u=\log(1+100m),\qquad \widetilde m=',
        r'\frac{u-\operatorname{mean}_{H,W}u}',
        r'{\sqrt{\operatorname{mean}_{H,W}(u-\operatorname{mean}_{H,W}u)^2+10^{-6}}}.',
        '$$', '',
        'Она не использует маску, класс или статистики других изображений. В raw_joint '
        'та же action-архитектура и тот же замороженный backbone, но карты передаются '
        'в исходном масштабе. У plain нормируются обычные карты вероятности и '
        'неопределённости; у independent и joint — физические карты.', '',
        '**Назначение контролей:** joint против raw_joint отделяет нормализацию '
        'от одного замораживания backbone. Joint против independent сравнивает '
        'операторы при одинаковой нормализации. Joint против plain проверяет '
        'предметные карты относительно простых признаков. Сравнение с первым '
        'пилотом не изолирует одну причину: там менялись и backbone, и масштаб, '
        'а диагностический сдвиг карт был другим.', '',
        'Лосс прежний и одинаковый: BCE итоговой маски +1·geometry_loss по тем же '
        'слабым классовым меткам. Для ускорения кешируются признаки замороженного '
        'backbone; полный прямой проход по изображению остаётся определён. '
        'Кеширование допустимо из-за замораживания и проверено после обучения, '
        'а не только при нулевой инициализации голов.', '',
        '## Данные и ограниченный объём разработки', '',
        'Используется только прежний TRAIN_VAL.npz: 1152 слабые классовые метки, '
        '18/27 плотных масок из одного вложенного розыгрыша 5303 и 695 VAL-примеров. '
        'Один заранее выбранный seed — 5501. Это 2 бюджета ×4 варианта =8 моделей, '
        'по 500 шагов, всего 4000 обновлений декодеров. Батчи и начальные action-веса '
        'одинаковы. Четыре технических трёхшаговых запуска отброшены и не входят '
        'в эти 4000 обновлений.', '',
        'VAL уже использовалась в предыдущих этапах. Порог каждой модели выбирается '
        'по её actual-предсказаниям на VAL; затем тот же порог без настройки '
        'используется при обнулении и сдвиге карт. Здесь нельзя выбрать удачный '
        'вариант на VAL и назвать эту же оценку подтверждением на TEST.', '',
        '## Actual: качество на повторно используемой VAL', '',
        '| Масок | Вариант | Порог actual | Macro-F1, % | IoU, % |',
        '|---:|---|---:|---:|---:|']
    for budget in [18, 27]:
        for arm in ARMS:
            row = table[budget, arm]['selected']
            lines.append(f"| {budget} | {NAMES[arm]} | {row['threshold']:.2f} | "
                         f"{percent(row['mask_F1'])} | {percent(row['IoU'])} |")
    lines += ['', 'Это численные оценки одного seed, без доверительных интервалов '
              'или заявления статистического превосходства.', '',
              '## Вмешательства в условные карты без переобучения', '',
              '| Масок | Вариант | Вмешательство | Изменено пикселей | Доля, % | ΔF1, п.п. | ΔIoU, п.п. | Среднее изменение логита |',
              '|---:|---|---|---:|---:|---:|---:|---:|']
    for budget in [18, 27]:
        for arm in ARMS:
            obs = table[budget, arm]['ablations']
            for variant in ['zero', 'roll']:
                row = obs[variant]
                lines.append(f"| {budget} | {NAMES[arm]} | {variant} | {pixel_changes[budget, arm, variant]} | "
                    f"{percent(row['mask_flip_fraction'])} | {difference(row['mask_F1']-obs['actual']['mask_F1'])} | "
                    f"{difference(row['IoU']-obs['actual']['IoU'])} | {row['logit_mean_absolute_difference']:.6f} |")
    lines += ['', 'Zero обнуляет каналы **после** нормализации. Roll сдвигает эти '
              'же каналы на (5,5). Отрицательная ΔF1 означает, что actual-карты '
              'лучше данного вмешательства на этой VAL; положительная — обратное. '
              'Оба направления эффекта сохранены.', '',
              '![Разработка масштаба карт](figures/conditioning_development.png)', '',
              '## Технические проверки и интерпретация', '',
              f"Backbone не изменился у всех восьми моделей: **{backbone_ok}**. "
              f"Максимальное расхождение кешированного и полного выхода: **{parity_error:.3g}**. "
              'Веса голов изменились; проверены конечность потерь и градиентов, '
              'одинаковая инициализация и парность батчей. Независимые проверки '
              'хранятся отдельно и не являются научным PASS.', '',
              f"Полный этап занял **{result['seconds']:.2f} с**. Сохранены восемь новых "
              'моделей, вероятности всех трёх вмешательств, технические фикстуры '
              'полного выхода и SHA256 исходников/данных.', '',
              '**Что показано:** масштабирование и замороженный backbone позволяют '
              'обучить декодер так, чтобы условные каналы влияли на бинарное решение. '
              '**Что не показано:** улучшение на новом тесте, устойчивое превосходство '
              'joint над independent/plain/raw_joint, перенос между кристаллами '
              'или подтверждённая новизна. Более сильное влияние входа может как '
              'помогать, так и вредить — это видно по разным знакам ΔF1 в таблице.', '',
              'Первый архитектурный пилот остаётся FAIL_PILOT; этот этап его не '
              'переписывает. Численная эквивалентность электрических операторов '
              'из чувствительности маски также не утверждается. Нормализация '
              'и замораживание — изменения разработки, а не самостоятельное '
              'обоснование научной оригинальности.', '',
              '## Файлы', '',
              '- [Протокол](PROTOCOL.md), [конфигурация](CONFIG.json).',
              '- [Модель](model.py), [обучение и диагностика](run.py), [аудит](audit.py).',
              '- [Полный результат](RESULT.json), [контрольные SHA моделей](CHECKPOINT_HASHES.json), [генератор отчёта](report.py).',
              '- [Первый архитектурный пилот](../sem_architecture_pilot_20261102/REPORT.md).',
              '- [Повторная проверка новизны](../architecture_novelty_recheck_20261102/NOVELTY_RECHECK.md).', '']
    (ROOT/'REPORT.md').write_text('\n'.join(lines), encoding='utf-8')
    (ROOT/'README.md').write_text(
        '# Разработка масштаба условных карт CNN\n\n'
        '**Только TRAIN/VAL, один seed. TEST не использовался. Научный PASS не заявляется.**\n\n'
        '[Полный отчёт с числами и графиком](REPORT.md). [Протокол](PROTOCOL.md).\n\n'
        'Проверены нормализация карт и замораживание CNN-backbone. Обучены только '
        '6099 параметров трёх action-ветвей: восемь моделей по 500 шагов. '
        'Сравниваются plain, independent, joint и raw_joint при одинаковом лоссе.\n\n'
        'Зависимость масок от карт появилась, но полезность физических каналов '
        'на новом тесте не подтверждена. Первый архитектурный пилот остаётся '
        'неизменным. Все веса, вероятности и журналы сохранены рядом.\n', encoding='utf-8')
    names = ['REPORT.md', 'README.md', 'figures/conditioning_development.png']
    manifest = dict(status='COMPLETE_DEVELOPMENT_REPORT', result_sha256=sha(ROOT/'RESULT.json'),
        report_script_sha256=sha(Path(__file__)), script_sha256=sha(Path(__file__)),
        audit_sha256=sha(ROOT/'AUDIT.json') if audit is not None else None,
        files_sha256={name: sha(ROOT/name) for name in names},
        scope='TRAIN/VAL development report; no TEST statistics or scientific PASS.')
    (ROOT/'REPORT_MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(manifest), flush=True)


if __name__ == '__main__':
    main()
