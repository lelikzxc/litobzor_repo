"""TRAIN/VAL diagnostic of conditioning scale with a frozen CNN backbone.

The original circuit and action-head architecture are imported unchanged.
Only the conditioning transform and backbone freezing differ from the pilot.
"""
from pathlib import Path
import importlib.util
import sys

import torch
from torch import nn

PILOT=Path(__file__).resolve().parents[1]/'sem_architecture_pilot_20261102'
_spec=importlib.util.spec_from_file_location('conditioning_fix_original_model',PILOT/'model.py')
original=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(original)
ARMS=['plain','independent','joint','raw_joint']


def normalize_maps(raw,scale=100.,floor=1e-6):
    assert raw.ndim==4 and raw.shape[1]==2
    transformed=torch.log1p(scale*raw)
    centered=transformed-transformed.mean((-2,-1),keepdim=True)
    return centered/torch.sqrt(centered.square().mean((-2,-1),keepdim=True)+floor)


class NormalizedFrozenSegmenter(nn.Module):
    def __init__(self,arm,backbone_state=None,*,decoder_seed=None,epsilon=.001,eta=2.,scale=100.,norm_floor=1e-6):
        super().__init__();assert arm in ARMS
        self.arm=arm;self.operator_mode='joint' if arm=='raw_joint' else arm
        self.scale=float(scale);self.norm_floor=float(norm_floor)
        # The old module imports circuit by its conventional module name.
        # Change search paths only during construction; no old ROOT is rebound.
        sys.path.insert(0,str(PILOT))
        try:
            self.network=original.make_model(self.operator_mode,backbone_state,
                epsilon=epsilon,eta=eta,decoder_seed=decoder_seed)
        finally:
            sys.path.pop(0)
        for parameter in self.network.backbone.parameters():parameter.requires_grad_(False)
        assert sum(p.numel() for p in self.parameters())==16780
        assert sum(p.numel() for p in self.parameters() if p.requires_grad)==6099

    @property
    def backbone(self):return self.network.backbone

    @property
    def actions(self):return self.network.actions

    @torch.no_grad()
    def precompute(self,x):
        features=self.backbone[:-1](x);coarse=self.backbone[-1](features)
        p=coarse.sigmoid()
        if self.operator_mode=='plain':
            raw=torch.cat((p,4*p*(1-p)),dim=1)
        else:
            raw=self.network.circuit(coarse,mode=self.operator_mode)
        conditioning=raw if self.arm=='raw_joint' else normalize_maps(raw,self.scale,self.norm_floor)
        return torch.cat((features,coarse,x,conditioning),dim=1).detach().clone(),raw.detach().clone()

    def forward_cached(self,inputs,intervention='actual'):
        assert inputs.ndim==4 and inputs.shape[1:]==(28,12,12)
        assert intervention in ['actual','zero','roll']
        if intervention!='actual':
            inputs=inputs.clone()
            if intervention=='zero':inputs[:,-2:]=0
            else:inputs[:,-2:]=torch.roll(inputs[:,-2:],shifts=(5,5),dims=(-2,-1))
        logits=torch.cat([head(inputs) for head in self.actions],dim=1)
        actions=logits.softmax(1)
        coarse=inputs[:,24:25]
        correction=self.network.eta*(actions[:,1:2]-actions[:,2:3])
        return dict(logits=coarse+correction,coarse=coarse,
            maps_normalized=inputs[:,-2:],actions=actions,correction=correction)

    def forward_details(self,x,intervention='actual'):
        inputs,raw=self.precompute(x)
        result=self.forward_cached(inputs,intervention=intervention)
        result['maps_raw']=raw
        return result

    def forward(self,x):return self.forward_details(x)['logits']


def make_model(arm,backbone_state=None,**kwargs):
    return NormalizedFrozenSegmenter(arm,backbone_state,**kwargs)


state_digest=original.state_digest
