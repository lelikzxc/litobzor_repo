"""Eight fixed TRAIN/VAL-only conditioning diagnostics; no TEST evaluation.

The only fitted tensors are the 6099 action-head parameters. Frozen-backbone
features are cached without gradients, then checked against the full forward.
This is a development diagnostic, not a confirmatory performance experiment.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import time

os.environ['PYTORCH_ENABLE_MPS_FALLBACK']='0'
import numpy as np
import torch
from torch.nn import functional as F
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits

from model import ARMS,make_model,state_digest

ROOT=Path(__file__).resolve().parent
G=ROOT.parent
PILOT=G/'sem_architecture_pilot_20261102'
VARIANTS=['actual','zero','roll']
START=None
COMPLETED=0
CLASS_CACHE={}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name,value):
    path=ROOT/name;tmp=path.with_suffix(path.suffix+'.partial')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)


def tensor_digest(x):
    return hashlib.sha256(x.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value


physics=module('conditioning_fix_unchanged_physics',PILOT/'physics_adapter.py')
preparation=module('conditioning_fix_unchanged_class_rule',PILOT/'prepare.py')


def configuration():
    c=json.loads((ROOT/'CONFIG.json').read_text())
    assert c['arms']==ARMS and c['budgets']==[18,27] and c['seeds']==[5501]
    assert c['steps']==500 and c['batch_size']==8 and c['physics_weight']==1.
    assert c['epsilon']==.001 and c['eta']==2. and c['normalization_scale']==100. and c['normalization_variance_floor']==1e-6
    assert c['learning_rate']==.0005 and c['weight_decay']==.0001
    assert c['protocol_sha256']==sha(ROOT/'PROTOCOL.md')
    return c


def make(c,arm,state):
    return make_model(arm,state,decoder_seed=c['seeds'][0]+100003,
        epsilon=c['epsilon'],eta=c['eta'],scale=c['normalization_scale'],norm_floor=c['normalization_variance_floor']).to('mps')


def hard_classes(masks):
    masks=np.asarray(masks,dtype=bool).reshape(-1,12,12)
    keys=[r.tobytes() for r in np.packbits(masks.reshape(len(masks),144),axis=1)]
    missing=sorted(set(keys)-CLASS_CACHE.keys())
    if missing:
        values=np.array([np.unpackbits(np.frombuffer(k,dtype=np.uint8)).reshape(12,12) for k in missing],dtype=bool)
        CLASS_CACHE.update(zip(missing,preparation.class_labels(values).tolist()))
    return np.array([CLASS_CACHE[k] for k in keys],dtype=np.int64)


def source_hashes():
    names=['model.py','run.py','../sem_architecture_pilot_20261102/model.py',
        '../sem_architecture_pilot_20261102/circuit.py','../sem_architecture_pilot_20261102/physics_adapter.py',
        '../sem_architecture_pilot_20261102/prepare.py','../sem_physics_materials/physics_loss_example.py',
        '../sem_confirmation_20261028/prepare.py','../retained_evidence_20261027/SELECTED_SOURCES.zip']
    return {n:sha(ROOT/n) for n in names}


def inputs(c):
    # Only metadata and historical TRAIN/VAL backbones are accessed. No old
    # RESULT.json, EVAL archive, TEST archive or test predictions are opened.
    inherited=json.loads((PILOT/'INITIAL_LINEAGE.json').read_text())
    subsets=json.loads((PILOT/'SUBSETS.json').read_text())
    with np.load(PILOT/'TRAIN_VAL.npz',allow_pickle=False) as z:
        assert set(z['role'])=={'dense','weak','val'}
        data={k:z[k].copy() for k in z.files}
    assert sha(PILOT/'TRAIN_VAL.npz')==inherited['TRAIN_VAL_sha256']==subsets['train_val_sha256']
    weak_ids=np.flatnonzero(data['role']=='weak');val_ids=np.flatnonzero(data['role']=='val')
    assert len(weak_ids)==1152 and len(val_ids)==695
    sources={};states={}
    for b in c['budgets']:
        source=inherited['initials'][f'{b}:5501'];path=PILOT/source['file']
        assert sha(path)==source['sha256']
        payload=torch.load(path,map_location='cpu',weights_only=True)
        states[b]=payload['segmenter']
        assert state_digest(states[b])==source['backbone_state_sha256']
        sources[str(b)]=dict(file=str(path.relative_to(G)),sha256=sha(path),backbone_sha256=state_digest(states[b]))
    roles={}
    for b in c['budgets']:
        dense_ids=np.array(subsets['dense_indices'][str(b)],dtype=int)
        assert len(dense_ids)==b and set(data['role'][dense_ids])=={'dense'}
        assert np.array_equal(np.bincount(data['label'][dense_ids],minlength=9),np.full(9,b//9))
        roles[b]={}
        for role,ids in [('dense',dense_ids),('weak',weak_ids),('val',val_ids)]:
            roles[b][role]=dict(x=torch.tensor(5*(data['X'][ids]-.2),device='mps'),
                label=torch.tensor(data['label'][ids],device='mps'),indices=ids.tolist())
            if role!='weak':roles[b][role]['mask']=torch.tensor(data['Y'][ids].astype(np.float32),device='mps')
        assert set(roles[b]['weak'])=={'x','label','indices'}
    provenance=dict(TRAIN_VAL_sha256=sha(PILOT/'TRAIN_VAL.npz'),sources=sources,
        initial_lineage_sha256=sha(PILOT/'INITIAL_LINEAGE.json'),subsets_sha256=sha(PILOT/'SUBSETS.json'))
    return roles,states,provenance


@torch.no_grad()
def cache(model,data):
    result={};meta={}
    for role,values in data.items():
        chunks=[];raw_parts=[]
        for x in values['x'].split(16):
            features,raw=model.precompute(x)
            assert torch.isfinite(features).all() and torch.isfinite(raw).all()
            chunks.append(features);raw_parts.append(raw)
        features=torch.cat(chunks);raw=torch.cat(raw_parts)
        result[role]=dict(inputs=features,label=values['label'])
        if role!='weak':result[role]['mask']=values['mask']
        meta[role]=dict(examples=len(features),inputs_sha256=tensor_digest(features),
            raw_map_channel_mean=raw.mean((0,2,3)).cpu().tolist(),
            conditioning_channel_mean=features[:,-2:].mean((0,2,3)).cpu().tolist(),
            conditioning_channel_abs_mean=features[:,-2:].abs().mean((0,2,3)).cpu().tolist())
    return result,meta


def fit(c,model,data,steps,budget,arm,technical=False):
    global COMPLETED
    before=state_digest(model.backbone.state_dict());decoder_before=state_digest(model.actions.state_dict())
    parameters=[p for p in model.parameters() if p.requires_grad]
    assert sum(p.numel() for p in parameters)==6099
    optimizer=torch.optim.AdamW(parameters,lr=c['learning_rate'],weight_decay=c['weight_decay'])
    rng=np.random.default_rng(6501);batches=hashlib.sha256();start=time.monotonic()
    for step in range(1,steps+1):
        ai=rng.integers(0,len(data['dense']['inputs']),c['batch_size'])
        wi=rng.integers(0,len(data['weak']['inputs']),c['batch_size'])
        batches.update(ai.astype(np.int64).tobytes());batches.update(wi.astype(np.int64).tobytes())
        ai=torch.tensor(ai,device='mps');wi=torch.tensor(wi,device='mps')
        optimizer.zero_grad(set_to_none=True)
        dense=model.forward_cached(data['dense']['inputs'][ai])['logits']
        dense_loss=F.binary_cross_entropy_with_logits(dense,data['dense']['mask'][ai])
        labels=data['weak']['label'][wi];directions=torch.stack((labels//3,labels%3),dim=1)
        weak=model.forward_cached(data['weak']['inputs'][wi])['logits']
        loss=dense_loss+c['physics_weight']*physics.geometry_loss(weak,directions)
        assert torch.isfinite(loss),(budget,arm,step)
        loss.backward()
        assert all(p.grad is None for p in model.backbone.parameters())
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in parameters)
        optimizer.step()
        if not technical:COMPLETED+=1
        if step%100==0 or step==steps:
            row=dict(stage='TECHNICAL_SMOKE' if technical else 'HEAD_TRAINING',budget=budget,arm=arm,
                step=step,target_steps=steps,completed_updates=COMPLETED,total_updates=4000,
                seconds=time.monotonic()-START,model_seconds=time.monotonic()-start)
            if not technical:
                save('PROGRESS.json',row)
                with (ROOT/'progress.jsonl').open('a') as h:h.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
    torch.mps.synchronize()
    after=state_digest(model.backbone.state_dict());decoder_after=state_digest(model.actions.state_dict())
    assert before==after and decoder_before!=decoder_after
    return dict(seconds=time.monotonic()-start,steps=steps,backbone_before_sha256=before,
        backbone_after_sha256=after,decoder_initial_sha256=decoder_before,decoder_final_sha256=decoder_after,
        batch_sequence_sha256=batches.hexdigest(),trainable_parameters=6099,total_parameters=16780)


def rank(row):return row['mask_F1'],row['IoU'],-abs(row['threshold']-.5),-row['threshold']


def evaluate(model,data,thresholds):
    probabilities=[];logits=[]
    model.eval()
    with torch.no_grad():
        for variant in VARIANTS:
            output=torch.cat([model.forward_cached(x,intervention=variant)['logits'] for x in data['inputs'].split(16)])
            logits.append(output.cpu().numpy());probabilities.append(output[:,0].sigmoid().cpu().numpy())
    probabilities=np.array(probabilities);logits=np.array(logits)
    truth=data['label'].cpu().numpy();target=data['mask'][:,0].cpu().numpy().astype(bool)
    scores=[];predictions=[];packed=[]
    for p in probabilities:
        variant_scores=[];variant_preds=[];variant_packed=[]
        for threshold in thresholds:
            masks=p>=threshold;pred=hard_classes(masks);union=(masks|target).sum((1,2))
            iou=np.divide((masks&target).sum((1,2)),union,out=np.ones(len(union)),where=union>0)
            variant_scores.append(dict(threshold=threshold,mask_F1=float(f1_score(truth,pred,labels=range(9),average='macro',zero_division=0)),IoU=float(iou.mean())))
            variant_preds.append(pred);variant_packed.append(np.packbits(masks.reshape(len(masks),144),axis=1))
        scores.append(variant_scores);predictions.append(variant_preds);packed.append(variant_packed)
    selected=max(scores[0],key=rank);threshold=selected['threshold'];ti=thresholds.index(threshold)
    ablations={};actual_masks=probabilities[0]>=threshold
    for v,name in enumerate(VARIANTS):
        ablations[name]=dict(**scores[v][ti],mask_flip_fraction=float(np.mean((probabilities[v]>=threshold)!=actual_masks)),
            logit_mean_absolute_difference=float(np.abs(logits[v]-logits[0]).mean()),
            logit_max_absolute_difference=float(np.abs(logits[v]-logits[0]).max()))
    arrays=dict(probability=probabilities,logits=logits,truth=truth,target=target,
        thresholds=np.array(thresholds),variants=np.array(VARIANTS),predictions=np.array(predictions),
        packed_masks=np.array(packed),selected_threshold=np.array(threshold))
    return selected,ablations,arrays,scores


def main():
    global START,COMPLETED
    START=time.monotonic();COMPLETED=0
    assert torch.backends.mps.is_available() and os.environ['PYTORCH_ENABLE_MPS_FALLBACK']=='0'
    assert not (ROOT/'FROZEN.json').exists() and not (ROOT/'RESULT.json').exists(), 'No silent rerun/overwrite'
    torch.set_num_threads(2);c=configuration();roles,states,lineage=inputs(c)
    frozen=dict(protocol_sha256=sha(ROOT/'PROTOCOL.md'),config_sha256=sha(ROOT/'CONFIG.json'),
        source_sha256=source_hashes(),lineage=lineage,planned_models=8,planned_updates=4000,
        scope='TRAIN/VAL only; frozen historical backbones, heads-only normalization diagnostic; no old TEST/results read')
    save('FROZEN.json',frozen)
    (ROOT/'models').mkdir(exist_ok=True);(ROOT/'val_probs').mkdir(exist_ok=True);(ROOT/'fixtures').mkdir(exist_ok=True)
    rows=[];hashes={};head_initials=[];batch_hashes={};smoke=[]
    # Complete every technical arm before the first scientific diagnostic fit.
    for arm in ARMS:
        technical=make(c,arm,states[18]);technical_cache,_=cache(technical,roles[18])
        smoke.append(dict(arm=arm,**fit(c,technical,technical_cache,3,18,arm,technical=True)))
        del technical,technical_cache
    save('SMOKE_CHECK.json',dict(status='PASS_TECHNICAL_SMOKE',steps_per_arm=3,models=smoke,
        scope='Discarded technical head-only training; no held-out evaluation or scientific PASS'))
    for budget in c['budgets']:
        for arm in ARMS:
            net=make(c,arm,states[budget]);cached,cache_meta=cache(net,roles[budget])
            with torch.no_grad():
                identity=net.forward_cached(cached['dense']['inputs'][:8])
                assert torch.equal(identity['logits'],identity['coarse'])
            timing=fit(c,net,cached,c['steps'],budget,arm)
            head_initials.append(timing['decoder_initial_sha256'])
            batch_hashes.setdefault(str(budget),[]).append(timing['batch_sequence_sha256'])
            # This post-training test validates the cached optimization route,
            # not only its trivial zero-initialized prediction.
            x=roles[budget]['val']['x'][:16];inputs_fixture=cached['val']['inputs'][:16]
            parity={};full_logits=[]
            with torch.no_grad():
                for variant in VARIANTS:
                    actual=net.forward_details(x,intervention=variant)['logits']
                    from_cache=net.forward_cached(inputs_fixture,intervention=variant)['logits']
                    parity[variant]=float((actual-from_cache).abs().max().cpu())
                    assert parity[variant]<1e-5,(budget,arm,variant,parity[variant])
                    full_logits.append(actual.cpu().numpy())
                _,raw_fixture=net.precompute(x)
            selected,ablations,arrays,all_scores=evaluate(net,cached['val'],c['thresholds'])
            name=f'b{budget}_{arm}_s5501';row=dict(budget=budget,seed=5501,arm=arm,**timing,
                selected=selected,ablations=ablations,cache=cache_meta,cache_full_max_errors=parity)
            row['VAL_scores_all_thresholds']=dict(zip(VARIANTS,all_scores))
            temporary=ROOT/'models'/f'{name}.pt.partial';path=ROOT/'models'/f'{name}.pt'
            torch.save(dict(model={k:v.detach().cpu() for k,v in net.state_dict().items()},settings=row),temporary);temporary.replace(path)
            hashes[path.name]=sha(path)
            np.savez_compressed(ROOT/'val_probs'/f'{name}.npz',**arrays)
            np.savez_compressed(ROOT/'fixtures'/f'{name}.npz',x=x.cpu().numpy(),
                cached_inputs=inputs_fixture.cpu().numpy(),raw_maps=raw_fixture.cpu().numpy(),
                full_logits=np.array(full_logits),variants=np.array(VARIANTS))
            rows.append(row)
            save('PARTIAL_RESULTS.json',rows);save('CHECKPOINT_HASHES.json',hashes)
            del net,cached
    assert len(rows)==8 and len(hashes)==8 and COMPLETED==4000
    assert len(set(head_initials))==1 and all(len(set(v))==1 for v in batch_hashes.values())
    assert all(sha(ROOT/n)==h for n,h in frozen['source_sha256'].items())
    assert sha(ROOT/'CONFIG.json')==frozen['config_sha256'] and sha(ROOT/'PROTOCOL.md')==frozen['protocol_sha256']
    assert all(sha(G/v['file'])==v['sha256'] for v in lineage['sources'].values())
    save('SMOKE_CHECK.json',dict(status='PASS_TECHNICAL_SMOKE',steps_per_arm=3,models=smoke,
        scope='Discarded technical head-only training; no held-out evaluation or scientific PASS'))
    result=dict(status='COMPLETE_TRAIN_VAL_DIAGNOSTIC',rows=rows,models=8,updates=COMPLETED,
        technical_updates=12,common_decoder_initialization=True,paired_batches_by_budget=True,
        backbone_frozen=True,checkpoint_hashes=hashes,seconds=time.monotonic()-START,
        frozen_sha256=sha(ROOT/'FROZEN.json'),
        scope='Development diagnostic on reused VAL; no new TEST, no independent confirmation or statistical PASS claim. '
              'Actual threshold selected per trained model; zero/roll ablations reuse that threshold without retuning.')
    save('RESULT.json',result);save('PROGRESS.json',dict(stage='COMPLETE_TRAIN_VAL_DIAGNOSTIC',models=8,updates=4000,seconds=time.monotonic()-START))
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
