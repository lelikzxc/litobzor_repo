"""Persist child logs and status; each scientific stage is run explicitly once."""
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    name = sys.argv[1]
    assert name in ['train', 'evaluate', 'audit', 'report', 'verify']
    log = ROOT / f'{name}.log'
    assert not log.exists(), f'Refuse to overwrite stage log: {log}'
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='2',
               OMP_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2', PYTORCH_ENABLE_MPS_FALLBACK='0',
               MPLCONFIGDIR='/private/tmp/sem_cldice_mpl_20261030')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.Popen([sys.executable, '-B', str(ROOT / f'{name}.py')],
        cwd=ROOT.parent.parent, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, bufsize=1)
    status = {'stage': name, 'status': 'RUNNING', 'pid': process.pid,
              'started_UTC': started, 'log': log.name}
    (ROOT / 'STAGE_EXECUTION.json').write_text(json.dumps(status, indent=2)+'\n')
    print(json.dumps(status), flush=True)
    with log.open('x', encoding='utf-8') as output:
        for line in process.stdout:
            output.write(line); output.flush()
            try:
                row = json.loads(line)
                relay = row.get('stage') != 'train' or row.get('step', 0) % 500 == 0
                if relay: print(line, end='', flush=True)
            except json.JSONDecodeError:
                print(line, end='', flush=True)
    code = process.wait()
    status.update(status='COMPLETE' if code == 0 else 'FAILED', returncode=code,
                  ended_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (ROOT / f'{name.upper()}_EXECUTION.json').write_text(json.dumps(status, indent=2)+'\n')
    (ROOT / 'STAGE_EXECUTION.json').write_text(json.dumps(status, indent=2)+'\n')
    print(json.dumps(status), flush=True)
    sys.exit(code)


if __name__ == '__main__':
    main()
