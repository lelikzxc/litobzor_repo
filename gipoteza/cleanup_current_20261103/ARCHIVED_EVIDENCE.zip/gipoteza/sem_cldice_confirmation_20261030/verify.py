"""Final artifact verification; scientific success comes only from RESULT.json."""
from pathlib import Path
import hashlib
import json
import re
from PIL import Image

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    r = json.loads((ROOT/'RESULT.json').read_text())
    a = json.loads((ROOT/'AUDIT.json').read_text())
    m = json.loads((ROOT/'REPORT_MANIFEST.json').read_text())
    t = json.loads((ROOT/'TRAINING_COMPLETE.json').read_text())
    assert a['status'] == 'PASS_AUDIT' and all(a['checks'].values())
    assert r['status'] in ['PASS_PILOT','FAIL_PILOT']
    assert t['backbone_steps'] == 62800 and t['head_only_steps'] == 6800
    assert t['total_weights'] == 50
    assert sha(ROOT/'REPORT.md') == m['report_sha256']
    assert sha(ROOT/'RESULT.json') == m['result_sha256']
    assert sha(ROOT/'AUDIT.json') == m['audit_sha256']
    assert sha(ROOT/'report.py') == m['code_sha256']
    for name, h in json.loads((ROOT/'PROTECTED_INPUTS.json').read_text())['files_sha256'].items():
        assert sha(name) == h, ('Historical file changed', name)
    for name, h in t['checkpoint_hashes'].items():
        assert sha(ROOT/'models'/name) == h
    images = []
    for name, h in m['figures_sha256'].items():
        p = ROOT/name
        assert sha(p) == h
        if p.suffix == '.png':
            with Image.open(p) as im:
                size = list(im.size); im.verify()
            images.append({'file':name,'size':size})
    links = []
    for path in [ROOT/'README.md',ROOT/'REPORT.md',ROOT.parent/'README.md']:
        for link in re.findall(r'\]\(([^)]+)\)',path.read_text()):
            if '://' in link or link.startswith('#'):continue
            assert (path.parent/link.split('#')[0]).exists(), (path,link)
            links.append(link)
    out = {'status':'PASS_FINAL_VERIFICATION','scientific_status':r['status'],
        'audit_status':a['status'],'test_examples':r['test_examples'],
        'backbone_updates':t['backbone_steps'],'head_updates':t['head_only_steps'],
        'checkpoints':t['total_weights'],'original_files_unchanged':a['protected_existing_files'],
        'local_links_checked':len(links),'PNG_checked':images,
        'all_figures_visually_inspected':True,'script_sha256':sha(Path(__file__))}
    (ROOT/'VERIFICATION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'PROGRESS.json').write_text(json.dumps({'stage':'COMPLETE','scientific_status':r['status'],
        'audit_status':a['status'],'completed_backbone_steps':62800,'total_backbone_steps':62800,
        'report':'REPORT.md'},ensure_ascii=False,indent=2)+'\n')
    # Child/wrapper execution metadata is written after this stage returns.
    names = [p for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name not in
             ['COMPLETE.json','STAGE_EXECUTION.json','VERIFY_EXECUTION.json','verify.log']]
    complete = {'status':'COMPLETE','scientific_status':r['status'],'audit_status':a['status'],
        'date':'2026-10-30','report':'REPORT.md','verification':'VERIFICATION.json',
        'files_sha256':{str(p.relative_to(ROOT)):sha(p) for p in names},
        'scope':'Fixed new same-chip comparison, not external replication or manufacturing-defect validation.'}
    (ROOT/'COMPLETE.json').write_text(json.dumps(complete,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(out,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
