"""Publish the frozen clDice comparison after evaluation and independent audit.

CPU-only: this script neither fits models nor changes scientific inputs. The
same report structure is generated for PASS_PILOT and FAIL_PILOT.
"""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import os
import re
import time
from zoneinfo import ZoneInfo

os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/sem_cldice_mpl_20261030')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
ARMS = ['head9', 'cldice_head9', 'soft']
NAMES = {'head9': 'Голова: 9 классов', 'cldice_head9': 'clDice + голова 9',
         'soft': 'Непрерывная регуляризация'}
COLORS = {'head9': '#8064A2', 'cldice_head9': '#C18A36', 'soft': '#087F8C'}
GEOMETRY_LABELS = {
    'false_break_rate': ('Потерянный путь', '% эталонных направлений с путём', 100),
    'false_connection_rate': ('Ложный путь', '% эталонных направлений без пути', 100),
    'grade_error_per_true_connected': ('Неверная ненулевая градация', '% эталонных направлений с путём', 100),
    'joint_connection_error_rate': ('Ошибка наличия пути на фрагменте', '% фрагментов', 100),
    'component_count_mae': ('Ошибка числа связных компонент', 'Средняя абсолютная ошибка, компонент/фрагмент', 1),
    'hole_count_mae': ('Ошибка числа отверстий', 'Средняя абсолютная ошибка, отверстий/фрагмент', 1),
    'component_count_exact_rate': ('Точное число связных компонент', '% фрагментов', 100),
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def save_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.partial')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def fmt(value, factor=100, places=3, signed=False):
    spec = f'+.{places}f' if signed else f'.{places}f'
    return format(factor * value, spec).replace('.', ',')


def interval(values, factor=100, places=3):
    return '[' + '; '.join(fmt(v, factor, places, signed=True) for v in values) + ']'


def write_csv(name, rows):
    assert rows
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with (ROOT / name).open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader(); writer.writerows(rows)


def save_figure(fig, name):
    for suffix in ['png', 'svg']:
        fig.savefig(ROOT / 'figures' / f'{name}.{suffix}', dpi=220, bbox_inches='tight')
    plt.close(fig)


def figures(result, geometry_per_seed, geometry_names):
    (ROOT / 'figures').mkdir(exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
        'axes.spines.top': False, 'axes.spines.right': False, 'svg.fonttype': 'none'})
    ns = len(result['seeds'])
    jitter = np.linspace(-.09, .09, ns)
    fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.4), sharey=True)
    for j, family in enumerate(ARMS):
        metric = result['metrics'][family]
        for ax, key, per_key in zip(axes, ['mask_F1', 'IoU'], ['per_seed_mask_F1', 'per_seed_IoU']):
            values = np.array(metric[per_key]) * 100
            ax.scatter(values, j+jitter, color=COLORS[family], alpha=.52, s=30, zorder=2)
            ax.scatter([100*metric[key]], [j], marker='D', color=COLORS[family], s=65, zorder=3)
            ax.annotate(fmt(metric[key]), (100*metric[key], j), xytext=(7, 8),
                        textcoords='offset points', color=COLORS[family], fontsize=10)
    for ax, title in zip(axes, ['Класс из бинарной маски: Macro-F1, %', 'Сегментация металла: средний IoU, %']):
        ax.set_yticks(range(3), [NAMES[family] for family in ARMS])
        ax.set_title(title, loc='left', fontsize=11, pad=14)
        ax.grid(axis='x', alpha=.16); ax.set_axisbelow(True); ax.margins(x=.28)
    axes[0].set_ylim(2.5, -.5)
    fig.suptitle('Сравнение с clDice при одинаковых дополнительных метках', x=.03, ha='left', fontsize=14, weight='bold')
    fig.text(.03, .02, f"{result['test_examples']:,} фрагментов; 8 новых кадров одного чипа; 5 запусков. Точки — запуски, ромбы — средние.".replace(',', ' '),
             fontsize=9, color='#52606D')
    fig.tight_layout(rect=(0, .08, 1, .91), w_pad=3)
    save_figure(fig, 'comparison')

    fig, ax = plt.subplots(figsize=(11.3, 3.8))
    all_endpoints = [0., 1.]
    for j, family in enumerate(['head9', 'cldice_head9']):
        comparison = result['soft_minus_control'][family]
        point = comparison['delta'] * 100
        lo, hi = np.array(comparison['CI95']) * 100
        passed = all(comparison['gates'].values())
        color = '#087F8C' if passed else '#A85C38'
        ax.plot([lo, hi], [j, j], color=color, linewidth=2.4)
        ax.scatter([point], [j], s=50, color=color, zorder=3)
        gates = comparison['gates']
        yes = lambda value: 'да' if value else 'нет'
        status = ('PASS' if passed else 'FAIL') + ' — ' + '; '.join([
            'F1 ≥1 п.п.: '+yes(gates['gain_at_least_one_pp']),
            'CI >0: '+yes(gates['positive_CI_lower']),
            'IoU: '+yes(gates['IoU_guard'])])
        ax.annotate(f'{fmt(comparison["delta"],signed=True)} п.п.\n{status}', (hi, j),
                    xytext=(9, 8), textcoords='offset points', fontsize=9, color=color)
        all_endpoints += [lo, hi, point]
    ax.axvline(0, color='#8993A0', linestyle='--', linewidth=1)
    ax.axvline(1, color='#C18A36', linestyle=':', linewidth=1.2, label='Заранее заданный минимум: 1 п.п.')
    span = max(all_endpoints) - min(all_endpoints)
    span = max(span, 1.)
    ax.set_xlim(min(all_endpoints)-.12*span, max(all_endpoints)+.85*span)
    ax.set_yticks([0, 1], [NAMES['head9'], NAMES['cldice_head9']]); ax.set_ylim(1.55, -.55)
    ax.set_xlabel('Наш метод − контроль, п.п. Macro-F1 класса из маски')
    ax.set_title('Парные сравнения: 95%-интервалы по кадрам и запускам', loc='left', fontsize=12, pad=16)
    ax.grid(axis='x', alpha=.15); ax.legend(frameon=False, fontsize=9, loc='lower right')
    fig.text(.03, .02, 'Оба контроля зафиксированы до TEST. Все три условия должны выполняться против каждого контроля.',
             fontsize=9, color='#52606D')
    fig.tight_layout(rect=(0, .08, 1, 1))
    save_figure(fig, 'paired_comparisons')

    chosen = ['false_break_rate', 'false_connection_rate', 'grade_error_per_true_connected',
              'joint_connection_error_rate', 'component_count_mae', 'hole_count_mae']
    fig, axes = plt.subplots(2, 3, figsize=(13.2, 8.3))
    for ax, name in zip(axes.flat, chosen):
        title, ylabel, scale = GEOMETRY_LABELS[name]
        k = geometry_names.index(name)
        for j, family in enumerate(ARMS):
            point = result['metrics'][family]['geometry'][name]
            values = geometry_per_seed[:, j, k] * scale
            ax.bar(j, scale*point, color=COLORS[family], width=.62, alpha=.72)
            ax.scatter(j+jitter, values, color=COLORS[family], edgecolor='white', linewidth=.5, s=26, zorder=3)
            places = 2 if scale == 100 else 4
            ax.annotate(fmt(point, factor=scale, places=places), (j, float(values.max())),
                        xytext=(0, 6), textcoords='offset points', ha='center', fontsize=9)
        ax.set_xticks(range(3), ['Голова 9', 'clDice + голова', 'Наш метод'], rotation=12, ha='right')
        ax.set_title(title, loc='left', fontsize=10, pad=12)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.grid(axis='y', alpha=.14); ax.set_axisbelow(True)
        top = max(ax.get_ylim()[1], .001)
        ax.set_ylim(0, top * 1.18)
    fig.suptitle('Вторичные геометрические показатели', x=.03, ha='left', fontsize=14, weight='bold')
    fig.text(.03, .015, 'Столбцы — средние, точки — 5 запусков. Эти показатели не меняют основной критерий PASS/FAIL.',
             fontsize=9, color='#52606D')
    fig.tight_layout(rect=(0, .05, 1, .94), w_pad=2.4, h_pad=2.2)
    save_figure(fig, 'geometry_errors')


def execution_timing(name):
    path = ROOT / f'{name.upper()}_EXECUTION.json'
    if not path.exists():
        return None
    row = load(path.name)
    if row.get('status') != 'COMPLETE' or 'ended_UTC' not in row:
        return None
    start = datetime.datetime.fromisoformat(row['started_UTC'])
    end = datetime.datetime.fromisoformat(row['ended_UTC'])
    return {'seconds': (end-start).total_seconds(),
            'start_Moscow': start.astimezone(ZoneInfo('Europe/Moscow')).isoformat(),
            'end_Moscow': end.astimezone(ZoneInfo('Europe/Moscow')).isoformat()}


def main():
    started = time.monotonic()
    required = ['RESULT.json', 'AUDIT.json', 'DEV_RESULTS.json', 'SELECTION.json',
                'FINAL_VAL_RESULTS.json', 'TRAINING_COMPLETE.json', 'SMOKE_CHECK.json',
                'DATA_MANIFEST.json', 'FROZEN.json', 'CONFIG.json', 'BOOTSTRAP.npz', 'PREDICTIONS.npz']
    before = {name: sha(ROOT/name) for name in required}
    result = load('RESULT.json'); audit = load('AUDIT.json'); dev = load('DEV_RESULTS.json')
    selection = load('SELECTION.json'); final_val = load('FINAL_VAL_RESULTS.json')
    training = load('TRAINING_COMPLETE.json'); smoke = load('SMOKE_CHECK.json')
    data = load('DATA_MANIFEST.json'); frozen = load('FROZEN.json'); config = load('CONFIG.json')
    assert audit['status'] == 'PASS_AUDIT', 'Do not publish an unaudited result as final'
    assert all(audit['checks'].values()), audit['checks']
    assert result['status'] in ['PASS_PILOT', 'FAIL_PILOT']
    assert result['arms'] == ARMS and result['seeds'] == config['final_seeds']
    assert result['primary_controls'] == config['primary_controls'] == ['head9', 'cldice_head9']
    assert len(dev) == 30 and len(final_val) == 15
    assert training['backbone_steps'] == 62800 and training['head_only_steps'] == 6800
    assert training['total_weights'] == len(training['checkpoint_hashes']) == 50
    assert smoke['status'] == 'PASS_SMOKE_CHECK' and smoke['actual_skeleton_iterations'] == config['cldice_iterations'] == 24
    assert sha(ROOT/'SELECTION.json') == training['selection_sha256']
    assert sha(ROOT/'FROZEN.json') == training['frozen_sha256']
    assert sha(ROOT/'PROTOCOL.md') == frozen['protocol_sha256']
    assert sha(ROOT/'CONFIG.json') == frozen['config_sha256']
    assert sha(ROOT/'DATA_MANIFEST.json') == frozen['manifest_sha256']
    assert sha(ROOT/'PREDICTIONS.npz') == result['predictions_sha256']
    assert sha(ROOT/'BOOTSTRAP.npz') == result['bootstrap_sha256']
    for name, value in frozen['source_sha256'].items():
        assert sha(ROOT/name) == value, name
    for family in ['head9', 'cldice_head9']:
        comparison = result['soft_minus_control'][family]
        actual_gates = {
            'gain_at_least_one_pp': comparison['delta'] >= config['minimum_F1_gain'],
            'positive_CI_lower': comparison['CI95'][0] > 0,
            'IoU_guard': comparison['IoU_delta'] >= -config['maximum_IoU_drop'],
        }
        assert actual_gates == comparison['gates']
    passed = all(all(value['gates'].values()) for value in result['soft_minus_control'].values())
    assert passed == (result['status'] == 'PASS_PILOT')
    with np.load(ROOT/'BOOTSTRAP.npz', allow_pickle=False) as z:
        geometry_names = z['geometry_metric_names'].tolist()
        geometry_per_seed = z['geometry_numerators'].sum(2) / z['geometry_denominators'].sum(2)
    figures(result, geometry_per_seed, geometry_names)
    write_csv('dev_results.csv', dev)
    write_csv('val_configurations.csv', selection['all_VAL_configurations'])
    write_csv('final_val_results.csv', final_val)
    test_rows = []
    geometry_rows = []
    for a, family in enumerate(ARMS):
        metric = result['metrics'][family]
        for s, seed in enumerate(result['seeds']):
            test_rows.append({'seed': seed, 'family': family,
                'mask_F1': metric['per_seed_mask_F1'][s], 'IoU': metric['per_seed_IoU'][s],
                'direct_head_F1': metric.get('per_seed_direct_head_F1', [None]*5)[s]})
            for k, name in enumerate(geometry_names):
                geometry_rows.append({'seed': seed, 'family': family, 'metric': name,
                                      'value': float(geometry_per_seed[s, a, k]), 'scope': 'secondary_descriptive'})
        for name in geometry_names:
            geometry_rows.append({'seed': 'mean', 'family': family, 'metric': name,
                                  'value': metric['geometry'][name], 'scope': 'secondary_descriptive'})
    write_csv('final_test_results.csv', test_rows)
    write_csv('secondary_geometry.csv', geometry_rows)
    write_csv('secondary_geometry_comparisons.csv', [
        {'control': family, 'metric': name, 'improvement': value['improvement'],
         'CI95_lower': value['CI95'][0], 'CI95_upper': value['CI95'][1], 'scope': value['status']}
        for family, values in result['secondary_geometry'].items() for name, value in values.items()])
    results_table = ['| Метод | Macro-F1 класса из маски, % | IoU, % | Прямая голова: F1, % |',
                     '|---|---:|---:|---:|']
    selection_table = ['| Метод | Вес головы h | Вес clDice c | Вес физики p | VAL F1, % | VAL IoU, % |',
                       '|---|---:|---:|---:|---:|---:|']
    for family in ARMS:
        metric = result['metrics'][family]; settings = selection['chosen'][family]
        direct = fmt(metric['direct_head_F1']) if 'direct_head_F1' in metric else '—'
        results_table.append(f'| {NAMES[family]} | {fmt(metric["mask_F1"])} | {fmt(metric["IoU"])} | {direct} |')
        selection_table.append(f'| {NAMES[family]} | {settings["head_weight"]:g} | {settings["cldice_weight"]:g} | '
            f'{settings["physics_weight"]:g} | {fmt(settings["mask_F1"])} | {fmt(settings["IoU"])} |')
    comparisons_table = ['| Контроль | Наш метод − контроль, п.п. F1 | 95%-интервал, п.п. | Разность IoU, п.п. | ≥1 п.п. F1 | Нижняя CI >0 | IoU ≥−2 п.п. |',
                         '|---|---:|---|---:|---|---|---|']
    failed = []
    gate_labels = {'gain_at_least_one_pp': 'выигрыш F1 минимум 1 п.п.',
                   'positive_CI_lower': 'положительная нижняя граница интервала',
                   'IoU_guard': 'ограничение ухудшения IoU'}
    for family in ['head9', 'cldice_head9']:
        comparison = result['soft_minus_control'][family]
        gates = comparison['gates']
        flags = [('PASS' if gates[name] else 'FAIL') for name in gate_labels]
        comparisons_table.append(f'| {NAMES[family]} | {fmt(comparison["delta"],signed=True)} | '
            f'{interval(comparison["CI95"])} | {fmt(comparison["IoU_delta"],signed=True)} | '+ ' | '.join(flags)+' |')
        failed.extend(f'{NAMES[family]}: {label}' for key, label in gate_labels.items() if not gates[key])
    seed_table = ['| Seed | Голова 9: F1, % | clDice + голова: F1, % | Наш метод: F1, % | Δ к голове 9, п.п. | Δ к clDice, п.п. |',
                  '|---:|---:|---:|---:|---:|---:|']
    for s, seed in enumerate(result['seeds']):
        metric = result['metrics']
        seed_table.append(f'| {seed} | {fmt(metric["head9"]["per_seed_mask_F1"][s])} | '
            f'{fmt(metric["cldice_head9"]["per_seed_mask_F1"][s])} | {fmt(metric["soft"]["per_seed_mask_F1"][s])} | '
            f'{fmt(result["soft_minus_control"]["head9"]["per_seed_deltas"][s],signed=True)} | '
            f'{fmt(result["soft_minus_control"]["cldice_head9"]["per_seed_deltas"][s],signed=True)} |')
    geometry_table = ['| Вторичный показатель | Голова 9 | clDice + голова | Наш метод |', '|---|---:|---:|---:|']
    for name in geometry_names:
        label, unit, factor = GEOMETRY_LABELS[name]
        places = 3 if factor == 100 else 5
        geometry_table.append('| '+label+' ('+unit+') | '+ ' | '.join(
            fmt(result['metrics'][family]['geometry'][name], factor, places) for family in ARMS)+' |')
    geometry_ci_table = ['| Контроль | Показатель | Улучшение | Номинальный 95%-интервал |', '|---|---|---:|---|']
    for family in ['head9', 'cldice_head9']:
        for name in geometry_names:
            label, unit, factor = GEOMETRY_LABELS[name]
            value = result['secondary_geometry'][family][name]
            geometry_ci_table.append(f'| {NAMES[family]} | {label} | '
                f'{fmt(value["improvement"],factor,3 if factor==100 else 5,signed=True)} | '
                f'{interval(value["CI95"],factor,3 if factor==100 else 5)} |')
    if passed:
        verdict = ('Заранее заданный критерий выполнен против обоих контролей. '
                   'На новых кадрах этого чипа результат поддерживает дополнительную пользу '
                   'резисторной регуляризации относительно головы и проверенной конфигурации clDice.')
        reasons = 'Невыполненных обязательных условий нет.'
    else:
        verdict = ('Заранее заданный критерий преимущества резисторной регуляризации против обоих '
                   'контролей не выполнен. Этот опыт не подтверждает заявленное преимущество '
                   'перед всеми сравниваемыми вариантами; предыдущие результаты сохраняются отдельно.')
        reasons = 'Не выполнены условия:\n\n'+'\n'.join('- '+item+'.' for item in failed)
    counts_table = ['| Класс (LR, TB) | Фрагментов TEST |', '|---|---:|']
    counts_table += [f'| {k} ({k//3}, {k%3}) | {count} |' for k, count in enumerate(result['test_class_counts'])]
    download = load('DOWNLOAD.json')
    timing = {name: execution_timing(name) for name in ['train', 'evaluate', 'audit']}
    time_rows = ['| Этап | Измеренное время, с | Источник |', '|---|---:|---|',
        f'| Успешная загрузка 8 новых кадров | {download["seconds"]:.2f} | DOWNLOAD.json |',
        f'| Подготовка действующих данных | {data["seconds"]:.2f} | DATA_MANIFEST.json |',
        f'| Техническая проверка 24 итераций | {smoke["seconds"]:.2f} | SMOKE_CHECK.json |',
        f'| Обучение, включая подбор и прогревы | {training["seconds"]:.2f} | TRAINING_COMPLETE.json |',
        f'| TEST, геометрия и bootstrap | {result["seconds"]:.2f} | RESULT.json |',
        f'| Независимый аудит | {audit["seconds"]:.2f} | AUDIT.json |']
    for name, value in timing.items():
        if value is not None:
            time_rows.append(f'| Полный процесс {name}, включая запуск Python | {value["seconds"]:.2f} | {name.upper()}_EXECUTION.json |')
    time_chronology = ''
    if timing['train'] and timing['audit']:
        begin = datetime.datetime.fromisoformat(timing['train']['start_Moscow'])
        end = datetime.datetime.fromisoformat(timing['audit']['end_Moscow'])
        time_chronology = (f'По меткам исполнения: начало обучения {begin:%H:%M:%S}, '
            f'окончание аудита {end:%H:%M:%S} по Москве; между ними '
            f'{(end-begin).total_seconds()/60:.2f} мин, включая паузы между этапами.')
    holes = result['truth_hole_histogram']
    holes_note = ('Во всех тестовых эталонах нет отверстий; показатель отверстий измеряет только '
                  'их ложное появление и не проверяет сохранение настоящих отверстий.'
                  if set(holes) == {'0'} else
                  'Распределение числа отверстий эталона: '+json.dumps(holes, ensure_ascii=False)+'.')
    report = f'''# Сравнение резисторной регуляризации с clDice

30 октября 2026 года. **{result['status']}**. Технический аудит: **{audit['status']}**.

{verdict}

## Что проверялось

Один и тот же сегментатор, **54 плотные маски**, **1152 дополнительных изображения
с геометрическими классовыми метками**, **695 VAL-фрагментов**. Три метода:
обычная классификационная голова, та же голова с soft-clDice на плотных масках
и непрерывная резисторная регуляризация на слабых классах.

Основной показатель всех методов — Macro-F1 девяти модельных геометрических
классов, вычисленных из **бинарной предсказанной маски**. Это не типы
подтверждённых производственных дефектов и не измеренная проводимость ИС.

TEST: **{result['test_examples']} фрагмент**, восемь новых кадров
{', '.join(map(str,result['test_frames']))}; пять новых seed:
{', '.join(map(str,result['seeds']))}. Все кадры относятся к одному физическому
чипу, поэтому это не внешняя межчиповая репликация.

## Основные результаты

{chr(10).join(results_table)}

![Macro-F1 и IoU всех методов и пяти запусков](figures/comparison.png)

Прямые выходы голов приведены отдельно как вторичная практическая оценка.
Головы и веса подбирались по классу **из сегментации**, поэтому прямые головы
не являются отдельно оптимизированным сильнейшим классификатором.

## Заранее заданное решение

Для PASS требовались одновременно против **head9 и cldice_head9**:
выигрыш не менее 1 п.п. Macro-F1, положительная нижняя граница каждого
парного 95%-интервала и ухудшение IoU не более 2 п.п. Все условия обязательны.
Контроли не переизбирались по TEST; решения рассчитаны без округления.

{chr(10).join(comparisons_table)}

{reasons}

![Парные сравнения и проверка каждого условия](figures/paired_comparisons.png)

Интервалы получены 4000 парными пересэмплированиями исходных кадров и seed.
Матрицы ошибок сначала объединяются по выбранным кадрам, затем считается
Macro-F1 каждого выбранного seed и их среднее. Фрагменты и повторные обучения
не объявляются независимыми изделиями. Интервалы характеризуют ограниченный
набор восьми кадров и пяти запусков одного чипа.

## Каждый итоговый запуск

{chr(10).join(seed_table)}

Все пять запусков включены, последние веса сохранены. Итоговые VAL-оценки
публикуются, но не используются для смены параметров или длительности.

## Выбор параметров и равноправность сравнения

{chr(10).join(selection_table)}

Два разработочных seed:3011,3041; по1000 шагов на конфигурацию.
head9 и soft проверили по3 веса0.1/0.4/1.0; clDice —9 комбинаций веса
головы и веса связностной потери. Все30 разработочных обучений сохранены.
У clDice больший бюджет поиска; равный суммарный бюджет подбора не заявляется.
Выбранные веса головы и clDice равны1 — верхней границе проверенной сетки.
Поэтому сравнение относится к зафиксированному диапазону подбора; возможность
усилить контроль при более широком поиске этим опытом не исключена.
Выбор: средний VAL Macro-F1, затем IoU, затем меньший вес головы/физики,
затем меньший вес clDice. Все семейства прошли допуск VAL≥0.45 до TEST.

Каждый итоговый seed имеет общий400-шаговый BCE-прогрев; три метода
стартуют с одинаковых весов и видят одинаковые индексы батчей. Две головы
имеют одинаковую инициализацию и по200 дополнительных head-only шагов
на замороженных признаках. У soft этих шагов и дополнительных параметров
головы нет: равенство ёмкости и полного времени вычислений не заявляется.
Основное дообучение —2000 шагов у всех методов, AdamW,lr0.001,wd0.0001,
batch16 плотных +16 слабых. Всего62800 обновлений сегментатора,
6800 обновлений только голов и50 checkpoint:30 DEV,15 FINAL,5 FINAL-base.

clDice получает только54 плотные маски. У1152 дополнительных примеров
классовые метки доступны обоим головам и физике, а их маски не передаются
оптимизатору. Тренер открывает отдельный TRAIN_VAL.npz без TEST-тензоров.
Слабые метки исторически вычислены из SVG; экономия стоимости реальной
производственной разметки этим опытом не установлена.

## clDice: техническая поправка до обучения

Авторские файлы зафиксированы без изменений, commit
47d31a6cc4a8101b1ffe8052994821961e57af9f, лицензия и SHA сохранены.
На54 плотных TRAIN-масках скелетизация10и24 итерациями различалась
в7 случаях. До любого обучения протокол обновлён до версии2:
фабрика задаёт24 итерации через поле объекта; исходный авторский код
не исправляется. Это документировано в [поправке](AMENDMENT_01.md),
а [первая версия протокола](PROTOCOL_v1_before_skeleton_check.md) сохранена.

Результат24 итераций совпал с32 на всех54 TRAIN-масках; все их скелеты
непусты. Для синтетических дорожек, разрывов, перемычек и пустого прогноза
проверены потери и градиенты. При нулевом весе clDice голова и сегментатор
воспроизводят обычный head9 точно. smooth=1, единственный канал металла,
exclude_background=False; используется авторское пакетное суммирование.
Обычная Dice loss отдельно не добавлялась.

У полностью заполненной маски авторский мягкий скелет пуст; полностью
пустые и полные эталоны исключены прежней неизменной предобработкой.
clDice не объявляется математической гарантией сохранения наших конкретных
граничных путей на всех возможных изображениях.

## Вторичные геометрические показатели

{chr(10).join(geometry_table)}

![Типы геометрических ошибок всех трёх методов](figures/geometry_errors.png)

Разрыв — потеря четырёхсвязного пути между противоположными сторонами маски,
ложное соединение — появление пути при его отсутствии в эталоне. Это ошибки
масок фрагментов, а не установленный физический обрыв или короткое замыкание.
Знаменатель разрывов и неверных ненулевых градаций — все эталонные направления
с путём; ложных соединений — все эталонные направления без пути.
Ошибка наличия пути на фрагменте — наличие хотя бы одной такой ошибки в LR/TB.
Компоненты металла четырёхсвязны, фон для отверстий восьмисвязен;
компоненты фона, касающиеся края, отверстиями не считаются.

{holes_note}

{chr(10).join(geometry_ci_table)}

Положительное улучшение = «контроль − soft» для ошибок и «soft − контроль»
для точного числа компонент. Для процентов разность выражена в п.п.,
для MAE — в единицах счётчика на фрагмент. Эти интервалы номинальные,
исследовательские, без поправки на множественные показатели. Они не меняют
основной PASS/FAIL и не являются доказательством причинного механизма.

## Данные, время и аудит

{chr(10).join(counts_table)}

Новые кадры выбраны детерминированно до скачивания. По краям исключено512
нативных пикселей; изображение усреднено4×4, SVG-маска уменьшена по большинству;
размер фрагмента12×12, шаг6. Исключены точные D4-эквиваленты бинарных мотивов
и полутоновых сумм относительно всех прежних записей, включая старый TEST,
и между новыми кадрами. Это не исключает близких мотивов и пространственной
зависимости одного чипа. TRAIN/VAL переиспользованы побайтно, без нового отбора.

{chr(10).join(time_rows)}

{time_chronology}

Строки измерений внутри этапа и полного процесса описывают одно исполнение
и не складываются друг с другом. Время загрузки относится к успешной попытке;
предыдущие неудачные сетевые попытки сохранены отдельно. Подготовка кода,
поправки протокола и ожидания между действиями не входят во внутренние таймеры.
Предыдущий короткий замер был сделан с10 итерациями; его оценка обучения
не переносится напрямую на усиленный24-итерационный контроль. Фактическое
время указано в таблице выше. Это время всего эксперимента, не задержка
обработки одного изображения и не доказательство ускорения метода.

Аудит проверил происхождение и SHA, отдельный TRAIN_VAL, разбиение и D4,
выбор по VAL, F1 через sklearn, IoU из масок, все bootstrap-повторы другим
способом, геометрические показатели и CPU/MPS-прогнозы.
Максимальное расхождение F1:{audit['independent_sklearn_F1_max_error']:.3g},
IoU:{audit['independent_IoU_max_error']:.3g},
bootstrap:{audit['independent_bootstrap_max_error']:.3g},
вероятностей CPU/MPS:{audit['CPU_MPS_max_probability_error']:.3g}.
Технический PASS_AUDIT не подменяет научный PASS_PILOT/FAIL_PILOT.

Ограничения: один чип, очень малая CNN,12×12, геометрические классы по SVG.
Измеренных электрических параметров, независимых меток производственных
дефектов, проверки мирового приоритета или гарантии публикации здесь нет.

## Сохранённые материалы

- [Протокол](PROTOCOL.md), [параметры](CONFIG.json), [поправка](AMENDMENT_01.md),
  [технические проверки](SMOKE_CHECK.json), [данные и происхождение](DATA_MANIFEST.json).
- [Все результаты](RESULT.json), [аудит](AUDIT.json), [зафиксированные входы](FROZEN.json),
  [выбор по VAL](SELECTION.json), [завершение обучения](TRAINING_COMPLETE.json).
- [30 разработочных обучений](dev_results.csv), [15 конфигураций по VAL](val_configurations.csv),
  [итоговые VAL](final_val_results.csv), [все15 итоговых TEST-оценок](final_test_results.csv),
  [геометрия всех запусков](secondary_geometry.csv), [геометрические сравнения](secondary_geometry_comparisons.csv).
- [Скрипт подготовки](prepare.py), [обучение](train.py), [оценка](evaluate.py),
  [независимый аудит](audit.py), [графики и отчёт](report.py), [веса и SHA](CHECKPOINT_HASHES.json).

PREDICTIONS.npz содержит все классы, упакованные бинарные маски, IoU, выходы
голов и геометрию. BOOTSTRAP.npz содержит индексы повторов, матрицы ошибок
и показатели повторов. Архивы данных, исходные PNG/SVG и50 файлов весов сохранены.
'''
    report = re.sub(r'(?<=[А-Яа-яёЁ])(?=\d)|(?<=\d)(?=[А-Яа-яёЁ])', ' ', report)
    (ROOT/'REPORT.md').write_text(report, encoding='utf-8')
    (ROOT/'README.md').write_text(f'''# SEM: сравнение с clDice, 30 октября 2026

**{result['status']}**; независимый технический аудит **{audit['status']}**.

{verdict}

[Полный отчёт с числами, графиками и ограничениями](REPORT.md).

Сохранены исходники, протокол,54 плотные маски,1152 слабых примера,695 VAL,
{result['test_examples']} TEST-фрагмент восьми новых кадров одного чипа,50checkpoint
и все прогнозы. Пять итоговых запусков каждого метода; итоговые оценки не
использовались для смены параметров. Мировой приоритет и производственные
дефекты этим опытом не проверялись.

Код подготовки, обучения, оценки, аудита и построения отчёта лежит рядом.
Исторические результаты не перезаписывались. Перезапуск завершённых научных
стадий в этом каталоге запрещён защитами кода: для нового опыта нужен новый
каталог и отдельно зафиксированный протокол.

Прогресс и журнал сохранены:

```bash
cat gipoteza/sem_cldice_confirmation_20261030/PROGRESS.json
tail -n 20 gipoteza/sem_cldice_confirmation_20261030/progress.jsonl
```
''', encoding='utf-8')
    readme_path = ROOT/'README.md'
    readme_path.write_text(re.sub(r'(?<=[А-Яа-яёЁ])(?=\d)|(?<=\d)(?=[А-Яа-яёЁ])',
                                 ' ', readme_path.read_text(encoding='utf-8')), encoding='utf-8')
    assert before == {name: sha(ROOT/name) for name in required}, 'Scientific inputs changed during reporting'
    report_manifest = {
        'status': 'REPORT_COMPLETE', 'scientific_status': result['status'],
        'report_sha256': sha(ROOT/'REPORT.md'), 'result_sha256': sha(ROOT/'RESULT.json'),
        'audit_sha256': sha(ROOT/'AUDIT.json'), 'code_sha256': sha(Path(__file__)),
        'figures_sha256': {str(path.relative_to(ROOT)): sha(path) for path in sorted((ROOT/'figures').iterdir())},
        'csv_sha256': {path.name: sha(path) for path in sorted(ROOT.glob('*.csv'))},
        'input_sha256': before, 'scientific_inputs_unchanged': True,
        'seconds': time.monotonic()-started,
    }
    save_json(ROOT/'REPORT_MANIFEST.json', report_manifest)
    print(json.dumps({'status': report_manifest['status'], 'scientific_status': result['status'],
                      'audit': audit['status'], 'report': str(ROOT/'REPORT.md'),
                      'figures': len(report_manifest['figures_sha256']), 'seconds': report_manifest['seconds']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
