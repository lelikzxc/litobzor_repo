"""Freeze an untouched same-chip TEST and reuse the exact old TRAIN/VAL arrays."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import importlib.util
import json
import re
import struct
import time
import zipfile
import zlib

import numpy as np
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
OLD = G / 'sem_confirmation_20261028'
SHARED = G / 'shared_data/ic_sem_m2'
TEST = [233, 292, 17, 166, 319, 85, 202, 238]
PREFIX = 'SEM-CLDICE-20261030/'
URL = 'https://edmond.mpg.de/api/access/datafile/223856'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.partial')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def old_helper():
    spec = importlib.util.spec_from_file_location('sem_cldice_original_prepare_20261028', OLD / 'prepare.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    # In-memory path override only, never edits the old implementation.
    module.ROOT = ROOT
    return module


def class_labels(masks):
    return old_helper().class_labels(masks)


def remote_module():
    spec = importlib.util.spec_from_file_location('sem_cldice_public_remote', SHARED / 'sem_remote_zip.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def source_plan():
    assert (ROOT / 'PROTOCOL.md').exists(), 'Protocol must exist before new data access'
    source = json.loads((SHARED / 'SOURCE_MEMBERS.json').read_text())
    historical = {int(re.search(r'sem(\d+)\.png', row['path']).group(1)) for row in source['png_original_sources']}
    previous_test = set(json.loads((OLD / 'RESULT.json').read_text())['test_frames'])
    used = historical | previous_test
    assert len(historical) == 46 and len(used) == 54
    listing = json.loads((SHARED / 'sem_zip_listing.json').read_text())
    available = [int(match.group(1)) for row in listing
        if (match := re.fullmatch(r'dataset/sems/m2/sem(\d+)\.png', row['name']))
        and int(match.group(1)) not in used]
    available.sort(key=lambda i: hashlib.sha256((PREFIX + str(i)).encode()).hexdigest())
    assert available[:8] == TEST
    plan = {'test': TEST, 'train': list(range(6)), 'val': [6, 7],
        'selection_prefix': PREFIX, 'excluded_previous_frames': sorted(used),
        'protocol_sha256': sha(ROOT / 'PROTOCOL.md'), 'prepare_script_sha256': sha(Path(__file__)),
        'original_data_sha256': sha(OLD / 'DATA.npz'),
        'original_manifest_sha256': sha(OLD / 'DATA_MANIFEST.json'),
        'original_prepare_sha256': sha(OLD / 'prepare.py'),
        'shared_sha256': {n: sha(SHARED / n) for n in
             ['SOURCE_MEMBERS.json', 'labels.zip', 'sem_zip_listing.json', 'sem_remote_zip.py']},
        'remote_zip_url': URL, 'files': 8, 'maximum_png_bytes_each': 10_000_000,
        'scope': 'Fresh deterministic frames of the same IC. TRAIN/VAL identical to old pilot. Exclude old TEST motifs too.'}
    path = ROOT / 'SOURCE_PLAN.json'
    if path.exists():
        assert json.loads(path.read_text()) == plan, 'Frozen source plan changed'
    else:
        save(path, plan)
    return plan


def download():
    assert not (ROOT / 'DATA.npz').exists(), 'Prepared data already exists'
    plan = source_plan()
    (ROOT / 'sources').mkdir(exist_ok=True)
    start = time.monotonic()
    remote = remote_module()
    with zipfile.ZipFile(remote.RemoteZip()) as archive:
        infos = {i: archive.getinfo(f'dataset/sems/m2/sem{i:04}.png') for i in TEST}

    def fetch(frame):
        path = ROOT / 'sources' / f'sem{frame:04}.png'
        info = infos[frame]
        assert info.file_size <= 10_000_000 and info.compress_type == 0
        if path.exists():
            raw = path.read_bytes()
        else:
            last_error = None
            for attempt in range(1, 4):
                try:
                    stream = remote.RemoteZip(); stream.seek(info.header_offset)
                    block = stream.read(min(30 + len(info.filename.encode()) + 2048 + info.file_size,
                                            remote.SIZE - info.header_offset))
                    header = struct.unpack('<4s5H3L2H', block[:30])
                    assert header[0] == b'PK\x03\x04'
                    size_name, size_extra = header[-2:]
                    assert block[30:30 + size_name].decode() == info.filename
                    offset = 30 + size_name + size_extra
                    raw = block[offset:offset + info.file_size]
                    assert len(raw) == info.file_size and zlib.crc32(raw) == info.CRC
                    break
                except Exception as error:
                    last_error = error
                    print(json.dumps({'stage': 'DOWNLOAD_RETRY', 'frame': frame,
                                      'attempt': attempt, 'error': str(error)}), flush=True)
            else:
                raise RuntimeError(f'Unable to fetch fixed frame {frame}') from last_error
            temporary = path.with_suffix('.png.partial'); temporary.write_bytes(raw); temporary.replace(path)
        assert len(raw) == info.file_size and zlib.crc32(raw) == info.CRC
        return {'frame': frame, 'file': str(path.relative_to(ROOT)),
                'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'crc32': info.CRC}

    files = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(fetch, i): i for i in TEST}
        for future in as_completed(futures):
            row = future.result(); files.append(row)
            progress = {'stage': 'DOWNLOAD', 'completed': len(files), 'total': 8,
                        'seconds': time.monotonic() - start, 'files': sorted(files, key=lambda x:x['frame'])}
            save(ROOT / 'DOWNLOAD_PROGRESS.json', progress)
            print(json.dumps({'stage': 'DOWNLOAD', 'completed': len(files), 'total': 8, **row}), flush=True)
    with zipfile.ZipFile(SHARED / 'labels.zip') as archive:
        for frame in TEST:
            raw = archive.read(f'dataset/labels/m2/label{frame:04}.svg')
            path = ROOT / 'sources' / f'label{frame:04}.svg'
            if path.exists():
                assert path.read_bytes() == raw
            else:
                path.write_bytes(raw)
    assert sha(ROOT / 'PROTOCOL.md') == plan['protocol_sha256']
    save(ROOT / 'DOWNLOAD.json', {'status': 'COMPLETE', 'files': sorted(files,key=lambda x:x['frame']),
        'seconds': time.monotonic() - start, 'plan_sha256': sha(ROOT / 'SOURCE_PLAN.json')})


def prepare():
    assert not (ROOT / 'DATA.npz').exists(), 'Refuse overwrite completed data'
    assert json.loads((ROOT / 'DOWNLOAD.json').read_text())['status'] == 'COMPLETE'
    plan = source_plan()
    start = time.monotonic()
    old_manifest = json.loads((OLD / 'DATA_MANIFEST.json').read_text())
    old_records = old_manifest['records']
    with np.load(OLD / 'DATA.npz', allow_pickle=False) as old:
        inherited_ids = np.flatnonzero(old['role'] != 'test')
        trainval = {key: old[key][inherited_ids].copy() for key in ['X','Y','label','role','frame']}
    assert len(inherited_ids) == 1901
    inherited_records = [old_records[int(i)].copy() for i in inherited_ids]
    assert {role:int((trainval['role']==role).sum()) for role in ['dense','weak','val']} == {'dense':54,'weak':1152,'val':695}
    np.savez_compressed(ROOT / 'TRAIN_VAL.npz', **trainval)
    # Reject exact old TEST motifs too; TRAIN/VAL remain unmodified inherited rows.
    used_mask = {row['canonical_D4'] for row in old_records}
    used_raw = {row['raw_D4_sha256'] for row in old_records}
    helper = old_helper()
    rows = []; test_x = []; test_y = []; test_labels = []
    counters = {}; dedup_counts = {}
    for frame in TEST:
        x, y, coordinates = helper.patches(frame)
        keys = helper.canonical_keys(y)
        raw_keys = helper.canonical_keys(x, raw=True)
        kept = []; records = []; duplicates = 0
        for i, (key, rawkey) in enumerate(zip(keys,raw_keys)):
            canonical = key.hex(); rawhash = hashlib.sha256(rawkey).hexdigest()
            if canonical in used_mask or rawhash in used_raw:
                duplicates += 1
                continue
            used_mask.add(canonical); used_raw.add(rawhash); kept.append(i)
            records.append({'frame': frame, 'y': int(4*coordinates[i,0]+512),
                'x': int(4*coordinates[i,1]+512), 'canonical_D4': canonical,
                'raw_D4_sha256': rawhash, 'role': 'test'})
        ids = np.array(kept,dtype=np.int64)
        labels = helper.class_labels(y[ids])
        for row, label in zip(records, labels): row['label'] = int(label)
        rows.extend(records)
        test_x.extend(x[ids].astype(np.float32)/(16*255)); test_y.extend(y[ids]); test_labels.extend(labels)
        counters[str(frame)] = np.bincount(labels,minlength=9).tolist()
        dedup_counts[str(frame)] = {'candidate_patches':len(x),'excluded_duplicates':duplicates,'kept':len(ids)}
        save(ROOT / 'PREPARE_PROGRESS.json', {'stage':'PREPARE_TEST', 'frame':frame,
            'completed_frames':len(counters),'total_frames':8,'unique_test_patches':len(rows),
            'seconds':time.monotonic()-start})
        print(json.dumps({'stage':'PREPARE_TEST','frame':frame,'unique_test_patches':len(rows),
                          'class_counts':counters[str(frame)],'seconds':time.monotonic()-start}),flush=True)
    counts = np.bincount(test_labels,minlength=9)
    class_frames = {str(c): sorted({row['frame'] for row in rows if row['label']==c}) for c in range(9)}
    gates = {'min_16_each_class':bool(min(counts)>=16),
             'min_4_frames_each_class':all(len(v)>=4 for v in class_frames.values())}
    if not all(gates.values()):
        failed = {'status':'FAIL_DATA_GATE','test_class_counts':counts.tolist(),
                  'test_class_frames':class_frames,'gates':gates,'frames':TEST,
                  'scope':'Fixed TEST gate failed, no frame replacement or learning permitted.'}
        save(ROOT / 'FAIL_DATA_GATE.json',failed)
        raise RuntimeError(json.dumps(failed))
    test = {'X':np.array(test_x,dtype=np.float32)[:,None],
            'Y':np.array(test_y,dtype=np.uint8)[:,None],
            'label':np.array(test_labels,dtype=np.int64),
            'role':np.array(['test']*len(rows)),
            'frame':np.array([row['frame'] for row in rows],dtype=trainval['frame'].dtype)}
    np.savez_compressed(ROOT / 'TEST.npz',**test)
    combined = {key:np.concatenate((trainval[key],test[key])) for key in trainval}
    np.savez_compressed(ROOT / 'DATA.npz',**combined)
    records = inherited_records+rows
    assert len(records)==len(combined['X'])
    assert len({r['canonical_D4'] for r in records})==len(records)
    assert len({r['raw_D4_sha256'] for r in records})==len(records)
    assert not set(trainval['frame'])&set(test['frame'])
    assert not {r['canonical_D4'] for r in rows}&{r['canonical_D4'] for r in old_records}
    assert not {r['raw_D4_sha256'] for r in rows}&{r['raw_D4_sha256'] for r in old_records}
    with np.load(ROOT/'TRAIN_VAL.npz',allow_pickle=False) as tv, np.load(OLD/'DATA.npz',allow_pickle=False) as old:
        assert all(np.array_equal(tv[k],old[k][inherited_ids]) for k in trainval)
    assert sha(ROOT/'PROTOCOL.md')==plan['protocol_sha256']
    assert sha(OLD/'DATA.npz')==plan['original_data_sha256']
    assert sha(OLD/'DATA_MANIFEST.json')==plan['original_manifest_sha256']
    source_hashes = {str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'sources').iterdir()) if p.is_file()}
    inherited_sources = {name:h for name,h in old_manifest['sources_sha256'].items()
                        if int(re.search(r'(?:sem|label)(\d+)\.',Path(name).name).group(1))<8}
    manifest = {'status':'PASS_DATA_GATE',
        'split_counts':{role:int((combined['role']==role).sum()) for role in ['dense','weak','val','test']},
        'records':records,'sources_sha256':source_hashes,
        'inherited_source_files_sha256':inherited_sources,
        'inherited_source_root':str(OLD),
        'inherited_data_sha256':plan['original_data_sha256'],
        'inherited_manifest_sha256':plan['original_manifest_sha256'],
        'inherited_record_indices':inherited_ids.tolist(),
        'TRAIN_VAL_sha256':sha(ROOT/'TRAIN_VAL.npz'),'TEST_sha256':sha(ROOT/'TEST.npz'),
        'DATA_sha256':sha(ROOT/'DATA.npz'),'protocol_sha256':sha(ROOT/'PROTOCOL.md'),
        'prepare_script_sha256':sha(Path(__file__)),'source_plan_sha256':sha(ROOT/'SOURCE_PLAN.json'),
        'test_class_counts':counts.tolist(),'test_class_frames':class_frames,'test_frame_class_counts':counters,
        'deduplication':dedup_counts,'gates':gates,
        'exact_old_train_val_reused':True,'old_TEST_motifs_excluded':True,
        'seconds':time.monotonic()-start,
        'scope':'New held-out frames of same chip; exact inherited TRAIN/VAL; all old and new D4/raw duplicates excluded.'}
    save(ROOT/'DATA_MANIFEST.json',manifest)
    print(json.dumps({k:v for k,v in manifest.items() if k not in ['records','sources_sha256','inherited_source_files_sha256','inherited_record_indices']},ensure_ascii=False),flush=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(); parser.add_argument('stage',choices=['plan','download','prepare'])
    args=parser.parse_args()
    with threadpool_limits(limits=2):
        if args.stage=='plan': print(json.dumps(source_plan(),ensure_ascii=False),flush=True)
        elif args.stage=='download': download()
        else: prepare()
