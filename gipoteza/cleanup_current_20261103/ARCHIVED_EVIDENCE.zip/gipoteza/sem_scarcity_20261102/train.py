"""Scarcity experiment: prespecified TRAIN/VAL-only tuning and FINAL training.

Only main() launches training. Importing helpers is safe for the evaluator and
the technical smoke checks. All weight selection uses the fixed VAL split.
"""
from pathlib import Path
import hashlib
import itertools
import json
import os
import sys
import time

# This must be configured before importing torch. An unsupported operation
# should fail explicitly rather than change the planned device silently.
os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '0'

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
OLD = G / 'sem_cldice_confirmation_20261030'
from physics_adapter import make_segmenter, geometry_loss
from vendor.cldice import soft_cldice

CONFIG = json.loads((ROOT / 'CONFIG.json').read_text())
DEV_SEEDS = CONFIG['dev_seeds']
SEEDS = CONFIG['final_seeds']
ARMS = CONFIG['arms']
THRESHOLDS = CONFIG['thresholds']
BASE_STEPS = CONFIG['base_steps']
DEV_STEPS = CONFIG['dev_steps']
FINAL_STEPS = CONFIG['final_steps']
HEAD_WARM_STEPS = CONFIG['head_warm_steps']
BATCH_SIZE = CONFIG['batch_size']
CLDICE_ITERATIONS = CONFIG['cldice_iterations']
TOTAL = CONFIG['total_backbone_updates']
TOTAL_HEAD = CONFIG['total_head_updates']
START = None
COMPLETED = 0
HEAD_COMPLETED = 0
CLASS_CACHE = {}
CONTEXT = {}
from baselines import tube_targets, dense_auxiliary_loss


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.partial')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def progress(**details):
    record = dict(seconds=None if START is None else time.monotonic() - START,
                  completed_backbone_steps=COMPLETED, total_backbone_steps=TOTAL,
                  completed_head_only_steps=HEAD_COMPLETED,
                  total_head_only_steps=TOTAL_HEAD, **CONTEXT, **details)
    save(ROOT / 'PROGRESS.json', record)
    with (ROOT / 'progress.jsonl').open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + '\n')
    print(json.dumps(record, ensure_ascii=False), flush=True)


def hard_classes(masks):
    """Cache exact historical binary-grid classes; never use soft conductance."""
    from prepare import class_labels
    masks = np.asarray(masks, dtype=bool).reshape(-1, 12, 12)
    keys = [row.tobytes() for row in np.packbits(masks.reshape(len(masks), -1), axis=1)]
    missing = sorted(set(keys) - CLASS_CACHE.keys())
    if missing:
        values = np.array([np.unpackbits(np.frombuffer(key, dtype=np.uint8)).reshape(12, 12)
                           for key in missing], dtype=bool)
        CLASS_CACHE.update(zip(missing, class_labels(values).tolist()))
    return np.array([CLASS_CACHE[key] for key in keys], dtype=np.int64)


def make_head(family='head9'):
    assert family in ['head9', 'cldice_head9', 'dice_head9', 'skelrec_head9'], family
    return nn.Sequential(nn.Linear(3456, 64), nn.GELU(), nn.Linear(64, 9))


def head_classes(logits, family='head9'):
    assert family in ['head9', 'cldice_head9', 'dice_head9', 'skelrec_head9'], family
    return logits.argmax(1)


def head_loss(logits, targets, family='head9'):
    assert family in ['head9', 'cldice_head9', 'dice_head9', 'skelrec_head9'], family
    return F.cross_entropy(logits, targets)


def make_cldice():
    """Configure the unchanged author implementation with the frozen depth.

    The author's constructor hard-codes 10 iterations regardless of iter_.
    TRAIN-only technical checks require 24 here; set the public submodule
    property explicitly instead of changing the vendored source files.
    """
    loss = soft_cldice()
    loss.soft_skeletonize.num_iter = CLDICE_ITERATIONS
    return loss


def configuration(family, weight, cldice_weight=0.):
    weight = float(weight); cldice_weight = float(cldice_weight)
    assert family in ARMS
    token = lambda v: f'{v:g}'.replace('.', 'p')
    return dict(family=family, weight=weight,
        head_weight=0. if family == 'soft' else weight,
        cldice_weight=cldice_weight,
        dice_weight=1. if family in ['dice_head9', 'skelrec_head9'] else 0.,
        skelrec_weight=1. if family == 'skelrec_head9' else 0.,
        physics_weight=weight if family == 'soft' else 0.,
        config_id=f'{family}_w{token(weight)}_c{token(cldice_weight)}')


def configurations(arm=None):
    out = [configuration('head9', w) for w in [.4, 2., 4.]]
    out += [configuration('cldice_head9', h, c) for h, c in [(2., .4), (2., 1.), (4., 1.)]]
    out += [configuration(family, w) for family in ['dice_head9', 'skelrec_head9'] for w in [.4, 2., 4.]]
    out += [configuration('soft', w) for w in [.1, .4, 1.]]
    assert len(out) == 15
    return out if arm is None else [setting for setting in out if setting['family'] == arm]


def selection_rank(row):
    return (row['mask_F1'], row['IoU'], -abs(row['threshold']-.5),
            -row['head_weight'], -(row['cldice_weight']+row['dice_weight']+row['skelrec_weight']+row['physics_weight']),
            -row['threshold'])


def prepare_subsets():
    with np.load(ROOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        ids = np.flatnonzero(archive['role'] == 'dense')
        labels = archive['label']
        assert len(ids) == 54 and np.array_equal(np.bincount(labels[ids], minlength=9), np.full(9,6))
    subsets = {}
    for stage, draws in [('dev',CONFIG['dev_subset_seeds']), ('final', CONFIG['final_subset_seeds'])]:
        subsets[stage] = {'18':{},'27':{},'54':{'0':ids.tolist()}}
        for draw in draws:
            rng = np.random.default_rng(draw)
            by_class = [rng.permutation(ids[labels[ids] == c]) for c in range(9)]
            for budget, count in [(18,2),(27,3)]:
                chosen = np.sort(np.concatenate([group[:count] for group in by_class]))
                subsets[stage][str(budget)][str(draw)] = chosen.tolist()
                assert np.array_equal(np.bincount(labels[chosen], minlength=9), np.full(9,count))
            assert set(subsets[stage]['18'][str(draw)]) <= set(subsets[stage]['27'][str(draw)]) <= set(ids)
    result = dict(train_val_sha256=sha(ROOT/'TRAIN_VAL.npz'),
        index_space='global row indices in TRAIN_VAL.npz; weak and val unchanged', subsets=subsets)
    path = ROOT/'SUBSETS.json'
    if path.exists():
        assert json.loads(path.read_text()) == result, 'Do not change frozen subset assignment'
    else:
        save(path,result)
    return result


def load_training(device='mps'):
    # Only separate TRAIN/VAL archive is opened. Weak optimizer object has no mask/tube key.
    with np.load(ROOT/'TRAIN_VAL.npz',allow_pickle=False) as archive:
        roles = archive['role']; assert set(roles.tolist()) == {'dense','weak','val'}
        assert {role:int((roles==role).sum()) for role in set(roles)} == {'dense':54,'weak':1152,'val':695}
        data = {}
        for role in ['dense','weak','val']:
            ids = np.flatnonzero(roles==role)
            data[role] = dict(x=torch.tensor(5*(archive['X'][ids]-.2),device=device),
                              label=torch.tensor(archive['label'][ids],device=device))
            if role != 'weak':
                data[role]['mask'] = torch.tensor(archive['Y'][ids].astype(np.float32),device=device)
            if role == 'dense':
                data[role]['global_indices'] = ids.copy()
                tubes = tube_targets(archive['Y'][ids])
                assert ((tubes <= archive['Y'][ids]).all() and (tubes.sum((1,2,3)) > 0).all())
                data[role]['tubes'] = torch.tensor(tubes,device=device)
    assert set(data['weak']) == {'x','label'}
    return data


def subset_data(full,budget,subset_seed,stage,subsets=None):
    subsets = prepare_subsets() if subsets is None else subsets
    indices = np.array(subsets['subsets'][stage][str(budget)][str(subset_seed)],dtype=int)
    dense = full['dense']; lookup = {int(g):i for i,g in enumerate(dense['global_indices'])}
    local = np.array([lookup[int(i)] for i in indices],dtype=int)
    selected = {key:(value[local] if key == 'global_indices' else value[torch.tensor(local,device=value.device)])
                for key,value in dense.items()}
    assert len(selected['x']) == budget
    return dict(dense=selected,weak=full['weak'],val=full['val'])


def evaluate(net, head, data, family):
    net.eval()
    if head is not None:
        head.eval()
    masks = []; direct = []
    with torch.inference_mode():
        for x in data['x'].split(256):
            if head is None:
                logits = net(x)
            else:
                features = net[:-1](x)
                logits = net[-1](features)
                direct.append(head_classes(head(features.flatten(1)), family).cpu().numpy())
            masks.append((logits[:, 0] >= 0).cpu().numpy())
    masks = np.concatenate(masks)
    truth = data['label'].cpu().numpy()
    target = data['mask'][:, 0].cpu().numpy().astype(bool)
    prediction = hard_classes(masks)
    union = (masks | target).sum((1, 2))
    iou = np.divide((masks & target).sum((1, 2)), union,
                    out=np.ones(len(union), dtype=float), where=union > 0)
    result = {
        'mask_F1': float(f1_score(truth, prediction, labels=range(9), average='macro', zero_division=0)),
        'IoU': float(iou.mean()),
        'direct_head_F1': None if head is None else float(f1_score(
            truth, np.concatenate(direct), labels=range(9), average='macro', zero_division=0)),
    }
    assert np.isfinite(result['mask_F1']) and np.isfinite(result['IoU'])
    net.train()
    if head is not None:
        head.train()
    return result


def base_model(seed, data):
    global COMPLETED
    torch.manual_seed(seed)
    net = make_segmenter().to('mps')
    assert sum(p.numel() for p in net.parameters()) == 10681
    opt = torch.optim.AdamW(net.parameters(), lr=.003, weight_decay=.0001)
    rng = np.random.default_rng(seed)
    started = time.monotonic()
    for step in range(1, BASE_STEPS + 1):
        ids = torch.tensor(rng.integers(0, len(data['x']), BATCH_SIZE), device='mps')
        opt.zero_grad(set_to_none=True)
        loss = F.binary_cross_entropy_with_logits(net(data['x'][ids]), data['mask'][ids])
        assert torch.isfinite(loss), (seed, 'base', step)
        loss.backward(); opt.step(); COMPLETED += 1
        if step % 100 == 0:
            progress(stage='base', seed=seed, step=step, target_steps=BASE_STEPS,
                     method_seconds=time.monotonic()-started)
    return {key: value.detach().cpu().clone() for key, value in net.state_dict().items()}


def train_method(seed, settings, steps, initial, data):
    global COMPLETED, HEAD_COMPLETED
    family = settings['family']
    setup_started = time.monotonic()
    # make_segmenter consumes random numbers, but all its weights are replaced.
    # Reset the generator AFTER creation to obtain identical head initialization
    # for head9 and cldice_head9 of every setting of the same seed.
    net = make_segmenter().to('mps')
    net.load_state_dict(initial)
    torch.manual_seed(seed + 3)
    head = None if family == 'soft' else make_head(family).to('mps')
    dense, weak = data['dense'], data['weak']
    head_initial_sha = None
    if head is not None:
        head_initial_sha = state_digest(head.state_dict())
        with torch.inference_mode():
            features = torch.cat([net[:-1](x).flatten(1) for x in weak['x'].split(128)]).clone()
        # Clone outside inference_mode to permit gradients for head parameters.
        features = features.clone()
        opt_head = torch.optim.AdamW(head.parameters(), lr=.003, weight_decay=.0001)
        rng_head = np.random.default_rng(seed + 700)
        for step in range(1, HEAD_WARM_STEPS + 1):
            wi = torch.tensor(rng_head.integers(0, len(weak['x']), BATCH_SIZE), device='mps')
            opt_head.zero_grad(set_to_none=True)
            loss = head_loss(head(features[wi]), weak['label'][wi], family)
            assert torch.isfinite(loss), (seed, family, 'head', step)
            loss.backward(); opt_head.step(); HEAD_COMPLETED += 1
        del features, opt_head
    head_after_warm_sha = None if head is None else state_digest(head.state_dict())
    setup_seconds = time.monotonic() - setup_started
    params = list(net.parameters()) + ([] if head is None else list(head.parameters()))
    opt = torch.optim.AdamW(params, lr=.001, weight_decay=.0001)
    rng = np.random.default_rng(seed + 10)
    loss_cldice = make_cldice()
    assert loss_cldice.soft_skeletonize.num_iter == CLDICE_ITERATIONS == 24
    started = time.monotonic()
    for step in range(1, steps + 1):
        # Both arrays are drawn for all arms, including soft, in the same order.
        ai = torch.tensor(rng.integers(0, len(dense['x']), BATCH_SIZE), device='mps')
        wi = torch.tensor(rng.integers(0, len(weak['x']), BATCH_SIZE), device='mps')
        opt.zero_grad(set_to_none=True)
        dense_logits = net(dense['x'][ai])
        loss = F.binary_cross_entropy_with_logits(dense_logits, dense['mask'][ai])
        if family == 'soft':
            labels = weak['label'][wi]
            direction = torch.stack((labels // 3, labels % 3), 1)
            loss = loss + settings['physics_weight'] * geometry_loss(net(weak['x'][wi]), direction)
        else:
            weak_features = net[:-1](weak['x'][wi])
            loss = loss + settings['head_weight'] * head_loss(
                head(weak_features.flatten(1)), weak['label'][wi], family)
            # Zero weight deliberately takes exactly the baseline code path.
            if settings['cldice_weight'] != 0:
                loss = loss + settings['cldice_weight'] * loss_cldice(
                    dense['mask'][ai], dense_logits.sigmoid())
            if family in ['dice_head9','skelrec_head9']:
                loss = loss + dense_auxiliary_loss(dense_logits,dense['mask'][ai],family,tubes=dense['tubes'][ai])
        assert torch.isfinite(loss), (seed, settings, step)
        loss.backward(); opt.step(); COMPLETED += 1
        if step % 100 == 0:
            elapsed = time.monotonic() - started
            progress(stage='train', seed=seed, **settings, step=step,
                     target_steps=steps, method_seconds=elapsed,
                     method_steps_per_second=step / elapsed)
    timing = {'seconds': time.monotonic() - started, 'setup_seconds': setup_seconds,
              'head_initial_sha256': head_initial_sha,
              'head_after_warm_sha256': head_after_warm_sha}
    return net, head, timing


def state_digest(state):
    digest = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        digest.update(key.encode()); digest.update(str(value.dtype).encode())
        digest.update(str(value.shape).encode()); digest.update(value.tobytes())
    return digest.hexdigest()


def checkpoint(path, net, head, **settings):
    payload = {
        'segmenter': {key: value.detach().cpu() for key, value in net.state_dict().items()},
        'head': None if head is None else {key: value.detach().cpu() for key, value in head.state_dict().items()},
        'settings': settings,
    }
    temporary = path.with_suffix(path.suffix + '.partial')
    torch.save(payload, temporary)
    temporary.replace(path)
    return sha(path)


def source_hashes():
    files = ['train.py','smoke.py','physics_adapter.py','prepare.py','baselines.py','VENDOR.json',
             'vendor/cldice.py','vendor/soft_skeleton.py',
             '../sem_physics_materials/physics_loss_example.py',
             '../sem_confirmation_20261028/prepare.py',
             '../retained_evidence_20261027/SELECTED_SOURCES.zip']
    files += [str(path.relative_to(ROOT)) for path in sorted((ROOT/'vendor_skelrec').rglob('*')) if path.is_file()]
    for name in ['BASELINE_PARITY.json','baseline_parity.py','BASELINES.md','BASELINE_SOURCE.json','VENDOR_SKELREC.json']:
        if (ROOT/name).exists():
            files.append(name)
    return {name:sha(ROOT/name) for name in files}


def evaluate_thresholds(net,head,data,family,thresholds=THRESHOLDS):
    net.eval()
    if head is not None:
        head.eval()
    probabilities = []; direct = []
    with torch.inference_mode():
        for batch in data['x'].split(256):
            if head is None:
                logits = net(batch)
            else:
                features = net[:-1](batch)
                logits = net[-1](features)
                direct.append(head(features.flatten(1)).argmax(1).cpu().numpy())
            probabilities.append(logits.sigmoid()[:,0].cpu().numpy())
    probabilities = np.concatenate(probabilities)
    target = data['mask'][:,0].cpu().numpy().astype(bool)
    truth = data['label'].cpu().numpy()
    direct_f1 = None if head is None else float(f1_score(truth,np.concatenate(direct),labels=range(9),average='macro',zero_division=0))
    rows = []; predictions = []
    for threshold in thresholds:
        masks = probabilities >= threshold
        pred = hard_classes(masks)
        union = (masks | target).sum((1,2))
        iou = np.divide((masks & target).sum((1,2)),union,out=np.ones(len(union),dtype=float),where=union>0)
        rows.append(dict(threshold=threshold,
            mask_F1=float(f1_score(truth,pred,labels=range(9),average='macro',zero_division=0)),
            IoU=float(iou.mean()),direct_head_F1=direct_f1))
        predictions.append(pred)
    net.train()
    if head is not None:
        head.train()
    return rows,dict(probability=probabilities, prediction=np.stack(predictions),
                     thresholds=np.array(thresholds),truth=truth,target=target)


def metadata(stage,budget,draw,seed,settings,initial_sha,data):
    ids = np.array(data['dense']['global_indices'],dtype=np.int64)
    return dict(stage=stage,budget=budget,subset_seed=draw,seed=seed,**settings,
        base_sha256=initial_sha,subsets_sha256=sha(ROOT/'SUBSETS.json'),
        dense_global_indices=ids.tolist(),dense_indices_sha256=hashlib.sha256(ids.tobytes()).hexdigest())


def verify_preconditions():
    assert torch.backends.mps.is_available(), 'Explicit MPS required; no silent fallback'
    assert os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] == '0'
    assert not (ROOT/'FROZEN.json').exists(), 'Refuse overwrite/resume of a frozen training attempt'
    assert not (ROOT/'TRAINING_COMPLETE.json').exists() and not (ROOT/'RESULT.json').exists()
    assert CONFIG == json.loads((ROOT/'CONFIG.json').read_text())
    assert CONFIG['protocol_sha256'] == sha(ROOT/'PROTOCOL.md')
    manifest = json.loads((ROOT/'DATA_MANIFEST.json').read_text())
    assert manifest['status'] == 'PASS_DATA_GATE'
    assert manifest['protocol_sha256'] == sha(ROOT/'PROTOCOL.md')
    assert manifest['TRAIN_VAL_sha256'] == sha(ROOT/'TRAIN_VAL.npz')
    assert sha(ROOT/'TRAIN_VAL.npz') == sha(G/'sem_cldice_expansion_20261102/TRAIN_VAL.npz')
    smoke = json.loads((ROOT/'SMOKE_CHECK.json').read_text())
    assert smoke['status'] == 'PASS_SMOKE_CHECK'
    assert all(sha(ROOT/p) == h for p,h in smoke['source_sha256'].items()), 'Changed code after smoke'
    protected = json.loads((ROOT/'PROTECTED_BEFORE.json').read_text())
    assert all(sha(G/p) == h for p,h in protected.items()), 'Historical artifact changed'
    parity = json.loads((ROOT/'BASELINE_PARITY.json').read_text())
    assert 'PASS' in parity['status'], 'Official baseline formula parity failed'
    subsets = prepare_subsets()
    frozen = dict(protocol_sha256=sha(ROOT/'PROTOCOL.md'),config_sha256=sha(ROOT/'CONFIG.json'),
        source_sha256=source_hashes(),smoke_sha256=sha(ROOT/'SMOKE_CHECK.json'),
        subsets_sha256=sha(ROOT/'SUBSETS.json'),protected_sha256=sha(ROOT/'PROTECTED_BEFORE.json'),
        train_val_sha256=sha(ROOT/'TRAIN_VAL.npz'),manifest_sha256=sha(ROOT/'DATA_MANIFEST.json'),
        torch=torch.__version__,numpy=np.__version__,MPS_available=True,MPS_fallback='0',
        total_backbone_steps=TOTAL,total_head_steps=TOTAL_HEAD,
        TRAIN_TEST_archive_never_opened=True,weak_object_keys=['x','label'],
        selection_uses_TEST=False,configuration_grid=configurations(),
        primary_budgets=CONFIG['primary_budgets'])
    save(ROOT/'FROZEN.json',frozen)
    return subsets,frozen


def verify_frozen():
    frozen = json.loads((ROOT/'FROZEN.json').read_text())
    complete = json.loads((ROOT/'TRAINING_COMPLETE.json').read_text())
    checks = dict(
        protocol=sha(ROOT/'PROTOCOL.md')==frozen['protocol_sha256'],
        config=sha(ROOT/'CONFIG.json')==frozen['config_sha256'],
        train_val=sha(ROOT/'TRAIN_VAL.npz')==frozen['train_val_sha256'],
        subsets=sha(ROOT/'SUBSETS.json')==frozen['subsets_sha256']==complete['subsets_sha256'],
        manifest=sha(ROOT/'DATA_MANIFEST.json')==frozen['manifest_sha256'],
        sources=all(sha(ROOT/p)==h for p,h in frozen['source_sha256'].items()),
        frozen=sha(ROOT/'FROZEN.json')==complete['frozen_sha256'],
        selection=sha(ROOT/'SELECTION.json')==complete['selection_sha256'],
        checkpoints=all(sha(ROOT/'models'/p)==h for p,h in complete['checkpoint_hashes'].items()),
        update_counts=complete['backbone_steps']==TOTAL and complete['head_only_steps']==TOTAL_HEAD,
        checkpoint_count=len(complete['checkpoint_hashes'])==222)
    protected = json.loads((ROOT/'PROTECTED_BEFORE.json').read_text())
    checks['protected_files']=all(sha(G/p)==h for p,h in protected.items())
    assert all(checks.values()),checks
    return checks


def main():
    global START,COMPLETED,HEAD_COMPLETED,CONTEXT
    START = time.monotonic(); COMPLETED = 0; HEAD_COMPLETED = 0
    torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        subsets,frozen = verify_preconditions()
        full = load_training()
        (ROOT/'models').mkdir(exist_ok=True);(ROOT/'dev_val').mkdir(exist_ok=True)
        rows = []; threshold_rows = []; hashes = {}; initial_states = {}; base_hashes = {}
        initial_consistency = {}; warm_consistency = {}
        progress(stage='START_DEV_NO_TEST_OPENED')
        for budget in CONFIG['budgets']:
            for pair,(seed,dev_draw) in enumerate(zip(DEV_SEEDS,CONFIG['dev_subset_seeds'])):
                draw = 0 if budget == 54 else dev_draw
                CONTEXT = dict(phase='dev',budget=budget,subset_seed=draw)
                data = subset_data(full,budget,draw,'dev',subsets)
                initial = base_model(seed,data['dense'])
                base_name = f'base_dev_b{budget}_d{draw}_s{seed}.pt'
                base_net = make_segmenter();base_net.load_state_dict(initial)
                base_hash = checkpoint(ROOT/'models'/base_name,base_net,None,
                    stage='base_dev',budget=budget,subset_seed=draw,seed=seed,
                    dense_global_indices=data['dense']['global_indices'].tolist(),
                    state_sha256=state_digest(initial))
                hashes[base_name] = base_hash
                for settings in configurations():
                    net,head,timing = train_method(seed,settings,DEV_STEPS,initial,data)
                    consistency_key = (budget,draw,seed)
                    if head is not None:
                        initial_consistency.setdefault(consistency_key,timing['head_initial_sha256'])
                        warm_consistency.setdefault(consistency_key,timing['head_after_warm_sha256'])
                        assert initial_consistency[consistency_key] == timing['head_initial_sha256']
                        assert warm_consistency[consistency_key] == timing['head_after_warm_sha256']
                    metrics,arrays = evaluate_thresholds(net,head,data['val'],settings['family'])
                    meta = metadata('dev',budget,draw,seed,settings,base_hash,data)
                    half = next(r for r in metrics if r['threshold'] == .5)
                    row = dict(**meta,**timing,**half)
                    rows.append(row)
                    threshold_rows.extend(dict(**meta,**metric) for metric in metrics)
                    name = f'dev_b{budget}_d{draw}_{settings["config_id"]}_s{seed}.pt'
                    hashes[name] = checkpoint(ROOT/'models'/name,net,head,**row)
                    np.savez_compressed(ROOT/'dev_val'/(Path(name).stem+'.npz'),**arrays)
                    save(ROOT/'DEV_RESULTS.json',rows)
                    save(ROOT/'DEV_THRESHOLD_RESULTS.json',threshold_rows)
                    save(ROOT/'CHECKPOINT_HASHES.json',hashes)
                    progress(stage='DEV_VAL',completed_DEV_models=len(rows),completed_FINAL_models=0,
                             seed=seed,config_id=settings['config_id'],mask_F1=half['mask_F1'])
                    del net,head
        assert len(rows) == 90 and len(threshold_rows) == 630
        aggregate = [];chosen = {}
        for budget in CONFIG['budgets']:
            chosen[str(budget)] = {}
            for family in ARMS:
                candidates = []
                for settings in configurations(family):
                    for threshold in THRESHOLDS:
                        obs = [r for r in threshold_rows if r['budget']==budget and r['config_id']==settings['config_id'] and r['threshold']==threshold]
                        assert len(obs)==2 and sorted(r['seed'] for r in obs)==DEV_SEEDS
                        point = dict(budget=budget,**settings,threshold=threshold,
                            mask_F1=float(np.mean([r['mask_F1'] for r in obs])),
                            IoU=float(np.mean([r['IoU'] for r in obs])),
                            direct_head_F1=None if family=='soft' else float(np.mean([r['direct_head_F1'] for r in obs])))
                        candidates.append(point);aggregate.append(point)
                chosen[str(budget)][family] = max(candidates,key=selection_rank)
        assert len(aggregate)==315
        selection = dict(status='FROZEN_BEFORE_TEST',chosen=chosen,all_VAL_configurations=aggregate,
            selection_uses_TEST=False,protocol_sha256=sha(ROOT/'PROTOCOL.md'),
            DEV_results_sha256=sha(ROOT/'DEV_RESULTS.json'),
            DEV_threshold_results_sha256=sha(ROOT/'DEV_THRESHOLD_RESULTS.json'),
            rule='meanVALmaskF1,IoU,closest.5,lowerheadweight,lowerstructureweight,lowerthreshold',
            candidate_counts_per_arm_per_budget=3,thresholds=THRESHOLDS)
        save(ROOT/'SELECTION.json',selection)
        final_rows = [];final_val = []
        for budget in CONFIG['budgets']:
            draws = [0] if budget==54 else CONFIG['final_subset_seeds']
            for draw in draws:
                for seed in SEEDS:
                    CONTEXT = dict(phase='final',budget=budget,subset_seed=draw)
                    data = subset_data(full,budget,draw,'final',subsets)
                    initial = base_model(seed,data['dense'])
                    base_name = f'base_final_b{budget}_d{draw}_s{seed}.pt'
                    base_net = make_segmenter();base_net.load_state_dict(initial)
                    base_hash = checkpoint(ROOT/'models'/base_name,base_net,None,
                        stage='base_final',budget=budget,subset_seed=draw,seed=seed,
                        dense_global_indices=data['dense']['global_indices'].tolist(),state_sha256=state_digest(initial))
                    hashes[base_name] = base_hash
                    for family in ARMS:
                        point = chosen[str(budget)][family]
                        settings = {key:point[key] for key in configurations(family)[0]}
                        net,head,timing = train_method(seed,settings,FINAL_STEPS,initial,data)
                        consistency_key = (budget,draw,seed)
                        if head is not None:
                            initial_consistency.setdefault(consistency_key,timing['head_initial_sha256'])
                            warm_consistency.setdefault(consistency_key,timing['head_after_warm_sha256'])
                            assert initial_consistency[consistency_key] == timing['head_initial_sha256']
                            assert warm_consistency[consistency_key] == timing['head_after_warm_sha256']
                        thresholds = sorted(set([point['threshold'],.5]))
                        metrics,arrays = evaluate_thresholds(net,head,data['val'],family,thresholds)
                        meta = metadata('final',budget,draw,seed,settings,base_hash,data)
                        metric = next(r for r in metrics if r['threshold']==point['threshold'])
                        row = dict(**meta,**timing,**metric)
                        final_rows.append(row)
                        final_val.extend(dict(**meta,**m) for m in metrics)
                        name = f'final_b{budget}_d{draw}_{family}_s{seed}.pt'
                        hashes[name] = checkpoint(ROOT/'models'/name,net,head,**row)
                        save(ROOT/'FINAL_RESULTS.json',final_rows)
                        save(ROOT/'FINAL_VAL_RESULTS.json',final_val)
                        save(ROOT/'CHECKPOINT_HASHES.json',hashes)
                        progress(stage='FINAL_VAL',completed_DEV_models=len(rows),completed_FINAL_models=len(final_rows),
                                 seed=seed,family=family,mask_F1=metric['mask_F1'])
                        del net,head
        assert len(final_rows)==105 and len(hashes)==222
        assert COMPLETED==TOTAL==310800 and HEAD_COMPLETED==TOTAL_HEAD==31200
        assert sha(ROOT/'SELECTION.json') and all(sha(ROOT/p)==h for p,h in frozen['source_sha256'].items())
        protected = json.loads((ROOT/'PROTECTED_BEFORE.json').read_text())
        assert all(sha(G/p)==h for p,h in protected.items())
        complete = dict(status='COMPLETE_TRAINING_NO_TEST_OPENED',seconds=time.monotonic()-START,
            checkpoint_hashes=hashes,checkpoints=len(hashes),DEV_models=len(rows),FINAL_models=len(final_rows),base_models=27,
            completed_backbone_steps=COMPLETED,completed_head_only_steps=HEAD_COMPLETED,
            backbone_steps=COMPLETED,head_only_steps=HEAD_COMPLETED,
            frozen_sha256=sha(ROOT/'FROZEN.json'),selection_sha256=sha(ROOT/'SELECTION.json'),
            subsets_sha256=sha(ROOT/'SUBSETS.json'),train_val_sha256=sha(ROOT/'TRAIN_VAL.npz'),
            protected_files_unchanged=True,training_has_no_TEST_tensors=True,weak_has_no_mask_key=True,
            software=dict(torch=torch.__version__,numpy=np.__version__),
            head_initialization_consistency_groups=len(initial_consistency),head_warm_consistency_groups=len(warm_consistency))
        save(ROOT/'TRAINING_COMPLETE.json',complete)
        CONTEXT = {}
        progress(stage='COMPLETE_TRAINING_NO_TEST_OPENED',completed_DEV_models=90,completed_FINAL_models=105)


if __name__=='__main__':
    main()

