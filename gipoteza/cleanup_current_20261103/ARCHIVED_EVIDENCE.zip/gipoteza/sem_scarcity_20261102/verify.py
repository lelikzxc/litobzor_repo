"""Verify completion and artifacts without fitting or changing scientific input."""
from pathlib import Path
import hashlib
import json
import re
from PIL import Image

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    import train
    result = json.loads((ROOT/'RESULT.json').read_text())
    audit = json.loads((ROOT/'AUDIT.json').read_text())
    report = json.loads((ROOT/'REPORT_MANIFEST.json').read_text())
    manifest = json.loads((ROOT/'DATA_MANIFEST.json').read_text())
    evaluation = json.loads((ROOT/'EVALUATION_FROZEN.json').read_text())
    checks = dict(train.verify_frozen())
    checks.update(
        scientific_outcome_recorded=result['status'] in ['PASS_PILOT','FAIL_PILOT'],
        independent_audit=audit['status']=='PASS_AUDIT' and all(audit['checks'].values()),
        report_input_hashes=report['result_sha256']==sha(ROOT/'RESULT.json') and report['audit_sha256']==sha(ROOT/'AUDIT.json'),
        report_files=all(sha(ROOT/p)==h for p,h in report['files_sha256'].items()),
        report_script=report['report_script_sha256']==sha(ROOT/'report.py'),
        evaluation_script=evaluation['script_sha256']==result['analysis_sha256']==sha(ROOT/'evaluate.py'),
        evaluation_freeze=result['evaluation_frozen_sha256']==sha(ROOT/'EVALUATION_FROZEN.json'),
        stored_predictions=result['predictions_sha256']==sha(ROOT/'PREDICTIONS.npz'),
        stored_bootstrap=result['bootstrap_sha256']==sha(ROOT/'BOOTSTRAP.npz'),
        data_archives=all(sha(ROOT/(k+'.npz'))==manifest[k+'_sha256'] for k in ['DATA','TEST','TRAIN_VAL']),
        test_scope=result['test_examples']==14365 and len(result['test_frames'])==8,
        protocol_primary=result['primary_budgets']==[18,27] and len(result['primary_controls'])==4)
    links = []; missing = []
    for name in ['README.md','REPORT.md','PROTOCOL.md','BASELINES.md']:
        for target in re.findall(r'\]\(([^)]+)\)',(ROOT/name).read_text()):
            if target.startswith(('http:','https:','#')):
                continue
            path = (ROOT/target.split('#')[0]).resolve()
            links.append(str(path))
            if not path.is_file(): missing.append(str(path))
    checks['document_links'] = not missing
    for p in sorted((ROOT/'figures').glob('*.png')):
        with Image.open(p) as im:
            im.verify()
    checks['two_rendered_figures'] = len(list((ROOT/'figures').glob('*.png')))==2
    verification = dict(status='PASS_VERIFICATION' if all(checks.values()) else 'FAIL_VERIFICATION',
        checks=checks,missing_links=missing,local_links_checked=len(links))
    (ROOT/'VERIFICATION.json').write_text(json.dumps(verification,indent=2)+'\n')
    assert all(checks.values()),checks
    complete = dict(status='COMPLETE',scientific_status=result['status'],audit_status=audit['status'],
        result_sha256=sha(ROOT/'RESULT.json'),audit_sha256=sha(ROOT/'AUDIT.json'),
        report_manifest_sha256=sha(ROOT/'REPORT_MANIFEST.json'),verification_sha256=sha(ROOT/'VERIFICATION.json'),
        scope='Technical completion does not mean scientific hypothesis confirmed.')
    (ROOT/'COMPLETE.json').write_text(json.dumps(complete,indent=2)+'\n')
    print(json.dumps(verification),flush=True)


if __name__=='__main__':
    main()
