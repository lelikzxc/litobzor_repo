"""Render the full frozen study, including every control and label budget."""
from pathlib import Path
import hashlib
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
NAMES = {'head9': 'BCE + head', 'cldice_head9': 'BCE + clDice + head',
         'dice_head9': 'BCE + Dice + head', 'skelrec_head9': 'BCE + Dice + Skeleton Recall + head',
         'soft': 'BCE + conductance (ours)'}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    result = json.loads((ROOT / 'RESULT.json').read_text())
    audit = json.loads((ROOT / 'AUDIT.json').read_text())
    complete = json.loads((ROOT / 'TRAINING_COMPLETE.json').read_text())
    selection = json.loads((ROOT / 'SELECTION.json').read_text())
    data = json.loads((ROOT / 'DATA_MANIFEST.json').read_text())
    assert audit['status'] == 'PASS_AUDIT' and all(audit['checks'].values())
    arms = result['arms']; budgets = [18, 27, 54]
    with np.load(ROOT / 'BOOTSTRAP.npz') as z:
        draws = z['scores']
    figures = ROOT / 'figures'; figures.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    fig, ax = plt.subplots(figsize=(9, 5))
    for a, arm in enumerate(arms):
        points = 100*np.array([result['metrics'][str(b)][arm]['mask_F1'] for b in budgets])
        ci = 100*np.quantile(draws[:, a], [.025, .975], axis=1)
        line, = ax.plot(budgets, points, marker='o', lw=2 if arm == 'soft' else 1.5, label=NAMES[arm])
        ax.fill_between(budgets, ci[0], ci[1], color=line.get_color(), alpha=.08)
    ax.set(xlabel='Number of dense TRAIN masks (1152 weak labels fixed)',
           ylabel='Mask-derived classification Macro-F1, %', xticks=budgets,
           title='Fresh TEST: one IC, 8 frames; VAL-calibrated thresholds')
    ax.grid(alpha=.2); ax.legend(fontsize=8, loc='best')
    fig.tight_layout(); fig.savefig(figures / 'scarcity_f1.png', dpi=180); plt.close(fig)
    fig, ax = plt.subplots(figsize=(9, 4.7))
    for a, arm in enumerate(arms[:-1]):
        row = result['soft_minus_control'][arm]
        delta = 100*row['delta']; low, high = 100*np.array(row['CI98_75'])
        ax.plot([low, high], [a, a], color='C4', lw=2)
        ax.scatter([delta], [a], color='C4', zorder=3)
    ax.axvline(0, color='black', lw=1)
    ax.axvline(1, color='gray', lw=1, ls='--', label='Prespecified practical gain: 1 pp')
    ax.set(yticks=range(4), yticklabels=[NAMES[a] for a in arms[:-1]],
           xlabel='Ours minus control, percentage points',
           title='Primary mean over 18/27 masks; Bonferroni 98.75% intervals')
    ax.invert_yaxis(); ax.grid(axis='x', alpha=.2); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(figures / 'primary_comparisons.png', dpi=180); plt.close(fig)
    lines = ['# Проверка при дефиците масок — 2 ноября 2026', '',
        f"**Научный исход: `{result['status']}`. Технический аудит: `{audit['status']}`.**", '',
        'Это заранее ограниченное последующее исследование после отрицательного результата '
        'с 54 масками и расширенными контролями. Здесь проверяется условие сильного дефицита '
        'плотной разметки. Оно не отменяет прошлые результаты.', '',
        f"Новый TEST: **{result['test_examples']:,} участков**, восемь ранее не использованных кадров "
        'того же физического кристалла. Все девять классов представлены во всех восьми кадрах. '
        'TRAIN/VAL сохранены побайтно; 1152 слабые метки одинаковы у всех методов. '
        'Для 18/27 масок проведено 3 розыгрыша ×3 инициализации; для 54 — один полный '
        'набор ×3 инициализации. TEST не использовался для выбора '
        'конкретных новых кадров, инициализаций, весов или порогов.', '',
        '## Основной результат', '',
        '| Метод | 18 масок: F1, % | 27 масок: F1, % | 54 маски: F1, % | Среднее 18/27, % |',
        '|---|---:|---:|---:|---:|']
    for arm in arms:
        vals = [100*result['metrics'][str(b)][arm]['mask_F1'] for b in budgets]
        lines.append(f"| {NAMES[arm]} | {vals[0]:.2f} | {vals[1]:.2f} | {vals[2]:.2f} | "
                     f"{100*result['primary_metrics'][arm]['mask_F1']:.2f} |")
    lines += ['', '![F1 при трёх бюджетах](figures/scarcity_f1.png)', '',
        'Заливки — номинальные 95% интервалы crossed bootstrap. При 54 масках '
        'нет вариации розыгрыша: повторять одинаковый набор как три независимых нельзя.', '',
        '| Сравнение physics−контроль | Δ F1, п.п. | 98.75% CI, п.п. | Δ IoU, п.п. | Все условия |',
        '|---|---:|---:|---:|---|']
    for arm in arms[:-1]:
        row = result['soft_minus_control'][arm]; ci = row['CI98_75']
        lines.append(f"| {NAMES[arm]} | {100*row['delta']:+.2f} | "
                     f"[{100*ci[0]:+.2f}; {100*ci[1]:+.2f}] | {100*row['IoU_delta']:+.2f} | "
                     f"{'PASS' if all(row['gates'].values()) else 'FAIL'} |")
    lines += ['', '![Первичные сравнения](figures/primary_comparisons.png)', '',
        'Первичный критерий — равновесное среднее Macro-F1 по 18 и 27 маскам. '
        'Для PASS нужны прирост ≥1 п.п. против каждого из четырёх контролей, '
        'положительная нижняя граница поправленного интервала, отсутствие среднего '
        'вреда на обоих отдельных бюджетах и потеря IoU не более 2 п.п. '
        'Использованы 10 000 парных повторов по кадрам, seed и розыгрышам с сохранением '
        'вложенности бюджетов. Интервалы приближённые; 3×3 обучения и один кристалл '
        'ограничивают статистическую уверенность.', '',
        '## Калибровка, сегментация и вторичные результаты', '',
        '| Масок | Метод | Вес слабой потери | clDice | Порог VAL | IoU TEST, % | F1 при пороге 0.5, % |',
        '|---:|---|---:|---:|---:|---:|---:|']
    for b in budgets:
        for arm in arms:
            chosen = selection['chosen'][str(b)][arm]
            lines.append(f"| {b} | {NAMES[arm]} | {chosen['weight']:g} | {chosen['cldice_weight']:g} | "
                f"{chosen['threshold']:.2f} | {100*result['metrics'][str(b)][arm]['IoU']:.2f} | "
                f"{100*result['secondary_fixed05'][str(b)][arm]['mask_F1']:.2f} |")
    lines += ['', 'Вес Dice и Skeleton Recall фиксирован равным 1 для соответствующих контролей. '
        'Все методы получили по три конфигурации ×два DEV-обучения на бюджет и одну '
        'общую сетку из семи порогов. Это ограниченный поиск по VAL, не глобальная '
        'оптимальность. Для основного тестового маршрута головы удалены: все модели '
        'используют одинаковую архитектуру сегментатора и одинаковый бинарный '
        'резисторный классификатор. Преимущество по скорости основного инференса не заявляется.', '',
        'Прямые головы используют другой маршрут классификации и не входят в критерий PASS:', '',
        '| Метод | Прямая голова: 18 масок, % | 27 масок, % | 54 маски, % |',
        '|---|---:|---:|---:|']
    for arm in arms[:-1]:
        vals = [100*result['metrics'][str(b)][arm]['direct_head_F1'] for b in budgets]
        lines.append(f'| {NAMES[arm]} | {vals[0]:.2f} | {vals[1]:.2f} | {vals[2]:.2f} |')
    lines += ['', '## Что проверено и что остаётся', '',
        f"Аудит: **{sum(bool(v) for v in audit['checks'].values())}/{len(audit['checks'])}** проверок. "
        'Сохранены предсказания и бинарные маски всех моделей, независимые пересчёты '
        'метрик и интервалов, происхождение данных и SHA256 контрольных точек.', '',
        f"Обучение: {complete['seconds']/60:.1f} мин, 90 DEV +105 FINAL моделей +27 общих "
        f"BCE-прогревов, {complete['backbone_steps']:,} обновлений сегментатора и "
        f"{complete['head_only_steps']:,} head-only обновлений. Тестовая оценка: "
        f"{result['seconds']/60:.1f} мин. Загрузка: "
        f"{json.loads((ROOT/'DOWNLOAD.json').read_text())['seconds']:.1f} с.", '',
        'Это сегментация SEM-геометрии и классификация производных геометрических '
        'состояний. Это не проверка девяти реальных типов брака, электрических '
        'измерений или переноса между кристаллами/производствами. Отсутствие '
        'статистического преимущества не означает доказанную эквивалентность. '
        'Положительный исход ограничен данным режимом, отрицательный сохраняется '
        'наравне с предыдущими положительными пилотами.', '',
        '## Воспроизводимость', '',
        '- [Зафиксированный протокол](PROTOCOL.md), [конфигурация](CONFIG.json), [подвыборки](SUBSETS.json).',
        '- [Подготовка](prepare.py), [обучение](train.py), [контрольные потери](baselines.py), [численная проверка авторского кода](baseline_parity.py).',
        '- [Оценка](evaluate.py), [независимый аудит](audit.py), [генератор отчёта](report.py), [проверка артефактов](verify.py).',
        '- [Все тестовые числа](final_test_results.csv), [результат JSON](RESULT.json), [аудит JSON](AUDIT.json).',
        '- [Пороги: диагностика старых DEV, без TEST](../sem_threshold_diagnostic_20261102/README.md).',
        '- [Предыдущий отрицательный опыт с 54 масками](../sem_cldice_expansion_20261102/REPORT.md).', '',
        'Авторские источники: [clDice, CVPR 2021](https://arxiv.org/abs/2003.07311), '
        '[Skeleton Recall, ECCV 2024](https://github.com/MIC-DKFZ/Skeleton-Recall), '
        '[TopoMortar, BMVC 2025](https://arxiv.org/abs/2503.03365). '
        'Бинарная адаптация Skeleton Recall проверена против зафиксированных авторских '
        'исходников; это не воспроизведение полного nnU-Net. Детали и лицензии сохранены '
        'в [описании реализации](BASELINES.md) и `vendor_skelrec/`. Новизна и принятие статьи '
        'этим экспериментом не устанавливаются.', '']
    (ROOT / 'REPORT.md').write_text('\n'.join(lines), encoding='utf-8')
    readme = f'''# SEM: дефицит плотной разметки

Готовый опыт: **{result['status']}**, независимый аудит **{audit['status']}**.

[Полный отчёт с графиками и числами](REPORT.md). [Протокол](PROTOCOL.md).

Проверяется средний эффект при 18/27 масках; 54 — обязательная опорная точка.
Один физический кристалл, 1152 одинаковые слабые метки, новый TEST {result['test_examples']:,} участков.
Все пять методов и все бюджеты опубликованы, включая отрицательные исходы.
Скрипты и 222 контрольные точки находятся в этой папке; `run_stage.py` сохраняет журналы.
Для наблюдения за текущим прогоном: `tail -f gipoteza/sem_scarcity_20261102/train.log`.
Повторный запуск поверх завершённого опыта запрещён; для повторения создаётся новая папка.
'''
    (ROOT / 'README.md').write_text(readme, encoding='utf-8')
    names = ['REPORT.md', 'README.md', 'figures/scarcity_f1.png', 'figures/primary_comparisons.png']
    manifest = {'status': 'COMPLETE_REPORT', 'result_sha256': sha(ROOT/'RESULT.json'),
        'audit_sha256': sha(ROOT/'AUDIT.json'), 'report_script_sha256': sha(Path(__file__)),
        'files_sha256': {name: sha(ROOT/name) for name in names}}
    (ROOT/'REPORT_MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps(manifest), flush=True)


if __name__ == '__main__':
    main()
