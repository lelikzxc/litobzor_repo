"""Bounded technical MPS training checks, before freezing the scientific run."""
from pathlib import Path
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

import train as t
from baselines import foreground_dice_loss,skeleton_recall_loss

ROOT=Path(__file__).resolve().parent
STEPS=200


def main():
    assert torch.backends.mps.is_available(), 'Explicit MPS required'
    assert not (ROOT/'FROZEN.json').exists(), 'Do not smoke-train after freeze'
    assert 'PASS' in json.loads((ROOT/'BASELINE_PARITY.json').read_text())['status']
    torch.set_num_threads(2)
    subsets=t.prepare_subsets()
    full=t.load_training()
    data=t.subset_data(full,18,t.CONFIG['dev_subset_seeds'][0],'dev',subsets)
    checks=dict(weak_has_no_mask_key=set(data['weak'])=={'x','label'},
        dense_count_18=len(data['dense']['x'])==18,
        weak_fixed_1152=len(data['weak']['x'])==1152,
        val_fixed_695=len(data['val']['x'])==695,
        fallback_disabled=t.os.environ['PYTORCH_ENABLE_MPS_FALLBACK']=='0')
    assert np.array_equal(np.bincount(data['dense']['label'].cpu().numpy(),minlength=9),np.full(9,2))
    checks['all_dense_classes_balanced']=True
    gradients={}
    for family,fn,target in [('dice_head9',foreground_dice_loss,data['dense']['mask']),
                             ('skelrec_head9',skeleton_recall_loss,data['dense']['tubes'])]:
        torch.manual_seed(4901)
        logits=torch.randn(target.shape,device='cpu')
        cpu=logits.clone().requires_grad_(True)
        ref=fn(cpu,target.cpu());g1=torch.autograd.grad(ref,cpu)[0]
        mps=logits.to('mps').requires_grad_(True)
        actual=fn(mps,target);g2=torch.autograd.grad(actual,mps)[0].cpu()
        loss_error=abs(float(ref.detach())-float(actual.detach().cpu()))
        grad_error=float((g1-g2).abs().max())
        assert torch.isfinite(actual) and torch.isfinite(g2).all() and float(g2.abs().sum())>0
        assert loss_error<1e-5 and grad_error<1e-5,(family,loss_error,grad_error)
        gradients[family]=dict(loss_absolute_error=loss_error,gradient_max_error=grad_error)
    checks['Dice_SkeletonRecall_CPU_MPS_loss_gradient_parity']=True
    t.START=time.monotonic();t.CONTEXT=dict(phase='technical_smoke_only',budget=18,subset_seed=t.CONFIG['dev_subset_seeds'][0])
    initial=t.base_model(4909,data['dense'])
    timings={};heads=[];warm=[]
    for family in t.ARMS:
        settings=t.configurations(family)[1]
        net,head,timing=t.train_method(4909,settings,STEPS,initial,data)
        with torch.inference_mode():
            output=net(data['val']['x'][:32])
        assert torch.isfinite(output).all()
        if head is not None:
            heads.append(timing['head_initial_sha256']);warm.append(timing['head_after_warm_sha256'])
        timings[family]=dict(**timing,steps=STEPS,
            milliseconds_per_joint_step=1000*timing['seconds']/STEPS)
    checks['all_5_losses_finite_200_joint_steps']=True
    checks['common_head_initialization']=len(set(heads))==1
    checks['common_head_after_warm']=len(set(warm))==1
    checks['updates_match_smoke']=t.COMPLETED==400+STEPS*5 and t.HEAD_COMPLETED==200*4
    assert all(checks.values()),checks
    # Per arm: 18 DEV fits and 21 FINAL fits; each method's warm overhead is measured.
    train_seconds=sum(v['seconds']/STEPS*(18000+42000)+v['setup_seconds']*39 for v in timings.values())
    result=dict(status='PASS_SMOKE_CHECK',checks=checks,source_sha256=t.source_hashes(),
        config_sha256=t.sha(ROOT/'CONFIG.json'),protocol_sha256=t.sha(ROOT/'PROTOCOL.md'),
        subsets_sha256=t.sha(ROOT/'SUBSETS.json'),train_val_sha256=t.sha(ROOT/'TRAIN_VAL.npz'),
        timings=timings,CPU_MPS_baseline_gradient_checks=gradients,
        estimated_joint_and_head_seconds=train_seconds,
        estimated_minutes_with_base_val_io_margin=[train_seconds/60+3,train_seconds/60+12],
        scope='Technical finite-gradient/training smoke only; not DEV selection or TEST result')
    t.save(ROOT/'SMOKE_CHECK.json',result)
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):
        main()
