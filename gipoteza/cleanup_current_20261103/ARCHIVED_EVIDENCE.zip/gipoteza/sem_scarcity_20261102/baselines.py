"""Binary foreground adaptations of nnU-Net Dice and Skeleton Recall.

Pinned unchanged references, license and parity evidence are retained in
vendor_skelrec/ and BASELINE_PARITY.json. This module adds no weak-label loss:
the shared trainer supplies the same classification head to both controls.
"""
import numpy as np
import torch
from scipy import ndimage as ndi
from skimage.morphology import dilation, skeletonize

SMOOTH = 1e-5
BATCH_DICE = False
TUBE_RADIUS = 2


def tube_targets(masks):
    """CPU, non-differentiable author skeletonize→tube→intersection with GT.

    Accept N,H,W or N,1,H,W binary masks and retain the supplied shape. The
    reference transformation operates on whole examples, before batching.
    """
    if isinstance(masks, torch.Tensor):
        masks = masks.detach().cpu().numpy()
    masks = np.asarray(masks)
    assert masks.ndim in (3, 4), masks.shape
    assert masks.ndim == 3 or masks.shape[1] == 1, masks.shape
    assert np.isin(masks, [0, 1]).all()
    flat = masks[:, 0] if masks.ndim == 4 else masks
    footprint = ndi.iterate_structure(ndi.generate_binary_structure(2, 1), TUBE_RADIUS)
    out = np.zeros(flat.shape, dtype=np.float32)
    for i, mask in enumerate(flat):
        binary = mask > 0
        if binary.any():
            skeleton = (skeletonize(binary) > 0).astype(np.int16)
            tube = dilation(skeleton, footprint=footprint)
            out[i] = tube * mask.astype(np.int16)
    return out[:, None] if masks.ndim == 4 else out


def _check(logits, target):
    assert logits.ndim == 4 and logits.shape[1] == 1, logits.shape
    assert logits.shape == target.shape, (logits.shape, target.shape)


def foreground_dice_loss(logits, target):
    """-Dice, smooth1e-5, per-example mean, identical foreground convention.

    [0,logit] two-class softmax foreground equals sigmoid(logit). nnU-Net's
    MemoryEfficientSoftDiceLoss explicitly accumulates Dice in float32; retain
    this convention even when the input is float64 in the CPU parity check.
    """
    _check(logits, target)
    probability = logits.sigmoid()
    axes = (2, 3)
    truth = target.detach().to(dtype=torch.float32)
    intersection = (probability * truth).sum(axes, dtype=torch.float32)
    total = truth.sum(axes, dtype=torch.float32) + probability.sum(axes, dtype=torch.float32)
    return -((2 * intersection + SMOOTH) / (total + SMOOTH).clamp_min(1e-8)).mean()


def skeleton_recall_loss(logits, tubes):
    """Author -soft-recall on the tubed foreground skeleton, per example.

    No prediction skeletonization, no background, no gradients through tubes.
    Empty tubes contribute -1 (zero gradient), as in the official source.
    """
    _check(logits, tubes)
    probability = logits.sigmoid()
    truth = tubes.detach()
    intersection = (probability * truth).sum((2, 3))
    denominator = (truth.sum((2, 3)) + SMOOTH).clamp_min(1e-8)
    return -((intersection + SMOOTH) / denominator).mean()


def loss(logits, target, tubes=None):
    """Dense auxiliary term; shared BCE must be added by the trainer."""
    result = foreground_dice_loss(logits, target)
    if tubes is not None:
        result = result + skeleton_recall_loss(logits, tubes)
    return result


def dense_auxiliary_loss(logits, target, family, tubes=None):
    if family == 'dice_head9':
        return foreground_dice_loss(logits, target)
    if family == 'skelrec_head9':
        assert tubes is not None, 'Precomputed dense TRAIN skeleton tubes required'
        return loss(logits, target, tubes)
    raise ValueError(f'Unsupported baseline family: {family}')
