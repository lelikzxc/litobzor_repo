"""Independent CPU audit of provenance, model selection and scarcity statistics.

This module never trains or changes a chosen setting. It is run only after the
official TEST evaluation has completed. The numerical F1, IoU and bootstrap
calculations below do not import the evaluator's implementations.
"""
from pathlib import Path
import ast
import hashlib
import json
import re
import time

import numpy as np
from scipy import sparse
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import spsolve
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
PRIOR = [G / 'sem_confirmation_20261028', G / 'sem_cldice_confirmation_20261030',
         G / 'sem_cldice_expansion_20261102']
BUDGETS = [18, 27, 54]
ARMS = ['head9', 'cldice_head9', 'dice_head9', 'skelrec_head9', 'soft']
MODES = ['calibrated', 'fixed05']
SEEDS = [5501, 5521, 5557]
DRAWS = {18: [5303, 5351, 5387], 27: [5303, 5351, 5387], 54: [0]}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def save(value):
    path = ROOT / 'AUDIT.json'
    temporary = path.with_suffix('.json.partial')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def canonical_keys(masks, raw=False):
    """Independent minimum byte representation over the eight D4 variants."""
    a = np.asarray(masks)
    rotations = []
    for flip in [False, True]:
        source = a[:, :, ::-1] if flip else a
        rotations.extend(np.rot90(source, k, axes=(1, 2)) for k in range(4))
    encoded = ([r.astype('<u2') for r in rotations] if raw else
               [np.packbits(r.reshape(len(a), -1), axis=1) for r in rotations])
    values = [min(r[i].tobytes() for r in encoded) for i in range(len(a))]
    return [hashlib.sha256(v).hexdigest() if raw else v.hex() for v in values]


def independent_direction(mask):
    """Sparse Kirchhoff solve on the components joining the two electrodes."""
    a = np.asarray(mask, dtype=bool)
    assert a.shape == (12, 12)
    edges = [(12*y+x, 12*yy+xx) for y in range(12) for x in range(12)
             for yy, xx in [(y+1, x), (y, x+1)]
             if yy < 12 and xx < 12 and a[y, x] and a[yy, xx]]
    if not edges:
        return 0
    u = np.array([e[0] for e in edges]); v = np.array([e[1] for e in edges])
    graph = sparse.csr_matrix((np.ones(2*len(u)), (np.r_[u, v], np.r_[v, u])), shape=(144, 144))
    _, component = connected_components(graph, directed=False)
    left = np.arange(0, 144, 12); right = np.arange(11, 144, 12)
    common = np.intersect1d(component[left[a[:, 0]]], component[right[a[:, -1]]])
    if not len(common):
        return 0
    active = np.isin(component, common)
    graph = graph.multiply(active[:, None]*active[None, :]).tocsr()
    lap = sparse.diags(np.asarray(graph.sum(1)).ravel()) - graph
    free = np.array([12*y+x for y in range(12) for x in range(1, 11) if active[12*y+x]])
    rhs = -np.asarray(lap[free][:, right].sum(1)).ravel()
    voltage = spsolve(lap[free][:, free].tocsc(), rhs)
    conductance = float(lap[right][:, right].sum() - rhs@voltage)/(12/11)
    return 0 if conductance < 1e-8 else 1 if conductance < .5-1e-8 else 2


def independent_segmenter():
    return nn.Sequential(nn.Conv2d(1, 24, 3, padding=1), nn.GELU(),
        nn.Conv2d(24, 24, 3, padding=2, dilation=2), nn.GELU(),
        nn.Conv2d(24, 24, 3, padding=4, dilation=4), nn.GELU(), nn.Conv2d(24, 1, 1))


def independent_head():
    return nn.Sequential(nn.Linear(3456, 64), nn.GELU(), nn.Linear(64, 9))


def state_digest(state):
    digest = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        digest.update(key.encode()); digest.update(str(value.dtype).encode())
        digest.update(str(value.shape).encode()); digest.update(value.tobytes())
    return digest.hexdigest()


def macro(confusion):
    """Nine fixed classes; an absent class contributes zero, like sklearn."""
    denominator = confusion.sum(-1) + confusion.sum(-2)
    diagonal = np.diagonal(confusion, axis1=-2, axis2=-1)
    return np.divide(2*diagonal, denominator, out=np.zeros_like(diagonal, dtype=float),
                     where=denominator > 0).mean(-1)


def independent_bootstrap(confusions, subset_ids, seed_ids, frame_ids):
    """Weighted contingency tables, independent of evaluator advanced indexing.

    Intermediate allocation is under 5 MB per 128-draw chunk, rather than
    materializing all repeated model/frame confusion matrices at once.
    """
    repetitions = len(seed_ids)
    output = np.empty((3, 5, repetitions), dtype=float)
    sw = np.asarray([np.bincount(row, minlength=3) for row in seed_ids])
    dw = np.asarray([np.bincount(row, minlength=3) for row in subset_ids])
    fw = np.asarray([np.bincount(row, minlength=8) for row in frame_ids])
    for bi, budget in enumerate(BUDGETS):
        c = confusions[budget].astype(float)
        for start in range(0, repetitions, 128):
            stop = min(start+128, repetitions)
            weighted = np.einsum('rf,dsafij->rdsaij', fw[start:stop], c)
            values = macro(weighted)
            draw_weights = dw[start:stop] if budget != 54 else np.ones((stop-start, 1))
            denom = 9 if budget != 54 else 3
            output[bi, :, start:stop] = np.einsum('rd,rs,rdsa->ra',
                draw_weights, sw[start:stop], values).T/denom
    return output


def check_subsets(config, tv):
    document = read('SUBSETS.json')
    dense = np.flatnonzero(tv['role'] == 'dense')
    label = tv['label']
    expected = {}
    for stage, seeds in [('dev', config['dev_subset_seeds']), ('final', config['final_subset_seeds'])]:
        expected[stage] = {'18': {}, '27': {}, '54': {'0': dense.tolist()}}
        for seed in seeds:
            rng = np.random.default_rng(seed)
            by_class = [rng.permutation(dense[label[dense] == c]) for c in range(9)]
            for budget, count in [(18, 2), (27, 3)]:
                expected[stage][str(budget)][str(seed)] = np.sort(np.concatenate(
                    [group[:count] for group in by_class])).tolist()
    subsets = document['subsets']
    balance = True; nesting = True
    for stage in ['dev', 'final']:
        balance &= set(subsets[stage]) == {'18', '27', '54'}
        balance &= set(subsets[stage]['54']) == {'0'}
        for budget in BUDGETS:
            for draw, rows in subsets[stage][str(budget)].items():
                rows = np.asarray(rows, dtype=int)
                balance &= len(rows) == budget and len(set(rows.tolist())) == budget
                balance &= set(rows).issubset(set(dense))
                balance &= np.array_equal(np.bincount(label[rows], minlength=9), np.full(9, budget//9))
        for draw in subsets[stage]['18']:
            nesting &= (set(subsets[stage]['18'][draw]) <= set(subsets[stage]['27'][draw])
                        <= set(subsets[stage]['54']['0']))
    return {'subset_indices_recomputed': expected == subsets,
            'subset_stratification_and_single_full_set': bool(balance),
            'subsets_nested': bool(nesting),
            'subset_archive_hash': document['train_val_sha256'] == sha(ROOT/'TRAIN_VAL.npz')}


def expected_settings():
    settings = []
    pairs = {'head9': [(.4, 0.), (2., 0.), (4., 0.)],
             'cldice_head9': [(2., .4), (2., 1.), (4., 1.)],
             'dice_head9': [(.4, 0.), (2., 0.), (4., 0.)],
             'skelrec_head9': [(.4, 0.), (2., 0.), (4., 0.)],
             'soft': [(.1, 0.), (.4, 0.), (1., 0.)]}
    for arm in ARMS:
        for weight, cldice in pairs[arm]:
            token = lambda v: f'{v:g}'.replace('.', 'p')
            settings.append(dict(family=arm, weight=weight,
                head_weight=0. if arm == 'soft' else weight,
                cldice_weight=cldice,
                dice_weight=1. if arm in ['dice_head9', 'skelrec_head9'] else 0.,
                skelrec_weight=1. if arm == 'skelrec_head9' else 0.,
                physics_weight=weight if arm == 'soft' else 0.,
                config_id=f'{arm}_w{token(weight)}_c{token(cldice)}'))
    return settings


def selection_rank(row):
    return (row['mask_F1'], row['IoU'], -abs(row['threshold']-.5), -row['head_weight'],
            -(row['cldice_weight']+row['dice_weight']+row['skelrec_weight']+row['physics_weight']),
            -row['threshold'])


def check_selection(config, selection):
    rows = read('DEV_THRESHOLD_RESULTS.json')
    expected = expected_settings()
    assert len(rows) == 630, f'Expected 90 models times seven thresholds, got {len(rows)}'
    candidates = {}; pair_ok = True; settings_ok = True
    for budget in BUDGETS:
        candidates[str(budget)] = {}
        for arm in ARMS:
            aggregate = []
            for setting in [s for s in expected if s['family'] == arm]:
                for threshold in config['thresholds']:
                    subset = [r for r in rows if r['budget'] == budget
                              and r['config_id'] == setting['config_id'] and r['threshold'] == threshold]
                    assert len(subset) == 2, (budget, setting, threshold, len(subset))
                    pairs = {(r['subset_seed'], r['seed']) for r in subset}
                    expected_pairs = {(d if budget != 54 else 0, s) for d, s in
                                      zip(config['dev_subset_seeds'], config['dev_seeds'])}
                    pair_ok &= pairs == expected_pairs
                    settings_ok &= all(all(r[k] == v for k, v in setting.items()) for r in subset)
                    aggregate.append(dict(setting, threshold=threshold,
                        mask_F1=float(np.mean([r['mask_F1'] for r in subset])),
                        IoU=float(np.mean([r['IoU'] for r in subset]))))
            candidates[str(budget)][arm] = max(aggregate, key=selection_rank)
    chosen = selection['chosen']
    chosen_ok = set(chosen) == {str(b) for b in BUDGETS}
    for budget in BUDGETS:
        chosen_ok &= set(chosen[str(budget)]) == set(ARMS)
        for arm in ARMS:
            own = candidates[str(budget)][arm]
            chosen_ok &= all(k in chosen[str(budget)][arm] and
                             chosen[str(budget)][arm][k] == v for k, v in own.items())
    return {'DEV_full_equal_candidate_grid': bool(settings_ok),
            'DEV_pairs_match_prespecified': bool(pair_ok),
            'VAL_selection_recomputed': bool(chosen_ok),
            'selection_frozen_before_TEST': (selection['status'] == 'FROZEN_BEFORE_TEST'
                and selection['selection_uses_TEST'] is False
                and selection['DEV_results_sha256'] == sha(ROOT/'DEV_RESULTS.json')
                and selection['DEV_threshold_results_sha256'] == sha(ROOT/'DEV_THRESHOLD_RESULTS.json'))}, candidates


def check_provenance(config, frozen, complete, manifest, before, tv, test, selection):
    checks = {}
    checks['frozen_training_dependencies'] = (
        before['PROTOCOL.md'] == frozen['protocol_sha256']
        and before['CONFIG.json'] == frozen['config_sha256']
        and before['TRAIN_VAL.npz'] == frozen['train_val_sha256'] == manifest['TRAIN_VAL_sha256']
        and before['DATA.npz'] == manifest['DATA_sha256']
        and before['DATA_MANIFEST.json'] == frozen['manifest_sha256']
        and before['SUBSETS.json'] == frozen['subsets_sha256'] == complete['subsets_sha256']
        and before['FROZEN.json'] == complete['frozen_sha256']
        and before['SELECTION.json'] == complete['selection_sha256']
        and sha(ROOT/'PROTECTED_BEFORE.json') == frozen['protected_sha256']
        and all(sha(ROOT/name) == h for name, h in frozen['source_sha256'].items()))
    checks['training_update_counts'] = (
        complete['completed_backbone_steps'] == config['total_backbone_updates'] == 310800
        and complete['completed_head_only_steps'] == config['total_head_updates'] == 31200
        and complete['DEV_models'] == 90 and complete['FINAL_models'] == 105
        and complete['base_models'] == 27
        and frozen['total_backbone_steps'] == 310800 and frozen['total_head_steps'] == 31200)
    checks['training_test_isolation_declarations'] = (
        complete['status'] == 'COMPLETE_TRAINING_NO_TEST_OPENED'
        and complete['training_has_no_TEST_tensors'] is True and complete['weak_has_no_mask_key'] is True
        and frozen['TRAIN_TEST_archive_never_opened'] is True
        and frozen['weak_object_keys'] == ['x', 'label']
        and frozen['selection_uses_TEST'] is False
        and frozen['MPS_available'] is True and frozen['MPS_fallback'] == '0')
    tree = ast.parse((ROOT/'train.py').read_text())
    loads = [node.args[0] for node in ast.walk(tree)
             if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
             and isinstance(node.func.value, ast.Name) and node.func.value.id == 'np'
             and node.func.attr == 'load']
    expected_argument = ast.parse("ROOT / 'TRAIN_VAL.npz'", mode='eval').body
    checks['training_code_loads_only_TRAIN_VAL'] = (len(loads) == 2 and all(
        ast.dump(arg, include_attributes=False) == ast.dump(expected_argument, include_attributes=False)
        for arg in loads))
    with np.load(PRIOR[-1]/'TRAIN_VAL.npz', allow_pickle=False) as z:
        old_tv = {k: z[k] for k in z.files}
    checks['TRAIN_VAL_byte_and_array_exact'] = (
        before['TRAIN_VAL.npz'] == sha(PRIOR[-1]/'TRAIN_VAL.npz')
        == '119cf2f5286067ad06c7e83034516abb0bd2a946383fe4c0987ba7a16fa15ade'
        and set(tv) == {'X', 'Y', 'label', 'role', 'frame'}
        and all(tv[k].dtype == old_tv[k].dtype and np.array_equal(tv[k], old_tv[k]) for k in tv)
        and {r: int((tv['role'] == r).sum()) for r in ['dense', 'weak', 'val']}
        == {'dense': 54, 'weak': 1152, 'val': 695})
    checks['frame_split_and_weak_balance'] = (
        set(tv['frame'][tv['role'] == 'val']) == {6, 7}
        and set(tv['frame'][np.isin(tv['role'], ['dense', 'weak'])]) == set(range(6))
        and not set(tv['frame']) & set(test['frame'])
        and np.array_equal(np.bincount(tv['label'][tv['role'] == 'weak'], minlength=9), np.full(9, 128)))
    with np.load(ROOT/'DATA.npz', allow_pickle=False) as z:
        combined = {k: z[k] for k in z.files}
    checks['combined_archives_exact'] = all(np.array_equal(combined[k][:1901], tv[k])
        and np.array_equal(combined[k][1901:], test[k]) for k in tv)
    records = manifest['records']
    checks['manifest_rows_aligned'] = (len(records) == len(combined['role']) and
        all([r[k] for r in records] == combined[k].tolist() for k in ['role', 'frame', 'label']))
    keys = canonical_keys(combined['Y'][:, 0].astype(bool))
    raw = canonical_keys(np.rint(combined['X'][:, 0].astype(float)*(16*255)).astype(np.uint16), raw=True)
    checks['D4_keys_recomputed'] = (keys == [r['canonical_D4'] for r in records]
                                   and raw == [r['raw_D4_sha256'] for r in records])
    checks['D4_new_data_unique'] = len(set(keys)) == len(keys) and len(set(raw)) == len(raw)
    prior_records = [row for folder in PRIOR for row in
                     json.loads((folder/'DATA_MANIFEST.json').read_text())['records']]
    checks['TEST_excludes_all_prior_motifs'] = (
        not set(keys[1901:]) & {r['canonical_D4'] for r in prior_records}
        and not set(raw[1901:]) & {r['raw_D4_sha256'] for r in prior_records})
    checks['source_images_and_prior_provenance'] = (
        all(sha(ROOT/name) == h for name, h in manifest['sources_sha256'].items())
        and all(sha(PRIOR[0]/name) == h for name, h in manifest['inherited_source_files_sha256'].items())
        and all(sha(ROOT/name) == h for key in ['prior_manifests_sha256', 'prior_data_sha256', 'prior_results_sha256']
                for name, h in manifest[key].items()))
    plan = read('SOURCE_PLAN.json'); shared = G/'shared_data/ic_sem_m2'
    historical = json.loads((shared/'SOURCE_MEMBERS.json').read_text())
    excluded = {int(re.search(r'sem(\d+)\.png', r['path']).group(1)) for r in historical['png_original_sources']}
    for folder in PRIOR:
        excluded.update(json.loads((folder/'RESULT.json').read_text())['test_frames'])
    candidates = [int(m[1]) for row in json.loads((shared/'sem_zip_listing.json').read_text())
                  if (m := re.fullmatch(r'dataset/sems/m2/sem(\d+)\.png', row['name']))
                  and int(m[1]) not in excluded]
    candidates.sort(key=lambda n: hashlib.sha256(('SEM-SCARCITY-20261102/'+str(n)).encode()).hexdigest())
    checks['fresh_source_selection_recomputed'] = (
        len(excluded) == 70 and plan['excluded_previous_frames'] == sorted(excluded)
        and plan['test'] == config['test_frames'] == candidates[:8]
        and set(test['frame']) == set(candidates[:8])
        and plan['selection_prefix'] == 'SEM-SCARCITY-20261102/'
        and sha(ROOT/'SOURCE_PLAN.json') == manifest['source_plan_sha256']
        and plan['prepare_script_sha256'] == before['prepare.py'] == manifest['prepare_script_sha256']
        and all(sha(shared/name) == h for name, h in plan['shared_sha256'].items()))
    checks['TEST_data_gates'] = (min(np.bincount(test['label'], minlength=9)) >= 16
        and all(len(set(test['frame'][test['label'] == c])) >= 4 for c in range(9)))
    prepare_check = read('PREPARE_CHECK.json')
    smoke = read('SMOKE_CHECK.json'); parity = read('BASELINE_PARITY.json')
    checks['technical_data_and_loss_checks_pass'] = (
        prepare_check['status'] == 'PASS_PREPARE_CHECK' and all(prepare_check['checks'].values())
        and smoke['status'] == 'PASS_SMOKE_CHECK' and sha(ROOT/'SMOKE_CHECK.json') == frozen['smoke_sha256']
        and all(sha(ROOT/name) == h for name, h in smoke['source_sha256'].items())
        and parity['status'] == 'PASS_BASELINE_PARITY' and parity['exact_author_tubes'] is True)
    vendor = read('VENDOR.json')
    checks['author_cldice_unmodified'] = (
        vendor['source_modifications'] is False
        and vendor['commit'] == '47d31a6cc4a8101b1ffe8052994821961e57af9f'
        and all(sha(ROOT/'vendor'/name) == row['sha256'] for name, row in vendor['files'].items())
        and config['cldice_iterations'] == 24)
    hashes = complete['checkpoint_hashes']
    checks['all_checkpoint_hashes'] = (len(hashes) == 222
        and hashes == read('CHECKPOINT_HASHES.json')
        and all(sha(ROOT/'models'/name) == h for name, h in hashes.items()))
    subsets = read('SUBSETS.json')['subsets']
    dev_rows = read('DEV_RESULTS.json'); final_rows = read('FINAL_RESULTS.json')
    by_name = {}
    for row in dev_rows:
        name = f'dev_b{row["budget"]}_d{row["subset_seed"]}_{row["config_id"]}_s{row["seed"]}.pt'
        by_name[name] = row
    for row in final_rows:
        name = f'final_b{row["budget"]}_d{row["subset_seed"]}_{row["family"]}_s{row["seed"]}.pt'
        by_name[name] = row
    model_meta_ok = len(dev_rows) == 90 and len(final_rows) == 105 and len(by_name) == 195
    warm_groups = {}; init_groups = {}; init_by_seed = {}; expected_names = set(by_name)
    base_count = 0
    for name, h in hashes.items():
        payload = torch.load(ROOT/'models'/name, map_location='cpu', weights_only=True)
        settings = payload['settings']; budget = settings['budget']; draw = settings['subset_seed']; seed = settings['seed']
        stage = settings['stage']; indices = settings['dense_global_indices']
        source_stage = stage.removeprefix('base_')
        model_meta_ok &= indices == subsets[source_stage][str(budget)][str(draw)]
        model_meta_ok &= sum(v.numel() for v in payload['segmenter'].values()) == 10681
        model_meta_ok &= all(torch.isfinite(v).all().item() for v in payload['segmenter'].values())
        if stage.startswith('base_'):
            base_count += 1; expected_names.add(name)
            model_meta_ok &= name == f'base_{source_stage}_b{budget}_d{draw}_s{seed}.pt'
            model_meta_ok &= payload['head'] is None and settings['state_sha256'] == state_digest(payload['segmenter'])
            continue
        model_meta_ok &= settings == by_name[name]
        model_meta_ok &= settings['subsets_sha256'] == sha(ROOT/'SUBSETS.json')
        model_meta_ok &= settings['dense_indices_sha256'] == hashlib.sha256(np.array(indices, dtype=np.int64).tobytes()).hexdigest()
        base_name = f'base_{stage}_b{budget}_d{draw}_s{seed}.pt'
        model_meta_ok &= settings['base_sha256'] == hashes[base_name]
        model_meta_ok &= (payload['head'] is None) == (settings['family'] == 'soft')
        if stage == 'final':
            chosen = selection['chosen'][str(budget)][settings['family']]
            model_meta_ok &= all(settings[k] == chosen[k] for k in expected_settings()[0])
            model_meta_ok &= settings['threshold'] == chosen['threshold']
        if payload['head'] is not None:
            group = (stage, budget, draw, seed)
            warm_groups.setdefault(group, set()).add(settings['head_after_warm_sha256'])
            init_groups.setdefault(group, set()).add(settings['head_initial_sha256'])
            init_by_seed.setdefault(seed, set()).add(settings['head_initial_sha256'])
            model_meta_ok &= all(torch.isfinite(v).all().item() for v in payload['head'].values())
    checks['checkpoint_metadata_and_common_warm_starts'] = bool(model_meta_ok and base_count == 27
        and expected_names == set(hashes)
        and len(warm_groups) == len(init_groups) == 27
        and all(len(v) == 1 for v in warm_groups.values())
        and all(len(v) == 1 for v in init_groups.values())
        and all(len(v) == 1 for v in init_by_seed.values()))
    return checks


def check_dev_evidence(config, tv):
    """Recompute all 630 VAL scores from the saved 90 probability archives."""
    rows = read('DEV_THRESHOLD_RESULTS.json'); models = read('DEV_RESULTS.json')
    ids = np.flatnonzero(tv['role'] == 'val')
    truth = tv['label'][ids]; target = tv['Y'][ids, 0].astype(bool)
    f1_error = 0.; iou_error = 0.; probability_error = 0.; classes_ok = True; arrays_ok = True
    sparse_cases = []
    rng = np.random.default_rng(911103)
    for row in models:
        stem = f'dev_b{row["budget"]}_d{row["subset_seed"]}_{row["config_id"]}_s{row["seed"]}'
        with np.load(ROOT/'dev_val'/f'{stem}.npz', allow_pickle=False) as z:
            probability = z['probability']; prediction = z['prediction']; thresholds = z['thresholds']
            arrays_ok &= (np.array_equal(z['truth'], truth) and np.array_equal(z['target'], target)
                          and thresholds.tolist() == config['thresholds']
                          and probability.shape == (695, 12, 12) and prediction.shape == (7, 695)
                          and np.isfinite(probability).all()
                          and probability.min() >= 0 and probability.max() <= 1)
        payload = torch.load(ROOT/'models'/f'{stem}.pt', map_location='cpu', weights_only=True)
        net = independent_segmenter(); net.load_state_dict(payload['segmenter']); net.eval()
        with torch.inference_mode():
            cpu = net(torch.tensor(5*(tv['X'][ids[:24]]-.2))).sigmoid().numpy()[:, 0]
        probability_error = max(probability_error, float(np.max(np.abs(cpu-probability[:24]))))
        for ti, threshold in enumerate(thresholds):
            metric = [r for r in rows if r['budget'] == row['budget'] and r['subset_seed'] == row['subset_seed']
                      and r['seed'] == row['seed'] and r['config_id'] == row['config_id']
                      and r['threshold'] == threshold]
            assert len(metric) == 1, (stem, threshold)
            metric = metric[0]
            cm = np.bincount(9*truth+prediction[ti], minlength=81).reshape(9, 9)
            f1_error = max(f1_error, abs(float(macro(cm))-metric['mask_F1']))
            masks = probability >= threshold
            union = (masks | target).sum((1, 2)); intersection = (masks & target).sum((1, 2))
            iou = np.divide(intersection, union, out=np.ones(len(truth)), where=union > 0)
            iou_error = max(iou_error, abs(float(iou.mean())-metric['IoU']))
            witness = int(rng.integers(0, len(truth)))
            sparse_cases.append((masks[witness], int(prediction[ti, witness])))
            if threshold == .5:
                f1_error = max(f1_error, abs(float(macro(cm))-row['mask_F1']))
                iou_error = max(iou_error, abs(float(iou.mean())-row['IoU']))
    for mask, expected in sparse_cases:
        classes_ok &= 3*independent_direction(mask)+independent_direction(mask.T) == expected
    return dict(checks={'DEV_VAL_archives_alignment': bool(arrays_ok),
        'DEV_all_630_VAL_metrics_recomputed': f1_error < 1e-12 and iou_error < 1e-12,
        'DEV_CPU_MPS_probability_fixtures': probability_error < 1e-4,
        'DEV_sparse_threshold_class_witnesses': bool(classes_ok)},
        DEV_F1_max_error=f1_error, DEV_IoU_max_error=iou_error,
        DEV_CPU_MPS_probability_max_error=probability_error,
        DEV_sparse_class_cases=len(sparse_cases))


def check_statistics(config, result, chosen, complete, test):
    truth = test['label']; frames = test['frame']; target = test['Y'][:, 0].astype(bool)
    _, gid = np.unique(frames, return_inverse=True)
    n = len(truth); checks = {}
    point = np.empty((3, 5, 2), dtype=float); iou_point = np.empty_like(point)
    matrices = {}; f1_error = 0.; iou_error = 0.; fixture_error = 0.; head_error = 0.
    decode_ok = True; shape_ok = True; mask_fixture_ok = True
    sparse_cases = [(target[i], int(truth[i])) for c in range(9)
                    for i in np.flatnonzero(truth == c)[:16]]
    rng_sparse = np.random.default_rng(911102)
    with np.load(ROOT/'PREDICTIONS.npz', allow_pickle=False) as z:
        checks['prediction_alignment'] = (
            np.array_equal(z['truth'], truth) and np.array_equal(z['frames'], frames)
            and z['arms'].tolist() == ARMS == config['arms'] == result['arms']
            and z['modes'].tolist() == MODES and z['budgets'].tolist() == BUDGETS
            and z['seeds'].tolist() == SEEDS == config['final_seeds'] == result['seeds']
            and np.array_equal(z['truth_packed'], np.packbits(target.reshape(n, 144), axis=1)))
        for bi, budget in enumerate(BUDGETS):
            pred = z[f'pred_b{budget}']; packed = z[f'packed_b{budget}']
            ious = z[f'ious_b{budget}']; fixtures = z[f'probs_fixture_b{budget}']
            direct = z[f'direct_b{budget}']; head_fixtures = z[f'head_fixture_b{budget}']
            nd = len(DRAWS[budget])
            shape_ok &= (pred.shape == ious.shape == (nd, 3, 5, 2, n)
                and packed.shape == (nd, 3, 5, 2, n, 18)
                and fixtures.shape == (nd, 3, 5, 24, 1, 12, 12)
                and direct.shape == (nd, 3, 5, n)
                and z[f'draws_b{budget}'].tolist() == DRAWS[budget])
            cm = np.zeros((nd, 3, 5, 2, 8, 9, 9), dtype=np.int64)
            true_iou = np.zeros((nd, 3, 5, 2), dtype=float)
            for d, draw in enumerate(DRAWS[budget]):
                for si, seed in enumerate(SEEDS):
                    for ai, arm in enumerate(ARMS):
                        for mi, threshold in enumerate([chosen[str(budget)][arm]['threshold'], .5]):
                            masks = np.unpackbits(packed[d, si, ai, mi], axis=1, count=144).reshape(n, 12, 12).astype(bool)
                            mask_fixture_ok &= np.array_equal(masks[:24], fixtures[d, si, ai, :, 0] >= threshold)
                            y = pred[d, si, ai, mi]
                            for f in range(8):
                                keep = gid == f
                                cm[d, si, ai, mi, f] = np.bincount(9*truth[keep]+y[keep], minlength=81).reshape(9, 9)
                            score = f1_score(truth, y, labels=range(9), average='macro', zero_division=0)
                            section = result['metrics'] if mi == 0 else result['secondary_fixed05']
                            saved = section[str(budget)][arm]
                            f1_error = max(f1_error, abs(score-saved['per_draw_seed_mask_F1'][d][si]))
                            union = (masks | target).sum((1, 2)); intersection = (masks & target).sum((1, 2))
                            own_iou = np.divide(intersection, union, out=np.ones(n), where=union > 0)
                            true_iou[d, si, ai, mi] = own_iou.mean()
                            iou_error = max(iou_error, float(np.max(np.abs(own_iou-ious[d, si, ai, mi]))))
                            sample = rng_sparse.choice(n, 4, replace=False)
                            sparse_cases.extend((masks[i], int(y[i])) for i in sample)
                        name = f'final_b{budget}_d{draw}_{arm}_s{seed}.pt'
                        payload = torch.load(ROOT/'models'/name, map_location='cpu', weights_only=True)
                        net = independent_segmenter(); net.load_state_dict(payload['segmenter']); net.eval()
                        x = torch.tensor(5*(test['X'][:24]-.2))
                        with torch.inference_mode():
                            features = net[:-1](x); probability = net[-1](features).sigmoid().numpy()
                            fixture_error = max(fixture_error, float(np.max(np.abs(probability-fixtures[d, si, ai]))))
                            if arm != 'soft':
                                head = independent_head(); head.load_state_dict(payload['head']); head.eval()
                                logits = head(features.flatten(1)).numpy()
                                head_error = max(head_error, float(np.max(np.abs(logits-head_fixtures[d, si, ai]))))
                                decode_ok &= np.array_equal(head_fixtures[d, si, ai].argmax(1), direct[d, si, ai, :24])
                            else:
                                decode_ok &= np.all(direct[d, si, ai] == -1) and np.isnan(head_fixtures[d, si, ai]).all()
                        print(json.dumps({'stage': 'AUDIT_MODEL', 'budget': budget, 'draw': draw, 'seed': seed, 'arm': arm}), flush=True)
            model_f1 = macro(cm.sum(4))
            point[bi] = model_f1.mean((0, 1)); iou_point[bi] = true_iou.mean((0, 1))
            for ai, arm in enumerate(ARMS):
                for mi, section in enumerate([result['metrics'], result['secondary_fixed05']]):
                    saved = section[str(budget)][arm]
                    f1_error = max(f1_error, abs(point[bi, ai, mi]-saved['mask_F1']))
                    iou_error = max(iou_error, abs(iou_point[bi, ai, mi]-saved['IoU']))
                if arm != 'soft':
                    direct_score = np.mean([f1_score(truth, direct[d, s, ai], labels=range(9),
                        average='macro', zero_division=0) for d in range(nd) for s in range(3)])
                    f1_error = max(f1_error, abs(direct_score-result['metrics'][str(budget)][arm]['direct_head_F1']))
            matrices[budget] = cm[:, :, :, 0]
    checks['prediction_shapes_and_unique_54'] = bool(shape_ok)
    checks['probability_threshold_matches_saved_masks'] = bool(mask_fixture_ok)
    checks['direct_head_fixtures_decode'] = bool(decode_ok)
    checks['independent_F1_matches'] = f1_error < 1e-12
    # Saved per-example IoUs are deliberately float32, unlike the exact ratio.
    checks['independent_IoU_matches'] = iou_error < 2e-7
    checks['CPU_MPS_probability_fixtures'] = fixture_error < 1e-4
    checks['CPU_MPS_head_logit_fixtures'] = head_error < 1e-3
    with np.load(ROOT/'BOOTSTRAP.npz', allow_pickle=False) as z:
        stored = z['scores']; subset_ids = z['subset_ids']; seed_ids = z['seed_ids']; frame_ids = z['frame_ids']
        checks['all_frame_confusions_recomputed'] = all(np.array_equal(matrices[b], z[f'confusion_b{b}']) for b in BUDGETS)
    rng = np.random.default_rng(261102)
    checks['bootstrap_indices_recomputed'] = (
        np.array_equal(subset_ids, rng.integers(0, 3, (10000, 3)))
        and np.array_equal(seed_ids, rng.integers(0, 3, (10000, 3)))
        and np.array_equal(frame_ids, rng.integers(0, 8, (10000, 8)))
        and config['bootstrap_seed'] == 261102 and config['bootstrap_repetitions'] == 10000)
    draws = independent_bootstrap(matrices, subset_ids, seed_ids, frame_ids)
    bootstrap_error = float(np.max(np.abs(draws-stored)))
    checks['all_10000_bootstrap_draws_match'] = bootstrap_error < 1e-12
    primary = point[:2, :, 0].mean(0); primary_iou = iou_point[:2, :, 0].mean(0)
    primary_draws = draws[:2].mean(0)
    interval_error = 0.; gates_ok = True; primary_error = 0.; gate_set = []
    for ai, arm in enumerate(ARMS):
        primary_error = max(primary_error, abs(primary[ai]-result['primary_metrics'][arm]['mask_F1']),
                            abs(primary_iou[ai]-result['primary_metrics'][arm]['IoU']))
    for ai, arm in enumerate(ARMS[:-1]):
        delta = primary[4]-primary[ai]; distribution = primary_draws[4]-primary_draws[ai]
        interval = np.quantile(distribution, [.00625, .99375]); nominal = np.quantile(distribution, [.025, .975])
        individual = point[:2, 4, 0]-point[:2, ai, 0]
        own_iou_delta = primary_iou[4]-primary_iou[ai]
        own_gates = dict(gain_at_least_one_pp=bool(delta >= .01),
            positive_multiplicity_adjusted_CI_lower=bool(interval[0] > 0),
            both_budget_means_nonnegative=bool(individual.min() >= 0), IoU_guard=bool(own_iou_delta >= -.02))
        saved = result['soft_minus_control'][arm]
        gates_ok &= own_gates == saved['gates']; gate_set.append(all(own_gates.values()))
        interval_error = max(interval_error, abs(delta-saved['delta']),
            float(np.max(np.abs(interval-saved['CI98_75']))), float(np.max(np.abs(nominal-saved['CI95_nominal']))),
            float(np.max(np.abs(individual-saved['budget18_27_deltas']))), abs(own_iou_delta-saved['IoU_delta']))
        for bi, budget in enumerate(BUDGETS):
            descriptive = result['budget_comparisons_descriptive'][arm][str(budget)]
            own_interval = np.quantile(draws[bi, 4]-draws[bi, ai], [.025, .975])
            interval_error = max(interval_error,
                abs(point[bi, 4, 0]-point[bi, ai, 0]-descriptive['delta']),
                float(np.max(np.abs(own_interval-descriptive['CI95_nominal']))))
    checks['primary_mean18_27_matches'] = primary_error < 2e-7
    checks['nominal_and_Bonferroni_intervals_match'] = interval_error < 2e-7
    checks['scientific_gates_match'] = bool(gates_ok and
        result['status'] == ('PASS_PILOT' if all(gate_set) else 'FAIL_PILOT')
        and result['primary_budgets'] == [18, 27] and result['primary_controls'] == ARMS[:-1])
    checks['TEST_metadata_matches'] = (result['test_examples'] == n
        and result['test_frames'] == sorted(set(frames.tolist()))
        and result['test_class_counts'] == np.bincount(truth, minlength=9).tolist())
    mismatches = 0
    with threadpool_limits(limits=2):
        for mask, expected in sparse_cases:
            mismatches += int(3*independent_direction(mask)+independent_direction(mask.T) != expected)
    checks['independent_sparse_classes'] = mismatches == 0
    return dict(checks=checks, independent_F1_max_error=f1_error, independent_IoU_max_error=iou_error,
        CPU_MPS_probability_max_error=fixture_error, CPU_MPS_head_logit_max_error=head_error,
        independent_bootstrap_max_error=bootstrap_error, primary_point_max_error=primary_error,
        interval_max_error=interval_error, independent_sparse_class_cases=len(sparse_cases),
        sparse_class_mismatches=mismatches)


def main():
    started = time.monotonic(); torch.set_num_threads(2)
    # RESULT.json exists only after the official evaluator has completed.
    result = read('RESULT.json')
    config = read('CONFIG.json'); frozen = read('FROZEN.json')
    complete = read('TRAINING_COMPLETE.json'); selection = read('SELECTION.json')
    manifest = read('DATA_MANIFEST.json'); ef = read('EVALUATION_FROZEN.json')
    names = ['PROTOCOL.md', 'CONFIG.json', 'train.py', 'prepare.py', 'evaluate.py',
             'DATA.npz', 'TRAIN_VAL.npz', 'TEST.npz', 'DATA_MANIFEST.json', 'SOURCE_PLAN.json',
             'SUBSETS.json', 'DEV_RESULTS.json', 'DEV_THRESHOLD_RESULTS.json', 'SELECTION.json', 'TRAINING_COMPLETE.json',
             'FROZEN.json', 'RESULT.json', 'PREDICTIONS.npz', 'BOOTSTRAP.npz', 'EVALUATION_FROZEN.json']
    before = {name: sha(ROOT/name) for name in names}
    checks = {}
    checks['protocol_and_evaluator_frozen'] = (
        before['PROTOCOL.md'] == config['protocol_sha256'] == manifest['protocol_sha256'] == ef['protocol_sha256']
        and before['CONFIG.json'] == ef['config_sha256']
        and before['evaluate.py'] == ef['script_sha256'] == result['analysis_sha256']
        and before['EVALUATION_FROZEN.json'] == result['evaluation_frozen_sha256']
        and before['SELECTION.json'] == ef['selection_sha256']
        and before['TRAINING_COMPLETE.json'] == ef['training_complete_sha256']
        and before['FROZEN.json'] == ef['frozen_sha256']
        and before['TEST.npz'] == ef['TEST_sha256'] == manifest['TEST_sha256']
        and before['PREDICTIONS.npz'] == result['predictions_sha256']
        and before['BOOTSTRAP.npz'] == result['bootstrap_sha256'])
    # Frozen-trainer/checkpoint schema is inspected separately below.
    with np.load(ROOT/'TRAIN_VAL.npz', allow_pickle=False) as z:
        tv = {k: z[k] for k in z.files}
    with np.load(ROOT/'TEST.npz', allow_pickle=False) as z:
        test = {k: z[k] for k in z.files}
    checks.update(check_subsets(config, tv))
    extra, chosen = check_selection(config, selection); checks.update(extra)
    # Remaining provenance/model-metadata checks are kept separate from the
    # scientific score calculations so a scientific FAIL can still audit PASS.
    checks.update(check_provenance(config, frozen, complete, manifest, before, tv, test, selection))
    dev_evidence = check_dev_evidence(config, tv)
    checks.update(dev_evidence.pop('checks'))
    statistics = check_statistics(config, result, chosen, complete, test)
    checks.update(statistics.pop('checks'))
    checks['audit_did_not_modify_inputs'] = before == {name: sha(ROOT/name) for name in names}
    protected = read('PROTECTED_BEFORE.json')
    checks['protected_old_files_unchanged'] = all(sha(G/name) == h for name, h in protected.items())
    checks['protected_old_file_count'] = len(protected) == 434
    output = dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        checks={k: bool(v) for k, v in checks.items()},
        input_sha256=before, script_sha256=sha(Path(__file__)),
        protected_existing_files=len(protected), seconds=time.monotonic()-started,
        scope='Independent CPU audit. Technical PASS/FAIL is separate from the scientific pilot outcome.',
        **dev_evidence, **statistics)
    save(output); print(json.dumps(output, ensure_ascii=False), flush=True)
    assert output['status'] == 'PASS_AUDIT', {k: v for k, v in checks.items() if not v}


if __name__ == '__main__':
    main()
