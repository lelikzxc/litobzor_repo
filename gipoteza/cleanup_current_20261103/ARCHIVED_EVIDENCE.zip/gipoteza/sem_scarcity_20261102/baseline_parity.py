"""CPU-only comparison with unmodified pinned author class definitions.

Only the needed classes are compiled from their AST, omitting imports for the
uninstalled nnU-Net/DDP/training framework. No numerical method is rewritten in
the reference classes. The unused DDP path fails if accidentally entered.
"""
from pathlib import Path
import ast
import hashlib
import json
from typing import Callable, List, Union

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from scipy import ndimage as ndi
from skimage.morphology import dilation, skeletonize

from baselines import (tube_targets, foreground_dice_loss,
                       skeleton_recall_loss, loss)

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / 'vendor_skelrec'


class UnusedFrameworkBase:
    pass


class ForbiddenDDP:
    @staticmethod
    def apply(*args):
        raise AssertionError('Distributed path must never be used')


def author_class(path, name):
    parsed = ast.parse(path.read_text())
    nodes = [node for node in parsed.body if isinstance(node, ast.ClassDef) and node.name == name]
    assert len(nodes) == 1
    module = ast.Module(body=nodes, type_ignores=[])
    space = dict(torch=torch, nn=nn, np=np, ndi=ndi, skeletonize=skeletonize,
                 dilation=dilation, Callable=Callable, Union=Union, List=List,
                 SegOnlyTransform=UnusedFrameworkBase, AllGatherGrad=ForbiddenDDP)
    exec(compile(module, str(path), 'exec'), space)
    return space[name]


def main():
    torch.set_num_threads(2)
    torch.manual_seed(911002)
    transform_cls = author_class(VENDOR / 'skeleton_recall/training/data_augmentation/skeletonization.py', 'SkeletonTransform')
    recall_cls = author_class(VENDOR / 'skeleton_recall/training/loss/dice.py', 'SoftSkeletonRecallLoss')
    dice_cls = author_class(VENDOR / 'nnunet_v2_8_0/nnunetv2/training/loss/dice.py', 'MemoryEfficientSoftDiceLoss')
    with np.load(ROOT.parent / 'sem_cldice_expansion_20261102/TRAIN_VAL.npz', allow_pickle=False) as z:
        dense = z['Y'][z['role'] == 'dense'].copy()
    assert dense.shape == (54, 1, 12, 12)
    witnesses = np.zeros((8, 1, 12, 12), dtype=np.uint8)
    witnesses[1] = 1
    witnesses[2, 0, 6, 6] = 1
    witnesses[3, 0, :, 6] = 1
    witnesses[4, 0, 6, :] = 1
    witnesses[5, 0, 3:9, 3:9] = 1
    witnesses[5, 0, 4:8, 4:8] = 0
    witnesses[6, 0, ::2, ::2] = 1
    witnesses[7, 0, 1:4, 1:4] = 1
    witnesses[7, 0, 8:11, 8:11] = 1
    masks = np.concatenate((dense, witnesses))
    transform = transform_cls(do_tube=True)
    official_tubes = torch.stack([
        transform._add_skeleton(torch.from_numpy(mask.astype(np.float32)))[1:]
        for mask in masks
    ]).numpy()
    ours_tubes = tube_targets(masks)
    assert np.array_equal(official_tubes, ours_tubes)
    assert np.array_equal(tube_targets(masks[:, 0]), ours_tubes[:, 0])
    assert not np.logical_and(ours_tubes > 0, masks == 0).any()
    kwargs = dict(apply_nonlin=lambda x: x.softmax(1), batch_dice=False,
                  do_bg=False, smooth=1e-5, ddp=False)
    official_dice = dice_cls(**kwargs)
    official_recall = recall_cls(**kwargs)
    records = []
    for dtype in [torch.float32, torch.float64]:
        target = torch.tensor(masks.astype(np.float32), dtype=dtype)
        tubes = torch.tensor(ours_tubes, dtype=dtype)
        for scale in [.2, 3., 25.]:
            initial = scale * torch.randn(target.shape, dtype=dtype)
            for term in ['dice', 'recall', 'composite']:
                ours = initial.clone().requires_grad_(True)
                reference = initial.clone().requires_grad_(True)
                two_logits = torch.cat((torch.zeros_like(reference), reference), dim=1)
                if term == 'dice':
                    a = foreground_dice_loss(ours, target)
                    b = official_dice(two_logits, target)
                elif term == 'recall':
                    a = skeleton_recall_loss(ours, tubes)
                    b = official_recall(two_logits, tubes)
                else:
                    a = F.binary_cross_entropy_with_logits(ours, target) + loss(ours, target, tubes)
                    b = F.cross_entropy(two_logits, target[:, 0].long()) + official_dice(two_logits, target) + official_recall(two_logits, tubes)
                ga, = torch.autograd.grad(a, ours)
                gb, = torch.autograd.grad(b, reference)
                error_loss = abs(float(a.detach()) - float(b.detach()))
                error_grad = float((ga - gb).abs().max())
                assert torch.isfinite(ga).all() and torch.isfinite(gb).all()
                assert error_loss < 1e-6, (dtype, scale, term, error_loss)
                assert error_grad < 1e-6, (dtype, scale, term, error_grad)
                records.append(dict(dtype=str(dtype), scale=scale, term=term,
                                    loss_error=error_loss, gradient_max_error=error_grad))
    # Empty tubed targets have the exact author convention: value -1, zero grad.
    empty_logits = torch.zeros((1, 1, 12, 12), requires_grad=True)
    empty = torch.zeros_like(empty_logits)
    value = skeleton_recall_loss(empty_logits, empty)
    gradient, = torch.autograd.grad(value, empty_logits)
    assert float(value.detach()) == -1 and torch.count_nonzero(gradient) == 0
    result = dict(status='PASS_BASELINE_PARITY', dense_masks=54, witness_masks=8,
                  exact_author_tubes=True, dtype_checks=['float32', 'float64'],
                  comparison_cases=len(records), loss_tolerance=1e-6,
                  gradient_tolerance=1e-6, empty_skeleton_value=-1,
                  empty_skeleton_gradient_zero=True,
                  max_loss_error=max(r['loss_error'] for r in records),
                  max_gradient_error=max(r['gradient_max_error'] for r in records),
                  references='unchanged class ASTs, framework imports omitted; no DDP/ignore labels',
                  records=records)
    (ROOT / 'BASELINE_PARITY.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'records'}, indent=2))


if __name__ == '__main__':
    main()
