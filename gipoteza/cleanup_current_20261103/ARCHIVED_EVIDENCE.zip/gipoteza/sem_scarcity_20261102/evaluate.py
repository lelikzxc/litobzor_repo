"""Single frozen TEST evaluation of the label-scarcity study; no fitting."""
from pathlib import Path
import csv
import json
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

import train

ROOT = Path(__file__).resolve().parent
ARMS = ['head9', 'cldice_head9', 'dice_head9', 'skelrec_head9', 'soft']
BUDGETS = [18, 27, 54]
MODES = ['calibrated', 'fixed05']
SEEDS = [5501, 5521, 5557]
DRAWS = {18: [5303, 5351, 5387], 27: [5303, 5351, 5387], 54: [0]}


def save(name, value):
    train.save(ROOT / name, value)


def macro(confusion):
    den = confusion.sum(-1) + confusion.sum(-2)
    num = 2 * np.diagonal(confusion, axis1=-2, axis2=-1)
    return np.divide(num, den, out=np.zeros_like(num, dtype=float), where=den > 0).mean(-1)


def bootstrap(confusions, subset_ids, seed_ids, frame_ids):
    """Bounded chunks, preserving crossed seed/draw and nested-budget pairing."""
    out = np.empty((3, 5, len(seed_ids)), dtype=float)
    for b, budget in enumerate(BUDGETS):
        c = confusions[budget]
        for start in range(0, len(seed_ids), 128):
            end = min(start + 128, len(seed_ids))
            d = subset_ids[start:end] if budget != 54 else np.zeros((end-start, 1), dtype=int)
            s = seed_ids[start:end]
            f = frame_ids[start:end]
            # Advanced indices broadcast to (repetition, draw, seed, frame).
            sampled = c[d[:, :, None, None], s[:, None, :, None], :, f[:, None, None, :]]
            assert sampled.shape == (end-start, d.shape[1], 3, 8, 5, 9, 9)
            out[b, :, start:end] = macro(sampled.sum(3)).mean((1, 2)).T
    return out


def main():
    started = time.monotonic()
    assert torch.backends.mps.is_available(), 'MPS required; fallback prohibited'
    assert not (ROOT / 'RESULT.json').exists() and not (ROOT / 'PREDICTIONS.npz').exists()
    config = json.loads((ROOT / 'CONFIG.json').read_text())
    complete = json.loads((ROOT / 'TRAINING_COMPLETE.json').read_text())
    frozen = json.loads((ROOT / 'FROZEN.json').read_text())
    selection = json.loads((ROOT / 'SELECTION.json').read_text())
    assert complete['status'] == 'COMPLETE_TRAINING_NO_TEST_OPENED'
    assert selection['status'] == 'FROZEN_BEFORE_TEST'
    assert config['arms'] == ARMS and config['final_seeds'] == SEEDS
    assert complete['backbone_steps'] == config['total_backbone_updates'] == 310800
    assert complete['head_only_steps'] == config['total_head_updates'] == 31200
    hashes = complete['checkpoint_hashes']
    assert len(hashes) == 222
    assert all(train.sha(ROOT / 'models' / name) == h for name, h in hashes.items())
    # Training freezes only its dependencies; evaluator is independently frozen
    # here before the first model sees any new TEST input.
    checks = train.verify_frozen() if hasattr(train, 'verify_frozen') else {}
    assert train.sha(ROOT / 'PROTOCOL.md') == config['protocol_sha256']
    manifest = json.loads((ROOT / 'DATA_MANIFEST.json').read_text())
    assert train.sha(ROOT / 'TEST.npz') == manifest['TEST_sha256']
    evaluation_frozen = {
        'script_sha256': train.sha(Path(__file__)),
        'protocol_sha256': config['protocol_sha256'],
        'config_sha256': train.sha(ROOT / 'CONFIG.json'),
        'selection_sha256': train.sha(ROOT / 'SELECTION.json'),
        'training_complete_sha256': train.sha(ROOT / 'TRAINING_COMPLETE.json'),
        'frozen_sha256': train.sha(ROOT / 'FROZEN.json'),
        'TEST_sha256': manifest['TEST_sha256'], 'checkpoint_count': len(hashes),
        'bootstrap_repetitions': 10000, 'bootstrap_seed': 261102,
        'primary_budgets': [18, 27], 'primary_controls': ARMS[:-1],
        'input_checks': checks,
    }
    save('EVALUATION_FROZEN.json', evaluation_frozen)
    torch.set_num_threads(2)
    with np.load(ROOT / 'TEST.npz', allow_pickle=False) as z:
        x = z['X']; target = z['Y'][:, 0].astype(bool)
        truth = z['label']; frames = z['frame']
    frame_values, gid = np.unique(frames, return_inverse=True)
    assert len(frame_values) == 8 and set(frame_values) == set(config['test_frames'])
    n = len(truth)
    saved = {'truth': truth, 'frames': frames, 'arms': np.array(ARMS),
             'seeds': np.array(SEEDS), 'budgets': np.array(BUDGETS), 'modes': np.array(MODES),
             'truth_packed': np.packbits(target.reshape(n, 144), axis=1)}
    confusions = {}; rows = []; metric = {}; fixed = {}; iou_means = {}
    completed = 0
    with threadpool_limits(limits=2):
        for budget in BUDGETS:
            nd = len(DRAWS[budget])
            predictions = np.empty((nd, 3, 5, 2, n), dtype=np.int64)
            packed = np.empty((nd, 3, 5, 2, n, 18), dtype=np.uint8)
            ious = np.empty((nd, 3, 5, 2, n), dtype=np.float32)
            fixtures = np.empty((nd, 3, 5, 24, 1, 12, 12), dtype=np.float32)
            direct = np.full((nd, 3, 5, n), -1, dtype=np.int64)
            head_fixture = np.full((nd, 3, 5, 24, 9), np.nan, dtype=np.float32)
            conf = np.zeros((nd, 3, 5, 2, 8, 9, 9), dtype=np.int32)
            for d, draw in enumerate(DRAWS[budget]):
                for s, seed in enumerate(SEEDS):
                    for a, arm in enumerate(ARMS):
                        name = f'final_b{budget}_d{draw}_{arm}_s{seed}.pt'
                        payload = torch.load(ROOT / 'models' / name, map_location='cpu', weights_only=True)
                        selected = selection['chosen'][str(budget)][arm]
                        net = train.make_segmenter().to('mps')
                        net.load_state_dict(payload['segmenter']); net.eval()
                        head = None if arm == 'soft' else train.make_head(arm).to('mps')
                        assert (payload['head'] is None) == (head is None)
                        if head is not None:
                            head.load_state_dict(payload['head']); head.eval()
                        parts = []; heads = []
                        with torch.inference_mode():
                            for offset in range(0, n, 256):
                                batch = torch.tensor(5*(x[offset:offset+256]-.2), device='mps')
                                features = net[:-1](batch)
                                probability = net[-1](features).sigmoid().cpu().numpy()
                                parts.append(probability[:, 0])
                                if offset == 0:
                                    fixtures[d, s, a] = probability[:24]
                                if head is not None:
                                    hl = head(features.flatten(1)).cpu().numpy()
                                    heads.append(hl.argmax(1))
                                    if offset == 0:
                                        head_fixture[d, s, a] = hl[:24]
                        probability = np.concatenate(parts)
                        if head is not None:
                            direct[d, s, a] = np.concatenate(heads)
                        for m, threshold in enumerate([selected['threshold'], .5]):
                            masks = probability >= threshold
                            predictions[d, s, a, m] = train.hard_classes(masks)
                            packed[d, s, a, m] = np.packbits(masks.reshape(n, 144), axis=1)
                            union = (masks | target).sum((1, 2))
                            iou = np.divide((masks & target).sum((1, 2)), union,
                                            out=np.ones(n, dtype=float), where=union > 0)
                            ious[d, s, a, m] = iou
                            for f in range(8):
                                ids = gid == f
                                conf[d, s, a, m, f] = np.bincount(
                                    9*truth[ids] + predictions[d, s, a, m, ids], minlength=81).reshape(9, 9)
                            rows.append({'budget': budget, 'draw': draw, 'seed': seed,
                                'family': arm, 'mode': MODES[m], 'threshold': threshold,
                                'mask_F1': float(macro(conf[d, s, a, m].sum(0))),
                                'IoU': float(iou.mean()), 'checkpoint': name,
                                'checkpoint_sha256': hashes[name]})
                        completed += 1
                        save('EVALUATION_PROGRESS.json', {'stage': 'TEST_INFERENCE',
                            'completed_models': completed, 'total_models': 105,
                            'budget': budget, 'draw': draw, 'seed': seed, 'arm': arm,
                            'seconds': time.monotonic()-started})
                        print(json.dumps({'stage': 'TEST_INFERENCE', 'completed': completed,
                            'total': 105, 'budget': budget, 'draw': draw, 'seed': seed, 'arm': arm}), flush=True)
                        del net, head
            saved.update({f'pred_b{budget}': predictions, f'packed_b{budget}': packed,
                          f'ious_b{budget}': ious, f'probs_fixture_b{budget}': fixtures,
                          f'direct_b{budget}': direct, f'head_fixture_b{budget}': head_fixture,
                          f'draws_b{budget}': np.array(DRAWS[budget])})
            confusions[budget] = conf[:, :, :, 0]
            p = macro(conf.sum(4))  # draw, seed, arm, mode
            metric[str(budget)] = {}; fixed[str(budget)] = {}; iou_means[budget] = ious.mean((0, 1, 4))
            for a, arm in enumerate(ARMS):
                for m, container in enumerate([metric[str(budget)], fixed[str(budget)]]):
                    container[arm] = {'mask_F1': float(p[:, :, a, m].mean()),
                        'per_draw_seed_mask_F1': p[:, :, a, m].tolist(),
                        'IoU': float(ious[:, :, a, m].mean()),
                        'threshold': float(selection['chosen'][str(budget)][arm]['threshold']) if m == 0 else .5}
                if arm != 'soft':
                    hp = []
                    for d in range(nd):
                        hp.append([])
                        for s in range(3):
                            cm = np.bincount(9*truth+direct[d, s, a], minlength=81).reshape(9, 9)
                            hp[d].append(float(macro(cm)))
                    metric[str(budget)][arm]['direct_head_F1'] = float(np.mean(hp))
                    metric[str(budget)][arm]['direct_head_status'] = 'Secondary; different inference route'
    np.savez_compressed(ROOT / 'PREDICTIONS.npz', **saved)
    with (ROOT / 'final_test_results.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    rng = np.random.default_rng(261102)
    subset_ids = rng.integers(0, 3, (10000, 3))
    seed_ids = rng.integers(0, 3, (10000, 3))
    frame_ids = rng.integers(0, 8, (10000, 8))
    draws = bootstrap(confusions, subset_ids, seed_ids, frame_ids)
    primary_draws = draws[:2].mean(0)
    primary = {arm: {'mask_F1': float(np.mean([metric[str(b)][arm]['mask_F1'] for b in [18, 27]])),
                     'IoU': float(np.mean([metric[str(b)][arm]['IoU'] for b in [18, 27]]))}
               for arm in ARMS}
    comparisons = {}; budget_comparisons = {}
    for a, arm in enumerate(ARMS[:-1]):
        distribution = primary_draws[4]-primary_draws[a]
        interval = np.quantile(distribution, [.00625, .99375])
        delta = primary['soft']['mask_F1'] - primary[arm]['mask_F1']
        iou_delta = primary['soft']['IoU'] - primary[arm]['IoU']
        individual = [metric[str(b)]['soft']['mask_F1']-metric[str(b)][arm]['mask_F1'] for b in [18, 27]]
        comparisons[arm] = {'delta': float(delta), 'CI98_75': interval.tolist(),
            'CI95_nominal': np.quantile(distribution, [.025, .975]).tolist(),
            'IoU_delta': float(iou_delta), 'budget18_27_deltas': individual,
            'gates': {'gain_at_least_one_pp': bool(delta >= .01),
                      'positive_multiplicity_adjusted_CI_lower': bool(interval[0] > 0),
                      'both_budget_means_nonnegative': bool(min(individual) >= 0),
                      'IoU_guard': bool(iou_delta >= -.02)}}
        budget_comparisons[arm] = {}
        for b, budget in enumerate(BUDGETS):
            budget_comparisons[arm][str(budget)] = {
                'delta': metric[str(budget)]['soft']['mask_F1']-metric[str(budget)][arm]['mask_F1'],
                'CI95_nominal': np.quantile(draws[b, 4]-draws[b, a], [.025, .975]).tolist(),
                'status': 'Descriptive; primary criterion is mean18/27, no separate superiority claim'}
    passed = all(all(v['gates'].values()) for v in comparisons.values())
    np.savez_compressed(ROOT / 'BOOTSTRAP.npz', scores=draws, subset_ids=subset_ids,
        seed_ids=seed_ids, frame_ids=frame_ids,
        **{f'confusion_b{b}': confusions[b] for b in BUDGETS})
    result = {'status': 'PASS_PILOT' if passed else 'FAIL_PILOT',
        'test_examples': n, 'test_frames': frame_values.tolist(),
        'test_class_counts': np.bincount(truth, minlength=9).tolist(),
        'arms': ARMS, 'seeds': SEEDS, 'subset_draws': DRAWS,
        'primary_budgets': [18, 27], 'primary_controls': ARMS[:-1],
        'metrics': metric, 'primary_metrics': primary,
        'soft_minus_control': comparisons, 'budget_comparisons_descriptive': budget_comparisons,
        'secondary_fixed05': fixed,
        'seconds': time.monotonic()-started,
        'predictions_sha256': train.sha(ROOT / 'PREDICTIONS.npz'),
        'bootstrap_sha256': train.sha(ROOT / 'BOOTSTRAP.npz'),
        'analysis_sha256': train.sha(Path(__file__)),
        'evaluation_frozen_sha256': train.sha(ROOT / 'EVALUATION_FROZEN.json'),
        'scope': 'Follow-up scarcity study after negative54-mask result; one physical IC. '
                 'Three crossed subset draws and seeds at18/27;54 has one unique full set. '
                 'Geometric proxy classes, not production defect labels. Four controls and '
                 'Bonferroni intervals; finite fixed VAL grid. No novelty or publication guarantee.'}
    save('RESULT.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
