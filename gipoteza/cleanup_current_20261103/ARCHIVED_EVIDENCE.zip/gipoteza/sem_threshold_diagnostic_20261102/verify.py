"""Independent saved-output checks; CPU only, no TEST access."""
from pathlib import Path
import hashlib
import json
import os
import sys
import time

import numpy as np
from scipy import sparse
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import spsolve
import torch
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def direction(mask):
    """Sparse Kirchhoff solve only on components joining the two electrodes."""
    mask = np.asarray(mask, dtype=bool)
    edges = [(12*y+x, 12*yy+xx) for y in range(12) for x in range(12)
             for yy, xx in [(y+1, x), (y, x+1)]
             if yy < 12 and xx < 12 and mask[y, x] and mask[yy, xx]]
    if not edges:
        return 0
    first, second = np.array(edges).T
    graph = sparse.csr_matrix((np.ones(2*len(edges)),
        (np.r_[first, second], np.r_[second, first])), shape=(144, 144))
    _, component = connected_components(graph, directed=False)
    left = np.arange(0, 144, 12); right = left + 11
    shared = np.intersect1d(component[left[mask[:, 0]]], component[right[mask[:, -1]]])
    if not len(shared):
        return 0
    active = np.isin(component, shared)
    graph = graph.multiply(active[:, None] * active[None, :]).tocsr()
    laplacian = sparse.diags(np.asarray(graph.sum(1)).ravel()) - graph
    free = np.array([12*y+x for y in range(12) for x in range(1, 11) if active[12*y+x]])
    rhs = -np.asarray(laplacian[free][:, right].sum(1)).ravel()
    voltage = spsolve(laplacian[free][:, free].tocsc(), rhs)
    value = float(laplacian[right][:, right].sum() - rhs @ voltage) / (12/11)
    return 0 if value < 1e-8 else 1 if value < .5 - 1e-8 else 2


def key(row):
    return (row['mask_F1'], row['IoU'], -abs(row['threshold'] - .5),
            -row['weight'], -row['cldice_weight'], -row['threshold'])


def main():
    started = time.monotonic()
    protocol = json.loads((ROOT/'PROTOCOL.json').read_text())
    result = json.loads((ROOT/'RESULT.json').read_text())
    rows = json.loads((ROOT/'VAL_ROWS.json').read_text())
    aggregate = json.loads((ROOT/'AGGREGATE_VAL.json').read_text())
    checks = {
        'protocol_hash': sha(ROOT/'PROTOCOL.json') == result['protocol_sha256'],
        'protected_files_unchanged': all(sha(ROOT/p) == h for p,h in protocol['protected_files_sha256'].items()),
        'result_files_hash': all(sha(ROOT/p) == h for p,h in result['output_sha256'].items()),
        'no_test_selection_declared': result['selection_uses_TEST'] is False and protocol['no_TEST_access'],
        'row_counts': len(rows) == 322 and len(aggregate) == 161,
        'historical_half_exact': result['fixed_half_historical_max_F1_error'] == 0 and result['fixed_half_historical_max_IoU_error'] == 0,
    }
    with np.load(ROOT/'VAL_PROBABILITIES.npz', allow_pickle=False) as z:
        probability = z['probability']; truth = z['truth']; target = z['target']; pred = z['prediction']
        thresholds = z['threshold']; configs = z['config_id']; seeds = z['seed']; ids = z['val_indices']
    checks['array_shape'] = probability.shape == (46, 695, 12, 12) and pred.shape == (46, 7, 695)
    checks['probability_finite'] = bool(np.isfinite(probability).all() and (probability >= 0).all() and (probability <= 1).all())
    checks['threshold_grid'] = thresholds.tolist() == protocol['thresholds']
    with np.load(G/'sem_cldice_expansion_20261102/TRAIN_VAL.npz', allow_pickle=False) as archive:
        checks['only_VAL_indices'] = np.array_equal(ids, np.flatnonzero(archive['role'] == 'val'))
        checks['truth_matches_VAL'] = np.array_equal(truth, archive['label'][ids]) and np.array_equal(target, archive['Y'][ids, 0].astype(bool))
        x = 5*(archive['X'][ids[:24]] - .2)
    errors = []
    for row in rows:
        model = np.flatnonzero((configs == row['config_id']) & (seeds == row['seed']))
        threshold = np.flatnonzero(thresholds == row['threshold'])
        assert len(model) == len(threshold) == 1
        i, j = int(model[0]), int(threshold[0])
        confusion = np.bincount(9*truth + pred[i,j], minlength=81).reshape(9,9)
        denominator = confusion.sum(0) + confusion.sum(1)
        f1 = np.divide(2*np.diag(confusion), denominator, out=np.zeros(9, dtype=float), where=denominator > 0).mean()
        mask = probability[i] >= thresholds[j]
        union = (mask | target).sum((1,2))
        iou = np.divide((mask & target).sum((1,2)), union,
                        out=np.ones(len(union)), where=union > 0).mean()
        errors.append(max(abs(f1-row['mask_F1']), abs(iou-row['IoU'])))
    checks['all_322_metrics_reproduced'] = max(errors) < 1e-12
    for row in aggregate:
        source = [r for r in rows if r['config_id'] == row['config_id'] and r['threshold'] == row['threshold']]
        assert len(source) == 2
        assert row['mask_F1'] == np.mean([r['mask_F1'] for r in source])
        assert row['IoU'] == np.mean([r['IoU'] for r in source])
    checks['all_161_aggregations_reproduced'] = True
    checks['selection_reproduced'] = all(
        result['selected'][arm]['calibrated'] == max([r for r in aggregate if r['family'] == arm], key=key)
        and result['selected'][arm]['fixed_half'] == max([r for r in aggregate if r['family'] == arm and r['threshold'] == .5], key=key)
        for arm in protocol['arms'])
    rng = np.random.default_rng(211102)
    independent = []
    for _ in range(256):
        i = int(rng.integers(46)); j = int(rng.integers(7)); k = int(rng.integers(695))
        mask = probability[i,k] >= thresholds[j]
        actual = 3*direction(mask) + direction(mask.T)
        assert actual == pred[i,j,k], (i,j,k,actual,int(pred[i,j,k]))
        independent.append(dict(model=i, threshold_index=j, row=k, actual=actual))
    checks['independent_256_sparse_classes'] = True
    sys.path.insert(0, str(G/'sem_physics_materials'))
    from physics_loss_example import make_segmenter
    cpu_errors = []
    for i in [0, 15, 32, 45]:
        record = protocol['checkpoints'][i]
        model = make_segmenter()
        payload = torch.load(G/record['path'], map_location='cpu', weights_only=True)
        model.load_state_dict(payload['segmenter']); model.eval()
        with torch.inference_mode():
            actual = model(torch.from_numpy(x)).sigmoid()[:,0].numpy()
        cpu_errors.append(float(np.max(np.abs(actual - probability[i,:24]))))
    checks['CPU_MPS_probability_agreement'] = max(cpu_errors) < 1e-4
    checks['protected_files_still_unchanged'] = all(sha(ROOT/p) == h for p,h in protocol['protected_files_sha256'].items())
    checks = {name: bool(value) for name, value in checks.items()}
    assert all(checks.values()), checks
    audit = dict(status='PASS_VAL_DIAGNOSTIC_AUDIT', checks=checks,
                 metric_max_error=max(errors), CPU_MPS_probability_max_error=max(cpu_errors),
                 independent_class_fixtures=independent, seconds=time.monotonic()-started,
                 script_sha256=sha(Path(__file__)), result_sha256=sha(ROOT/'RESULT.json'))
    (ROOT/'AUDIT.json').write_text(json.dumps(audit, indent=2)+'\n')
    manifest = {p.name: sha(p) for p in ROOT.iterdir() if p.is_file() and p.name not in ['COMPLETE.json','verify.log','diagnose.log']}
    (ROOT/'COMPLETE.json').write_text(json.dumps(dict(status='COMPLETE_VAL_ONLY_DIAGNOSTIC',
        scientific_status='EXPLORATORY_VAL_ONLY_NO_TEST_CONFIRMATION',
        audit_status=audit['status'], artifact_sha256=manifest), indent=2)+'\n')
    print(json.dumps({k:v for k,v in audit.items() if k != 'independent_class_fixtures'}), flush=True)


if __name__ == '__main__':
    torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        main()
