# Порог бинаризации: только диагностика на VAL

Проверяются существующие DEV-модели без обучения и без доступа к TEST. До вывода вероятностей фиксируются одинаковая сетка порогов, критерий выбора и SHA-256 всех входов в [PROTOCOL.json](PROTOCOL.json).

На 695 валидационных фрагментах сравниваются 46 сохранённых моделей: 5 настроек BCE + голова, 17 настроек BCE + clDice + голова и одна заранее фиксированная настройка физической регуляризации; каждая обучена ранее с двумя DEV-инициализациями. Изменение на VAL после подбора порога является оптимистичной диагностикой. Оно не подтверждает превосходство на новых изображениях.

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B gipoteza/sem_threshold_diagnostic_20261102/diagnose.py --freeze
PYTHONDONTWRITEBYTECODE=1 PYTORCH_ENABLE_MPS_FALLBACK=0 .venv/bin/python -B gipoteza/sem_threshold_diagnostic_20261102/diagnose.py --device mps
```

Итог будет сохранён в [REPORT.md](REPORT.md), численные строки — в `per_seed_VAL.csv` и `aggregate_VAL.csv`, вероятности — в `VAL_PROBABILITIES.npz`. Текущий этап доступен в `PROGRESS.json` и `diagnose.log`.
