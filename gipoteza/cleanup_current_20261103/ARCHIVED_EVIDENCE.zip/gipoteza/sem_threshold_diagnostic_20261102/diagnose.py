"""VAL-only threshold calibration of existing DEV models; no TEST or training.

Freeze with --freeze first, then run --device mps (or explicit cpu).
The import-safe historical helpers only construct models and label binary grids.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import importlib.util
import json
import os
import sys
import time

os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '0'
import numpy as np
import torch
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
LATEST = G / 'sem_cldice_expansion_20261102'
OLD = G / 'sem_cldice_confirmation_20261030'
THRESHOLDS = [.30, .40, .45, .50, .55, .60, .70]
SEEDS = [3011, 3041]
ARMS = ['head9', 'cldice_head9', 'soft']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    path = ROOT / name
    temp = path.with_suffix(path.suffix + '.partial')
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    temp.replace(path)


def helper():
    sys.path.insert(0, str(LATEST))
    spec = importlib.util.spec_from_file_location('threshold_historical_train', LATEST / 'train.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sources(t):
    paths = [Path(__file__), ROOT / 'README.md', LATEST / 'train.py',
             LATEST / 'TRAIN_VAL.npz', LATEST / 'physics_adapter.py',
             LATEST / 'prepare.py', LATEST / 'vendor/cldice.py',
             LATEST / 'vendor/soft_skeleton.py',
             G / 'sem_physics_materials/physics_loss_example.py',
             G / 'sem_confirmation_20261028/prepare.py',
             G / 'retained_evidence_20261027/SELECTED_SOURCES.zip',
             OLD / 'DEV_RESULTS.json', LATEST / 'DEV_RESULTS.json']
    checkpoints = []
    for config in t.selection_candidates():
        for seed in SEEDS:
            name = f'dev_{config["config_id"]}_{seed}.pt'
            matches = [folder / 'models' / name for folder in [LATEST, OLD]
                       if (folder / 'models' / name).exists()]
            assert len(matches) == 1, (name, matches)
            checkpoints.append(dict(config=config, seed=seed,
                                    path=str(matches[0].relative_to(G)), sha256=sha(matches[0])))
            paths.extend(matches)
    assert len(checkpoints) == 46
    return checkpoints, {os.path.relpath(p, ROOT): sha(p) for p in paths}


def freeze(t):
    checkpoints, protected = sources(t)
    protocol = {
        'version': 1, 'date': '2026-11-02',
        'status': 'FROZEN_VAL_ONLY_BEFORE_INFERENCE',
        'device_rule': 'explicit CPU or MPS inference, no training or TEST access',
        'training_archive': '../sem_cldice_expansion_20261102/TRAIN_VAL.npz',
        'validation_rows': 695, 'dev_seeds': SEEDS, 'arms': ARMS,
        'thresholds': THRESHOLDS, 'probability_definition': 'sigmoid(raw segmentation logits)',
        'physics_weight_fixed': .4,
        'configuration_counts': {'head9': 5, 'cldice_head9': 17, 'soft': 1},
        'ranking': ['mean VAL mask Macro-F1', 'mean VAL IoU',
                    'closest threshold to .5', 'lower head/physics weight',
                    'lower clDice weight', 'lower threshold'],
        'ranking_direction': 'maximize first two; minimize remaining criteria',
        'fixed_half_reference': 'independently choose best configuration at threshold .5 for each arm',
        'calibrated': 'joint weight and threshold selection, identical grid per arm',
        'classification': 'same exact binary four-neighbour resistor-grid 9 classes as original experiment',
        'no_retraining': True, 'no_TEST_access': True,
        'scope': 'Exploratory VAL diagnostic only. Optimized VAL gains are not confirmation or new TEST evidence.',
        'checkpoints': checkpoints, 'protected_files_sha256': protected,
    }
    if (ROOT / 'PROTOCOL.json').exists():
        assert json.loads((ROOT / 'PROTOCOL.json').read_text()) == protocol
    else:
        save('PROTOCOL.json', protocol)
    return protocol


def write_csv(name, rows):
    with (ROOT / name).open('w', newline='') as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def rank(row):
    return (row['mask_F1'], row['IoU'], -abs(row['threshold'] - .5),
            -row['weight'], -row['cldice_weight'], -row['threshold'])


def run(device):
    started = time.monotonic()
    t = helper()
    protocol = freeze(t)
    assert not (ROOT / 'RESULT.json').exists(), 'Refuse to overwrite completed diagnosis'
    assert all(sha(ROOT / p) == h for p, h in protocol['protected_files_sha256'].items())
    if device == 'mps':
        assert torch.backends.mps.is_available(), 'MPS requested; no silent fallback'
    torch.set_num_threads(2)
    with np.load(LATEST / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        assert set(archive['role'].tolist()) == {'dense', 'weak', 'val'}
        ids = np.flatnonzero(archive['role'] == 'val')
        assert len(ids) == protocol['validation_rows']
        x = torch.tensor(5 * (archive['X'][ids] - .2), device=device)
        target = archive['Y'][ids, 0].astype(bool)
        truth = archive['label'][ids].copy()
        frames = archive['frame'][ids].copy()
    old_rows = json.loads((OLD / 'DEV_RESULTS.json').read_text())
    new_rows = json.loads((LATEST / 'DEV_RESULTS.json').read_text())
    previous = {(r['seed'], r['config_id']): r for r in old_rows + new_rows}
    rows = []; probabilities = []; predictions = []
    differences = []
    with threadpool_limits(limits=2):
        for index, record in enumerate(protocol['checkpoints']):
            config = record['config']; seed = record['seed']
            payload = torch.load(G / record['path'], map_location='cpu', weights_only=True)
            assert payload['settings']['config_id'] == config['config_id']
            assert payload['settings']['seed'] == seed
            net = t.make_segmenter().to(device); net.load_state_dict(payload['segmenter']); net.eval()
            with torch.inference_mode():
                probability = np.concatenate([net(batch).sigmoid()[:, 0].cpu().numpy()
                                              for batch in x.split(256)])
            probabilities.append(probability)
            per_threshold = []
            for threshold in THRESHOLDS:
                mask = probability >= threshold
                prediction = t.hard_classes(mask)
                union = (mask | target).sum((1, 2))
                iou = np.divide((mask & target).sum((1, 2)), union,
                                out=np.ones(len(union), dtype=float), where=union > 0)
                row = dict(seed=seed, **config, threshold=threshold,
                    mask_F1=float(f1_score(truth, prediction, labels=range(9), average='macro', zero_division=0)),
                    IoU=float(iou.mean()))
                rows.append(row); per_threshold.append(prediction)
                if threshold == .5:
                    reference = previous[seed, config['config_id']]
                    differences.append({
                        'seed': seed, 'config_id': config['config_id'],
                        'F1_absolute_error': abs(row['mask_F1'] - reference['mask_F1']),
                        'IoU_absolute_error': abs(row['IoU'] - reference['IoU']),
                    })
            predictions.append(per_threshold)
            progress = dict(stage='VAL_ONLY_THRESHOLD_DIAGNOSTIC', completed=index+1,
                total=len(protocol['checkpoints']), seed=seed, config_id=config['config_id'],
                seconds=time.monotonic()-started, unique_binary_masks=len(t.CLASS_CACHE))
            save('PROGRESS.json', progress)
            print(json.dumps(progress), flush=True)
    probabilities = np.stack(probabilities)
    predictions = np.array(predictions)
    np.savez_compressed(ROOT / 'VAL_PROBABILITIES.npz',
        probability=probabilities, truth=truth, target=target, frames=frames,
        seed=np.array([r['seed'] for r in protocol['checkpoints']]),
        config_id=np.array([r['config']['config_id'] for r in protocol['checkpoints']]),
        threshold=np.array(THRESHOLDS), prediction=predictions,
        val_indices=ids)
    assert probabilities.shape == (46, 695, 12, 12)
    assert predictions.shape == (46, 7, 695)
    aggregate = []
    for config in t.selection_candidates():
        for threshold in THRESHOLDS:
            chosen = [r for r in rows if r['config_id'] == config['config_id'] and r['threshold'] == threshold]
            assert sorted(r['seed'] for r in chosen) == SEEDS
            aggregate.append(dict(**config, threshold=threshold,
                mask_F1=float(np.mean([r['mask_F1'] for r in chosen])),
                IoU=float(np.mean([r['IoU'] for r in chosen]))))
    selected = {}
    for arm in ARMS:
        candidates = [r for r in aggregate if r['family'] == arm]
        half = max([r for r in candidates if r['threshold'] == .5], key=rank)
        calibrated = max(candidates, key=rank)
        selected[arm] = {'fixed_half': half, 'calibrated': calibrated,
                        'optimistic_VAL_F1_gain': calibrated['mask_F1'] - half['mask_F1']}
    assert len(rows) == 322 and len(aggregate) == 161
    unchanged = all(sha(ROOT / p) == h for p, h in protocol['protected_files_sha256'].items())
    max_f1_error = max(r['F1_absolute_error'] for r in differences)
    max_iou_error = max(r['IoU_absolute_error'] for r in differences)
    assert unchanged
    assert max_f1_error < 1e-10 and max_iou_error < 1e-10, (max_f1_error, max_iou_error)
    write_csv('per_seed_VAL.csv', rows)
    write_csv('aggregate_VAL.csv', aggregate)
    save('VAL_ROWS.json', rows)
    save('AGGREGATE_VAL.json', aggregate)
    save('HISTORICAL_HALF_CHECK.json', differences)
    result = dict(status='COMPLETE_VAL_ONLY_DIAGNOSTIC',
        protocol_sha256=sha(ROOT / 'PROTOCOL.json'),
        selection_uses_TEST=False, device=device,
        torch=torch.__version__, numpy=np.__version__,
        selected=selected, total_DEV_checkpoints=46,
        fixed_half_historical_max_F1_error=max_f1_error,
        fixed_half_historical_max_IoU_error=max_iou_error,
        protected_files_unchanged=unchanged,
        seconds=time.monotonic()-started,
        interpretation='VAL-only model selection; no scientific confirmation, no TEST access and no training.',
        output_sha256={name: sha(ROOT/name) for name in ['VAL_PROBABILITIES.npz',
            'per_seed_VAL.csv', 'aggregate_VAL.csv', 'VAL_ROWS.json',
            'AGGREGATE_VAL.json', 'HISTORICAL_HALF_CHECK.json']})
    save('RESULT.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    report(result)


def report(result):
    lines = ['# Диагностика порога на VAL, 02.11.2026', '',
        '**Это диагностика на валидации, а не подтверждение на тесте.** '
        'Обучение не запускалось. Тестовые массивы и предсказания не открывались.', '',
        'Повторно использованы 46 DEV-моделей: 23 настройки × 2 начальных состояния. '
        'Каждой модели предъявлена одинаковая сетка порогов: 0,30; 0,40; 0,45; 0,50; 0,55; 0,60; 0,70. '
        'Для физического метода вес заранее фиксирован 0,4; у контролей использованы все прежние настройки.', '',
        '| Метод | Macro-F1 VAL при выбранном весе, порог 0,5 | Macro-F1 VAL после выбора порога и веса | Порог | Изменение, п.п. |',
        '|---|---:|---:|---:|---:|']
    names = {'head9': 'BCE + классификационная голова', 'cldice_head9': 'BCE + clDice + голова',
             'soft': 'BCE + непрерывная резисторная регуляризация'}
    for arm, selected in result['selected'].items():
        half, calibrated = selected['fixed_half'], selected['calibrated']
        lines.append(f"| {names[arm]} | {100*half['mask_F1']:.3f}% | {100*calibrated['mask_F1']:.3f}% | {calibrated['threshold']:.2f} | {100*selected['optimistic_VAL_F1_gain']:+.3f} |")
    lines += ['', 'Выбор: средний Macro-F1 по двум DEV-инициализациям; при равенстве — IoU, '
        'близость порога к 0,5, меньшие веса, меньший порог. Одинаковая сетка порогов '
        'не устраняет различие числа прежних конфигураций: 5 у головы, 17 у clDice, 1 у физического метода.', '',
        'Проверка воспроизводимости при пороге 0,5: '
        f"максимальная ошибка Macro-F1 {result['fixed_half_historical_max_F1_error']:.3g}; "
        f"IoU {result['fixed_half_historical_max_IoU_error']:.3g}. "
        'Все использованные исторические файлы сохранили исходные SHA-256.', '',
        'Повышение на VAL ожидаемо при выборе лучшего порога; его нельзя переносить на TEST '
        'или использовать как доказательство преимущества. Независимый опыт с дефицитом плотных масок '
        'должен иметь заранее зафиксированные собственные правила выбора и новый тест.', '',
        'Сигмоида с множителем 4 в физической функции потерь и обычная сигмоида имеют одну '
        'границу бинаризации при нулевом логите. Поэтому эта проверка исследует калибровку '
        'и чувствительность дискретной геометрии, а не исправляет якобы математически неверный порог.', '',
        'Файлы: [скрипт](diagnose.py), [протокол](PROTOCOL.json), [результат](RESULT.json), '
        '[все строки](per_seed_VAL.csv), [агрегация](aggregate_VAL.csv), '
        '[вероятности и классы VAL](VAL_PROBABILITIES.npz).', '']
    (ROOT / 'REPORT.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--freeze', action='store_true')
    parser.add_argument('--device', choices=['cpu', 'mps'])
    args = parser.parse_args()
    if args.freeze:
        frozen = freeze(helper())
        print(json.dumps({'status': frozen['status'], 'checkpoints': len(frozen['checkpoints']),
                          'protocol_sha256': sha(ROOT / 'PROTOCOL.json')}))
    else:
        assert args.device is not None, 'Select explicit inference device'
        run(args.device)
