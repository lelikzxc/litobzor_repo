"""Independent CPU audit for the sequential TRAIN/VAL architecture search.

No optimization, external downloads, or TEST/EVAL data access.  Development
gates are not confirmatory tests.  This file is maintained independently of
the model and training runner.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import time

import numpy as np
from scipy import linalg, ndimage
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
PILOT = G / 'sem_architecture_pilot_20261102'
VARIANTS = ['actual', 'zero', 'roll']
COUNTS = {'direct': 4065, 'split': 3361, 'film': 5537, 'gated': 5233}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def digest(state):
    h = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()


def macro_f1(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    denominator = confusion.sum(0) + confusion.sum(1)
    return float(np.divide(2 * np.diag(confusion), denominator,
                           out=np.zeros(9, float), where=denominator > 0).mean())


def mean_iou(masks, target):
    union = (masks | target).sum((-2, -1))
    intersection = (masks & target).sum((-2, -1))
    return float(np.divide(intersection, union, out=np.ones(len(union)),
                           where=union > 0).mean())


def normalized_maps(raw):
    value = np.log1p(100 * np.asarray(raw, dtype=np.float64))
    centered = value - value.mean((-2, -1), keepdims=True)
    return centered / np.sqrt((centered * centered).mean((-2, -1), keepdims=True) + 1e-6)


_DIRECTION_CACHE = {}
_CLASS_CACHE = {}


def direction_class(mask):
    """Independent active-node Cholesky solve of the binary unit-edge graph."""
    mask = np.ascontiguousarray(mask, dtype=bool)
    key = np.packbits(mask).tobytes()
    if key in _DIRECTION_CACHE:
        return _DIRECTION_CACHE[key]
    components, _ = ndimage.label(mask, ndimage.generate_binary_structure(2, 1))
    spanning = np.intersect1d(components[:, 0], components[:, -1])
    spanning = spanning[spanning > 0]
    if not len(spanning):
        answer = 0
    else:
        active = np.isin(components, spanning)
        vertices = np.flatnonzero(active.ravel())
        lookup = np.full(144, -1, dtype=int)
        lookup[vertices] = np.arange(len(vertices))
        laplacian = np.zeros((len(vertices), len(vertices)), dtype=np.float64)
        for vertex in vertices:
            y, x = divmod(int(vertex), 12)
            for yy, xx in [(y + 1, x), (y, x + 1)]:
                if yy < 12 and xx < 12 and active[yy, xx]:
                    a, b = lookup[vertex], lookup[yy * 12 + xx]
                    laplacian[a, a] += 1; laplacian[b, b] += 1
                    laplacian[a, b] -= 1; laplacian[b, a] -= 1
        left = np.flatnonzero(vertices % 12 == 0)
        right = np.flatnonzero(vertices % 12 == 11)
        free = np.setdiff1d(np.arange(len(vertices)), np.r_[left, right])
        potential = np.zeros(len(vertices)); potential[right] = 1
        if len(free):
            potential[free] = linalg.solve(
                laplacian[np.ix_(free, free)],
                -laplacian[np.ix_(free, right)].sum(1), assume_a='pos',
                check_finite=False)
        conductance = float((laplacian[right] @ potential).sum()) / (12 / 11)
        answer = 0 if conductance < 1e-8 else (1 if conductance < .5 - 1e-8 else 2)
    _DIRECTION_CACHE[key] = answer
    return answer


def classify(masks):
    result = []
    for mask in np.asarray(masks, dtype=bool).reshape(-1, 12, 12):
        key = np.packbits(mask).tobytes()
        if key not in _CLASS_CACHE:
            _CLASS_CACHE[key] = 3 * direction_class(mask) + direction_class(mask.T)
        result.append(_CLASS_CACHE[key])
    return np.asarray(result, dtype=np.int64)


def conv(x, state, prefix, padding=0, dilation=1):
    return F.conv2d(x, state[prefix + '.weight'], state[prefix + '.bias'],
                    padding=padding, dilation=dilation)


def independent_backbone(x, state):
    features = x
    for index, dilation in [(0, 1), (2, 2), (4, 4)]:
        features = F.gelu(conv(features, state, str(index), dilation, dilation))
    coarse = conv(features, state, '6')
    return torch.cat((features, coarse, x), 1), coarse


def independent_logits(candidate, state, visual, coarse, maps, intervention='actual'):
    """Functional reconstruction; does not import the candidate model code."""
    if intervention == 'zero':
        maps = torch.zeros_like(maps)
    elif intervention == 'roll':
        maps = torch.roll(maps, (5, 5), (-2, -1))
    if candidate == 'direct':
        residual = conv(F.gelu(conv(torch.cat((visual, maps), 1), state,
                                     'network.0', 1)), state, 'network.2')
    elif candidate == 'split':
        f = F.gelu(conv(visual, state, 'visual.0', 1))
        m = F.gelu(conv(maps, state, 'conditioning.0', 1))
        residual = conv(F.gelu(conv(torch.cat((f, m), 1), state,
                                     'fusion.0')), state, 'fusion.2')
    else:
        features = F.gelu(conv(visual, state, 'visual.0', 1))
        condition = conv(maps, state, 'conditioning', 1)
        if candidate == 'film':
            gamma, beta = condition.chunk(2, 1)
            features = features * (1 + .5 * gamma.tanh()) + .5 * beta.tanh()
        elif candidate == 'gated':
            features = features * (1 + .5 * condition.tanh())
        else:
            raise ValueError(candidate)
        residual = conv(F.gelu(conv(features, state, 'output.0', 1)), state, 'output.2')
    return coarse + 2 * residual.tanh()


def selected(scores):
    return max(scores, key=lambda row: (row['mask_F1'], row['IoU'],
                -abs(row['threshold'] - .5), -row['threshold']))


def gate(delta_f1, delta_iou, config):
    checks = {
        'mean_F1_gain': float(np.mean(delta_f1)) >= config['minimum_mean_F1_gain'],
        'each_budget_guard': min(delta_f1) >= config['minimum_budget_F1_delta'],
        'mean_IoU_guard': float(np.mean(delta_iou)) >= config['minimum_mean_IoU_delta'],
    }
    return {'passed': all(checks.values()), 'checks': checks,
            'mean_F1_delta': float(np.mean(delta_f1)),
            'budget_F1_deltas': list(map(float, delta_f1)),
            'mean_IoU_delta': float(np.mean(delta_iou))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--trial', type=Path, help='Trial directory, relative to this folder or absolute.')
    args = parser.parse_args()
    torch.set_num_threads(2)
    folders = [args.trial if args.trial.is_absolute() else ROOT / args.trial] if args.trial else sorted(
        path.parent for path in (ROOT / 'trials').glob('*/RESULT.json'))
    assert folders, 'No completed development trial exists yet'
    outcomes = []
    with threadpool_limits(limits=2):
        for folder in folders:
            if (folder / 'AUDIT.json').exists():
                old = json.loads((folder / 'AUDIT.json').read_text())
                assert old['result_sha256'] == sha(folder / 'RESULT.json')
                if old['audit_source_sha256'] != sha(__file__):
                    archive = folder / f"AUDIT_PREVIOUS_{old['audit_source_sha256'][:12]}.json"
                    assert not archive.exists(), 'Previous audit archive already exists'
                    (folder / 'AUDIT.json').rename(archive)
                else:
                    outcomes.append(old)
            if not (folder / 'AUDIT.json').exists():
                outcome = audit_trial(folder)
                (folder / 'AUDIT.json').write_text(json.dumps(outcome, indent=2, ensure_ascii=False) + '\n')
                outcomes.append(outcome)
            print(json.dumps({key: outcomes[-1][key] for key in
                              ['status', 'trial', 'checks_passed', 'checks_total', 'seconds', 'independent_gates']}), flush=True)
    assert all(outcome['status'] == 'PASS_AUDIT' for outcome in outcomes)


def audit_trial(folder):
    started = time.monotonic()
    load = lambda name: json.loads((folder / name).read_text())
    result, frozen, config = (load(name) for name in ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json'])
    before = {str(path): sha(path) for path in [folder / 'RESULT.json', folder / 'FROZEN.json',
              folder / 'CONFIG_SNAPSHOT.json', folder / 'PROTOCOL.md', ROOT / 'model.py', ROOT / 'runner.py']}
    checks = {}
    checks['development_scope_explicit'] = (
        result['status'] == 'COMPLETE_DEVELOPMENT_TRIAL' and 'VAL' in result['scope'] and
        'not independent confirmation' in result['scope'] and 'TEST/EVAL' in frozen['scope'])
    checks['frozen_protocol_configuration'] = (
        sha(folder / 'FROZEN.json') == result['frozen_sha256'] and
        sha(folder / 'CONFIG_SNAPSHOT.json') == frozen['config_snapshot_sha256'] and
        sha(folder / 'PROTOCOL.md') == frozen['protocol_sha256'] == config['protocol_sha256'])
    checks['frozen_sources_and_snapshots'] = (
        all(sha(ROOT / name) == value for name, value in frozen['source_sha256'].items()) and
        all(sha(folder / 'source' / name) == frozen['source_sha256'][name] for name in ['model.py', 'runner.py']))
    checks['fixed_design_and_hyperparameters'] = (
        config['queue'] == list(COUNTS) and config['budgets'] == [18, 27] and
        config['screen_seeds'] == [5501] and config['replication_seeds'] == [5501, 5521, 5557] and
        config['steps'] == 500 and config['batch_size'] == 8 and config['learning_rate'] == .0005 and
        config['weight_decay'] == .0001 and config['physics_weight'] == 1 and config['epsilon'] == .001 and
        config['eta'] == 2 and config['normalization_scale'] == 100 and
        config['normalization_variance_floor'] == 1e-6 and
        config['thresholds'] == [.3, .4, .45, .5, .55, .6, .7] and
        config['gates'] == dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025,
                               minimum_mean_IoU_delta=-.002))
    runner_tree = ast.parse((folder / 'source' / 'runner.py').read_text())
    functions = {node.name: node for node in runner_tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    loads = [(name, ast.unparse(node)) for name, function in functions.items() for node in ast.walk(function)
             if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and
             isinstance(node.func.value, ast.Name) and node.func.value.id == 'np' and node.func.attr == 'load']
    checks['runner_array_reads_only_TRAIN_VAL_and_feature_cache'] = (
        len(loads) == 2 and any(name == 'inputs' and 'TRAIN_VAL.npz' in source for name, source in loads) and
        any(name == 'cached_inputs' and 'np.load(path,' in source for name, source in loads))
    fit_source, inputs_source = (ast.unparse(functions[name]) for name in ['fit', 'inputs'])
    checks['unchanged_loss_heads_only_optimizer'] = (
        "loss = loss + c['physics_weight'] * physics.geometry_loss(weak, direction)" in fit_source and
        'binary_cross_entropy_with_logits' in fit_source and
        'params = [p for p in model.parameters() if p.requires_grad]' in fit_source and
        'all((p.grad is None for p in model.backbone.parameters()))' in fit_source and
        "if role != 'weak':" in inputs_source and "['mask']" in inputs_source)
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    lineage = frozen['lineage']; subsets = json.loads((PILOT / 'SUBSETS.json').read_text())
    checks['frozen_data_and_source_lineage'] = (
        sha(PILOT / 'TRAIN_VAL.npz') == lineage['TRAIN_VAL_sha256'] == subsets['train_val_sha256'] and
        sha(PILOT / 'SUBSETS.json') == lineage['subsets_sha256'] and
        sha(PILOT / 'INITIAL_LINEAGE.json') == lineage['initial_lineage_sha256'] and
        all(sha(G / source['file']) == source['sha256'] for source in lineage['sources'].values()))
    checks['TRAIN_VAL_roles_frames_subsets'] = (
        {role: int(np.sum(data['role'] == role)) for role in set(data['role'])} ==
        {'dense': 54, 'weak': 1152, 'val': 695} and
        set(data['frame'][data['role'] == 'val']) == {6, 7} and
        set(data['frame'][data['role'] != 'val']) == set(range(6)) and
        all(np.array_equal(np.bincount(data['label'][subsets['dense_indices'][str(budget)]], minlength=9),
                           np.full(9, budget // 9)) for budget in [18, 27]) and
        set(subsets['dense_indices']['18']).issubset(subsets['dense_indices']['27']))
    val = np.flatnonzero(data['role'] == 'val')
    truth, target = data['label'][val], data['Y'][val, 0].astype(bool)
    checks['independent_classifier_matches_all_VAL_truth'] = np.array_equal(classify(target), truth)
    candidate, phase, seeds = result['candidate'], result['phase'], result['seeds']
    expected_seeds = [5501] if phase == 'screen' else [5521, 5557]
    expected = {(budget, seed, arm) for budget in [18, 27] for seed in expected_seeds for arm in ['plain', 'joint']}
    rows = result['rows']
    checks['all_planned_models_updates_no_seed_double_count'] = (
        seeds == expected_seeds and len(rows) == len(expected) and
        {(row['budget'], row['seed'], row['arm']) for row in rows} == expected and
        result['updates'] == 500 * len(rows) and frozen['seeds'] == expected_seeds and
        len(lineage['sources']) == 2 * len(expected_seeds))
    checkpoints = result['checkpoint_hashes']
    checks['all_checkpoint_hashes'] = len(checkpoints) == len(rows) and all(
        sha(folder / 'models' / name) == value for name, value in checkpoints.items())
    # The byte-identical live copy resolves its relative circuit dependency;
    # the archived source is preserved verbatim and checked above.
    spec = importlib.util.spec_from_file_location('iterative_audit_model_initialization', ROOT / 'model.py')
    model_module = importlib.util.module_from_spec(spec); spec.loader.exec_module(model_module)
    circuit_spec = importlib.util.spec_from_file_location('iterative_audit_fixed_circuit', PILOT / 'circuit.py')
    circuit_module = importlib.util.module_from_spec(circuit_spec); circuit_spec.loader.exec_module(circuit_module)
    circuit = circuit_module.CircuitMaps(epsilon=.001)
    metric_error = 0.; forward_error = 0.; normalization_error = 0.; raw_map_error = 0.; probability_error = 0.
    predictions_ok = True; packed_ok = True; metadata_ok = True; frozen_weights = True
    initialization_ok = True; counts_ok = True; caches_ok = True; batch_ok = True; selections_ok = True
    baseline_recomputed = []; recomputed_rows = []; comparisons = {}
    inspected_caches = {}; states = {}

    def scores_for(probability):
        nonlocal predictions_ok, packed_ok
        scores, predictions, packed = [], [], []
        for threshold in config['thresholds']:
            masks = probability >= threshold
            prediction = classify(masks)
            scores.append(dict(threshold=threshold, mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target)))
            predictions.append(prediction); packed.append(np.packbits(masks.reshape(len(masks), 144), axis=1))
        return scores, np.asarray(predictions), np.asarray(packed)

    def record_error(actual, stored):
        nonlocal metric_error
        for key in actual:
            metric_error = max(metric_error, abs(float(actual[key]) - float(stored[key])))

    for budget in [18, 27]:
        for seed in seeds:
            source = lineage['sources'][f'{budget}:{seed}']
            payload = torch.load(G / source['file'], map_location='cpu', weights_only=True)
            state = payload['segmenter']; states[budget, seed] = state
            frozen_weights &= digest(state) == source['backbone_sha256']
            stem = f'base_b{budget}_s{seed}'
            with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
                arrays = {key: archive[key] for key in archive.files}
            metadata_ok &= np.array_equal(arrays['truth'], truth) and np.array_equal(arrays['target'], target)
            scores, pred, bits = scores_for(arrays['probability'])
            predictions_ok &= np.array_equal(pred, arrays['predictions'])
            packed_ok &= np.array_equal(bits, arrays['packed_masks'])
            baseline = next(row for row in result['baselines'] if row['budget'] == budget and row['seed'] == seed)
            for score, stored in zip(scores, baseline['all_scores']):
                record_error(score, stored)
            record_error(selected(scores), baseline['selected'])
            baseline_recomputed.append(dict(budget=budget, seed=seed, selected=selected(scores)))

    for row in rows:
        budget, seed, arm = row['budget'], row['seed'], row['arm']
        source = lineage['sources'][f'{budget}:{seed}']; state = states[budget, seed]
        stem = f'b{budget}_{arm}_s{seed}'
        payload = torch.load(folder / 'models' / f'{stem}.pt', map_location='cpu', weights_only=True)
        metadata_ok &= payload['settings'] == row and row['steps'] == 500 and row['candidate'] == candidate
        weights = payload['model']
        backbone = {key[len('backbone.'):]: value for key, value in weights.items() if key.startswith('backbone.')}
        refiner = {key[len('refiner.'):]: value for key, value in weights.items() if key.startswith('refiner.')}
        frozen_weights &= all(torch.equal(backbone[key], value) for key, value in state.items())
        frozen_weights &= row['backbone_before_sha256'] == row['backbone_after_sha256'] == source['backbone_sha256']
        initial = model_module.make_model(candidate, arm, state, decoder_seed=seed + 100003)
        initial_state = {key: value for key, value in initial.named_parameters() if value.requires_grad}
        initialization_ok &= digest(initial_state) == row['decoder_initial_sha256']
        initialization_ok &= digest({'refiner.' + key: value for key, value in refiner.items()}) == row['decoder_final_sha256']
        initialization_ok &= row['decoder_initial_sha256'] != row['decoder_final_sha256']
        counts_ok &= (row['trainable_parameters'] == COUNTS[candidate] and
                      row['total_parameters'] == 10681 + COUNTS[candidate] and
                      sum(value.numel() for value in refiner.values()) == COUNTS[candidate] and
                      sum(value.numel() for value in weights.values()) == 10681 + COUNTS[candidate] and
                      all(torch.isfinite(value).all().item() for value in weights.values()))
        rng = np.random.default_rng(seed + 1000); trace = hashlib.sha256()
        for _ in range(500):
            trace.update(rng.integers(0, budget, 8).astype(np.int64).tobytes())
            trace.update(rng.integers(0, 1152, 8).astype(np.int64).tobytes())
        batch_ok &= trace.hexdigest() == row['batch_sequence_sha256']
        cache_meta = row['cache']; cache_path = ROOT / cache_meta['file']
        caches_ok &= sha(cache_path) == cache_meta['archive_sha256'] and cache_meta['label_free']
        if str(cache_path) not in inspected_caches:
            with np.load(cache_path, allow_pickle=False) as archive:
                cache = {key: archive[key] for key in archive.files}
            inspected_caches[str(cache_path)] = cache
        cache = inspected_caches[str(cache_path)]
        caches_ok &= set(cache) == {f'{role}_{field}' for role in ['dense', 'weak', 'val']
                                    for field in ['visual', 'coarse', 'maps', 'maps_raw']}
        caches_ok &= all(len(cache[f'{role}_visual']) == count for role, count in
                         [('dense', budget), ('weak', 1152), ('val', 695)])
        for role in ['dense', 'weak', 'val']:
            ids = np.asarray(subsets['dense_indices'][str(budget)]) if role == 'dense' else np.flatnonzero(data['role'] == role)
            caches_ok &= np.array_equal(cache[f'{role}_visual'][:, -1:], 5 * (data['X'][ids] - .2))
            caches_ok &= np.array_equal(cache[f'{role}_visual'][:, 24:25], cache[f'{role}_coarse'])
            normalization_error = max(normalization_error, float(np.max(np.abs(
                normalized_maps(cache[f'{role}_maps_raw']) - cache[f'{role}_maps']))))
        with np.load(folder / 'fixtures' / f'{stem}.npz', allow_pickle=False) as archive:
            fixture = {key: archive[key] for key in archive.files}
        metadata_ok &= np.array_equal(fixture['x'], 5 * (data['X'][val[:16]] - .2))
        with torch.inference_mode():
            visual, coarse = independent_backbone(torch.tensor(fixture['x']), backbone)
            if arm == 'plain':
                probability = coarse.sigmoid(); raw = torch.cat((probability, 4 * probability * (1 - probability)), 1)
            else:
                raw = circuit(coarse, mode='joint')
            raw_map_error = max(raw_map_error, float(np.max(np.abs(raw.numpy() - fixture['maps_raw']))))
            full_maps = torch.from_numpy(normalized_maps(raw.numpy())).float()
            forward_error = max(forward_error, float(np.max(np.abs(visual.numpy() - fixture['visual']))),
                                float(np.max(np.abs(coarse.numpy() - fixture['coarse']))))
            for index, variant in enumerate(VARIANTS):
                logits = independent_logits(candidate, refiner, visual, coarse, full_maps, variant)
                forward_error = max(forward_error, float(np.max(np.abs(logits.numpy() - fixture['full_logits'][index]))))
        with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
            arrays = {key: archive[key] for key in archive.files}
        metadata_ok &= (arrays['variants'].tolist() == VARIANTS and
                        arrays['thresholds'].tolist() == config['thresholds'] and
                        np.array_equal(arrays['truth'], truth) and np.array_equal(arrays['target'], target) and
                        arrays['probability'].shape == (3, 695, 12, 12) and
                        arrays['logits'].shape == (3, 695, 1, 12, 12) and
                        np.isfinite(arrays['logits']).all() and np.isfinite(arrays['probability']).all())
        probability_error = max(probability_error, float(np.max(np.abs(
            torch.tensor(arrays['logits'][:, :, 0]).sigmoid().numpy() - arrays['probability']))))
        per_variant = []
        for index, variant in enumerate(VARIANTS):
            with torch.inference_mode():
                logits = independent_logits(candidate, refiner, torch.tensor(cache['val_visual']),
                    torch.tensor(cache['val_coarse']), torch.tensor(cache['val_maps']), variant)
            forward_error = max(forward_error, float(np.max(np.abs(logits.numpy() - arrays['logits'][index]))))
            scores, predictions, packed = scores_for(arrays['probability'][index])
            predictions_ok &= np.array_equal(predictions, arrays['predictions'][index])
            packed_ok &= np.array_equal(packed, arrays['packed_masks'][index])
            for score, stored in zip(scores, row['VAL_scores_all_thresholds'][variant]):
                record_error(score, stored)
            per_variant.append(scores)
        winner = selected(per_variant[0]); record_error(winner, row['selected'])
        selections_ok &= winner['threshold'] == float(arrays['selected_threshold'])
        ti = config['thresholds'].index(winner['threshold'])
        actual_masks = arrays['probability'][0] >= winner['threshold']
        for index, variant in enumerate(VARIANTS):
            observation = dict(**per_variant[index][ti],
                mask_flip_fraction=float(np.mean((arrays['probability'][index] >= winner['threshold']) != actual_masks)),
                logit_mean_absolute_difference=float(np.abs(arrays['logits'][index] - arrays['logits'][0]).mean()),
                logit_max_absolute_difference=float(np.abs(arrays['logits'][index] - arrays['logits'][0]).max()))
            record_error(observation, row['ablations'][variant])
        recomputed_rows.append(dict(budget=budget, seed=seed, arm=arm, selected=winner))

    checks.update(all_final_backbones_exactly_frozen=bool(frozen_weights),
        all_head_initializations_and_final_digests=bool(initialization_ok),
        all_parameter_counts_and_weights_finite=bool(counts_ok),
        all_500_batch_sequences_independently_reconstructed=bool(batch_ok),
        label_free_feature_caches_shapes_hashes=bool(caches_ok),
        all_saved_metadata_valid=bool(metadata_ok),
        normalization_matches_float64_reference=normalization_error < 1e-5,
        physical_maps_CPU_MPS_parity=raw_map_error < 1e-4,
        independent_full_and_cached_CNN_forward_parity=forward_error < 1e-4,
        sigmoid_probability_parity=probability_error < 3e-7,
        all_mask_classifications_independently_recomputed=bool(predictions_ok),
        all_packed_masks_recomputed=bool(packed_ok),
        all_VAL_grid_selection_intervention_metrics=metric_error < 2e-7 and bool(selections_ok))
    for budget in [18, 27]:
        for seed in seeds:
            pair = [row for row in rows if row['budget'] == budget and row['seed'] == seed]
            initialization_ok &= len({row['decoder_initial_sha256'] for row in pair}) == 1
            batch_ok &= len({row['batch_sequence_sha256'] for row in pair}) == 1
    checks['paired_arm_initializations_batches'] = bool(initialization_ok and batch_ok)
    independent_gates = recompute_gates(recomputed_rows, baseline_recomputed, config)
    gates_error = compare_gates(independent_gates, result['gates'])
    checks['architecture_and_physics_gates_independently_recomputed'] = gates_error < 2e-7
    if phase == 'replicate':
        aggregate = load('AGGREGATE_RESULT.json')
        old_folder = ROOT / aggregate['source_trials'][0]
        old_result = json.loads((old_folder / 'RESULT.json').read_text())
        old_audit = json.loads((old_folder / 'AUDIT.json').read_text())
        checks['replication_uses_two_new_seeds_after_valid_screen'] = (
            old_audit['status'] == 'PASS_AUDIT' and old_result['seeds'] == [5501] and
            old_result['gates']['A_any'] and old_result['signature'] == result['signature'] and
            aggregate['rows'] == old_result['rows'] + rows and
            aggregate['baselines'] == old_result['baselines'] + result['baselines'] and
            len({(r['budget'], r['seed'], r['arm']) for r in aggregate['rows']}) == 12)
        all_gates = recompute_gates(old_result['rows'] + recomputed_rows,
                                   old_result['baselines'] + baseline_recomputed, config)
        checks['aggregate_three_seed_gates_recomputed'] = compare_gates(all_gates, aggregate['gates']) < 2e-7
        comparisons['new_two_seeds'] = independent_gates
        comparisons['all_three_seeds'] = all_gates
    checks['all_inputs_unchanged_by_audit'] = all(sha(path) == value for path, value in before.items())
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        scope='INDEPENDENT_CPU_AUDIT_OF_ADAPTIVE_TRAIN_VAL_DEVELOPMENT_ONLY',
        trial=str(folder.relative_to(ROOT)), candidate=candidate, phase=phase,
        audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks),
        maximum_errors=dict(metrics=metric_error, independent_forward=forward_error,
            normalization=normalization_error, raw_maps=raw_map_error, probabilities=probability_error),
        numerical_tolerances=dict(metrics=2e-7, independent_forward=1e-4,
            normalization=1e-5, raw_maps=1e-4, probabilities=3e-7),
        audit_note='Normalization tolerance permits float32 device rounding; the preliminary 3e-6 bound produced a technical false alarm at 4.18e-6. Previous audit outputs are preserved.',
        unique_masks_independently_classified=len(_CLASS_CACHE), independent_gates=independent_gates,
        replication=comparisons, seconds=time.monotonic() - started,
        caveat='Repeated VAL development. Passing a gate does not establish TEST superiority, Q1 novelty, or a causal physical-map benefit.')


def recompute_gates(rows, baselines, config):
    means = {budget: {arm: {key: float(np.mean([row['selected'][key] for row in rows
        if row['budget'] == budget and row['arm'] == arm])) for key in ['mask_F1', 'IoU']}
        for arm in ['plain', 'joint']} for budget in [18, 27]}
    base = {budget: {key: float(np.mean([row['selected'][key] for row in baselines
        if row['budget'] == budget])) for key in ['mask_F1', 'IoU']} for budget in [18, 27]}
    architecture = {}
    for arm in ['plain', 'joint']:
        architecture[arm] = gate([means[b][arm]['mask_F1'] - base[b]['mask_F1'] for b in [18, 27]],
            [means[b][arm]['IoU'] - base[b]['IoU'] for b in [18, 27]], config['gates'])
    physics = gate([means[b]['joint']['mask_F1'] - means[b]['plain']['mask_F1'] for b in [18, 27]],
        [means[b]['joint']['IoU'] - means[b]['plain']['IoU'] for b in [18, 27]], config['gates'])
    physics['joint_architecture_gate'] = architecture['joint']['passed']
    physics['passed'] &= physics['joint_architecture_gate']
    return dict(A_architecture=architecture, A_any=any(row['passed'] for row in architecture.values()), B_physics=physics)


def compare_gates(actual, stored):
    error = 0.
    assert actual['A_any'] == stored['A_any'], 'A_any disagrees'
    for computed, observed in [(actual['A_architecture'][arm], stored['A_architecture'][arm]) for arm in ['plain', 'joint']] + [
                               (actual['B_physics'], stored['B_physics'])]:
        assert computed['passed'] == observed['passed'], 'Gate status disagrees'
        assert computed['checks']['mean_F1_gain'] == observed['checks']['mean_F1_gain']
        assert computed['checks']['each_budget_guard'] == observed['checks']['budget_F1_guard']
        assert computed['checks']['mean_IoU_guard'] == observed['checks']['mean_IoU_guard']
        error = max(error, abs(computed['mean_F1_delta'] - observed['delta']),
                    abs(computed['mean_IoU_delta'] - observed['IoU_delta']),
                    float(np.max(np.abs(np.asarray(computed['budget_F1_deltas']) - observed['budget_deltas']))))
    return error


if __name__ == '__main__':
    main()
