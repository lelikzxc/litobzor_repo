"""Append-only adaptive architecture development on TRAIN/VAL, never TEST.

Each command fits one candidate and its matched plain control. Screen uses
seed5501; replication adds5521/5557 without refitting/counting5501 twice.
Every trial snapshots its configuration and numerical source files. Cached
inputs contain image-derived features only, never labels or masks.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import time
import traceback

os.environ['PYTORCH_ENABLE_MPS_FALLBACK']='0'
import numpy as np
import torch
from torch.nn import functional as F
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits
from model import CANDIDATES,make_model,state_digest,architecture_spec

ROOT=Path(__file__).resolve().parent;G=ROOT.parent;PILOT=G/'sem_architecture_pilot_20261102'
VARIANTS=['actual','zero','roll'];CACHE_KEYS=['visual','coarse','maps','maps_raw'];ARMS=['plain','joint']
CLASS_CACHE={};START=None


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+f'.{os.getpid()}.partial')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)


def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);result=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result);return result


physics=module('iterative_unchanged_physics',PILOT/'physics_adapter.py')
preparation=module('iterative_unchanged_class_rule',PILOT/'prepare.py')


def source_hashes():
    names=['runner.py','model.py','../sem_architecture_pilot_20261102/model.py',
        '../sem_architecture_pilot_20261102/circuit.py','../sem_architecture_pilot_20261102/physics_adapter.py',
        '../sem_architecture_pilot_20261102/prepare.py','../sem_physics_materials/physics_loss_example.py',
        '../sem_confirmation_20261028/prepare.py','../retained_evidence_20261027/SELECTED_SOURCES.zip']
    return {n:sha(ROOT/n) for n in names}


def configuration(path):
    c=json.loads(path.read_text())
    assert c['queue']==list(CANDIDATES)==['direct','split','film','gated']
    assert c['budgets']==[18,27] and c['screen_seeds']==[5501] and c['replication_seeds']==[5501,5521,5557]
    assert c['steps']==500 and c['batch_size']==8 and c['physics_weight']==1.
    assert c['epsilon']==.001 and c['eta']==2. and c['normalization_scale']==100.
    assert c['normalization_variance_floor']==1e-6 and c['subset_seed']==5303
    assert c['learning_rate']==.0005 and c['weight_decay']==.0001
    assert c['gates']==dict(minimum_mean_F1_gain=.005,minimum_budget_F1_delta=-.0025,minimum_mean_IoU_delta=-.002)
    assert c['protocol_sha256']==sha(ROOT/'PROTOCOL.md')
    return c


def append_ledger(event):
    lock=ROOT/'.ledger.lock'
    with lock.open('a') as handle:
        fcntl.flock(handle,fcntl.LOCK_EX)
        path=ROOT/'LEDGER.json'
        ledger=json.loads(path.read_text()) if path.exists() else dict(version=1,scope='ADAPTIVE_REUSED_VAL_ONLY',events=[])
        event=dict(event,UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),index=len(ledger['events']))
        ledger['events'].append(event);save(path,ledger)
        fcntl.flock(handle,fcntl.LOCK_UN)


def inputs(c,seeds,device):
    lineage=json.loads((PILOT/'INITIAL_LINEAGE.json').read_text())
    subsets=json.loads((PILOT/'SUBSETS.json').read_text())
    with np.load(PILOT/'TRAIN_VAL.npz',allow_pickle=False) as z:
        assert set(z['role'])=={'dense','weak','val'}
        arrays={k:z[k].copy() for k in z.files}
    assert sha(PILOT/'TRAIN_VAL.npz')==lineage['TRAIN_VAL_sha256']==subsets['train_val_sha256']
    data={};states={};sources={}
    for b in c['budgets']:
        data[b]={}
        for role in ['dense','weak','val']:
            ids=np.array(subsets['dense_indices'][str(b)]) if role=='dense' else np.flatnonzero(arrays['role']==role)
            data[b][role]=dict(x=torch.tensor(5*(arrays['X'][ids]-.2),device=device),
                label=torch.tensor(arrays['label'][ids],device=device),indices=ids.tolist())
            if role!='weak':data[b][role]['mask']=torch.tensor(arrays['Y'][ids].astype(np.float32),device=device)
        assert len(data[b]['dense']['x'])==b and len(data[b]['weak']['x'])==1152 and len(data[b]['val']['x'])==695
        assert np.array_equal(np.bincount(data[b]['dense']['label'].cpu().numpy(),minlength=9),np.full(9,b//9))
        for seed in seeds:
            row=lineage['initials'][f'{b}:{seed}'];p=PILOT/row['file']
            assert sha(p)==row['sha256']
            payload=torch.load(p,map_location='cpu',weights_only=True);state=payload['segmenter']
            assert state_digest(state)==row['backbone_state_sha256']
            states[b,seed]=state;sources[f'{b}:{seed}']=dict(file=str(p.relative_to(G)),sha256=sha(p),backbone_sha256=state_digest(state))
    return data,states,dict(TRAIN_VAL_sha256=sha(PILOT/'TRAIN_VAL.npz'),sources=sources,
        initial_lineage_sha256=sha(PILOT/'INITIAL_LINEAGE.json'),subsets_sha256=sha(PILOT/'SUBSETS.json'))


def make(c,candidate,arm,state,seed,device):
    return make_model(candidate,arm,state,decoder_seed=seed+100003,epsilon=c['epsilon'],eta=c['eta'],
        scale=c['normalization_scale'],norm_floor=c['normalization_variance_floor']).to(device)


def trainable_digest(model):return state_digest({k:p for k,p in model.named_parameters() if p.requires_grad})


@torch.no_grad()
def cached_inputs(c,model,data,budget,seed,arm,source,device):
    key=digest(dict(backbone=source['backbone_sha256'],TRAIN_VAL=sha(PILOT/'TRAIN_VAL.npz'),
        indices={r:v['indices'] for r,v in data.items()},arm=arm,model_sha256=sha(ROOT/'model.py'),
        circuit_sha256=sha(PILOT/'circuit.py'),epsilon=c['epsilon'],scale=c['normalization_scale'],floor=c['normalization_variance_floor']))
    path=ROOT/'cache'/f'b{budget}_s{seed}_{arm}_{key[:16]}.npz';meta_path=path.with_suffix('.json')
    path.parent.mkdir(exist_ok=True)
    if path.exists() and meta_path.exists():
        meta=json.loads(meta_path.read_text());assert meta['key']==key and sha(path)==meta['archive_sha256']
        with np.load(path,allow_pickle=False) as z:
            cache={r:{k:torch.tensor(z[f'{r}_{k}'],device=device) for k in CACHE_KEYS} for r in data}
    else:
        cache={};arrays={}
        for role,values in data.items():
            parts=[model.precompute(x) for x in values['x'].split(16)]
            cache[role]={k:torch.cat([part[k] for part in parts]).detach().clone() for k in CACHE_KEYS}
            arrays.update({f'{role}_{k}':v.cpu().numpy() for k,v in cache[role].items()})
        tmp=path.with_suffix('.npz.partial')
        with tmp.open('wb') as h:np.savez_compressed(h,**arrays)
        tmp.replace(path)
        meta=dict(key=key,archive_sha256=sha(path),label_free=True,fields=CACHE_KEYS,
            counts={r:len(v['visual']) for r,v in cache.items()})
        save(meta_path,meta)
    assert all(torch.isfinite(v).all() for vals in cache.values() for v in vals.values())
    return cache,dict(file=str(path.relative_to(ROOT)),**meta)


def slice_cache(cache,indices):return {k:v[indices] for k,v in cache.items()}


def hard_classes(masks):
    masks=np.asarray(masks,dtype=bool).reshape(-1,12,12)
    keys=[r.tobytes() for r in np.packbits(masks.reshape(len(masks),144),axis=1)]
    missing=sorted(set(keys)-CLASS_CACHE.keys())
    if missing:
        values=np.array([np.unpackbits(np.frombuffer(k,dtype=np.uint8)).reshape(12,12) for k in missing],dtype=bool)
        CLASS_CACHE.update(zip(missing,preparation.class_labels(values).tolist()))
    return np.array([CLASS_CACHE[k] for k in keys],dtype=np.int64)


def rank(row):return row['mask_F1'],row['IoU'],-abs(row['threshold']-.5),-row['threshold']


def score_probabilities(probability,truth,target,thresholds):
    rows=[];predictions=[];packed=[]
    for threshold in thresholds:
        mask=probability>=threshold;prediction=hard_classes(mask);union=(mask|target).sum((1,2))
        iou=np.divide((mask&target).sum((1,2)),union,out=np.ones(len(mask)),where=union>0)
        rows.append(dict(threshold=threshold,mask_F1=float(f1_score(truth,prediction,labels=range(9),average='macro',zero_division=0)),IoU=float(iou.mean())))
        predictions.append(prediction);packed.append(np.packbits(mask.reshape(len(mask),144),axis=1))
    return rows,np.array(predictions),np.array(packed)


def evaluate(model,cache,data,thresholds):
    model.eval();outputs=[]
    with torch.no_grad():
        for variant in VARIANTS:
            parts=[]
            for start in range(0,len(cache['visual']),16):
                part=slice_cache(cache,slice(start,start+16));parts.append(model.forward_cached(part,intervention=variant)['logits'])
            outputs.append(torch.cat(parts).cpu().numpy())
    logits=np.array(outputs);probability=1/(1+np.exp(-np.clip(logits[:,:,0],-80,80)))
    truth=data['label'].cpu().numpy();target=data['mask'][:,0].cpu().numpy().astype(bool)
    all_scores=[];predictions=[];packed=[]
    for p in probability:
        rows,pred,bits=score_probabilities(p,truth,target,thresholds)
        all_scores.append(rows);predictions.append(pred);packed.append(bits)
    selected=max(all_scores[0],key=rank);i=thresholds.index(selected['threshold']);ablations={}
    actual=probability[0]>=selected['threshold']
    for v,name in enumerate(VARIANTS):
        ablations[name]=dict(**all_scores[v][i],mask_flip_fraction=float(np.mean((probability[v]>=selected['threshold'])!=actual)),
            logit_mean_absolute_difference=float(np.abs(logits[v]-logits[0]).mean()),logit_max_absolute_difference=float(np.abs(logits[v]-logits[0]).max()))
    return dict(selected=selected,ablations=ablations,VAL_scores_all_thresholds=dict(zip(VARIANTS,all_scores))),dict(
        logits=logits,probability=probability,truth=truth,target=target,thresholds=np.array(thresholds),
        variants=np.array(VARIANTS),predictions=np.array(predictions),packed_masks=np.array(packed),selected_threshold=np.array(selected['threshold']))


def fit(c,model,cache,data,budget,seed,arm,trial,counter):
    before=state_digest(model.backbone.state_dict());decoder=trainable_digest(model)
    params=[p for p in model.parameters() if p.requires_grad];count=sum(p.numel() for p in params)
    optimizer=torch.optim.AdamW(params,lr=c['learning_rate'],weight_decay=c['weight_decay'])
    rng=np.random.default_rng(seed+1000);batches=hashlib.sha256();start=time.monotonic()
    for step in range(1,c['steps']+1):
        ai=rng.integers(0,len(cache['dense']['visual']),c['batch_size']);wi=rng.integers(0,len(cache['weak']['visual']),c['batch_size'])
        batches.update(ai.astype(np.int64).tobytes());batches.update(wi.astype(np.int64).tobytes())
        ai=torch.tensor(ai,device='mps');wi=torch.tensor(wi,device='mps');optimizer.zero_grad(set_to_none=True)
        dense=model.forward_cached(slice_cache(cache['dense'],ai))['logits']
        loss=F.binary_cross_entropy_with_logits(dense,data['dense']['mask'][ai])
        y=data['weak']['label'][wi];direction=torch.stack((y//3,y%3),dim=1)
        weak=model.forward_cached(slice_cache(cache['weak'],wi))['logits']
        loss=loss+c['physics_weight']*physics.geometry_loss(weak,direction)
        assert torch.isfinite(loss);loss.backward()
        assert all(p.grad is None for p in model.backbone.parameters())
        assert all(p.grad is None or torch.isfinite(p.grad).all() for p in params)
        assert any(p.grad is not None and float(p.grad.abs().sum())>0 for p in params)
        optimizer.step();counter[0]+=1
        if step%100==0 or step==c['steps']:
            row=dict(stage='TRAIN_VAL_DEVELOPMENT',trial=trial.name,budget=budget,seed=seed,arm=arm,
                step=step,target_steps=c['steps'],completed_updates=counter[0],seconds=time.monotonic()-START)
            save(trial/'PROGRESS.json',row);save(ROOT/'PROGRESS.json',row)
            with (trial/'progress.jsonl').open('a') as h:h.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
    torch.mps.synchronize();after=state_digest(model.backbone.state_dict())
    assert before==after and trainable_digest(model)!=decoder
    return dict(seconds=time.monotonic()-start,steps=c['steps'],backbone_before_sha256=before,
        backbone_after_sha256=after,decoder_initial_sha256=decoder,decoder_final_sha256=trainable_digest(model),
        batch_sequence_sha256=batches.hexdigest(),trainable_parameters=count,total_parameters=sum(p.numel() for p in model.parameters()))


def gates(rows,baselines,c):
    budgets=c['budgets'];means={};base={}
    for b in budgets:
        base[b]={k:float(np.mean([r['selected'][k] for r in baselines if r['budget']==b])) for k in ['mask_F1','IoU']}
        means[b]={a:{k:float(np.mean([r['selected'][k] for r in rows if r['budget']==b and r['arm']==a]))
                     for k in ['mask_F1','IoU']} for a in ARMS}
    limits=c['gates']
    def compare(left,right):
        deltas=[left[b]['mask_F1']-right[b]['mask_F1'] for b in budgets]
        gain=float(np.mean(deltas));iou=float(np.mean([left[b]['IoU']-right[b]['IoU'] for b in budgets]))
        checks=dict(mean_F1_gain=bool(gain>=limits['minimum_mean_F1_gain']),
            budget_F1_guard=bool(min(deltas)>=limits['minimum_budget_F1_delta']),mean_IoU_guard=bool(iou>=limits['minimum_mean_IoU_delta']))
        return dict(delta=gain,IoU_delta=iou,budget_deltas=deltas,checks=checks,passed=all(checks.values()))
    A={a:compare({b:means[b][a] for b in budgets},base) for a in ARMS}
    B=compare({b:means[b]['joint'] for b in budgets},{b:means[b]['plain'] for b in budgets})
    B['joint_architecture_gate']=A['joint']['passed'];B['passed']=bool(B['passed'] and B['joint_architecture_gate'])
    return dict(A_architecture=A,A_any=any(x['passed'] for x in A.values()),B_physics=B,
        interpretation='Development-only screening gates, not statistical hypothesis confirmation'),dict(by_budget=means,base_by_budget=base)


def training_signature(c,candidate):
    keys=['steps','batch_size','learning_rate','weight_decay','physics_weight','epsilon','eta','normalization_scale',
          'normalization_variance_floor','thresholds','subset_seed','budgets','gates']
    return digest(dict(candidate=candidate,configuration={k:c[k] for k in keys},model_sha256=sha(ROOT/'model.py'),
        circuit_sha256=sha(PILOT/'circuit.py'),TRAIN_VAL_sha256=sha(PILOT/'TRAIN_VAL.npz')))


def previous_screen(candidate,signature):
    values=[]
    for p in (ROOT/'trials').glob('*/RESULT.json'):
        r=json.loads(p.read_text())
        if r['candidate']==candidate and r['phase']=='screen' and r['signature']==signature and r['status']=='COMPLETE_DEVELOPMENT_TRIAL':values.append((p,r))
    assert len(values)==1, 'Replication requires exactly one compatible completed screen, with original5501 retained once'
    return values[0]


def preflight(c,candidate):
    data,states,lineage=inputs(c,[5501],'cpu');hashes=[];counts=[]
    for arm in ARMS:
        net=make(c,candidate,arm,states[18,5501],5501,'cpu');x=data[18]['dense']['x'][:2]
        cache=net.precompute(x);result=net.forward_cached(cache)
        assert torch.equal(result['logits'],cache['coarse'])
        hashes.append(trainable_digest(net));counts.append(sum(p.numel() for p in net.parameters() if p.requires_grad))
        result['logits'].sum().backward();assert all(p.grad is None for p in net.backbone.parameters())
        assert any(p.grad is not None and float(p.grad.abs().sum())>0 for p in net.refiner.parameters())
    assert len(set(hashes))==len(set(counts))==1
    result=dict(status='PASS_PREFLIGHT',candidate=candidate,trainable_parameters=counts[0],identity=True,
        matched_initialization=True,nonzero_head_gradient=True,backbone_frozen=True,source_sha256=source_hashes(),lineage=lineage)
    save(ROOT/f'PREFLIGHT_{candidate}.json',result);print(json.dumps(result),flush=True)


def run(c,candidate,phase,queue_path):
    global START
    START=time.monotonic();assert torch.backends.mps.is_available() and os.environ['PYTORCH_ENABLE_MPS_FALLBACK']=='0'
    seeds=c['screen_seeds'] if phase=='screen' else [s for s in c['replication_seeds'] if s not in c['screen_seeds']]
    signature=training_signature(c,candidate);inherited=None
    if phase=='replicate':inherited=previous_screen(candidate,signature)
    code_id=digest(source_hashes())[:10];trial_id=f'{candidate}_{phase}_s{"-".join(map(str,seeds))}_{code_id}'
    trial=ROOT/'trials'/trial_id;assert not trial.exists(), 'Immutable trial already exists; never silently overwrite'
    trial.mkdir(parents=True);(trial/'models').mkdir();(trial/'val_probs').mkdir();(trial/'fixtures').mkdir();(trial/'source').mkdir()
    save(trial/'CONFIG_SNAPSHOT.json',c);shutil.copy2(ROOT/'PROTOCOL.md',trial/'PROTOCOL.md')
    sources=source_hashes()
    for name in ['runner.py','model.py']:shutil.copy2(ROOT/name,trial/'source'/name)
    data,states,lineage=inputs(c,seeds,'mps')
    frozen=dict(candidate=candidate,phase=phase,seeds=seeds,signature=signature,source_sha256=sources,lineage=lineage,
        protocol_sha256=sha(ROOT/'PROTOCOL.md'),queue_sha256=sha(queue_path),config_snapshot_sha256=sha(trial/'CONFIG_SNAPSHOT.json'),
        architecture=architecture_spec(),scope='Adaptive reused TRAIN/VAL development only; no TEST/EVAL or previous test metrics accessed')
    save(trial/'FROZEN.json',frozen);append_ledger(dict(status='RUNNING',trial=trial_id,candidate=candidate,phase=phase,signature=signature))
    rows=[];baselines=[];hashes={};counter=[0]
    try:
        for b in c['budgets']:
            for seed in seeds:
                paired=[]
                for arm in ARMS:
                    net=make(c,candidate,arm,states[b,seed],seed,'mps')
                    cache,cache_meta=cached_inputs(c,net,data[b],b,seed,arm,lineage['sources'][f'{b}:{seed}'],'mps')
                    with torch.no_grad():
                        identity=net.forward_cached(slice_cache(cache['dense'],slice(0,8)))
                        assert torch.equal(identity['logits'],identity['coarse'])
                    if arm=='plain':
                        truth=data[b]['val']['label'].cpu().numpy();target=data[b]['val']['mask'][:,0].cpu().numpy().astype(bool)
                        p=cache['val']['coarse'][:,0].sigmoid().cpu().numpy()
                        scores,pred,bits=score_probabilities(p,truth,target,c['thresholds'])
                        baselines.append(dict(budget=b,seed=seed,selected=max(scores,key=rank),all_scores=scores))
                        np.savez_compressed(trial/'val_probs'/f'base_b{b}_s{seed}.npz',probability=p,truth=truth,target=target,
                            thresholds=np.array(c['thresholds']),predictions=pred,packed_masks=bits)
                    timing=fit(c,net,cache,data[b],b,seed,arm,trial,counter)
                    evaluation,arrays=evaluate(net,cache['val'],data[b]['val'],c['thresholds'])
                    fixture_cache=slice_cache(cache['val'],slice(0,16));x=data[b]['val']['x'][:16];parity={};full=[]
                    with torch.no_grad():
                        for variant in VARIANTS:
                            a=net.forward_details(x,intervention=variant)['logits'];d=net.forward_cached(fixture_cache,intervention=variant)['logits']
                            parity[variant]=float((a-d).abs().max().cpu());assert parity[variant]<1e-5
                            full.append(a.cpu().numpy())
                    name=f'b{b}_{arm}_s{seed}';row=dict(candidate=candidate,budget=b,seed=seed,arm=arm,
                        **timing,**evaluation,cache=cache_meta,cache_full_max_errors=parity)
                    path=trial/'models'/f'{name}.pt';tmp=path.with_suffix('.pt.partial')
                    torch.save(dict(model={k:v.detach().cpu() for k,v in net.state_dict().items()},settings=row),tmp);tmp.replace(path)
                    hashes[path.name]=sha(path);np.savez_compressed(trial/'val_probs'/f'{name}.npz',**arrays)
                    np.savez_compressed(trial/'fixtures'/f'{name}.npz',x=x.cpu().numpy(),full_logits=np.array(full),
                        variants=np.array(VARIANTS),**{k:v.cpu().numpy() for k,v in fixture_cache.items()})
                    rows.append(row);paired.append(row);save(trial/'PARTIAL_RESULTS.json',rows)
                    assert sha(ROOT/cache_meta['file'])==cache_meta['archive_sha256']
                    del net,cache
                assert len({r['decoder_initial_sha256'] for r in paired})==1
                assert len({r['batch_sequence_sha256'] for r in paired})==1
                assert len({r['trainable_parameters'] for r in paired})==1
        assert all(sha(ROOT/n)==h for n,h in sources.items())
        assert sha(ROOT/'PROTOCOL.md')==frozen['protocol_sha256']
        assert sha(queue_path)==frozen['queue_sha256']
        assert all(sha(G/v['file'])==v['sha256'] for v in lineage['sources'].values())
        development,means=gates(rows,baselines,c)
        result=dict(status='COMPLETE_DEVELOPMENT_TRIAL',candidate=candidate,phase=phase,seeds=seeds,signature=signature,
            rows=rows,baselines=baselines,gates=development,means=means,checkpoint_hashes=hashes,updates=counter[0],
            seconds=time.monotonic()-START,frozen_sha256=sha(trial/'FROZEN.json'),
            scope='Adaptive reused VAL only; development gate is not independent confirmation, publication novelty or TEST superiority')
        save(trial/'RESULT.json',result)
        aggregate=None
        if inherited is not None:
            p,old=inherited;all_rows=old['rows']+rows;all_base=old['baselines']+baselines
            assert {r['seed'] for r in all_rows}==set(c['replication_seeds'])
            assert len({(r['budget'],r['seed'],r['arm']) for r in all_rows})==len(all_rows)
            ag,am=gates(all_rows,all_base,c)
            aggregate=dict(status='COMPLETE_REUSED_VAL_REPLICATION',candidate=candidate,seeds=c['replication_seeds'],
                source_trials=[str(p.parent.relative_to(ROOT)),str(trial.relative_to(ROOT))],rows=all_rows,
                baselines=all_base,gates=ag,means=am,signature=signature,scope='Paired additional seeds on reused VAL; no new TEST')
            save(trial/'AGGREGATE_RESULT.json',aggregate)
        summary=dict(status=result['status'],trial=str(trial.relative_to(ROOT)),candidate=candidate,phase=phase,
            result_sha256=sha(trial/'RESULT.json'),gates=aggregate['gates'] if aggregate else development,
            means=aggregate['means'] if aggregate else means)
        append_ledger(summary);save(ROOT/'LATEST_RESULT.json',summary);print(json.dumps(summary),flush=True)
    except BaseException as error:
        failed=dict(status='FAILED',trial=trial_id,candidate=candidate,phase=phase,error=str(error),error_type=type(error).__name__,traceback=traceback.format_exc())
        save(trial/'FAILURE.json',failed);append_ledger(failed);raise


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--candidate',required=True,choices=CANDIDATES)
    parser.add_argument('--phase',choices=['screen','replicate'],default='screen');parser.add_argument('--queue',type=Path)
    parser.add_argument('--preflight',action='store_true');args=parser.parse_args()
    queue=args.queue or (ROOT/'QUEUE.json' if (ROOT/'QUEUE.json').exists() else ROOT/'CONFIG.json')
    c=configuration(queue);torch.set_num_threads(2)
    if args.preflight:preflight(c,args.candidate)
    else:run(c,args.candidate,args.phase,queue)


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
