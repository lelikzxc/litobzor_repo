"""Measure bounded disposable TRAIN-only loops; never run the full experiment."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import statistics
import subprocess
import sys
import time
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'sem_confirmation_20261028'
os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '0'
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
os.environ.setdefault('OMP_NUM_THREADS', '2')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(name, value):
    ROOT.mkdir(parents=True, exist_ok=True)
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def fetch():
    vendor = ROOT / 'vendor'; vendor.mkdir(exist_ok=True)
    def get(url):
        req = Request(url, headers={'User-Agent': 'SEM-clDice-timing/1.0'})
        with urlopen(req, timeout=30) as r:
            return r.read()
    commit = json.loads(get('https://api.github.com/repos/jocpae/clDice/commits/master'))['sha']
    files = {}
    for name in ['soft_skeleton.py', 'cldice.py']:
        url = f'https://raw.githubusercontent.com/jocpae/clDice/{commit}/cldice_loss/pytorch/{name}'
        raw = get(url); (vendor / name).write_bytes(raw)
        files[name] = {'url': url, 'sha256': sha(vendor / name)}
    (vendor / '__init__.py').write_text('"""Unmodified author clDice source, see VENDOR.json."""\n')
    items = json.loads(get(f'https://api.github.com/repos/jocpae/clDice/contents?ref={commit}'))
    licenses = [r for r in items if r['type'] == 'file' and r['name'].lower().startswith('license')]
    for item in licenses:
        raw = get(item['download_url']); (vendor / item['name']).write_bytes(raw)
        files[item['name']] = {'url': item['download_url'], 'sha256': sha(vendor / item['name'])}
    save('VENDOR.json', {'repository': 'https://github.com/jocpae/clDice', 'commit': commit,
        'files': files, 'source_modifications': False,
        'iterations': 'Author soft_cldice.forward uses SoftSkeletonize(num_iter=10); preserved unchanged.'})
    print(json.dumps({'stage': 'FETCHED', 'commit': commit, 'files': list(files)}), flush=True)


def main():
    import numpy as np
    import torch
    from torch import nn
    from torch.nn import functional as F
    from threadpoolctl import threadpool_limits
    from vendor.cldice import soft_cldice
    sys.path.insert(0, str(OLD))
    from physics_adapter import make_segmenter, geometry_loss
    from train import make_head, head_loss, evaluate
    assert torch.backends.mps.is_available(), 'MPS required for this timing, no CPU fallback'
    torch.set_num_threads(2)
    torch.manual_seed(301030)
    original_hashes = {str(p.relative_to(OLD)): sha(p) for p in OLD.rglob('*') if p.is_file()}
    try:
        processes = subprocess.check_output(['ps', '-axo', 'pid,etime,command'], text=True)
        active = [r.strip() for r in processes.splitlines() if 'python' in r.lower() and
                  ('gipoteza/' in r or 'sem_cldice' in r) and 'benchmark.py' not in r]
    except Exception as error:
        active = ['unavailable: ' + type(error).__name__]
    started = time.monotonic()
    with threadpool_limits(limits=2):
        with np.load(OLD / 'DATA.npz', allow_pickle=False) as z:
            data = {}
            for role in ['dense', 'weak', 'val']:
                ids = np.flatnonzero(z['role'] == role)
                data[role] = {'x': torch.tensor(5*(z['X'][ids]-.2), device='mps'),
                              'label': torch.tensor(z['label'][ids], device='mps')}
                if role != 'weak':
                    data[role]['mask'] = torch.tensor(z['Y'][ids].astype(np.float32), device='mps')
        assert set(data['weak']) == {'x', 'label'}
        torch.mps.synchronize()
        load_seconds = time.monotonic() - started
        dense, weak = data['dense'], data['weak']
        cl = soft_cldice()
        assert cl.soft_skeletonize.num_iter == 10
        # Technical gradient check; no TEST and no quality/parameter selection.
        cpu_pred = torch.linspace(-2, 2, 4*144).reshape(4,1,12,12).requires_grad_()
        cpu_gt = dense['mask'][:4].cpu()
        cpu_loss = cl(cpu_gt, cpu_pred.sigmoid())
        cpu_grad = torch.autograd.grad(cpu_loss, cpu_pred)[0]
        mp = cpu_pred.detach().to('mps').requires_grad_()
        ml = cl(cpu_gt.to('mps'), mp.sigmoid())
        mg = torch.autograd.grad(ml, mp)[0]
        cpu_mps_loss_error = abs(float(cpu_loss.detach()) - float(ml.detach().cpu()))
        cpu_mps_gradient_max_error = float((cpu_grad - mg.cpu()).abs().max())
        assert torch.isfinite(ml) and torch.isfinite(mg).all() and mg.abs().sum() > 0
        assert cpu_mps_loss_error < 1e-5 and cpu_mps_gradient_max_error < 1e-5
        records = {}
        benchmark_steps = 60

        def timed(name, step, repeats=3, count=benchmark_steps, warm=20):
            for i in range(warm): step(i)
            torch.mps.synchronize()
            durations = []
            for repeat in range(repeats):
                t0 = time.monotonic()
                for i in range(count): step(i + repeat*count + warm)
                torch.mps.synchronize()
                durations.append(time.monotonic() - t0)
            result = {'steps_per_repeat': count, 'repeats': repeats,
                'seconds_per_repeat': durations,
                'seconds_per_step': [v / count for v in durations],
                'median_seconds_per_step': statistics.median(durations) / count}
            records[name] = result
            save('PROGRESS.json', {'stage': 'TIMING', 'done': list(records), 'records': records})
            print(json.dumps({'stage': name, **result}), flush=True)
            return result

        net = make_segmenter().to('mps')
        opt = torch.optim.AdamW(net.parameters(), lr=.003, weight_decay=.0001)
        rng = np.random.default_rng(301030)
        def base_step(i):
            ids = torch.tensor(rng.integers(0, len(dense['x']), 16), device='mps')
            opt.zero_grad(set_to_none=True)
            loss = F.binary_cross_entropy_with_logits(net(dense['x'][ids]), dense['mask'][ids])
            assert torch.isfinite(loss)
            loss.backward(); opt.step()
        timed('base_BCE', base_step)
        initial = {k:v.detach().cpu().clone() for k,v in net.state_dict().items()}
        del net, opt

        for family in ['head9', 'cldice_head9', 'soft']:
            net = make_segmenter().to('mps'); net.load_state_dict(initial)
            head = None if family == 'soft' else make_head('head9').to('mps')
            params = list(net.parameters()) + ([] if head is None else list(head.parameters()))
            opt = torch.optim.AdamW(params, lr=.001, weight_decay=.0001)
            rng = np.random.default_rng(301031)
            def method_step(i):
                ai = torch.tensor(rng.integers(0, len(dense['x']), 16), device='mps')
                wi = torch.tensor(rng.integers(0, len(weak['x']), 16), device='mps')
                opt.zero_grad(set_to_none=True)
                zz = net(dense['x'][ai])
                loss = F.binary_cross_entropy_with_logits(zz, dense['mask'][ai])
                if family == 'soft':
                    labels = weak['label'][wi]
                    direction = torch.stack((labels//3, labels%3), 1)
                    loss = loss + .4*geometry_loss(net(weak['x'][wi]), direction)
                else:
                    features = net[:-1](weak['x'][wi])
                    loss = loss + .4*head_loss(head(features.flatten(1)), weak['label'][wi], 'head9')
                    if family == 'cldice_head9':
                        loss = loss + .4*cl(dense['mask'][ai], zz.sigmoid())
                assert torch.isfinite(loss)
                loss.backward(); opt.step()
            timed(family, method_step)
            if family == 'head9':
                feature_times = []
                for _ in range(3):
                    torch.mps.synchronize(); t0 = time.monotonic()
                    with torch.inference_mode():
                        feats = torch.cat([net[:-1](x).flatten(1) for x in weak['x'].split(128)]).clone()
                    feats = feats.clone(); torch.mps.synchronize()
                    feature_times.append(time.monotonic()-t0)
                records['feature_extraction'] = {'seconds_per_repeat': feature_times,
                                                  'median_seconds': statistics.median(feature_times)}
                ho = torch.optim.AdamW(head.parameters(), lr=.003, weight_decay=.0001)
                def head_step(i):
                    wi = torch.tensor(rng.integers(0, len(weak['x']), 16), device='mps')
                    ho.zero_grad(set_to_none=True)
                    loss = head_loss(head(feats[wi]), weak['label'][wi], 'head9')
                    loss.backward(); ho.step()
                timed('head_only', head_step)
                del ho, feats
            # Timing validation only, values intentionally not saved/selected.
            # Clear the previous hard-mask cache to represent new predictions.
            import train as old_train
            old_train.CLASS_CACHE.clear()
            t0 = time.monotonic()
            evaluate(net, head, data['val'], 'soft' if family == 'soft' else 'head9')
            torch.mps.synchronize()
            records['validation_'+family] = {'seconds': time.monotonic()-t0, 'examples': len(data['val']['x'])}
            t0 = time.monotonic()
            tmp = ROOT/'temporary_checkpoint.pt'
            torch.save({'segmenter': {k:v.detach().cpu() for k,v in net.state_dict().items()},
                        'head': None if head is None else {k:v.detach().cpu() for k,v in head.state_dict().items()}}, tmp)
            _ = sha(tmp); records['checkpoint_'+family] = {'seconds': time.monotonic()-t0, 'bytes': tmp.stat().st_size}
            tmp.unlink()
            del net, head, opt
        unchanged = all(sha(OLD/name) == h for name,h in original_hashes.items())
        assert unchanged
        budget = {'base_steps': 2800, 'head9_steps': 16000, 'soft_steps': 16000,
                  'cldice_head9_steps': 28000, 'head_only_steps': 6800,
                  'feature_extractions': 34,
                  'validation_counts': {'head9': 11, 'soft': 11, 'cldice_head9': 23},
                  'total_backbone_updates': 62800}
        compute = {k: records[k]['median_seconds_per_step']*budget[k+'_steps']
                   for k in ['head9','soft','cldice_head9','head_only']}
        compute['base_BCE'] = records['base_BCE']['median_seconds_per_step']*budget['base_steps']
        compute['feature_extraction'] = records['feature_extraction']['median_seconds']*34
        compute['validation'] = sum(records['validation_'+k]['seconds']*v for k,v in budget['validation_counts'].items())
        compute['checkpoints'] = sum(records['checkpoint_'+k]['seconds']*v for k,v in budget['validation_counts'].items()) + 5*.01
        training_total = sum(compute.values())
        final = {'status': 'COMPLETE_TIMING_ONLY', 'date': '2026-10-30',
            'full_experiment_started': False, 'final_models_or_test_metrics_produced': False,
            'MPS_available': True, 'MPS_fallback': os.environ['PYTORCH_ENABLE_MPS_FALLBACK'],
            'torch_version': torch.__version__, 'numpy_version': np.__version__,
            'hardware': subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'], text=True).strip(),
            'competing_relevant_python_processes': active,
            'load_seconds': load_seconds,
            'CPU_MPS_cldice_loss_error': cpu_mps_loss_error,
            'CPU_MPS_cldice_gradient_max_error': cpu_mps_gradient_max_error,
            'author_skeleton_iterations': 10,
            'budget': budget, 'records': records, 'projected_training_stage_seconds': compute,
            'projected_training_seconds': training_total,
            'actual_benchmark_wall_seconds': time.monotonic()-started,
            'old_files_unchanged': unchanged, 'protected_old_files': len(original_hashes),
            'input_sha256': {n:sha(OLD/n) for n in ['DATA.npz','PREDICTIONS.npz']},
            'script_sha256': sha(Path(__file__)), 'vendor_manifest_sha256': sha(ROOT/'VENDOR.json'),
            'scope': 'TRAIN-only disposable microbenchmark,3x60timedsteps perloop afterwarmup; total estimate depends on proposedHPOgrid,newdata/network,thermalstate. No newqualityclaim.'}
        save('TIMING.json', final)
        save('PROGRESS.json', {'stage': 'COMPLETE_TIMING_ONLY', 'projected_training_seconds': training_total})
        print(json.dumps(final, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--fetch', action='store_true')
    args = parser.parse_args()
    if args.fetch: fetch()
    else: main()
