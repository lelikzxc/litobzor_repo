"""Independent CPU-only connectivity and component audit of fixed SEM masks.

No model is imported or evaluated. scipy connected-component labels provide
an implementation independent of the main error analysis and resistor solver.
"""
from pathlib import Path
import hashlib
import json
import time

import numpy as np
from scipy import ndimage


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "sem_confirmation_20261028"
CROSS = ndimage.generate_binary_structure(2, 1)
EIGHT = np.ones((3, 3), dtype=bool)


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def characteristics(mask):
    """LR/TB boundary paths; 4-connected foreground; 8-background holes."""
    mask = np.asarray(mask, dtype=bool)
    labelled, components = ndimage.label(mask, structure=CROSS)
    lr = bool((set(labelled[:, 0]) & set(labelled[:, -1])) - {0})
    tb = bool((set(labelled[0]) & set(labelled[-1])) - {0})
    background, bg_count = ndimage.label(~mask, structure=EIGHT)
    exterior = set(np.concatenate((background[0], background[-1],
                                   background[:, 0], background[:, -1]))) - {0}
    holes = int(bg_count - len(exterior))
    return lr, tb, int(components), holes


def batch_characteristics(masks):
    return np.asarray([characteristics(m) for m in masks], dtype=np.int16)


def fixtures():
    empty = np.zeros((12, 12), dtype=bool)
    full = ~empty
    rows = empty.copy(); rows[[2, 8]] = True
    ring = full.copy(); ring[1:-1, 1:-1] = False
    diagonal = np.eye(12, dtype=bool)
    diagonal_holes = full.copy(); diagonal_holes[4, 4] = False; diagonal_holes[5, 5] = False
    cases = [("empty", empty, (False, False, 0, 0)),
             ("full", full, (True, True, 1, 0)),
             ("two_rows", rows, (True, False, 2, 0)),
             ("ring", ring, (True, True, 1, 1)),
             ("diagonal", diagonal, (False, False, 12, 0)),
             ("diagonal_background_8_connected", diagonal_holes, (True, True, 1, 1))]
    checked = []
    for name, mask, expected in cases:
        actual = characteristics(mask)
        assert actual == expected, (name, actual, expected)
        checked.append({"name": name, "actual": list(actual), "expected": list(expected)})
    return checked


def rate(numerator, denominator):
    return float(numerator / denominator) if denominator else None


def directional_metrics(truth, prediction):
    truth_positive = truth > 0
    pred_positive = prediction > 0
    categories = {
        "correct": prediction == truth,
        "false_break": truth_positive & ~pred_positive,
        "false_connection": ~truth_positive & pred_positive,
        "grade_error": truth_positive & pred_positive & (prediction != truth),
    }
    assert np.all(sum(v.astype(np.int8) for v in categories.values()) == 1)
    counts = {k: int(v.sum()) for k, v in categories.items()}
    positives = int(truth_positive.sum()); negatives = int((~truth_positive).sum())
    return {"total": int(truth.size), "truth_positive": positives,
            "truth_negative": negatives,
            "both_connected": int((truth_positive & pred_positive).sum()), "counts": counts,
            "false_break_rate": rate(counts["false_break"], positives),
            "false_connection_rate": rate(counts["false_connection"], negatives),
            "grade_error_rate": rate(counts["grade_error"], positives),
            "grade_error_per_both_connected": rate(counts["grade_error"], int((truth_positive & pred_positive).sum())),
            "directional_error_rate": rate(truth.size - counts["correct"], truth.size)}


def count_metrics(truth, prediction):
    delta = prediction - truth
    return {"absolute_error_sum": int(np.abs(delta).sum()),
            "MAE": float(np.abs(delta).mean()),
            "exact_count": int((delta == 0).sum()),
            "exact_agreement": float((delta == 0).mean()),
            "under_count": int((delta < 0).sum()),
            "over_count": int((delta > 0).sum()),
            "signed_bias": float(delta.mean())}


def main():
    start = time.monotonic()
    checked = fixtures()
    hashes_before = {name: sha(SOURCE / name) for name in
                     ["DATA.npz", "PREDICTIONS.npz", "BOOTSTRAP.npz"]}
    with np.load(SOURCE / "DATA.npz", allow_pickle=False) as z:
        source_masks = z["Y"][:, 0].astype(bool)
        source_labels = z["label"]
        source_roles = z["role"]
        source_frames = z["frame"]
    with np.load(SOURCE / "PREDICTIONS.npz", allow_pickle=False) as z:
        ids = z["source_indices"]
        truth = z["truth"]
        predictions = z["mask_predictions"]
        packed = z["packed_masks"]
        seeds = z["seeds"].tolist(); arms = z["arms"].tolist()
        frames = z["frames"]
    assert np.all(source_roles[ids] == "test")
    assert np.array_equal(truth, source_labels[ids])
    assert np.array_equal(frames, source_frames[ids])
    gt = batch_characteristics(source_masks[ids])
    true_directions = np.column_stack((truth // 3, truth % 3))
    main_result = json.loads((ROOT / "RESULT.json").read_text())
    with np.load(ROOT / "ERROR_ARRAYS.npz", allow_pickle=False) as z:
        main_topology = z["predicted_topology"]
        main_truth_topology = z["truth_topology"]
        main_directional_events = z["directional_events"]
        main_joint_events = z["joint_events"]
        main_directional_confusion = z["directional_confusion"]
        main_bootstrap_scores = z["bootstrap_scores"]
        main_metric_names = z["metric_names"].tolist()
    with np.load(SOURCE / "BOOTSTRAP.npz", allow_pickle=False) as z:
        seed_draws = z["seed_ids"]
        frame_draws = z["frame_ids"]
    main_hashes_before = {name: sha(ROOT / name) for name in ["RESULT.json", "ERROR_ARRAYS.npz"]}
    unique_frames = sorted(set(frames.tolist()))
    key_metrics = ["false_break_rate", "false_connection_rate", "grade_error_per_true_connected",
                   "joint_connection_error_rate", "component_count_mae"]
    # Build these independently from per-mask connected-component analysis,
    # not from the main script's preaggregated numerator/denominator arrays.
    independent_num = np.zeros((len(seeds), len(arms), len(unique_frames), len(key_metrics)))
    independent_den = np.zeros_like(independent_num)
    main_metric_error = 0.0
    main_integer_mismatches = 0
    topology_mismatches = int(np.count_nonzero(gt[:, [2, 3, 0, 1]] != main_truth_topology))
    directional_event_mismatches = 0
    joint_event_mismatches = 0
    truth_path_mismatches = int(np.count_nonzero(gt[:, :2].astype(bool) != (true_directions > 0)))
    prediction_path_mismatches = 0
    rows = []
    for si, seed in enumerate(seeds):
        for ai, arm in enumerate(arms):
            masks = np.unpackbits(packed[si, ai], axis=1, count=144).reshape(-1, 12, 12).astype(bool)
            pc = batch_characteristics(masks)
            labels = predictions[si, ai]
            pred_directions = np.column_stack((labels // 3, labels % 3))
            mismatches = int(np.count_nonzero(pc[:, :2].astype(bool) != (pred_directions > 0)))
            prediction_path_mismatches += mismatches
            topology_mismatches += int(np.count_nonzero(pc[:, [2, 3, 0, 1]] != main_topology[si, ai]))
            broken = gt[:, :2].astype(bool) & ~pc[:, :2].astype(bool)
            falsely_joined = ~gt[:, :2].astype(bool) & pc[:, :2].astype(bool)
            changed_grade = ((true_directions > 0) & (pred_directions > 0)
                             & (true_directions != pred_directions))
            # Explicit categories reconstructed independently from label maps.
            independent_events = (broken.astype(np.uint8) + 2 * falsely_joined.astype(np.uint8)
                                  + 3 * changed_grade.astype(np.uint8))
            directional_event_mismatches += int(np.count_nonzero(independent_events != main_directional_events[si, ai]))
            connection_error = np.logical_or(broken, falsely_joined).any(axis=1)
            grade_only = ~connection_error & changed_grade.any(axis=1)
            independent_joint_events = connection_error.astype(np.uint8) + 2 * grade_only.astype(np.uint8)
            joint_event_mismatches += int(np.count_nonzero(independent_joint_events != main_joint_events[si, ai]))
            direction_confusion = np.zeros((2, 3, 3), dtype=np.int64)
            for direction in range(2):
                np.add.at(direction_confusion[direction],
                          (true_directions[:, direction], pred_directions[:, direction]), 1)
            row = {"seed": seed, "arm": arm,
                   "directional": directional_metrics(true_directions, pred_directions),
                   "LR": directional_metrics(true_directions[:, 0], pred_directions[:, 0]),
                   "TB": directional_metrics(true_directions[:, 1], pred_directions[:, 1]),
                   "direction_confusion": direction_confusion.tolist(),
                   "components": count_metrics(gt[:, 2], pc[:, 2]),
                   "holes": count_metrics(gt[:, 3], pc[:, 3]),
                   "both_counts_exact": int(np.all(gt[:, 2:] == pc[:, 2:], axis=1).sum()),
                   "joint": {"errors": int((truth != labels).sum()),
                             "connection_errors": int(connection_error.sum()),
                             "grade_only_errors": int(grade_only.sum())},
                   "path_class_mismatches": mismatches}
            # Check all 13 reported metric points and all integer partitions.
            n = len(truth)
            expected_main = {
                "direction_error_rate": row["directional"]["directional_error_rate"],
                "false_break_rate": row["directional"]["false_break_rate"],
                "false_connection_rate": row["directional"]["false_connection_rate"],
                "grade_error_per_true_connected": row["directional"]["grade_error_rate"],
                "grade_error_per_both_connected": row["directional"]["grade_error_per_both_connected"],
                "joint_error_rate": row["joint"]["errors"] / n,
                "joint_connection_error_rate": row["joint"]["connection_errors"] / n,
                "joint_grade_only_error_rate": row["joint"]["grade_only_errors"] / n,
                "component_count_mae": row["components"]["MAE"],
                "component_count_exact_rate": row["components"]["exact_agreement"],
                "hole_count_mae": row["holes"]["MAE"],
                "hole_count_exact_rate": row["holes"]["exact_agreement"],
                "topology_counts_exact_rate": row["both_counts_exact"] / n,
            }
            saved_row = next(r for r in main_result["per_seed"] if r["seed"] == seed and r["arm"] == arm)
            main_metric_error = max(main_metric_error, max(abs(saved_row[k] - v) for k, v in expected_main.items()))
            for dname in ["LR", "TB", "both"]:
                own = row["directional"] if dname == "both" else row[dname]
                saved_count = next(r for r in main_result["directional_counts"]
                                   if r["seed"] == seed and r["arm"] == arm and r["direction"] == dname)
                for own_name, main_name in [("correct", "correct"), ("false_break", "break"),
                                             ("false_connection", "false_connection"), ("grade_error", "grade")]:
                    main_integer_mismatches += int(own["counts"][own_name] != saved_count[main_name])
                main_integer_mismatches += int(own["truth_positive"] != saved_count["truth_connected"])
                main_integer_mismatches += int(own["truth_negative"] != saved_count["truth_disconnected"])
                main_integer_mismatches += int(own["total"] != saved_count["total"])
            independent_aggregates = [
                (broken.sum(axis=1), (true_directions > 0).sum(axis=1)),
                (falsely_joined.sum(axis=1), (true_directions == 0).sum(axis=1)),
                (changed_grade.sum(axis=1), (true_directions > 0).sum(axis=1)),
                (connection_error, np.ones(n, dtype=int)),
                (np.abs(pc[:, 2] - gt[:, 2]), np.ones(n, dtype=int)),
            ]
            for fi, frame in enumerate(unique_frames):
                selected = frames == frame
                for mi, (num, den) in enumerate(independent_aggregates):
                    independent_num[si, ai, fi, mi] = num[selected].sum()
                    independent_den[si, ai, fi, mi] = den[selected].sum()
                for direction in range(2):
                    dc = np.bincount(3 * true_directions[selected, direction]
                                     + pred_directions[selected, direction], minlength=9).reshape(3, 3)
                    main_integer_mismatches += int(np.count_nonzero(dc != main_directional_confusion[si, ai, fi, direction]))
            rows.append(row)
            print(json.dumps({"seed": seed, "arm": arm, "path_mismatches": mismatches,
                              "break_rate": row["directional"]["false_break_rate"],
                              "false_connection_rate": row["directional"]["false_connection_rate"],
                              "component_MAE": row["components"]["MAE"]}), flush=True)
    # Independent crossed bootstrap: multiplicities of frames/seeds instead
    # of main analysis's advanced-index sampling tensor.
    seed_weights = np.asarray([np.bincount(draw, minlength=len(seeds)) for draw in seed_draws])
    frame_weights = np.asarray([np.bincount(draw, minlength=len(unique_frames)) for draw in frame_draws])
    sampled_num = np.einsum("bf,safk->bsak", frame_weights, independent_num)
    sampled_den = np.einsum("bf,safk->bsak", frame_weights, independent_den)
    assert np.all(sampled_den > 0)
    independent_scores = np.einsum("bs,bsak->bak", seed_weights, sampled_num / sampled_den) / len(seeds)
    soft_index = arms.index("soft"); head_index = arms.index("head9")
    bootstrap_checks = {}
    bootstrap_max_error = 0.0
    for k, name in enumerate(key_metrics):
        main_k = main_metric_names.index(name)
        # Positive delta denotes a reduction in error for these five metrics.
        own_delta = independent_scores[:, head_index, k] - independent_scores[:, soft_index, k]
        main_delta = main_bootstrap_scores[:, head_index, main_k] - main_bootstrap_scores[:, soft_index, main_k]
        point_by_seed = independent_num[:, :, :, k].sum(axis=2) / independent_den[:, :, :, k].sum(axis=2)
        own_point = float((point_by_seed[:, head_index] - point_by_seed[:, soft_index]).mean())
        saved = main_result["soft_improvement_over_control"]["head9"][name]
        own_ci = np.quantile(own_delta, [.025, .975])
        score_error = float(np.max(np.abs(independent_scores[:, :, k] - main_bootstrap_scores[:, :, main_k])))
        delta_error = float(np.max(np.abs(own_delta - main_delta)))
        point_error = float(abs(own_point - saved["improvement"]))
        ci_error = float(np.max(np.abs(own_ci - saved["CI95"])))
        bootstrap_max_error = max(bootstrap_max_error, score_error, delta_error, point_error, ci_error)
        bootstrap_checks[name] = {"draws_checked": len(own_delta), "all_arm_score_max_error": score_error,
                                 "head9_minus_soft_delta_max_error": delta_error,
                                 "point_error": point_error, "CI95_error": ci_error,
                                 "independent_improvement": own_point,
                                 "independent_CI95": own_ci.tolist()}
    hashes_after = {name: sha(SOURCE / name) for name in hashes_before}
    original_result = json.loads((SOURCE / "RESULT.json").read_text())
    source_hash_ok = hashes_before["PREDICTIONS.npz"] == original_result["predictions_sha256"]
    unchanged = hashes_before == hashes_after
    main_unchanged = main_hashes_before == {name: sha(ROOT / name) for name in main_hashes_before}
    passed = (truth_path_mismatches == prediction_path_mismatches == topology_mismatches
              == directional_event_mismatches == joint_event_mismatches == main_integer_mismatches == 0
              and main_metric_error < 1e-12 and bootstrap_max_error < 1e-12
              and unchanged and source_hash_ok and main_unchanged)
    out = {"status": "PASS_INDEPENDENT_ARITHMETIC" if passed else "FAIL_INDEPENDENT_ARITHMETIC",
           "scope": "Exploratory error analysis of already-opened TEST. No new training, tuning, model selection, or confirmatory experiment.",
           "implementation": "Independent scipy.ndimage labels: foreground 4-connectivity; background 8-connectivity; holes exclude any component touching the border.",
           "definitions": {"false_break_rate": "count(truth direction > 0 and prediction == 0) / count(truth direction > 0)",
                           "false_connection_rate": "count(truth direction == 0 and prediction > 0) / count(truth direction == 0)",
                           "grade_error_rate": "count(truth > 0 and prediction > 0 and prediction != truth) / count(truth > 0)",
                           "partition": "correct, false_break, false_connection, grade_error partition all 2*N directional cases"},
           "sources_sha256": hashes_before, "sources_unchanged": unchanged,
           "predictions_match_original_result_hash": source_hash_ok,
           "script_sha256": sha(Path(__file__)),
           "fixtures": checked, "truth_path_class_mismatches": truth_path_mismatches,
           "prediction_path_class_mismatches": prediction_path_mismatches,
           "main_output_comparison": {
               "main_output_sha256": main_hashes_before,
               "main_outputs_unchanged": main_unchanged,
               "all_truth_and_prediction_topology_mismatches": topology_mismatches,
               "directional_event_mismatches": directional_event_mismatches,
               "joint_event_mismatches": joint_event_mismatches,
               "integer_count_and_directional_confusion_mismatches": main_integer_mismatches,
               "per_seed_metrics_checked": len(seeds) * len(arms) * 13,
               "per_seed_metric_max_error": main_metric_error,
               "bootstrap_implementation": "Independent frame/seed multiplicity weights via numpy.bincount and einsum; no advanced-index resampling",
               "bootstrap_max_error": bootstrap_max_error,
               "bootstrap_head9_soft_checks": bootstrap_checks},
           "test_examples": len(truth), "test_frames": sorted(set(frames.tolist())),
           "seeds": seeds, "arms": arms,
           "truth_components_distribution": {str(k): int(v) for k, v in zip(*np.unique(gt[:, 2], return_counts=True))},
           "truth_holes_distribution": {str(k): int(v) for k, v in zip(*np.unique(gt[:, 3], return_counts=True))},
           "rows": rows, "seconds": time.monotonic() - start}
    (ROOT / "INDEPENDENT_AUDIT.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
    assert passed, out["status"]
    print(json.dumps({"status": out["status"], "seconds": out["seconds"]}))


if __name__ == "__main__":
    main()
