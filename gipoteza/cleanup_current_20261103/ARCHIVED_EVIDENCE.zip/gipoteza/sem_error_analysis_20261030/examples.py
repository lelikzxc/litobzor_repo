"""Deterministic post-hoc examples from immutable saved SEM predictions.

No training, inference, or parameter selection is performed. The illustrated
seed is the middle seed in the original saved order, fixed before inspecting
any candidate image. Examples are illustrations, not a frequency estimate.
"""
from pathlib import Path
import hashlib
import json
import os

os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/sem_error_examples_mpl_20261030')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'sem_confirmation_20261028'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    ROOT.mkdir(exist_ok=True)
    figures = ROOT / 'figures'
    figures.mkdir(exist_ok=True)
    metadata = json.loads((SOURCE / 'DATA_MANIFEST.json').read_text())
    with np.load(SOURCE / 'PREDICTIONS.npz', allow_pickle=False) as z:
        seeds = z['seeds'].tolist()
        seed_position = len(seeds) // 2
        assert seeds[seed_position] == 2833
        arms = z['arms'].tolist()
        indices = z['source_indices']
        truth = z['truth']
        predicted = z['mask_predictions'][seed_position]
        masks = np.unpackbits(z['packed_masks'][seed_position], axis=-1).reshape(len(arms), -1, 12, 12).astype(bool)
    with np.load(SOURCE / 'DATA.npz', allow_pickle=False) as z:
        inputs = z['X'][indices, 0]
        target = z['Y'][indices, 0].astype(bool)
        assert np.array_equal(truth, z['label'][indices])
    s = arms.index('soft')
    h = arms.index('head9')
    t_direction = np.stack([truth // 3, truth % 3], axis=-1)
    h_direction = np.stack([predicted[h] // 3, predicted[h] % 3], axis=-1)
    soft_correct = predicted[s] == truth
    head_correct = predicted[h] == truth
    head_break = ((t_direction > 0) & (h_direction == 0)).any(1)
    head_connection = ((t_direction == 0) & (h_direction > 0)).any(1)
    head_connectivity_correct = ((t_direction > 0) == (h_direction > 0)).all(1)
    head_grade_only = head_connectivity_correct & ~head_correct
    categories = [
        ('break_fixed', 'Исправлен пропуск соединения', soft_correct & ~head_correct & head_break),
        ('connection_fixed', 'Исправлено ложное соединение', soft_correct & ~head_correct & head_connection),
        ('grade_fixed', 'Исправлена ошибка градации при сохранённой связности', soft_correct & head_grade_only),
        ('regression', 'Обратный случай: контроль верен, наш метод ошибся', head_correct & ~soft_correct),
        ('shared_failure', 'Оба метода ошиблись', ~head_correct & ~soft_correct),
        ('shared_success', 'Оба метода определили класс верно', head_correct & soft_correct),
    ]
    test_records = [metadata['records'][int(i)] for i in indices]
    keys = [hashlib.sha256(f"SEM-ERROR-EXAMPLE-20261030/{r['frame']}/{r['x']}/{r['y']}".encode()).hexdigest() for r in test_records]
    selected = []
    used_indices = set()
    used_frames = set()
    for category, title, eligible in categories:
        candidates = sorted(np.flatnonzero(eligible).tolist(), key=lambda i: keys[i])
        unused = [i for i in candidates if i not in used_indices]
        new_frame = [i for i in unused if test_records[i]['frame'] not in used_frames]
        pool = new_frame or unused
        assert pool, f'No candidate in category {category}; change selection explicitly, not silently.'
        i = pool[0]
        used_indices.add(i)
        used_frames.add(test_records[i]['frame'])
        record = test_records[i]
        selected.append({'category': category, 'title': title,
                         'candidate_count': len(candidates), 'unused_frame_candidates': len(new_frame),
                         'test_position': i, 'source_index': int(indices[i]),
                         'frame': record['frame'], 'x': record['x'], 'y': record['y'],
                         'selection_sha256': keys[i], 'new_frame_preference_used': bool(new_frame),
                         'truth': int(truth[i]),
                         'predictions': {arm: int(predicted[a, i]) for a, arm in enumerate(arms)}})

    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'svg.fonttype': 'none'})
    fig, axes = plt.subplots(6, 7, figsize=(14.7, 15.0))
    fig.subplots_adjust(left=.035, right=.985, top=.905, bottom=.075, wspace=.14, hspace=.62)
    fig.suptitle('Сохранённые прогнозы: исправления, ухудшения и общие ошибки',
                 x=.035, y=.985, ha='left', fontsize=16, weight='bold')
    fig.text(.035, .958, 'Один заранее выбранный запуск: 2833. Контроль — голова на 9 классов. '
             'Примеры выбраны по категориям и SHA256.', fontsize=10, color='#475569')
    names = ['SEM: 48 × 48', 'Эталон: 12 × 12', 'Исходный BCE', 'BCE: дообучение',
             'Голова: 9 классов', 'Голова: 4 цели', 'Наш метод']
    method_order = ['base', 'replay', 'head9', 'head4', 'soft']
    metal = np.array([.07, .37, .40])
    background = np.array([.96, .97, .97])
    fp_color = np.array([.91, .43, .32])
    fn_color = np.array([.35, .59, .87])
    source_hashes = {}
    max_input_error = 0.
    native_images = {}
    for row, example in enumerate(selected):
        i = example['test_position']
        native_path = SOURCE / 'sources' / f"sem{example['frame']:04}.png"
        source_hashes[str(native_path.relative_to(SOURCE))] = sha(native_path)
        if example['frame'] not in native_images:
            native_images[example['frame']] = np.asarray(Image.open(native_path))
        image = native_images[example['frame']]
        x, y = example['x'], example['y']
        crop = image[y:y+48, x:x+48]
        assert crop.shape == (48, 48)
        reconstructed = crop.reshape(12, 4, 12, 4).sum((1, 3)).astype(np.float32) / (16 * 255)
        error = float(np.max(np.abs(reconstructed - inputs[i])))
        assert error == 0, ('Native crop does not match model input', example, error)
        max_input_error = max(max_input_error, error)
        axes[row, 0].imshow(crop, cmap='gray', vmin=0, vmax=255, interpolation='nearest')
        rgb = np.where(target[i][..., None], metal, background)
        axes[row, 1].imshow(rgb, interpolation='nearest')
        for column, arm in enumerate(method_order, start=2):
            a = arms.index(arm)
            mask = masks[a, i]
            rgb = np.where(mask[..., None], metal, background)
            rgb[mask & ~target[i]] = fp_color
            rgb[~mask & target[i]] = fn_color
            axes[row, column].imshow(rgb, interpolation='nearest')
        for column, ax in enumerate(axes[row]):
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
            if column == 0:
                label = f"Кадр {example['frame']}; x={x}, y={y}"
            else:
                c = int(truth[i]) if column == 1 else example['predictions'][method_order[column - 2]]
                label = f"Класс {c}: ({c // 3}, {c % 3})"
                if column >= 2:
                    label += ' ✓' if c == truth[i] else ' ×'
            ax.set_xlabel(label, fontsize=8, labelpad=5,
                          color='#087F8C' if column >= 2 and c == truth[i] else '#334155')
            if row == 0:
                ax.set_title(names[column], fontsize=9.4, pad=27,
                             weight='bold' if column == 6 else 'normal')
        box = axes[row, 0].get_position()
        row_title = f"{row+1}. {example['title']}"
        fig.text(.035, box.y1 + .009, row_title, fontsize=10.2, weight='bold', color='#243746')

    legend = [Patch(facecolor=metal, label='Предсказанная металлизация'),
              Patch(facecolor=fp_color, label='Лишний пиксель металла'),
              Patch(facecolor=fn_color, label='Пропущенный пиксель металла')]
    fig.legend(handles=legend, loc='lower left', bbox_to_anchor=(.025, .025), ncol=3,
               frameon=False, fontsize=9)
    fig.text(.035, .013, 'Один чип; классы модельные. В подписи: класс и состояния (слева–справа, сверху–снизу). '
             'Примеры не оценивают частоту ошибок.', fontsize=8.8, color='#475569')
    for extension in ['png', 'svg']:
        fig.savefig(figures / f'examples.{extension}', dpi=190, facecolor='white')
    plt.close(fig)
    result = {
        'status': 'COMPLETE_EXAMPLES',
        'scope': 'Post-hoc illustrations from frozen outputs; no retraining, inference, or frequency estimate.',
        'seed': seeds[seed_position], 'seed_rule': 'Middle position of original saved seed order, fixed before inspecting images.',
        'primary_control': 'head9',
        'selection_rule': 'Categories fixed; ascending SHA256 of SEM-ERROR-EXAMPLE-20261030/{frame}/{x}/{y}; '
                          'prefer unused frame, then any unused patch. First three require soft joint class correct.',
        'categories': selected,
        'native_input_match_max_error': max_input_error,
        'input_display': 'Original 48x48 crop at fixed grayscale [0,255]. The actual model input was 4x4 block mean, 12x12.',
        'mask_display': '12x12; nearest-neighbor interpolation, same palette for all; red FP and blue FN relative to target.',
        'sources_sha256': {name: sha(SOURCE / name) for name in ['DATA.npz', 'PREDICTIONS.npz', 'DATA_MANIFEST.json']},
        'native_sources_sha256': source_hashes,
        'script_sha256': sha(__file__),
        'figures_sha256': {f'examples.{ext}': sha(figures / f'examples.{ext}') for ext in ['png', 'svg']}
    }
    save(ROOT / 'EXAMPLES.json', result)
    print(json.dumps({'status': result['status'], 'seed': result['seed'],
                      'examples': [{'category': v['category'], 'candidates': v['candidate_count'],
                                    'frame': v['frame'], 'truth': v['truth'], 'soft': v['predictions']['soft'],
                                    'head9': v['predictions']['head9']} for v in selected]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
