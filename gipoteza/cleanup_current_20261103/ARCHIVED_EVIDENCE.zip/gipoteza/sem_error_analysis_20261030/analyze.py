"""Post-hoc error analysis of immutable saved SEM predictions; CPU only."""
from pathlib import Path
import csv
import hashlib
import json
import time

import numpy as np
from scipy import ndimage

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'sem_confirmation_20261028'
METRICS = [
    'direction_error_rate', 'false_break_rate', 'false_connection_rate',
    'grade_error_per_true_connected', 'grade_error_per_both_connected',
    'joint_error_rate', 'joint_connection_error_rate', 'joint_grade_only_error_rate',
    'component_count_mae', 'component_count_exact_rate',
    'hole_count_mae', 'hole_count_exact_rate', 'topology_counts_exact_rate',
]
HIGHER_BETTER = {'component_count_exact_rate', 'hole_count_exact_rate', 'topology_counts_exact_rate'}
INPUT_NAMES = ['DATA.npz', 'PREDICTIONS.npz', 'BOOTSTRAP.npz', 'DATA_MANIFEST.json',
               'RESULT.json', 'SELECTION.json', 'AUDIT.json']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def topology(masks):
    """Label disconnected image planes as one volume; planes cannot connect.

    Return foreground beta0, background holes beta1, LR-path and TB-path.
    Global component IDs allow vectorised border intersection without making
    assumptions about component numbering order inside/between image planes.
    """
    masks = np.asarray(masks, dtype=bool)
    assert masks.ndim == 3
    n = len(masks)
    s4 = np.zeros((3, 3, 3), dtype=bool)
    s4[1] = ndimage.generate_binary_structure(2, 1)
    fg, nf = ndimage.label(masks, structure=s4)
    owner = np.zeros(nf + 1, dtype=np.int32)
    # Every nonzero label belongs to exactly one plane; repeated writes agree.
    owner[fg] = np.arange(n, dtype=np.int32)[:, None, None]
    b0 = np.bincount(owner[1:], minlength=n)
    lr_ids = np.intersect1d(np.unique(fg[:, :, 0]), np.unique(fg[:, :, -1]))
    tb_ids = np.intersect1d(np.unique(fg[:, 0, :]), np.unique(fg[:, -1, :]))
    lr = np.zeros(n, dtype=bool); tb = lr.copy()
    lr[owner[lr_ids[lr_ids != 0]]] = True
    tb[owner[tb_ids[tb_ids != 0]]] = True
    s8 = np.zeros((3, 3, 3), dtype=bool); s8[1] = True
    bg, nb = ndimage.label(~masks, structure=s8)
    bg_owner = np.zeros(nb + 1, dtype=np.int32)
    bg_owner[bg] = np.arange(n, dtype=np.int32)[:, None, None]
    border = np.concatenate((bg[:, 0, :].ravel(), bg[:, -1, :].ravel(),
                             bg[:, :, 0].ravel(), bg[:, :, -1].ravel()))
    touches = np.zeros(nb + 1, dtype=bool); touches[border] = True
    hole_ids = np.flatnonzero(~touches); hole_ids = hole_ids[hole_ids != 0]
    b1 = np.bincount(bg_owner[hole_ids], minlength=n)
    return np.stack((b0, b1, lr, tb), axis=1).astype(np.int16)


def selfcheck():
    m = np.zeros((9, 12, 12), dtype=bool)
    m[1] = True
    m[2, 5] = True
    m[3, :, 5] = True
    m[4, 2, 2] = True; m[4, 9, 9] = True
    np.fill_diagonal(m[5], True)
    m[6, 3:9, 3:9] = True; m[6, 4:8, 4:8] = False
    m[7] = m[6]; m[7, 3, 5] = False
    m[8, [3, 8], :] = True
    expected = np.array([[0, 0, 0, 0], [1, 0, 1, 1], [1, 0, 1, 0],
                         [1, 0, 0, 1], [2, 0, 0, 0], [12, 0, 0, 0],
                         [1, 1, 0, 0], [1, 0, 0, 0], [2, 0, 1, 0]])
    got = topology(m)
    assert np.array_equal(got, expected), (got, expected)
    assert all(np.array_equal(topology(m[i:i+1])[0], got[i]) for i in range(len(m)))
    return {'analytic_masks': len(m), 'no_cross_plane_connections': True}


def csv_write(name, rows):
    with (ROOT / name).open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def f1(c):
    den = c.sum(-1) + c.sum(-2)
    return np.divide(2 * np.diagonal(c, axis1=-2, axis2=-1), den,
                     out=np.zeros(den.shape, dtype=float), where=den > 0)


def main():
    start = time.monotonic()
    checks = selfcheck()
    before = {name: sha(SOURCE / name) for name in INPUT_NAMES}
    # All old files (including checkpoints/sources/reports) are protected.
    old_files = {str(p.relative_to(SOURCE)): sha(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()}
    with np.load(SOURCE / 'DATA.npz', allow_pickle=False) as z:
        ids = np.flatnonzero(z['role'] == 'test')
        truth_masks = z['Y'][ids, 0].astype(bool)
        labels = z['label'][ids]
        frames = z['frame'][ids]
    with np.load(SOURCE / 'PREDICTIONS.npz', allow_pickle=False) as z:
        assert np.array_equal(ids, z['source_indices'])
        assert np.array_equal(labels, z['truth'])
        assert np.array_equal(frames, z['frames'])
        pred = z['mask_predictions']; packed = z['packed_masks']
        seeds = z['seeds'].tolist(); arms = z['arms'].tolist()
    with np.load(SOURCE / 'BOOTSTRAP.npz', allow_pickle=False) as z:
        si = z['seed_ids']; fi = z['frame_ids']; original_confusion = z['confusion']
    prior = json.loads((SOURCE / 'RESULT.json').read_text())
    assert before['PREDICTIONS.npz'] == prior['predictions_sha256']
    n = len(labels); ns = len(seeds); na = len(arms)
    unique_frames, gid = np.unique(frames, return_inverse=True)
    nf = len(unique_frames)
    truth_dir = np.stack((labels // 3, labels % 3), axis=1)
    truth_topo = topology(truth_masks)
    assert np.array_equal(truth_topo[:, 2:], truth_dir > 0)
    predicted_topo = np.empty((ns, na, n, 4), dtype=np.int16)
    events = np.empty((ns, na, n, 2), dtype=np.uint8)
    joint_events = np.empty((ns, na, n), dtype=np.uint8)
    # Axis metric denotes sums before dividing: means use per-frame patch counts.
    num = np.zeros((ns, na, nf, len(METRICS)), dtype=np.float64)
    den = np.zeros_like(num)
    confusion = np.zeros((ns, na, nf, 9, 9), dtype=np.int32)
    dir_confusion = np.zeros((ns, na, nf, 2, 3, 3), dtype=np.int32)
    per_seed = []; directional_counts = []; per_class = []; frame_rows = []
    for s, seed in enumerate(seeds):
        for a, arm in enumerate(arms):
            mask = np.unpackbits(packed[s, a], axis=1).reshape(n, 12, 12).astype(bool)
            tp = topology(mask); predicted_topo[s, a] = tp
            pd = np.stack((pred[s, a] // 3, pred[s, a] % 3), axis=1)
            assert np.array_equal(tp[:, 2:], pd > 0), (seed, arm)
            broken = (truth_dir > 0) & (pd == 0)
            added = (truth_dir == 0) & (pd > 0)
            grade = (truth_dir > 0) & (pd > 0) & (truth_dir != pd)
            correct = truth_dir == pd
            assert np.all(correct.astype(int) + broken + added + grade == 1)
            ev = np.zeros((n, 2), dtype=np.uint8)
            ev[broken] = 1; ev[added] = 2; ev[grade] = 3
            events[s, a] = ev
            conn = (broken | added).any(1)
            grade_only = ~conn & grade.any(1)
            joint_correct = labels == pred[s, a]
            assert np.all(joint_correct.astype(int) + conn + grade_only == 1)
            joint_events[s, a] = np.where(conn, 1, np.where(grade_only, 2, 0))
            abs_c = np.abs(tp[:, 0] - truth_topo[:, 0])
            abs_h = np.abs(tp[:, 1] - truth_topo[:, 1])
            values = [
                ((ev != 0).sum(1), np.full(n, 2)),
                (broken.sum(1), (truth_dir > 0).sum(1)),
                (added.sum(1), (truth_dir == 0).sum(1)),
                (grade.sum(1), (truth_dir > 0).sum(1)),
                (grade.sum(1), ((truth_dir > 0) & (pd > 0)).sum(1)),
                (~joint_correct, np.ones(n)), (conn, np.ones(n)),
                (grade_only, np.ones(n)), (abs_c, np.ones(n)),
                (abs_c == 0, np.ones(n)), (abs_h, np.ones(n)),
                (abs_h == 0, np.ones(n)), ((abs_c == 0) & (abs_h == 0), np.ones(n)),
            ]
            np.add.at(confusion[s, a], (gid, labels, pred[s, a]), 1)
            for d in range(2):
                np.add.at(dir_confusion[s, a, :, d], (gid, truth_dir[:, d], pd[:, d]), 1)
            for k, (numerator, denominator) in enumerate(values):
                num[s, a, :, k] = np.bincount(gid, weights=numerator, minlength=nf)
                den[s, a, :, k] = np.bincount(gid, weights=denominator, minlength=nf)
            c = confusion[s, a].sum(0)
            m = num[s, a].sum(0) / den[s, a].sum(0)
            row = {'seed': seed, 'arm': arm, 'Macro_F1': float(f1(c).mean())}
            row.update({k: float(v) for k, v in zip(METRICS, m)})
            per_seed.append(row)
            assert abs(row['Macro_F1'] - prior['metrics'][arm]['per_seed_mask_F1'][s]) < 1e-12
            for d, name in [(0, 'LR'), (1, 'TB'), (None, 'both')]:
                dd = truth_dir if d is None else truth_dir[:, d]
                ee = ev if d is None else ev[:, d]
                directional_counts.append({'seed': seed, 'arm': arm, 'direction': name,
                    'correct': int((ee == 0).sum()), 'break': int((ee == 1).sum()),
                    'false_connection': int((ee == 2).sum()), 'grade': int((ee == 3).sum()),
                    'truth_connected': int((dd > 0).sum()), 'truth_disconnected': int((dd == 0).sum()),
                    'total': int(ee.size)})
            precision = np.divide(c.diagonal(), c.sum(0), out=np.zeros(9), where=c.sum(0) > 0)
            recall = c.diagonal() / c.sum(1)
            for cl in range(9):
                per_class.append({'seed': seed, 'arm': arm, 'class': cl,
                    'LR': cl // 3, 'TB': cl % 3, 'support': int(c[cl].sum()),
                    'precision': float(precision[cl]), 'recall': float(recall[cl]), 'F1': float(f1(c)[cl])})
            for g, frame in enumerate(unique_frames):
                row = {'seed': seed, 'arm': arm, 'frame': int(frame), 'patches': int((gid == g).sum())}
                for k, metric in enumerate(METRICS):
                    row[metric + '_numerator'] = float(num[s, a, g, k])
                    row[metric + '_denominator'] = float(den[s, a, g, k])
                frame_rows.append(row)
            save('PROGRESS.json', {'stage': 'TOPOLOGY', 'seed': seed, 'arm': arm,
                                   'completed': s * na + a + 1, 'total': ns * na,
                                   'seconds': time.monotonic() - start})
            print(json.dumps({'stage': 'TOPOLOGY', 'seed': seed, 'arm': arm,
                              'seconds': round(time.monotonic() - start, 2)}), flush=True)
    assert np.array_equal(confusion, original_confusion)
    # Reuse exactly the crossed frame/seed samples of the original evaluation.
    sample_num = num[si[:, :, None], :, fi[:, None, :], :].sum(2)
    sample_den = den[si[:, :, None], :, fi[:, None, :], :].sum(2)
    assert sample_num.shape == (len(si), ns, na, len(METRICS))
    assert (sample_den > 0).all()
    draws = (sample_num / sample_den).mean(1)  # repeats, arms, metrics
    point_per_seed = num.sum(2) / den.sum(2)
    point = point_per_seed.mean(0)
    soft = arms.index('soft')
    comparisons = {}; summary = []; paired_cases = []
    for a, arm in enumerate(arms):
        for k, metric in enumerate(METRICS):
            summary.append({'arm': arm, 'metric': metric, 'mean': float(point[a, k]),
                'CI95_lower': float(np.quantile(draws[:, a, k], .025)),
                'CI95_upper': float(np.quantile(draws[:, a, k], .975))})
        if arm == 'soft':
            continue
        comparisons[arm] = {}
        for k, metric in enumerate(METRICS):
            sign = 1 if metric in HIGHER_BETTER else -1
            delta = sign * (point[soft, k] - point[a, k])
            ds = sign * (draws[:, soft, k] - draws[:, a, k])
            per_s = sign * (point_per_seed[:, soft, k] - point_per_seed[:, a, k])
            comparisons[arm][metric] = {'improvement': float(delta),
                'CI95': np.quantile(ds, [.025, .975]).tolist(),
                'per_seed_improvement': per_s.tolist(),
                'positive_means': 'soft minus control' if sign == 1 else 'control minus soft'}
        for s, seed in enumerate(seeds):
            cc = pred[s, a] == labels; sc = pred[s, soft] == labels
            paired_cases.append({'seed': seed, 'control': arm,
                'both_correct': int((cc & sc).sum()), 'soft_repairs_control': int((~cc & sc).sum()),
                'soft_regresses_from_control': int((cc & ~sc).sum()), 'both_wrong': int((~cc & ~sc).sum()),
                'net_correct_gain': int((~cc & sc).sum() - (cc & ~sc).sum())})
    csv_write('summary.csv', summary); csv_write('per_seed.csv', per_seed)
    csv_write('directional_counts.csv', directional_counts); csv_write('per_class.csv', per_class)
    csv_write('per_frame_counts.csv', frame_rows); csv_write('paired_cases.csv', paired_cases)
    csv_write('confusion.csv', [{'seed': seed, 'arm': arm, 'truth': t, 'prediction': p,
        'count': int(confusion[s, a, :, t, p].sum())} for s, seed in enumerate(seeds)
        for a, arm in enumerate(arms) for t in range(9) for p in range(9)])
    np.savez_compressed(ROOT / 'ERROR_ARRAYS.npz', truth_topology=truth_topo,
        predicted_topology=predicted_topo, directional_events=events, joint_events=joint_events,
        numerators=num, denominators=den, metric_names=np.array(METRICS),
        confusion=confusion, directional_confusion=dir_confusion,
        bootstrap_scores=draws, source_indices=ids, frames=frames, frame_values=unique_frames,
        labels=labels, predictions=pred, seeds=np.array(seeds), arms=np.array(arms))
    after = {name: sha(SOURCE / name) for name in INPUT_NAMES}
    assert before == after
    unchanged = all(sha(SOURCE / name) == h for name, h in old_files.items())
    assert unchanged
    result = {'status': 'COMPLETE_EXPLORATORY_ANALYSIS', 'date': '2026-10-30',
        'training_performed': False, 'new_test_opened': False, 'test_examples': n,
        'test_frames': unique_frames.tolist(), 'seeds': seeds, 'arms': arms, 'primary_control': 'head9',
        'metrics': {arm: {metric: float(point[a, k]) for k, metric in enumerate(METRICS)}
                    for a, arm in enumerate(arms)},
        'per_seed': per_seed, 'directional_counts': directional_counts,
        'soft_improvement_over_control': comparisons, 'paired_cases': paired_cases,
        'truth_component_histogram': {str(k): int(v) for k, v in zip(*np.unique(truth_topo[:, 0], return_counts=True))},
        'truth_hole_histogram': {str(k): int(v) for k, v in zip(*np.unique(truth_topo[:, 1], return_counts=True))},
        'bootstrap': {'repetitions': len(si), 'indices': 'Exact saved original BOOTSTRAP.npz draws',
            'unit': 'independently resampled frames and seeds, ratios after pooling selected frames',
            'intervals': 'Nominal descriptive 95%; exploratory, no multiplicity correction or new PASS gate'},
        'checks': {**checks, 'all_directional_partitions_exhaustive': True,
            'all_joint_partitions_exhaustive': True, 'all_masks_paths_match_saved_classes': True,
            'all_F1_match_original': True, 'all_confusions_match_original': True,
            'all_original_files_unchanged': unchanged, 'protected_original_files': len(old_files)},
        'input_sha256': before, 'analysis_sha256': sha(Path(__file__)), 'plan_sha256': sha(ROOT / 'PLAN.md'),
        'arrays_sha256': sha(ROOT / 'ERROR_ARRAYS.npz'), 'seconds': time.monotonic() - start,
        'scope': 'Post-hoc analysis of fixed 12x12 SVG-derived geometry classes on one IC, not independent manufacturing defects or proof of causal mechanism.'}
    save('RESULT.json', result)
    save('ORIGINAL_FILES.json', old_files)
    print(json.dumps({'status': result['status'], 'metrics': result['metrics'],
                      'head9_effects': comparisons['head9'], 'seconds': result['seconds']}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
