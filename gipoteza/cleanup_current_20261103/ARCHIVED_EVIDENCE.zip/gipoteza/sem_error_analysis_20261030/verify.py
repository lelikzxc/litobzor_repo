"""Final provenance/link/image checks; does not rewrite research results."""
from pathlib import Path
import hashlib
import json
import re

from PIL import Image

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'sem_confirmation_20261028'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    result = json.loads((ROOT / 'RESULT.json').read_text())
    audit = json.loads((ROOT / 'INDEPENDENT_AUDIT.json').read_text())
    manifest = json.loads((ROOT / 'REPORT_MANIFEST.json').read_text())
    assert result['training_performed'] is False
    assert audit['status'] == 'PASS_INDEPENDENT_ARITHMETIC'
    for name, expected in json.loads((ROOT / 'ORIGINAL_FILES.json').read_text()).items():
        assert sha(SOURCE / name) == expected, name
    for name, expected in audit['main_output_comparison']['main_output_sha256'].items():
        assert sha(ROOT / name) == expected, name
    assert sha(ROOT / 'analyze.py') == result['analysis_sha256']
    assert sha(ROOT / 'PLAN.md') == result['plan_sha256']
    assert sha(ROOT / 'independent_audit.py') == audit['script_sha256']
    assert sha(ROOT / 'report.py') == manifest['code_sha256']
    assert sha(ROOT / 'REPORT.md') == manifest['report_sha256']
    assert sha(ROOT / 'INDEPENDENT_AUDIT.json') == manifest['audit_sha256']
    assert sha(ROOT / 'EXAMPLES.json') == manifest['examples_sha256']
    figures = []
    for name, expected in manifest['figures_sha256'].items():
        path = ROOT / name
        assert sha(path) == expected, name
        if path.suffix == '.png':
            with Image.open(path) as image:
                size = list(image.size)
                image.verify()
            figures.append({'path': name, 'size': size})
    links = []
    for doc in [ROOT / 'README.md', ROOT / 'REPORT.md', ROOT.parent / 'README.md']:
        for link in re.findall(r'\]\(([^)]+)\)', doc.read_text(encoding='utf-8')):
            if '://' in link or link.startswith('#'):
                continue
            target = link.split('#')[0]
            assert (doc.parent / target).exists(), (doc, link)
            links.append({'document': str(doc.relative_to(ROOT.parent)), 'link': link})
    out = {'status': 'PASS_FINAL_VERIFICATION', 'no_training': True,
        'old_files_unchanged': result['checks']['protected_original_files'],
        'independent_metric_points': audit['main_output_comparison']['per_seed_metrics_checked'],
        'independent_metric_max_error': audit['main_output_comparison']['per_seed_metric_max_error'],
        'independent_bootstrap_max_error': audit['main_output_comparison']['bootstrap_max_error'],
        'local_links_checked': len(links), 'pngs_checked': figures,
        'scope': 'All figures additionally inspected visually; original pilot artifacts retained unchanged.',
        'script_sha256': sha(Path(__file__))}
    (ROOT / 'VERIFICATION.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (ROOT / 'PROGRESS.json').write_text(json.dumps({'stage': 'COMPLETE', 'training_performed': False,
        'report': 'REPORT.md', 'verification': 'PASS_FINAL_VERIFICATION'}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    files = {str(p.relative_to(ROOT)): sha(p) for p in sorted(ROOT.rglob('*'))
             if p.is_file() and p.name != 'COMPLETE.json'}
    complete = {'status': 'COMPLETE', 'date': '2026-10-30', 'report': 'REPORT.md',
        'verification': 'VERIFICATION.json', 'file_sha256': files,
        'training_performed': False, 'scope': 'Post-hoc saved-prediction error analysis, not a new confirmatory experiment.'}
    (ROOT / 'COMPLETE.json').write_text(json.dumps(complete, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(out, ensure_ascii=False))


if __name__ == '__main__':
    main()
