"""Build research tables/figures from fixed error-analysis outputs only."""
from pathlib import Path
import csv
import hashlib
import json
import os

os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/sem_errors_mpl_20261030')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'sem_confirmation_20261028'
NAMES = {'base': 'Исходный BCE', 'replay': 'BCE: дообучение',
         'head9': 'Голова: 9 классов', 'head4': 'Голова: 4 цели',
         'soft': 'Наш метод'}
ORDER = ['base', 'replay', 'head9', 'head4', 'soft']
COLORS = {'base': '#8693A5', 'replay': '#A8B2BF', 'head9': '#8064A2',
          'head4': '#C18A36', 'soft': '#087F8C'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fmt(x, places=2, factor=100):
    return f'{factor*x:.{places}f}'.replace('.', ',')


def ci_text(values, factor=100, places=2):
    return '[' + '; '.join(fmt(x, places, factor) for x in values) + ']'


def finish(fig, name):
    for ext in ['png', 'svg']:
        fig.savefig(ROOT / 'figures' / f'{name}.{ext}', dpi=220, bbox_inches='tight')
    plt.close(fig)


def figures(r, arrays):
    (ROOT / 'figures').mkdir(exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
        'axes.spines.top': False, 'axes.spines.right': False, 'svg.fonttype': 'none'})
    metrics = ['false_break_rate', 'false_connection_rate', 'grade_error_per_true_connected']
    titles = ['Потерянный путь', 'Ложный путь', 'Неверная градация при наличии пути']
    notes = ['% эталонных направлений с путём', '% эталонных направлений без пути',
             '% эталонных направлений с путём']
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.9))
    for ax, metric, title, note in zip(axes, metrics, titles, notes):
        for i, arm in enumerate(ORDER):
            point = r['metrics'][arm][metric] * 100
            per_seed = [v[metric] * 100 for v in r['per_seed'] if v['arm'] == arm]
            ax.bar(i, point, color=COLORS[arm], alpha=.75, width=.66)
            ax.scatter(i + np.linspace(-.12, .12, len(per_seed)), per_seed,
                       color=COLORS[arm], edgecolor='white', linewidth=.5, s=24, zorder=3)
            ax.annotate(fmt(r['metrics'][arm][metric]), (i, max(per_seed)),
                        xytext=(0, 6), textcoords='offset points', ha='center', fontsize=9)
        ax.set_title(title, loc='left', fontsize=11, pad=13)
        ax.set_xticks(range(5), ['BCE', 'BCE+', 'Голова 9', 'Голова 4', 'Наш метод'], rotation=30, ha='right')
        ax.set_ylabel(note); ax.set_ylim(0, ax.get_ylim()[1] * 1.13)
        ax.grid(axis='y', alpha=.15); ax.set_axisbelow(True)
    fig.suptitle('Типы ошибок: средние и три отдельных запуска', x=.03, ha='left', fontsize=14, weight='bold')
    fig.text(.03, .025, '16 707 фрагментов восьми кадров одного чипа. Разные знаменатели: столбцы между панелями не складываются.',
             color='#52606D', fontsize=9)
    fig.tight_layout(rect=(0, .07, 1, .93), w_pad=2)
    finish(fig, 'error_types')

    selected = ['false_break_rate', 'false_connection_rate', 'grade_error_per_true_connected',
                'joint_connection_error_rate', 'joint_grade_only_error_rate', 'joint_error_rate']
    labels = ['Потерянный путь', 'Ложный путь', 'Неверная градация направления',
              'Фрагменты с ошибкой наличия пути', 'Фрагменты только с ошибкой градации',
              'Любая ошибка совместного класса']
    fig, axes = plt.subplots(1, 2, figsize=(13.8, 4.9), gridspec_kw={'width_ratios': [1.6, 1]})
    for j, metric in enumerate(selected):
        v = r['soft_improvement_over_control']['head9'][metric]
        lo, hi = np.array(v['CI95']) * 100; point = v['improvement'] * 100
        color = '#087F8C' if lo > 0 else '#9A6724'
        axes[0].plot([lo, hi], [j, j], color=color, linewidth=2)
        axes[0].scatter([point], [j], color=color, s=35, zorder=3)
    axes[0].set_yticks(range(len(selected)), labels)
    axes[0].set_ylim(len(selected)-.5, -.5)
    axes[0].axvline(0, color='#8993A0', linestyle='--', linewidth=1)
    axes[0].set_xlabel('Уменьшение ошибки: голова 9 − наш метод, п.п.')
    axes[0].set_title('Парные разности и номинальные 95%-интервалы', loc='left', fontsize=11, pad=14)
    axes[0].grid(axis='x', alpha=.15)
    for i, arm in enumerate(['head9', 'soft']):
        vals = [v['component_count_mae'] for v in r['per_seed'] if v['arm'] == arm]
        point = r['metrics'][arm]['component_count_mae']
        axes[1].bar(i, point, color=COLORS[arm], alpha=.75, width=.55)
        axes[1].scatter(i + np.linspace(-.1, .1, 3), vals, color=COLORS[arm], edgecolor='white', linewidth=.5, zorder=3)
        axes[1].annotate(fmt(point, 4, 1), (i, max(vals)), xytext=(0, 6),
                         textcoords='offset points', ha='center')
    axes[1].set_xticks([0, 1], ['Голова: 9 классов', 'Наш метод'])
    axes[1].set_ylabel('Средняя абсолютная ошибка числа компонент')
    axes[1].set_title('Геометрический показатель вне порога проводимости', loc='left', fontsize=10, pad=14)
    axes[1].grid(axis='y', alpha=.15); axes[1].set_axisbelow(True)
    axes[1].set_ylim(0, axes[1].get_ylim()[1] * 1.17)
    fig.suptitle('Сравнение с основным контролем', x=.03, ha='left', fontsize=14, weight='bold')
    fig.text(.03, .02, 'Исследовательский анализ открытого TEST. Интервалы без поправки на множественные показатели; один чип.',
             fontsize=9, color='#52606D')
    fig.tight_layout(rect=(0, .06, 1, .93), w_pad=3.5)
    finish(fig, 'paired_error_reduction')

    arms = arrays['arms'].tolist(); conf = arrays['confusion'].sum(2)
    fig, axes = plt.subplots(1, 2, figsize=(12.6, 6.1))
    class_labels = [f'{k}: ({k//3},{k%3})' for k in range(9)]
    for ax, arm in zip(axes, ['head9', 'soft']):
        c = conf[:, arms.index(arm)].sum(0)
        normalized = c / c.sum(1, keepdims=True)
        im = ax.imshow(normalized, vmin=0, vmax=1, cmap='Blues', interpolation='nearest')
        for i in range(9):
            for j in range(9):
                if normalized[i, j] >= .01 or i == j:
                    ax.text(j, i, f'{100*normalized[i,j]:.0f}', ha='center', va='center',
                            color='white' if normalized[i, j] > .55 else '#253746', fontsize=9)
        ax.set_xticks(range(9), range(9)); ax.set_yticks(range(9), class_labels)
        ax.set_title(NAMES[arm], loc='left', pad=10)
        ax.set_xlabel('Предсказанный класс'); ax.set_ylabel('Эталонный класс: (слева–справа, сверху–снизу)')
    fig.subplots_adjust(left=.10, right=.88, bottom=.18, top=.85, wspace=.40)
    cbax = fig.add_axes([.91, .24, .018, .56]); fig.colorbar(im, cax=cbax, label='Доля внутри эталонного класса')
    fig.suptitle('Матрицы ошибок совместного класса', x=.03, ha='left', fontsize=14, weight='bold')
    fig.text(.03, .07, 'Строки нормированы; числа в ячейках — %. Суммированы три запуска на одних и тех же фрагментах.',
             fontsize=9, color='#52606D')
    fig.text(.03, .035, 'Классы 0/1/2 направления: нет пути / меньший / больший модельный отклик. Совместный класс = 3·LR + TB.',
             fontsize=9, color='#52606D')
    finish(fig, 'confusion')


def main():
    r = json.loads((ROOT / 'RESULT.json').read_text())
    audit = json.loads((ROOT / 'INDEPENDENT_AUDIT.json').read_text())
    examples = json.loads((ROOT / 'EXAMPLES.json').read_text())
    assert audit['status'] == 'PASS_INDEPENDENT_ARITHMETIC'
    assert all(sha(SOURCE / k) == v for k, v in r['input_sha256'].items())
    assert sha(ROOT / 'analyze.py') == r['analysis_sha256']
    with np.load(ROOT / 'ERROR_ARRAYS.npz', allow_pickle=False) as arrays:
        assert sha(ROOT / 'ERROR_ARRAYS.npz') == r['arrays_sha256']
        figures(r, arrays)
    primary = 'head9'; effects = r['soft_improvement_over_control'][primary]
    metrics = r['metrics']; c = metrics[primary]; s = metrics['soft']
    metric_specs = [
        ('false_break_rate', 'Потерянный путь / эталонные направления с путём', 100, 2),
        ('false_connection_rate', 'Ложный путь / эталонные направления без пути', 100, 2),
        ('grade_error_per_true_connected', 'Неверная ненулевая градация / эталонные направления с путём', 100, 2),
        ('direction_error_rate', 'Любая ошибка направления / все направления', 100, 2),
        ('joint_connection_error_rate', 'Фрагменты с хотя бы одной ошибкой наличия пути', 100, 2),
        ('joint_grade_only_error_rate', 'Фрагменты только с ошибкой ненулевой градации', 100, 2),
        ('joint_error_rate', 'Любая ошибка совместного класса / фрагменты', 100, 2),
        ('component_count_mae', 'Абсолютная ошибка числа компонент, компонент/фрагмент', 1, 4),
        ('component_count_exact_rate', 'Точное число связных компонент', 100, 2),
        ('hole_count_mae', 'Абсолютная ошибка числа отверстий, отверстий/фрагмент', 1, 5),
    ]
    table = ['| Показатель | Голова 9 | Наш метод | Улучшение | 95%-интервал улучшения |',
             '|---|---:|---:|---:|---|']
    for metric, label, factor, places in metric_specs:
        e = effects[metric]
        unit = ', %' if factor == 100 else ''
        table.append(f'| {label}{unit} | {fmt(c[metric],places,factor)} | {fmt(s[metric],places,factor)} | '
                     f'{fmt(e["improvement"],places,factor)} | {ci_text(e["CI95"],factor,places)} |')
    all_table = ['| Метод | Ошибка направления, % | Ошибка совместного класса, % | Ошибка наличия пути на фрагменте, % | MAE числа компонент |',
                 '|---|---:|---:|---:|---:|']
    for arm in ORDER:
        m = metrics[arm]
        all_table.append(f'| {NAMES[arm]} | {fmt(m["direction_error_rate"])} | {fmt(m["joint_error_rate"])} | '
                         f'{fmt(m["joint_connection_error_rate"])} | {fmt(m["component_count_mae"],4,1)} |')
    paired = [v for v in r['paired_cases'] if v['control'] == primary]
    paired_table = ['| Seed | Контроль ошибся, наш метод верен | Контроль верен, наш метод ошибся | Оба ошиблись | Чистая прибавка верных ответов |',
                    '|---:|---:|---:|---:|---:|']
    for v in paired:
        paired_table.append(f'| {v["seed"]} | {v["soft_repairs_control"]} | {v["soft_regresses_from_control"]} | '
                            f'{v["both_wrong"]} | {v["net_correct_gain"]} |')
    with (ROOT / 'per_class.csv').open(encoding='utf-8-sig') as file:
        rows = list(csv.DictReader(file))
    class_table = ['| Класс (LR, TB) | Фрагментов | F1 головы 9, % | F1 нашего метода, % | Разность, п.п. |',
                   '|---|---:|---:|---:|---:|']
    for cl in range(9):
        cc = [v for v in rows if int(v['class']) == cl and v['arm'] == primary]
        ss = [v for v in rows if int(v['class']) == cl and v['arm'] == 'soft']
        cf = np.mean([float(v['F1']) for v in cc]); sf = np.mean([float(v['F1']) for v in ss])
        class_table.append(f'| {cl} ({cl//3}, {cl%3}) | {cc[0]["support"]} | {fmt(cf)} | {fmt(sf)} | +{fmt(sf-cf)} |')
    seed_table = ['| Seed | Разрывы: голова 9 → наш метод, % | Ложные соединения: голова 9 → наш метод, % |',
                  '|---:|---|---|']
    for seed in r['seeds']:
        hh = next(v for v in r['per_seed'] if v['seed'] == seed and v['arm'] == primary)
        ss = next(v for v in r['per_seed'] if v['seed'] == seed and v['arm'] == 'soft')
        seed_table.append(f'| {seed} | {fmt(hh["false_break_rate"])} → {fmt(ss["false_break_rate"])} | '
                          f'{fmt(hh["false_connection_rate"])} → {fmt(ss["false_connection_rate"])} |')
    reduction = 1 - s['component_count_mae'] / c['component_count_mae']
    share = effects['joint_connection_error_rate']['improvement'] / effects['joint_error_rate']['improvement']
    report = f'''# Какие ошибки сокращает геометрическая регуляризация

30 октября 2026 года. Анализ сохранённых прогнозов опыта от 28 октября.
**Новое обучение не выполнялось.** Все исходные файлы сохранены без изменения.

## Главный результат

По сравнению с основной контрольной головой 9 классов наш метод уменьшил долю
фрагментов с ошибкой наличия пути с **{fmt(c['joint_connection_error_rate'])}% до {fmt(s['joint_connection_error_rate'])}%**.
Средняя абсолютная ошибка числа связных компонент сократилась с
**{fmt(c['component_count_mae'],4,1)} до {fmt(s['component_count_mae'],4,1)}**, на **{fmt(reduction,1)}%** относительно контроля.
Эти наблюдения согласуются с гипотезой о пользе сохранения геометрии.
Они не устанавливают причинный механизм и не заменяют сравнение с другой
специализированной потерей связности.

Данные: {r['test_examples']} уникальных фрагментов 12×12, восемь исходных кадров
одного физического чипа, три seed: {', '.join(map(str,r['seeds']))}.
Итоговый Macro-F1 исходного опыта: **76,34% против 72,97%**, +3,37 п.п.
Новые показатели рассчитаны дополнительно на уже открытом TEST и имеют
исследовательский статус. Основной контроль head9 не переизбирался.

## Определения ошибок

В каждом фрагменте рассматриваются направления слева направо (LR) и сверху
вниз (TB). Четырёхсвязный путь ищется непосредственно в бинарной маске.

- **Разрыв:** эталонный путь есть, предсказанного нет. Знаменатель — все
  эталонные направления с путём: 10 548 на один seed.
- **Ложное соединение:** эталонного пути нет, предсказанный есть. Знаменатель —
  22 866 эталонных направлений без пути на один seed.
- **Ошибка градации:** путь есть в обеих масках, но состояния 1 и 2 отличаются.
  В основной таблице знаменатель — те же 10 548 эталонных направлений с путём.
- **Ошибка наличия пути на фрагменте:** хотя бы одно направление имеет разрыв
  или ложное соединение. Такой фрагмент может дополнительно ошибаться в градации.
- **Только ошибка градации:** наличие пути в обоих направлениях определено верно,
  но хотя бы одна ненулевая градация неверна. Вместе с предыдущей категорией
  исчерпывает все ошибки совместного класса.

«Разрыв» здесь — ошибка граничной связности фрагмента; это не экспертная
разметка физического обрыва. Термины не означают установленный отказ ИС.
Градации вычислены по прежней резисторной модели и порогу; новые пороги не подбирались.

Число компонент считается для четырёхсвязной металлизации. Отверстия —
восьмисвязные компоненты фона, которые не касаются границы. Число компонент
не использует порог проводимости. Оно не определяет всю топологию или точность
маски: разные ошибочные геометрии могут иметь одинаковое число компонент.

## Сравнение с основным контролем

{chr(10).join(table)}

Улучшение для ошибок = «контроль − наш метод», для точного совпадения =
«наш метод − контроль». У долей разность выражена в процентных пунктах,
у абсолютных ошибок — в единицах счётчика на фрагмент.

Интервалы: те же 4000 парных пересэмплирований исходных кадров и seed,
что в исходном опыте. Числители и знаменатели сначала объединяются по выбранным
кадрам, затем рассчитывается показатель каждого выбранного seed и их среднее.
Интервалы номинальные 95%, без поправки на множественные показатели. Новый
критерий PASS не вводится; фрагменты и seed не объявляются независимыми чипами.

![Типы ошибок всех методов](figures/error_types.png)

![Парные уменьшения ошибок и число компонент](figures/paired_error_reduction.png)

**Важная граница вывода:** отдельные интервалы для разрывов и ложных соединений
пересекают ноль. По их средним нельзя утверждать, что каждый тип ошибки устойчиво
сокращается во всех запусках. Совокупная частота ошибок наличия пути и ошибка
числа компонент дают более устойчивый сигнал внутри этого стенда.

{chr(10).join(seed_table)}

У seed 2833 разрывов немного больше у нашего метода; у seed 2801 немного
больше ложных соединений. Эти ухудшения сохранены, а не скрыты усреднением.

## Откуда берётся прибавка правильных классов

Доля неверных совместных классов уменьшилась с {fmt(c['joint_error_rate'])}% до
{fmt(s['joint_error_rate'])}%: разность {fmt(effects['joint_error_rate']['improvement'])} п.п.
Из неё {fmt(effects['joint_connection_error_rate']['improvement'])} п.п. приходится на уменьшение
категории ошибок наличия пути и {fmt(effects['joint_grade_only_error_rate']['improvement'])} п.п. —
на уменьшение категории ошибок только ненулевой градации.
Первая составляет около {fmt(share,1)}% **чистой прибавки точности совместного класса**.
Это арифметическое разложение двух взаимоисключающих категорий, а не
разложение Macro-F1 и не причинная оценка вклада регуляризации.

{chr(10).join(paired_table)}

В каждом запуске исправлений больше, чем ухудшений, однако ухудшения существуют.
Счётчики разных seed относятся к одним и тем же 16 707 фрагментам; их нельзя
представлять как новые независимые наблюдения.

## Все методы и все классы

{chr(10).join(all_table)}

{chr(10).join(class_table)}

Среднее F1 выше у нашего метода во всех девяти классах. Это описательное
наблюдение; для каждого класса отдельно не устанавливался подтверждающий
критерий и не оценивалась семейная ошибка множественных сравнений.

![Матрицы ошибок двух методов](figures/confusion.png)

В матрицах строки нормированы по эталонному классу. Суммирование прогнозов
трёх seed не увеличивает число независимых фрагментов. Числа каждого seed,
класса и кадра сохранены отдельно в CSV и NPZ.

## Примеры без ручного отбора

![Сравнение на одинаковых фрагментах, включая ухудшения](figures/examples.png)

Один фиксированный seed 2833. Для шести категорий примеры выбраны по SHA256
с предпочтением разных кадров, без ручной замены: исправление разрыва,
ложного соединения и градации; ухудшение; общая ошибка; общий успех.
На каждом фрагменте показаны все пять методов. Цвета ошибок относятся
к пикселям; отметка верного класса не означает безошибочную сегментацию.

Слева исходный фрагмент SEM 48×48 пикселей. Модель получала его среднее
по блокам 4×4, то есть 12×12. Вход проверен на точное совпадение с DATA.npz.
Эталон — уже уменьшенная SVG-маска 12×12; потеря детализации исходной
разметки здесь отдельно не измерялась. Примеры иллюстративные и не показывают
частоту ошибок; все кандидаты и выбранные координаты сохранены в EXAMPLES.json.

## Ограничения и значение для гипотезы

1. Метод лучше сохраняет модельную геометрию в этом опыте: реже ошибается
   в наличии граничного пути и в числе компонент. Это содержательнее одной
   прибавки усреднённого F1, но не новая независимая репликация.
2. Считать отдельно разрывы и ложные соединения полезно: улучшения по ним
   неодинаковы между seed, их отдельные интервалы включают ноль.
3. Во всех 16 707 эталонах **нет отверстий**. Поэтому соответствующая метрика
   измеряет только ложное появление отверстий. Проверка сохранения настоящих
   отверстий на этих данных невозможна. Наш метод по этому показателю лучше
   head9, но хуже исходного BCE; универсального сохранения топологии не заявляем.
4. Один чип, очень малая CNN, фрагменты 12×12 и модельные классы по SVG.
   Независимой разметки производственных дефектов и электрических измерений нет.
5. Следующее сравнение: специализированная потеря связности с теми же
   дополнительными классовыми метками и заранее зафиксированный новый тест.
   Текущий разбор не используется для донастройки на старом TEST.

## Воспроизведение и проверки

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 .venv/bin/python -B gipoteza/sem_error_analysis_20261030/analyze.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B gipoteza/sem_error_analysis_20261030/independent_audit.py
PYTHONDONTWRITEBYTECODE=1 MPLCONFIGDIR=/private/tmp/sem_errors_mpl_20261030 .venv/bin/python -B gipoteza/sem_error_analysis_20261030/examples.py
PYTHONDONTWRITEBYTECODE=1 MPLCONFIGDIR=/private/tmp/sem_errors_mpl_20261030 .venv/bin/python -B gipoteza/sem_error_analysis_20261030/report.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B gipoteza/sem_error_analysis_20261030/verify.py
```

CPU достаточно; CUDA/MPS и сеть не нужны. Исходные веса даже не загружаются.
Основной арифметический анализ занял {r['seconds']:.2f} с без построения иллюстраций.

- [План и определения](PLAN.md), [исходный опыт](../sem_confirmation_20261028/REPORT.md).
- [Все числа](RESULT.json), [готовые массивы](ERROR_ARRAYS.npz).
- [Основной код](analyze.py), [независимый алгоритм](independent_audit.py),
  [аудит](INDEPENDENT_AUDIT.json), [выбор примеров](EXAMPLES.json).
- [Средние](summary.csv), [каждый seed](per_seed.csv),
  [счётчики направлений](directional_counts.csv), [классы](per_class.csv),
  [кадры](per_frame_counts.csv), [матрицы ошибок](confusion.csv),
  [парные исправления и ухудшения](paired_cases.csv).
- [Код графиков и отчёта](report.py), [код примеров](examples.py).

Проверены все {r['checks']['protected_original_files']} исходных файлов: SHA не изменились.
Итоговые F1 и матрицы ошибок точно совпадают с исходным опытом. Прямой
поиск пути согласован с классами во всех эталонах и 250 605 предсказанных
масках. Отдельная реализация по каждому фрагменту проверила связные компоненты
и отверстия: все 195 значений метрик совпали точно. Независимая реализация
bootstrap через веса кадров/seed проверила 4000 повторов пяти ключевых метрик;
максимальное расхождение — {audit['main_output_comparison']['bootstrap_max_error']:.2g}.
'''
    (ROOT / 'REPORT.md').write_text(report, encoding='utf-8')
    (ROOT / 'README.md').write_text('''# Разбор ошибок SEM-гипотезы, 30 октября 2026

[Полный отчёт с числами и иллюстрациями](REPORT.md).

Это анализ сохранённых прогнозов опыта от 28 октября, без обучения и изменения
исторических данных. В отчёте приведены исправления и ухудшения, разрывы,
ложные соединения, градации, число компонент, матрицы ошибок и все ограничения.

Скрипты воспроизведения и ссылки на CSV/NPZ приведены в конце отчёта.
Показатели исследовательские: TEST уже был открыт до этого анализа.
''', encoding='utf-8')
    manifest = {'status': 'REPORT_COMPLETE', 'input_analysis_sha256': sha(ROOT / 'RESULT.json'),
        'report_sha256': sha(ROOT / 'REPORT.md'), 'code_sha256': sha(Path(__file__)),
        'audit_sha256': sha(ROOT / 'INDEPENDENT_AUDIT.json'),
        'examples_sha256': sha(ROOT / 'EXAMPLES.json'),
        'figures_sha256': {str(p.relative_to(ROOT)): sha(p) for p in sorted((ROOT/'figures').iterdir())}}
    (ROOT / 'REPORT_MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': manifest['status'], 'report': str(ROOT/'REPORT.md'),
                      'figures': len(manifest['figures_sha256'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()
