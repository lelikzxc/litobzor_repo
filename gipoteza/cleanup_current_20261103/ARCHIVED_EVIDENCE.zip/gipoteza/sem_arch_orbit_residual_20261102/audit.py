"""Independent CPU audit of C4 logit-residual CNN heads.

TRAIN/VAL development only. No fitting or fresh confirmation data access.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import time

import numpy as np
from scipy import linalg, ndimage
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
REPO = G.parent
PILOT = G / 'sem_architecture_pilot_20261102'
_DIRECTION_CACHE = {}
_CLASS_CACHE = {}
ARMS = ['residual_plain', 'residual_joint', 'residual_only']
VARIANTS = ['actual', 'zero', 'roll']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def digest(state):
    h = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()

def macro_f1(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    denominator = confusion.sum(0) + confusion.sum(1)
    return float(np.divide(2 * np.diag(confusion), denominator,
                           out=np.zeros(9, float), where=denominator > 0).mean())

def mean_iou(masks, target):
    union = (masks | target).sum((-2, -1))
    intersection = (masks & target).sum((-2, -1))
    return float(np.divide(intersection, union, out=np.ones(len(union)),
                           where=union > 0).mean())

def direction_class(mask):
    """Independent active-node Cholesky solve of the binary unit-edge graph."""
    mask = np.ascontiguousarray(mask, dtype=bool)
    key = np.packbits(mask).tobytes()
    if key in _DIRECTION_CACHE:
        return _DIRECTION_CACHE[key]
    components, _ = ndimage.label(mask, ndimage.generate_binary_structure(2, 1))
    spanning = np.intersect1d(components[:, 0], components[:, -1])
    spanning = spanning[spanning > 0]
    if not len(spanning):
        answer = 0
    else:
        active = np.isin(components, spanning)
        vertices = np.flatnonzero(active.ravel())
        lookup = np.full(144, -1, dtype=int)
        lookup[vertices] = np.arange(len(vertices))
        laplacian = np.zeros((len(vertices), len(vertices)), dtype=np.float64)
        for vertex in vertices:
            y, x = divmod(int(vertex), 12)
            for yy, xx in [(y + 1, x), (y, x + 1)]:
                if yy < 12 and xx < 12 and active[yy, xx]:
                    a, b = lookup[vertex], lookup[yy * 12 + xx]
                    laplacian[a, a] += 1; laplacian[b, b] += 1
                    laplacian[a, b] -= 1; laplacian[b, a] -= 1
        left = np.flatnonzero(vertices % 12 == 0)
        right = np.flatnonzero(vertices % 12 == 11)
        free = np.setdiff1d(np.arange(len(vertices)), np.r_[left, right])
        potential = np.zeros(len(vertices)); potential[right] = 1
        if len(free):
            potential[free] = linalg.solve(
                laplacian[np.ix_(free, free)],
                -laplacian[np.ix_(free, right)].sum(1), assume_a='pos',
                check_finite=False)
        conductance = float((laplacian[right] @ potential).sum()) / (12 / 11)
        answer = 0 if conductance < 1e-8 else (1 if conductance < .5 - 1e-8 else 2)
    _DIRECTION_CACHE[key] = answer
    return answer

def classify(masks):
    result = []
    for mask in np.asarray(masks, dtype=bool).reshape(-1, 12, 12):
        key = np.packbits(mask).tobytes()
        if key not in _CLASS_CACHE:
            _CLASS_CACHE[key] = 3 * direction_class(mask) + direction_class(mask.T)
        result.append(_CLASS_CACHE[key])
    return np.asarray(result, dtype=np.int64)

def conv(x, state, prefix, padding=0, dilation=1):
    return F.conv2d(x, state[prefix + '.weight'], state[prefix + '.bias'],
                    padding=padding, dilation=dilation)

def independent_backbone(x, state):
    features = x
    for index, dilation in [(0, 1), (2, 2), (4, 4)]:
        features = F.gelu(conv(features, state, str(index), dilation, dilation))
    coarse = conv(features, state, '6')
    return torch.cat((features, coarse, x), 1), coarse

def selected(scores):
    return max(scores, key=lambda row: (row['mask_F1'], row['IoU'],
                -abs(row['threshold'] - .5), -row['threshold']))

def gate(delta_f1, delta_iou, config):
    checks = {
        'mean_F1_gain': float(np.mean(delta_f1)) >= config['minimum_mean_F1_gain'],
        'each_budget_guard': min(delta_f1) >= config['minimum_budget_F1_delta'],
        'mean_IoU_guard': float(np.mean(delta_iou)) >= config['minimum_mean_IoU_delta'],
    }
    return {'passed': all(checks.values()), 'checks': checks,
            'mean_F1_delta': float(np.mean(delta_f1)),
            'budget_F1_deltas': list(map(float, delta_f1)),
            'mean_IoU_delta': float(np.mean(delta_iou))}

def compare_stored_gates(computed, stored):
    """Compare semantic gate outcomes, permitting only historical key spelling."""
    def canonical(value):
        if isinstance(value, dict):
            names = {'delta': 'mean_F1_delta', 'IoU_delta': 'mean_IoU_delta',
                     'budget_deltas': 'budget_F1_deltas', 'budget_F1_guard': 'each_budget_guard'}
            return {names.get(key, key): canonical(item) for key, item in value.items()
                    if key != 'interpretation'}
        if isinstance(value, list):
            return [canonical(item) for item in value]
        return value
    actual, observed = canonical(computed), canonical(stored)
    def compare(left, right):
        if isinstance(left, dict):
            assert set(left) == set(right), (set(left), set(right))
            return max([compare(left[key], right[key]) for key in left] + [0.])
        if isinstance(left, list):
            assert len(left) == len(right)
            return max([compare(a, b) for a, b in zip(left, right)] + [0.])
        if isinstance(left, (bool, str)):
            assert left == right, (left, right)
            return 0.
        return abs(float(left) - float(right))
    return compare(actual, observed)

def normalize_reference(raw):
    value = np.log1p(100 * np.asarray(raw, dtype=np.float64))
    centered = value - value.mean((-2, -1), keepdims=True)
    return centered / np.sqrt((centered * centered).mean((-2, -1), keepdims=True) + 1e-6)

def independent_views(x, backbone):
    features, logits = [], []
    for rotation in range(4):
        transformed = torch.rot90(x, rotation, (-2, -1)).contiguous()
        visual, coarse = independent_backbone(transformed, backbone)
        features.append(torch.rot90(visual[:, :24], -rotation, (-2, -1)))
        logits.append(torch.rot90(coarse, -rotation, (-2, -1)))
    aligned_features = torch.stack(features, 1)
    aligned_logits = torch.stack(logits, 1)
    probabilities = aligned_logits.sigmoid()
    return aligned_features, aligned_logits, probabilities, probabilities.mean(1)

def independent_mixture(aligned_logits, scores=None):
    if scores is None:
        log_weights = torch.full_like(aligned_logits, -np.log(4.))
    else:
        log_weights = scores.log_softmax(1)
    log_probability = torch.logsumexp(log_weights + F.logsigmoid(aligned_logits), 1)
    log_complement = torch.logsumexp(log_weights + F.logsigmoid(-aligned_logits), 1)
    return log_probability - log_complement, log_weights.exp()

def functional_attention(features, logits, mean_probability, sem, maps, head, intervention='actual'):
    if intervention == 'zero':
        maps = torch.zeros_like(maps)
    elif intervention == 'roll':
        maps = torch.roll(maps, (5, 5), (-2, -1))
    batch, views = logits.shape[:2]
    expanded = lambda value: value[:, None].expand(-1, views, -1, -1, -1)
    inputs = torch.cat((features, logits.sigmoid(), expanded(mean_probability), expanded(sem), expanded(maps)), 2)
    flat = inputs.reshape(batch * views, 29, 12, 12)
    score = F.conv2d(F.gelu(F.conv2d(flat, head['0.weight'], head['0.bias'])), head['2.weight'], head['2.bias'])
    score = score.reshape(batch, views, 1, 12, 12)
    output, weights = independent_mixture(logits, score)
    return output, weights, score

def batch_sequence(budget, seed):
    rng = np.random.default_rng(seed + 1000); value = hashlib.sha256()
    for _ in range(500):
        value.update(rng.integers(0, budget, 8).astype(np.int64).tobytes())
        value.update(rng.integers(0, 1152, 8).astype(np.int64).tobytes())
    return value.hexdigest()

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def reference_cache(images, backbone, circuit):
    result = {key: [] for key in ['view_features', 'view_logits', 'uniform_probability', 'x', 'raw_plain', 'maps_plain', 'raw_joint', 'maps_joint']}
    with torch.inference_mode():
        for x in images.split(16):
            features, logits, _, mu = independent_views(x, backbone)
            raw_plain = torch.cat((mu, 4 * mu * (1 - mu)), 1)
            raw_joint = circuit(torch.logit(mu.clamp(.001, .999)), mode='joint')
            values = dict(view_features=features, view_logits=logits, uniform_probability=mu, x=x,
                raw_plain=raw_plain, maps_plain=torch.tensor(normalize_reference(raw_plain.numpy()), dtype=torch.float32),
                raw_joint=raw_joint, maps_joint=torch.tensor(normalize_reference(raw_joint.numpy()), dtype=torch.float32))
            for key, value in values.items():
                result[key].append(value)
    return {key: torch.cat(value) for key, value in result.items()}

def reference_forward(cache, arm, scorer, residual, intervention='actual'):
    mode = 'plain' if arm == 'residual_plain' else 'joint'
    maps = cache['maps_' + mode]
    if intervention == 'zero':
        maps = torch.zeros_like(maps)
    elif intervention == 'roll':
        maps = torch.roll(maps, (5, 5), (-2, -1))
    if scorer is None:
        mixture, weights = independent_mixture(cache['view_logits'])
    else:
        mixture, weights, _ = functional_attention(cache['view_features'], cache['view_logits'],
            cache['uniform_probability'], cache['x'], maps, scorer)
    values = torch.cat((cache['view_features'].mean(1), cache['uniform_probability'], cache['x'], maps), 1)
    psi = F.conv2d(F.gelu(F.conv2d(values, residual['0.weight'], residual['0.bias'])), residual['2.weight'], residual['2.bias'])
    logits = mixture + 4 * psi
    return dict(logits=logits, probability=logits.sigmoid(), weights=weights, mixture_logits=mixture,
                residual=psi, correction=4 * psi, residual_inputs=values)


def recompute_gates(rows, control_rows, config):
    def mean(values, family, budget, arm, metric):
        return float(np.mean([row['selected'][metric] for row in values if row['source_lr'] == family and row['budget'] == budget and row['arm'] == arm]))
    def compare(family, left, right, reference=None):
        right_rows = rows if reference is None else reference
        return gate([mean(rows, family, budget, left, 'mask_F1') - mean(right_rows, family, budget, right, 'mask_F1') for budget in [18, 27]],
                    [mean(rows, family, budget, left, 'IoU') - mean(right_rows, family, budget, right, 'IoU') for budget in [18, 27]], config['gates'])
    architecture = {}
    for arm in ARMS:
        families = {}
        for family in ['high_lr', 'low_lr']:
            comparisons = {'vs_' + name: compare(family, arm, name, control_rows) for name in
                          ['uniform_frozen', 'uniform_adapted', 'single_adapted']}
            comparisons['vs_prior_head'] = compare(family, arm, config['prior_head_control_by_arm'][arm], control_rows)
            comparisons['prior_head_arm'] = config['prior_head_control_by_arm'][arm]
            comparisons['passed'] = all(item['passed'] for item in comparisons.values() if isinstance(item, dict))
            families[family] = comparisons
        architecture[arm] = dict(by_source_lr=families, passed=all(item['passed'] for item in families.values()))
    physics = {}; contribution = {}
    for family in ['high_lr', 'low_lr']:
        item = compare(family, 'residual_joint', 'residual_plain')
        item['joint_architecture_gate'] = architecture['residual_joint']['by_source_lr'][family]['passed']
        item['passed'] &= item['joint_architecture_gate']; physics[family] = item
        contribution[family] = compare(family, 'residual_joint', 'residual_only')
    return dict(A_architecture=architecture, A_any=any(item['passed'] for item in architecture.values()),
        B_physics=dict(by_source_lr=physics, passed=all(item['passed'] for item in physics.values())),
        C_attention_role=dict(by_source_lr=contribution, passed=all(item['passed'] for item in contribution.values())))
def audit_probes(config, model_module, circuit, backbone, images):
    preflight = json.loads((ROOT / 'PREFLIGHT.json').read_text())
    checks = {}; errors = dict(logits=0., probability=0., residual=0., permutation=0.)
    okay = (preflight['status'] == 'PASS_PREFLIGHT' and preflight['optimizer_updates'] == 0 and
        all(sha(ROOT / key) == value for key, value in preflight['source_sha256'].items()))
    initial_residuals = []; initial_scorers = []; gradients = True
    for arm in ARMS:
        net = model_module.make_model(arm, backbone, head_seed=105504)
        prior_arm = 'learned_plain' if arm == 'residual_plain' else 'learned_joint'
        previous = model_module.prior.make_model(prior_arm, backbone, head_seed=105504)
        initial_residuals.append(digest(net.residual.state_dict()))
        if net.scorer is not None:
            initial_scorers.append(digest(net.scorer.state_dict()))
            okay &= all(torch.equal(value, previous.scorer.state_dict()[key]) for key, value in net.scorer.state_dict().items())
        cache = net.precompute(images)
        value = net.forward_cached(cache)
        with torch.no_grad():
            old = previous.forward_cached(cache)
        okay &= torch.equal(value['logits'], old['logits']) and bool(torch.count_nonzero(value['residual']) == 0)
        value['logits'].sum().backward()
        gradients &= (all(parameter.grad is None for parameter in net.backbone.parameters()) and
            bool(net.residual[-1].weight.grad.abs().sum() > 0) and bool(torch.count_nonzero(net.residual[0].weight.grad) == 0))
        with np.load(ROOT / f'TECHNICAL_ACTIVE_{arm}.npz', allow_pickle=False) as archive:
            fixture = {key: archive[key] for key in archive.files}
        okay &= np.array_equal(fixture['x'], images.numpy())
        scorer = {key: torch.tensor(fixture['active_parameter_scorer_' + key.replace('.', '_')]) for key in ['0.weight', '0.bias', '2.weight', '2.bias']} if net.scorer is not None else None
        residual = {key: torch.tensor(fixture['active_parameter_residual_' + key.replace('.', '_')]) for key in ['0.weight', '0.bias', '2.weight', '2.bias']}
        net.residual.load_state_dict(residual)
        if scorer is not None:
            net.scorer.load_state_dict(scorer)
        net.zero_grad(set_to_none=True)
        live = net.forward_cached(cache); live['logits'].sum().backward()
        gradients &= bool(net.residual[0].weight.grad.abs().sum() > 0)
        reference = reference_cache(images, backbone, circuit)
        with torch.inference_mode():
            output = reference_forward(reference, arm, scorer, residual)
        for key in ['logits', 'probability', 'residual']:
            errors[key] = max(errors[key], float(np.max(np.abs(output[key].numpy() - fixture[key]))))
        for k in range(4):
            permuted = {key: value.roll(k, 1) if key in ['view_features', 'view_logits'] else value for key, value in reference.items()}
            with torch.inference_mode():
                p = reference_forward(permuted, arm, scorer, residual)['probability']
            errors['permutation'] = max(errors['permutation'], float((p - output['probability']).abs().max()),
                float(np.max(np.abs(p.numpy() - fixture['view_permuted_probability'][k]))))
        okay &= float(np.max(np.abs(fixture['restored_probability'] - fixture['probability'][None]))) <= 1e-6
    checks['fresh249_prior_scorer_and_identical241_psi_zero_exact_initial_logits'] = bool(okay) and len(set(initial_residuals)) == len(set(initial_scorers)) == 1
    checks['initial_output_gradient_active_hidden_gradient_and_frozen_CNN'] = bool(gradients)
    checks['independent_active490_241_forward_C4_and_permutation_probes'] = errors['logits'] < 1e-5 and errors['probability'] < 1e-6 and errors['residual'] < 1e-5 and errors['permutation'] < 1e-6
    # Construct a fixed consensus error, then use the unbounded residual bias.
    net = model_module.make_model('residual_only', backbone, head_seed=105504).eval()
    synthetic = net.precompute(images)
    synthetic['view_logits'] = torch.full_like(synthetic['view_logits'], -4.)
    synthetic['uniform_probability'] = torch.full_like(synthetic['uniform_probability'], float(torch.sigmoid(torch.tensor(-4.))))
    with torch.no_grad():
        net.residual[-1].bias.fill_(2.)
        changed = net.forward_cached(synthetic)
    source_probability = float(torch.sigmoid(torch.tensor(-4.)))
    checks['unbounded_four_psi_corrects_artificial_unanimous_view_error'] = (
        bool((changed['correction'] == 8).all()) and bool((changed['logits'] - 4).abs().max() < 1e-6) and
        bool(changed['probability'].min() > .98) and bool(changed['probability'].min() > source_probability))
    return checks, errors, dict(source_view_probability=source_probability, residual_bias=2., correction=8., corrected_probability=float(changed['probability'].min()))
def audit_trial(folder):
    started = time.monotonic()
    read = lambda name: json.loads((folder / name).read_text())
    result, frozen, config, snapshot = (read(name) for name in ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json', 'CONTROL_SNAPSHOT.json'])
    before = {str(path): sha(path) for path in [folder / 'RESULT.json', folder / 'FROZEN.json', folder / 'CONTROL_SNAPSHOT.json',
        folder / 'CONFIG_SNAPSHOT.json', folder / 'PROTOCOL.md', ROOT / 'model.py', ROOT / 'runner.py', PILOT / 'TRAIN_VAL.npz']}
    checks = {}
    checks['frozen_old_TRAIN_VAL_scope_protocol_configuration_and_all_sources'] = (
        result['status'] == 'COMPLETE_DEVELOPMENT_TRIAL' and result['scope'] == 'OldTRAIN_VALonly; nofreshTESTorlossinnovation' and
        frozen['fresh_confirmation_access'] is False and sha(folder / 'FROZEN.json') == result['frozen_sha256'] and
        sha(folder / 'PROTOCOL.md') == config['protocol_sha256'] == frozen['protocol_sha256'] and
        sha(folder / 'CONFIG_SNAPSHOT.json') == frozen['config_sha256'] and
        all(sha(ROOT / key) == value for key, value in frozen['source_sha256'].items()) and
        all(sha(folder / 'source' / key) == frozen['source_sha256'][key] for key in ['model.py', 'runner.py']))
    checks['fixed_three_head_arms_common81_thresholds_optimizer_and_strict_gates'] = (
        config['candidate'] == 'orbit_pointwise_residual' and config['fitted_arms'] == config['evaluation_arms'] == ARMS and
        config['source_lr'] == ['high_lr', 'low_lr'] and config['budgets'] == [18, 27] and config['subset_seed'] == 5303 and
        config['screen_seeds'] == [5501] and config['replication_seeds'] == [5501, 5521, 5557] and
        config['steps'] == 500 and config['batch_size'] == 8 and config['head_learning_rate'] == .0005 and config['weight_decay'] == .0001 and
        config['physics_weight'] == 1 and config['residual_scale'] == 4 and config['epsilon'] == .001 and
        config['normalization_scale'] == 100 and config['normalization_variance_floor'] == 1e-6 and
        config['thresholds'] == [round(.1 + .01 * i, 2) for i in range(81)] and config['equivariance_tolerance'] == 1e-6 and
        config['prior_head_control_by_arm'] == dict(residual_plain='learned_plain', residual_joint='learned_joint', residual_only='learned_joint') and
        config['gates'] == dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025, minimum_mean_IoU_delta=-.002))
    tree = ast.parse((folder / 'source' / 'runner.py').read_text())
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    source = ast.unparse(tree); fit = ast.unparse(functions['fit'])
    previous_runner_path = G / 'sem_arch_learned_orbit_20261102/runner.py'
    previous_tree = ast.parse(previous_runner_path.read_text())
    inputs = next(node for node in previous_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'inputs')
    checks['source_imported_TRAIN_VAL_inputs_only_no_weak_masks_or_closed_confirmation'] = (
        "np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False)" in ast.unparse(inputs) and "if role != 'weak':" in ast.unparse(inputs) and
        not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and
                node.func.value.id == 'np' and node.func.attr == 'load' for node in ast.walk(tree)) and
        'r.inputs(c, seeds' in source)
    checks['source_exact_old_BCE_geometry_loss_frozen_backbone_all_new_heads500steps'] = (
        "bce = F.binary_cross_entropy_with_logits(dense, values['dense']['mask'][ai])" in fit and
        'geometry = r.physics.geometry_loss(weak, torch.stack((labels // 3, labels % 3), dim=1))' in fit and
        "loss = bce + c['physics_weight'] * geometry" in fit and 'params = [p for p in model.parameters() if p.requires_grad]' in fit and
        'all((p.grad is None for p in model.backbone.parameters()))' in fit and
        "torch.optim.AdamW(params, lr=c['head_learning_rate'], weight_decay=c['weight_decay'])" in fit)
    model_source = ast.unparse(ast.parse((folder / 'source' / 'model.py').read_text()))
    checks['source_241_pointwise_residual_unbounded_plus4_without_tanh'] = (
        'nn.Conv2d(28, 8, 1)' in model_source and 'nn.Conv2d(8, 1, 1)' in model_source and
        'correction = 4 * psi' in model_source and 'logits = mixture_logits + correction' in model_source and
        '.tanh(' not in model_source and "self.backbone.requires_grad_(False)" in model_source)
    lineage = frozen['lineage']; subsets = json.loads((PILOT / 'SUBSETS.json').read_text())
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    val = np.flatnonzero(data['role'] == 'val'); images = torch.tensor(5 * (data['X'][val] - .2))
    truth, target = data['label'][val], data['Y'][val, 0].astype(bool)
    checks['unchanged_TRAIN_VAL_nested_balanced_subsets_roles_and_independent_truth'] = (
        sha(PILOT / 'TRAIN_VAL.npz') == lineage['TRAIN_VAL_sha256'] == subsets['train_val_sha256'] and
        sha(PILOT / 'SUBSETS.json') == lineage['subsets_sha256'] and sha(PILOT / 'INITIAL_LINEAGE.json') == lineage['initial_lineage_sha256'] and
        {role: int(np.sum(data['role'] == role)) for role in set(data['role'])} == {'dense': 54, 'weak': 1152, 'val': 695} and
        set(data['frame'][val]) == {6, 7} and set(subsets['dense_indices']['18']).issubset(subsets['dense_indices']['27']) and
        all(np.array_equal(np.bincount(data['label'][subsets['dense_indices'][str(b)]], minlength=9), np.full(9, b // 9)) for b in [18, 27]) and
        np.array_equal(classify(target), truth))
    seeds = [5501] if result['phase'] == 'screen' else [5521, 5557]
    refs, rows, controls = frozen['sources'], result['rows'], result['controls']
    units = {(family, budget, seed) for family in ['high_lr', 'low_lr'] for budget in [18, 27] for seed in seeds}
    control_arms = ['uniform_frozen', 'uniform_adapted', 'single_adapted', 'learned_plain', 'learned_joint']
    checks['exact_new_fit_and_reused_control_grids_no_refit_or_seed_double_count'] = (
        result['seeds'] == frozen['seeds'] == seeds and refs == frozen['sources'] and len(refs) == len(units) and
        {(ref['source_lr'], ref['budget'], ref['seed']) for ref in refs} == units and len(rows) == 3 * len(units) and
        {(r['source_lr'], r['budget'], r['seed'], r['arm']) for r in rows} == {(*u, arm) for u in units for arm in ARMS} and
        result['fitted_models'] == frozen['fitted_models'] == 3 * len(units) and result['updates'] == frozen['total_updates'] == 1500 * len(units) and
        result['evaluation_rows'] == frozen['evaluation_rows'] == len(rows) and result['reused_control_rows'] == frozen['reused_control_rows'] == 5 * len(units) and
        len(controls) == 5 * len(units) and {(r['source_lr'], r['budget'], r['seed'], r['arm']) for r in controls} == {(*u, arm) for u in units for arm in control_arms} and
        snapshot == dict(rows=controls, sources=result['control_sources']) and result['control_sources'] == frozen['control_sources'])
    control_ok = True; control_metric_error = 0.; controls_recomputed = []
    for row in controls:
        reference = row['control_ref']
        for key, path in reference.items():
            if key.endswith('_file'):
                control_ok &= sha(REPO / path) == reference[key[:-5] + '_sha256']
                before[str(REPO / path)] = sha(REPO / path)
        old_result = json.loads((REPO / reference['result_file']).read_text())
        old_audit = json.loads((REPO / reference['audit_file']).read_text())
        original = next(item for item in old_result['rows'] if (item['source_lr'], item['budget'], item['seed'], item['arm']) ==
                        (row['source_lr'], row['budget'], row['seed'], row['arm']))
        control_ok &= (old_audit['status'] == 'PASS_AUDIT' and all(old_audit['checks'].values()) and
            old_audit['result_sha256'] == sha(REPO / reference['result_file']) and row['reused'] and
            {key: value for key, value in row.items() if key not in ['reused', 'control_ref']} == original)
        with np.load(REPO / reference['val_probability_file'], allow_pickle=False) as archive:
            p = archive['probability'][0, :, 0]
            control_ok &= np.array_equal(archive['truth'], truth) and np.array_equal(archive['target'], target)
        masks = p >= row['selected']['threshold']; prediction = classify(masks)
        chosen = dict(threshold=row['selected']['threshold'], mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target))
        for key, value in chosen.items():
            control_metric_error = max(control_metric_error, abs(value - row['selected'][key]))
        controls_recomputed.append(dict(source_lr=row['source_lr'], budget=row['budget'], seed=row['seed'], arm=row['arm'], selected=chosen))
    checks['all_five_prior_controls_exact_immutable_audited_500step_artifacts_and_metrics'] = bool(control_ok) and control_metric_error < 2e-7
    checks['new_checkpoint_file_hashes'] = len(result['checkpoint_hashes']) == len(rows) and all(sha(folder / 'models' / name) == value for name, value in result['checkpoint_hashes'].items())
    states = {}; source_ok = True; probe_state = None
    for ref in refs:
        key = ref['source_lr'], ref['budget'], ref['seed']
        for file_key, hash_key in [('checkpoint_file', 'checkpoint_sha256'), ('control_result_file', 'control_result_sha256'),
                                  ('source_audit_file', 'source_audit_sha256'), ('config_snapshot_file', 'config_snapshot_sha256')]:
            source_ok &= sha(REPO / ref[file_key]) == ref[hash_key]
        states[key] = torch.load(REPO / ref['checkpoint_file'], map_location='cpu', weights_only=True)['model']
        source_ok &= digest(states[key]) == ref['backbone_state_sha256']
        if probe_state is None and ref['source_lr'] == 'high_lr':
            path = REPO / ref['control_result_file']; old = json.loads(path.read_text()); checkpoint = path.parent / 'models/base_b18_s5501.pt'
            source_ok &= sha(checkpoint) == old['checkpoint_hashes'][checkpoint.name]
            probe_state = torch.load(checkpoint, map_location='cpu', weights_only=True)['model']
    checks['all_source_CNN_checkpoints_unchanged_from_fair_source_families'] = bool(source_ok)
    model_module = load_module('orbit_residual_independent_audit_model', ROOT / 'model.py')
    circuit = load_module('orbit_residual_fixed_circuit', PILOT / 'circuit.py').CircuitMaps(epsilon=.001)
    probe_ids = subsets['dense_indices']['18'][:2]
    probe_checks, probe_errors, witness = audit_probes(config, model_module, circuit, probe_state,
        torch.tensor(5 * (data['X'][probe_ids] - .2)))
    checks.update(probe_checks)
    errors = dict(logits=0., probability=0., sigma_probability=0., metrics=0., cache_features=0., raw_maps=0., normalization=0.,
                  fixture=0., residual=0., correction=0., permutation=0.)
    metadata_ok = counts_ok = frozen_ok = initial_ok = batches_ok = cache_ok = predictions_ok = selection_ok = technical_ok = True
    recomputed = []
    for ref in refs:
        family, budget, seed = ref['source_lr'], ref['budget'], ref['seed']; backbone_source = states[family, budget, seed]
        cache = reference_cache(images, backbone_source, circuit)
        for arm in ARMS:
            row = next(r for r in rows if (r['source_lr'], r['budget'], r['seed'], r['arm']) == (family, budget, seed, arm))
            stem = f'{family}_b{budget}_s{seed}_{arm}'; payload = torch.load(folder / 'models' / f'{stem}.pt', map_location='cpu', weights_only=True)
            weights = payload['model']; backbone = {key[9:]: value for key, value in weights.items() if key.startswith('backbone.')}
            scorer = {key[7:]: value for key, value in weights.items() if key.startswith('scorer.')} if arm != 'residual_only' else None
            residual = {key[9:]: value for key, value in weights.items() if key.startswith('residual.')}
            head_state = {key: value for key, value in weights.items() if not key.startswith('backbone.')}
            count = 241 if arm == 'residual_only' else 490
            metadata_ok &= (payload['settings'] == row and row['source'] == ref and row['steps'] == row['optimizer_updates'] == 500 and row['fit_count'] == 1 and
                row['trainable_parameters'] == count and row['learning_rate'] == .0005 and row['weight_decay'] == .0001 and
                row['optimizer_group'] == 'allnewheads' and row['CNN_passes_per_image'] == 4)
            counts_ok &= (row['parameters'] == dict(backbone=10681, scorer=0 if arm == 'residual_only' else 249, residual=241, trainable=count, total=10681 + count) and
                sum(value.numel() for value in weights.values()) == 10681 + count and sum(value.numel() for value in residual.values()) == 241 and
                all(torch.isfinite(value).all().item() for value in weights.values()))
            frozen_ok &= (row['backbone_before_sha256'] == row['backbone_after_sha256'] == ref['backbone_state_sha256'] == digest(backbone) and
                all(torch.equal(value, backbone_source[key]) for key, value in backbone.items()))
            initial = model_module.make_model(arm, backbone_source, head_seed=seed + 100003)
            initial_head = {key: value for key, value in initial.named_parameters() if value.requires_grad}
            initial_ok &= (digest(initial_head) == row['head_initial_sha256'] and digest(head_state) == row['head_final_sha256'] != row['head_initial_sha256'] and
                digest(initial.residual.state_dict()) == row['residual_initial_sha256'] and digest(residual) == row['residual_final_sha256'] != row['residual_initial_sha256'])
            if scorer is not None:
                prior_control = next(r for r in controls if r['source_lr'] == family and r['budget'] == budget and r['seed'] == seed and r['arm'] == config['prior_head_control_by_arm'][arm])
                initial_ok &= (digest(initial.scorer.state_dict()) == row['scorer_initial_sha256'] == prior_control['head_initial_sha256'] and
                    digest(scorer) == row['scorer_final_sha256'])
            else:
                initial_ok &= row['scorer_initial_sha256'] is None and row['scorer_final_sha256'] is None
            batches_ok &= row['batch_sequence_sha256'] == batch_sequence(budget, seed) == ref['source_batch_sequence_sha256']
            meta = row['cache']; expected_indices = dict(dense=subsets['dense_indices'][str(budget)], weak=np.flatnonzero(data['role'] == 'weak').tolist(), val=val.tolist())
            cache_ok &= (meta['ephemeral'] and not meta['persisted'] and meta['image_only'] and meta['bytes'] == 63360 * (budget + 1152 + 695) and
                meta['bytes'] <= meta['maximum_bytes'] == 120 * 1024 ** 2 and meta['indices'] == expected_indices and
                meta['TRAIN_VAL_sha256'] == sha(PILOT / 'TRAIN_VAL.npz') and meta['backbone_state_sha256'] == ref['backbone_state_sha256'] and
                meta['model_sha256'] == sha(ROOT / 'model.py') and meta['prior_cache_builder_model_sha256'] == sha(G / 'sem_arch_learned_orbit_20261102/model.py'))
            with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
                arrays = {key: archive[key] for key in archive.files}
            metadata_ok &= (arrays['variants'].tolist() == VARIANTS and arrays['thresholds'].tolist() == config['thresholds'] and
                np.array_equal(arrays['truth'], truth) and np.array_equal(arrays['target'], target) and
                arrays['probability'].shape == arrays['logits'].shape == (3, 695, 1, 12, 12) and
                np.isfinite(arrays['probability']).all() and np.isfinite(arrays['logits']).all() and arrays['probability'].min() >= 0 and arrays['probability'].max() <= 1)
            errors['sigma_probability'] = max(errors['sigma_probability'], float(np.max(np.abs(torch.tensor(arrays['logits']).sigmoid().numpy() - arrays['probability']))))
            for vi, variant in enumerate(VARIANTS):
                with torch.inference_mode():
                    output = reference_forward(cache, arm, scorer, residual, variant)
                errors['logits'] = max(errors['logits'], float(np.max(np.abs(output['logits'].numpy() - arrays['logits'][vi]))))
                errors['probability'] = max(errors['probability'], float(np.max(np.abs(output['probability'].numpy() - arrays['probability'][vi]))))
                metric_rows = []
                for ti, threshold in enumerate(config['thresholds']):
                    masks = arrays['probability'][vi, :, 0] >= threshold; prediction = classify(masks)
                    predictions_ok &= np.array_equal(prediction, arrays['predictions'][vi, ti])
                    predictions_ok &= np.array_equal(np.packbits(masks.reshape(695, 144), axis=1), arrays['packed_masks'][vi, ti])
                    metrics = dict(threshold=threshold, mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target)); metric_rows.append(metrics)
                    for key, value in metrics.items():
                        errors['metrics'] = max(errors['metrics'], abs(value - row['VAL_scores_all_thresholds'][variant][ti][key]))
                if variant == 'actual':
                    chosen = selected(metric_rows); selection_ok &= chosen['threshold'] == float(arrays['selected_threshold'])
                    for key, value in chosen.items():
                        errors['metrics'] = max(errors['metrics'], abs(value - row['selected'][key]))
                    selected_index = config['thresholds'].index(chosen['threshold'])
                ablation = dict(**metric_rows[selected_index], mask_flip_fraction=float(np.mean(
                    (arrays['probability'][vi] >= chosen['threshold']) != (arrays['probability'][0] >= chosen['threshold']))))
                for key, value in ablation.items():
                    errors['metrics'] = max(errors['metrics'], abs(value - row['ablations'][variant][key]))
            with np.load(folder / 'fixtures' / f'{stem}.npz', allow_pickle=False) as archive:
                fixture = {key: archive[key] for key in archive.files}
            technical_ok &= np.array_equal(fixture['x'], images[:16].numpy()) and row['C4_equivariance_required']
            errors['fixture'] = max(errors['fixture'], float(np.max(np.abs(fixture['probability'] - arrays['probability'][0, :16]))))
            restored = np.stack([np.rot90(fixture['transformed_probability'][k], -k, (-2, -1)) for k in range(4)])
            eq = float(np.max(np.abs(restored - fixture['probability'][None])))
            technical_ok &= eq <= 1e-6 and abs(eq - row['C4_equivariance_max_error']) < 1e-10
            errors['fixture'] = max(errors['fixture'], float(np.max(np.abs(restored - fixture['restored_probability']))))
            with torch.inference_mode():
                values = reference_forward({key: value[:16] for key, value in cache.items()}, arm, scorer, residual)
            for key in ['mixture_logits', 'residual', 'correction', 'residual_inputs']:
                error = float(np.max(np.abs(values[key].numpy() - fixture[key])))
                if key in ['residual', 'correction']:
                    errors[key] = max(errors[key], error)
                else:
                    errors['cache_features'] = max(errors['cache_features'], error)
            errors['correction'] = max(errors['correction'], float(np.max(np.abs(fixture['correction'] - 4 * fixture['residual']))),
                float(np.max(np.abs(fixture['logits'] - fixture['mixture_logits'] - fixture['correction']))))
            for key in ['view_features', 'view_logits', 'uniform_probability']:
                expected = cache[key][:16]
                if key in ['view_features', 'view_logits']:
                    expected = expected.permute(1, 0, 2, 3, 4)
                errors['cache_features'] = max(errors['cache_features'], float(np.max(np.abs(expected.numpy() - fixture[key]))))
            for mode in ['plain', 'joint']:
                errors['raw_maps'] = max(errors['raw_maps'], float(np.max(np.abs(cache['raw_' + mode][:16].numpy() - fixture['raw_' + mode]))))
                errors['normalization'] = max(errors['normalization'], float(np.max(np.abs(normalize_reference(fixture['raw_' + mode]) - fixture['maps_' + mode]))))
            recomputed.append(dict(source_lr=family, budget=budget, seed=seed, arm=arm, selected=chosen))
    checks.update(all_model_metadata_frozen_CNNs_and_490_or241_counts=bool(metadata_ok and counts_ok and frozen_ok),
        fresh_zero_initializations_and_same_psi_with_no_warm_start=bool(initial_ok),
        all500_batch_sequences_and_old_source_pairing=bool(batches_ok), ephemeral_label_free_cache_provenance=bool(cache_ok),
        full_independent_stable_mixture_plus_unbounded4psi_forward=errors['logits'] < 1e-4 and errors['probability'] < 1e-5,
        sigmoid_logits_and_finite_probability_range=errors['sigma_probability'] < 3e-7,
        all81_threshold_classes_masks_metrics_and_fixed_actual_interventions=bool(predictions_ok and selection_ok) and errors['metrics'] < 2e-7,
        all_C4_fixtures_source_features_and_map_normalization=bool(technical_ok) and errors['fixture'] < 1e-5 and errors['cache_features'] < 1e-4 and errors['raw_maps'] < 1e-4 and errors['normalization'] < 1e-5,
        exact241_residual_and_four_times_unbounded_correction=errors['residual'] < 1e-4 and errors['correction'] < 1e-4)
    paired = True
    for unit in units:
        group = [r for r in rows if (r['source_lr'], r['budget'], r['seed']) == unit]
        paired &= len({r['residual_initial_sha256'] for r in group}) == 1 and len({r['scorer_initial_sha256'] for r in group if r['arm'] != 'residual_only'}) == 1 and len({r['batch_sequence_sha256'] for r in group}) == 1
    checks['identical_psi_initialization_all3_scorer_both_and_paired_batches'] = bool(paired)
    gates = recompute_gates(recomputed, controls_recomputed, config)
    checks['four_control_A_physical_B_and_optional_attention_C_recomputed'] = compare_stored_gates(gates, result['gates']) < 2e-7
    replication = {}
    if result['phase'] == 'replicate':
        aggregate = read('AGGREGATE_RESULT.json'); previous = ROOT / aggregate['source_trials'][0]
        old = json.loads((previous / 'RESULT.json').read_text()); old_audit = json.loads((previous / 'AUDIT.json').read_text())
        checks['valid_screen_and_exact_three_seed_aggregation_without_double_count'] = (
            old_audit['status'] == 'PASS_AUDIT' and old_audit['result_sha256'] == sha(previous / 'RESULT.json') and old['seeds'] == [5501] and old['gates']['A_any'] and
            aggregate['rows'] == old['rows'] + rows and aggregate['controls'] == old['controls'] + controls and aggregate['seeds'] == [5501, 5521, 5557])
        all_gates = recompute_gates(old['rows'] + recomputed, old['controls'] + controls_recomputed, config)
        robust = {arm: gates['A_architecture'][arm]['passed'] and all_gates['A_architecture'][arm]['passed'] for arm in ARMS}
        checks['new_two_all_three_and_robust_architecture_gates_recomputed'] = (
            compare_stored_gates(all_gates, aggregate['gates']) < 2e-7 and compare_stored_gates(gates, aggregate['new_seed_gates']) < 2e-7 and
            aggregate['robust_architecture_by_arm'] == robust and aggregate['robust_architecture_pass'] == any(robust.values()))
        replication = dict(new_two_seeds=gates, all_three_seeds=all_gates)
    checks['all_source_control_data_artifacts_unchanged_by_audit'] = all(sha(path) == value for path, value in before.items())
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT', scope='INDEPENDENT_CPU_RESIDUAL_C4_OLD_TRAIN_VAL_DEVELOPMENT_ONLY',
        trial=str(folder.relative_to(ROOT)), audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks), maximum_errors=errors,
        active_probe_errors=probe_errors, artificial_consensus_error_witness=witness, independent_gates=gates, replication=replication,
        seconds=time.monotonic() - started, caveat='Closed C4 confirmation data were not accessed. Reused VAL gates do not establish new-test superiority or publication novelty.')


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--trial', type=Path); args = parser.parse_args()
    folders = [args.trial if args.trial.is_absolute() else ROOT / args.trial] if args.trial else sorted(path.parent for path in (ROOT / 'trials').glob('*/RESULT.json'))
    assert folders, 'No completed development trial'
    torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        for folder in folders:
            output = folder / 'AUDIT.json'
            if output.exists():
                old = json.loads(output.read_text()); assert old['result_sha256'] == sha(folder / 'RESULT.json')
                if old['audit_source_sha256'] == sha(__file__):
                    outcome = old
                else:
                    archive = folder / f"AUDIT_PREVIOUS_{old['audit_source_sha256'][:12]}.json"; assert not archive.exists(); output.rename(archive)
                    outcome = audit_trial(folder)
            else:
                outcome = audit_trial(folder)
            if not output.exists():
                output.write_text(json.dumps(outcome, indent=2, ensure_ascii=False, default=lambda value: value.item()) + '\n')
            print(json.dumps({key: outcome[key] for key in ['status', 'trial', 'checks_passed', 'checks_total', 'maximum_errors', 'active_probe_errors',
                  'artificial_consensus_error_witness', 'independent_gates', 'replication', 'seconds']}, ensure_ascii=False, default=lambda value: value.item()), flush=True)
            assert outcome['status'] == 'PASS_AUDIT'


if __name__ == '__main__':
    main()
