"""Report saved residual-orbit CNN trials and immutable reused controls."""
from pathlib import Path
import datetime
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PRIOR = ROOT.parent / "sem_arch_learned_orbit_20261102"
HELPER = ROOT.parent / "sem_arch_joint_adaptation_20261102" / "report.py"
spec = importlib.util.spec_from_file_location("residual_orbit_report_helpers", HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
read, sha, rel = helpers.read, helpers.sha, helpers.rel
discover, actual_rows, views = helpers.discover, helpers.actual_rows, helpers.views
mean, pct, pp, passed = helpers.mean, helpers.percent, helpers.pp, helpers.passed
plt, np = helpers.plt, helpers.np
ARMS = ["residual_plain", "residual_joint", "residual_only"]
CONTROLS = ["uniform_frozen", "uniform_adapted", "single_adapted", "learned_plain", "learned_joint"]
A_KEYS = ["vs_uniform_frozen", "vs_uniform_adapted", "vs_single_adapted", "vs_prior_head"]
FAMILIES = ["high_lr", "low_lr"]


def verify(result):
    units = {(row["source_lr"], row["budget"], row["seed"]) for row in result["rows"]}
    rows = {(row["source_lr"], row["budget"], row["seed"], row["arm"]): row for row in result["rows"]}
    controls = {(row["source_lr"], row["budget"], row["seed"], row["arm"]): row for row in result["controls"]}
    assert len(rows) == len(result["rows"]) == 3 * len(units)
    assert len(controls) == len(result["controls"]) == 5 * len(units)
    for key in units:
        paired = [rows[key + (arm,)] for arm in ARMS]
        old = [controls[key + (arm,)] for arm in CONTROLS]
        source = paired[0]["source"]
        assert all(row["source"] == source for row in paired + old)
        assert len({row["batch_sequence_sha256"] for row in paired}) == 1
        assert paired[0]["batch_sequence_sha256"] == source["source_batch_sequence_sha256"]
        assert len({row["residual_initial_sha256"] for row in paired}) == 1
        assert len({row["scorer_initial_sha256"] for row in paired if row["arm"] != "residual_only"}) == 1
        for row in paired:
            size = 241 if row["arm"] == "residual_only" else 490
            assert row["fit_count"] == 1 and row["steps"] == row["optimizer_updates"] == 500
            assert row["trainable_parameters"] == row["parameters"]["trainable"] == size
            assert row["parameters"]["total"] == 10681 + size
            assert row["backbone_before_sha256"] == row["backbone_after_sha256"] == source["backbone_state_sha256"]
            assert row["head_initial_sha256"] != row["head_final_sha256"]
            assert row["residual_initial_sha256"] != row["residual_final_sha256"]
            assert row["CNN_passes_per_image"] == 4
        for row in old:
            assert row["reused"] is True
            if row["fit_count"]:
                assert row["batch_sequence_sha256"] == paired[0]["batch_sequence_sha256"]
            for field, path in row["control_ref"].items():
                if field.endswith("_file"):
                    assert sha(REPO / path) == row["control_ref"][field[:-5] + "_sha256"]


def figure(result_views):
    if not result_views:
        return None
    path = ROOT / "figures" / "residual_orbit_validation.png"
    path.parent.mkdir(exist_ok=True)
    points = [(label, family, result) for label, result in result_views for family in FAMILIES]
    x = np.arange(len(points));fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for offset, arm, color in [(-.18, "residual_plain", "#3c78a8"),
                               (0, "residual_joint", "#b25a43"), (.18, "residual_only", "#8d6cab")]:
        values = [100 * min(result["gates"]["A_architecture"][arm]["by_source_lr"][family][key]["delta"] for key in A_KEYS)
                  for _, family, result in points]
        axes[0].scatter(x + offset, values, color=color, s=50, label=arm)
    axes[0].set_title("A: smallest mean gain across the four controls")
    axes[0].set_ylabel("Minimum Macro-F1 gain, percentage points")
    axes[0].legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.16))
    for offset, key, label, color, marker in [(-.1, "B_physics", "B joint − plain", "#4d8d63", "D"),
                                             (.1, "C_attention_role", "C joint − residual-only", "#8d6cab", "s")]:
        values = [100 * result["gates"][key]["by_source_lr"][family]["delta"] for _, family, result in points]
        axes[1].scatter(x + offset, values, color=color, marker=marker, label=label, s=50)
    axes[1].set_title("B: maps; C: capacity-changing view-module ablation")
    axes[1].set_ylabel("Macro-F1 difference, percentage points")
    axes[1].legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.16))
    for axis in axes:
        axis.axhline(0, color="black", lw=.8)
        axis.axhline(.5, color="gray", ls="--", lw=.8)
        axis.set_xticks(x, [f"{label}\n{family}" for label, family, _ in points])
        axis.set_xlim(-.6, len(points) - .4)
    fig.suptitle("Residual CNN heads on reused VAL; dashed line = +0.5 pp mean-gain gate", fontsize=11)
    fig.tight_layout();fig.savefig(path, dpi=180, bbox_inches="tight");plt.close(fig)
    return path


def build():
    config = read(ROOT / "CONFIG.json")
    trials = discover(ROOT)
    complete = [trial for trial in trials if trial["result"]]
    failures = [trial for trial in trials if trial["failure"]]
    pending = [trial for trial in trials if not trial["result"] and not trial["failure"]]
    rows = actual_rows(trials)
    fits = sum(row["fit_count"] for row in rows);updates = sum(row["optimizer_updates"] for row in rows)
    prior_manifest = read(PRIOR / "REPORT_MANIFEST.json")
    prior_fits = prior_manifest["linked_stage_unique_completed_fits"]
    known_control_checkpoints = set()
    for name in prior_manifest["scientific_inputs_sha256"]:
        if name.startswith("trials/") and name.endswith("/RESULT.json"):
            path = PRIOR / name
            known_control_checkpoints.update((path.parent / "models" / checkpoint).resolve()
                                            for checkpoint in read(path).get("checkpoint_hashes", {}))
    referenced_checkpoints = {(REPO / row["control_ref"]["checkpoint_file"]).resolve()
                              for trial in complete for row in trial["result"]["controls"]
                              if "checkpoint_file" in row["control_ref"]}
    extra_control_checkpoints = referenced_checkpoints - known_control_checkpoints
    local_control_fits = sum(path.is_relative_to(ROOT) for path in extra_control_checkpoints)
    unique_fits = prior_fits + fits + len(extra_control_checkpoints)
    result_views = [("screen" if result.get("phase") == "screen" else label, result)
                    for label, result in views(trials)]
    for trial in complete:
        assert trial["result"]["frozen_sha256"] == sha(trial["path"] / "FROZEN.json")
        assert trial["frozen"]["fresh_confirmation_access"] is False
        verify(trial["result"])
        assert trial["result"]["fitted_models"] == sum(row["fit_count"] for row in trial["result"]["rows"])
        if trial["aggregate"]:
            verify(trial["aggregate"])
    output_figure = figure(result_views)
    text = ["# CNN-поправка к согласованному объединению четырёх видов", "",
            "К общему scorer четырёх видов добавлена обучаемая точечная ветвь "
            "`Conv1×1(28→8), GELU, Conv1×1(8→1)` с **241 параметром**. Её вход — средние 24 признака "
            "согласованных CNN-видов, равномерная вероятность, SEM и две условные карты. "
            "Итог: `z_final = z_weighted_mixture + 4·ψ`. Поправка не ограничена tanh, поэтому итоговая "
            "вероятность может выходить за диапазон четырёх исходных ответов. Это снимает ограничение "
            "одного выпуклого выбора видов; полезность на данных проверяется отдельно.", "",
            "Residual_plain/joint обучают 249 параметров view-scorer и 241 параметр ψ: **490**, "
            "всего **11 171** с замороженной CNN 10 681. Residual_only использует равномерные веса "
            "и ψ с физическими картами: **241** обучаемый параметр, всего **10 922**. "
            "Это абляция модуля выбора видов с изменением числа параметров. C не является сравнением "
            "одинаковой ёмкости. Plain/joint совпадают по архитектуре и числу параметров.", "",
            "249-параметровый scorer инициализирован заново точно как в прежнем этапе, "
            "без warm-start обученной головы. Последний слой ψ нулевой; одинаковая ψ у всех трёх вариантов "
            "сохраняет начальный равномерный C4 с точностью численной арифметики. "
            "Plain использует обычные карты, joint/only — DtN-карты из равномерного C4. "
            "Карты отделены от градиента, нормировка log1p100/центрирование/RMS прежняя. "
            "На предсказании нужны четыре прохода исходной CNN и новые малые головы.", "",
            "## Обучения и неизменные контроли", "",
            f"Локальных попыток {len(trials)}; завершено {len(complete)}; технических ошибок {len(failures)}; "
            f"незавершённых {len(pending)}. Новых обучений голов **{fits}**, обновлений {updates:,}. "
            f"Предыдущие {prior_fits} уникальных обучений сохранены; дополнительно обученных контрольных "
            f"моделей вне прежнего отчёта {len(extra_control_checkpoints)}. Уникальных обучений вместе: **{unique_fits}**. "
            "Сводные результаты и ссылки на прежние контроли повторно не считаются.", "",
            "Все новые головы получают 500 шагов AdamW, lr=0,0005, weight_decay=0,0001, "
            "8 dense + 8 weak; общий RNG(seed+1000). Прежние TRAIN/VAL, бюджеты 18/27, розыгрыш 5303, "
            "1152 weak и 695 VAL. Лосс прежний: BCE итоговой маски и geometry_loss с весом 1. "
            "Новой штрафной функции нет; weak-маски оптимизатору не передаются. "
            "Только замороженные источники используют временный кеш признаков.", "",
            "## Раздельные критерии A/B/C", "",
            "A каждого варианта требует выигрыша над **каждым из четырёх** контролей: uniform_frozen, "
            "uniform_adapted, single_adapted и соответствующей обученной 249-параметровой головой. "
            "Для residual_plain это learned_plain, для joint/only — learned_joint. "
            "Контроли используют те же источники CNN и точные пары (source_lr, бюджет, seed); "
            "их результат, аудит, конфигурация, checkpoint и VAL-вероятности связаны SHA. "
            "Общие батчи и 500 шагов проверены. Контроли здесь не переучиваются.", "",
            "Требования каждого сравнения: средний ΔMacro-F1 ≥0,5 п.п., ΔF1 каждого бюджета ≥−0,25 п.п., "
            "средний ΔIoU ≥−0,2 п.п.; отдельно для high_lr и low_lr. A требует обеих семей. "
            "B сравнивает residual_joint с residual_plain и требует A joint. "
            "C сравнивает residual_joint с residual_only; он отделён от A и меняет также ёмкость головы. "
            "Все выходы и сохранённые контроли калибруются по одной 81-точечной сетке 0,10…0,90, "
            "шаг 0,01; F1, IoU, близость к 0,5, меньший порог. "
            "Для расширения публикуются все три и новые два seed отдельно, и нужны оба результата.", ""]
    if result_views:
        text += ["| Набор seed | Семья | Residual plain F1, % | Residual joint F1, % | Residual-only F1, % | A plain / joint / only | B | C |",
                 "|---|---|---:|---:|---:|---|---|---|"]
        for label, result in result_views:
            for family in FAMILIES:
                selected = [row for row in result["rows"] if row["source_lr"] == family]
                values = " | ".join(pct(mean(selected, arm)) for arm in ARMS)
                gates = result["gates"]
                outcomes = " / ".join(passed(gates["A_architecture"][arm]["by_source_lr"][family]["passed"]) for arm in ARMS)
                text.append(f"| {label}: {result['seeds']} | {family} | {values} | {outcomes} | "
                            f"{passed(gates['B_physics']['by_source_lr'][family]['passed'])} | "
                            f"{passed(gates['C_attention_role']['by_source_lr'][family]['passed'])} |")
            text += ["", "Совместно обе семьи: " + "; ".join(f"A {arm} **{passed(result['gates']['A_architecture'][arm]['passed'])}**" for arm in ARMS) +
                     f"; B **{passed(result['gates']['B_physics']['passed'])}**; C **{passed(result['gates']['C_attention_role']['passed'])}**.", "",
                     "| Набор seed | Семья | Frozen C4 F1, % | C4-adapted F1, % | Single-adapted F1, % | Learned plain249 F1, % | Learned joint249 F1, % |",
                     "|---|---|---:|---:|---:|---:|---:|"]
            for family in FAMILIES:
                selected = [row for row in result["controls"] if row["source_lr"] == family]
                text.append(f"| {label}: {result['seeds']} | {family} | " + " | ".join(pct(mean(selected, arm)) for arm in CONTROLS) + " |")
            text.append("")
    else:
        text += ["Завершённого результата ещё нет; вывод о критериях A/B/C не сделан.", ""]
    if output_figure:
        text += ["![Минимальные архитектурные приросты и отдельные B/C](figures/residual_orbit_validation.png)", "",
                 "Слева показан наименьший средний ΔF1 из четырёх сравнений каждого варианта; "
                 "это необходимая часть A. Все ограничения по бюджетам/IoU и отдельные сравнения приведены ниже. "
                 "Точечные результаты относятся к повторно используемой VAL; независимые интервалы не строятся.", ""]
    text += ["## Все сохранённые попытки", ""]
    for trial in trials:
        path = trial["path"]
        text += [f"### {path.name}", "", f"[FROZEN.json]({rel(path / 'FROZEN.json', ROOT)}).", ""]
        if not trial["result"]:
            if trial["failure"]:
                error = trial["failure"]
                text += [f"Техническая ошибка `{error.get('error_type', 'см. файл')}`: "
                         f"{str(error.get('error', '')).replace(chr(10), ' ')}. "
                         f"[FAILURE.json]({rel(path / 'FAILURE.json', ROOT)}). Она не является "
                         "отрицательным научным исходом архитектуры.", ""]
            else:
                text += ["Попытка начата, итоговый RESULT.json ещё не сохранён.", ""]
            text += [f"Сохранённых обучений: {len(trial['partial'])}.", ""]
            continue
        result = trial["result"]
        text += [f"`{result['status']}`; {result['phase']}; seed {result['seeds']}; "
                 f"обучений {result['fitted_models']}, обновлений {result['updates']:,}; "
                 f"новых оценочных строк {result['evaluation_rows']}, повторно используемых контрольных строк "
                 f"{result['reused_control_rows']}; {result['seconds']:.2f} с. "
                 f"[RESULT.json]({rel(path / 'RESULT.json', ROOT)}), SHA-256 `{sha(path / 'RESULT.json')}`.", "",
                 "| Семья | Бюджет | Seed | Вариант | Обучаемых параметров | Порог | F1, % | IoU, % | Zero ΔF1, п.п. | Roll ΔF1, п.п. |",
                 "|---|---:|---:|---|---:|---:|---:|---:|---:|---:|"]
        for row in result["rows"]:
            selected = row["selected"];ablations = row["ablations"]
            text.append(f"| {row['source_lr']} | {row['budget']} | {row['seed']} | {row['arm']} | {row['trainable_parameters']} | "
                        f"{selected['threshold']:.2f} | {pct(selected['mask_F1'])} | {pct(selected['IoU'])} | "
                        f"{pp(ablations['zero']['mask_F1'] - selected['mask_F1'])} | {pp(ablations['roll']['mask_F1'] - selected['mask_F1'])} |")
        text.append("")
        gate_results = [("только эта попытка", result)]
        if trial["aggregate"]:
            gate_results.append(("все три seed", trial["aggregate"]))
            text += [f"[AGGREGATE_RESULT.json]({rel(path / 'AGGREGATE_RESULT.json', ROOT)}) "
                     "объединяет исходный скрининг и новые seed; обучений не добавляет.", ""]
        for label, item in gate_results:
            text += [f"**{label}: {item['seeds']}**", "",
                     "| Семья | Сравнение | ΔF1, п.п. | ΔIoU, п.п. | ΔF1 бюджеты 18 / 27, п.п. | Критерий |",
                     "|---|---|---:|---:|---|---|"]
            for family in FAMILIES:
                comparisons = []
                for arm in ARMS:
                    gates = item["gates"]["A_architecture"][arm]["by_source_lr"][family]
                    comparisons += [(f"A {arm} − {control}", gates[f"vs_{control}"])
                                    for control in ["uniform_frozen", "uniform_adapted", "single_adapted"]]
                    comparisons.append((f"A {arm} − prior {gates['prior_head_arm']}", gates["vs_prior_head"]))
                comparisons += [("B joint − plain, с A joint", item["gates"]["B_physics"]["by_source_lr"][family]),
                                ("C joint − residual_only", item["gates"]["C_attention_role"]["by_source_lr"][family])]
                for name, gate in comparisons:
                    text.append(f"| {family} | {name} | {pp(gate['delta'])} | {pp(gate['IoU_delta'])} | "
                                f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
            text.append("")
        if trial["aggregate"]:
            aggregate = trial["aggregate"]
            robust = {arm: aggregate["gates"]["A_architecture"][arm]["passed"] and result["gates"]["A_architecture"][arm]["passed"] for arm in ARMS}
            text += ["Одновременно все три и новые два seed: " + "; ".join(f"A {arm} {passed(robust[arm])}" for arm in ARMS) + "; " +
                     "; ".join(f"{name} {passed(aggregate['gates'][key]['passed'] and result['gates'][key]['passed'])}"
                               for name, key in [("B", "B_physics"), ("C", "C_attention_role")]) + ".", ""]
        audit = trial["audit"]
        text += [(f"Независимый CPU-аудит: `{audit.get('status', 'см. файл')}`, "
                  f"{audit.get('checks_passed', 'см. файл')} / {audit.get('checks_total', 'см. файл')}. "
                  f"[AUDIT.json]({rel(path / 'AUDIT.json', ROOT)})." if audit else "Итоговый аудит ещё не сохранён."), ""]
        if audit and audit.get("numerical_note"):
            text += [f"Примечание аудита: {audit['numerical_note']}", ""]
        for old_path in sorted(path.glob("AUDIT_PREVIOUS_*.json")):
            text += [f"Предыдущая техническая проверка [{old_path.name}]({rel(old_path, ROOT)}): "
                     f"`{read(old_path).get('status', 'см. файл')}`. Исходные обучения сохранены.", ""]
    text += ["## Пределы вывода и сохранность поиска", "",
             "Только прежняя TRAIN/VAL, без новых независимых результатов этого блока. Технический PASS "
             "проверяет реализацию и сохранённые числа; A/B/C проверяют пользу. Zero/roll при actual-пороге "
             "показывают чувствительность к картам, которая сама по себе не устанавливает их полезность. "
             "При B FAIL добавочная польза физических карт не установлена по заданному критерию. "
             "C меняет число параметров и не является доказательством при одинаковой ёмкости.", "",
             f"[Предыдущий обучаемый scorer, его A/B/D и все отрицательные результаты]({rel(PRIOR / 'REPORT.md', ROOT)}). "
             "Этот отчёт также сохраняет ссылку на отдельный FAIL_PILOT равномерного C4 на восьми новых полях "
             "той же ИС. Он остаётся исходом прежней модели, а не подтверждением нового residual-блока. "
             "Для выбранного нового блока потребуется отдельная закрытая проверка. "
             "Известные residual/attention/C4-принципы не объявляются новым открытием; "
             "перенос между изделиями и пригодность для Q1 не установлены.", "",
             "[PROTOCOL.md](PROTOCOL.md) · [CONFIG.json](CONFIG.json) · [LEDGER.json](LEDGER.json) · "
             "[model.py](model.py) · [runner.py](runner.py) · [audit.py](audit.py).", ""]
    (ROOT / "REPORT.md").write_text("\n".join(text))
    (ROOT / "README.md").write_text(
        "# Обучаемая CNN-поправка C4\n\n"
        "Residual_plain/joint490 и residual_only241 добавляют241-параметровую CNN-поправку к логиту C4. "
        "Исходная CNN заморожена, прежний BCE+geometry_loss общий. A требует выигрыша над4сохранёнными "
        "контролями в обеих LR-семьях; B проверяет карты, C — абляцию выбора видов с разной ёмкостью.\n\n"
        f"Завершено попыток {len(complete)}, технических ошибок {len(failures)}, новых обучений голов {fits}; "
        f"уникальных обучений с прежними {unique_fits}. Контроли повторно не считаются. "
        "Только старая TRAIN/VAL; независимого подтверждения нового блока нет.\n\n"
        "[Отчёт со всеми попытками](REPORT.md) · [Протокол](PROTOCOL.md) · [Конфигурация](CONFIG.json) · [Журнал](LEDGER.json).\n\n"
        "Пересоздать только отчёт и рисунок:\n\n"
        "```bash\n.venv/bin/python -B gipoteza/sem_arch_orbit_residual_20261102/report.py\n```\n")
    inputs = [HELPER, PRIOR / "REPORT_MANIFEST.json", PRIOR / "REPORT.md"]
    inputs += [ROOT / name for name in ["CONFIG.json", "PROTOCOL.md", "LEDGER.json"] if (ROOT / name).exists()]
    for trial in trials:
        inputs += [trial["path"] / name for name in ["FROZEN.json", "RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json",
                   "PARTIAL_RESULTS.json", "AUDIT.json", "CONFIG_SNAPSHOT.json", "CONTROL_SNAPSHOT.json"] if (trial["path"] / name).exists()]
        inputs += sorted(trial["path"].glob("AUDIT_PREVIOUS_*.json"))
    for trial in complete:
        for row in trial["result"]["controls"]:
            inputs += [REPO / path for key, path in row["control_ref"].items() if key.endswith("_file")]
    outputs = [ROOT / "REPORT.md", ROOT / "README.md"] + ([output_figure] if output_figure else [])
    manifest = dict(status="REPORT_GENERATED", UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope="ADAPTIVE_OLD_TRAIN_VAL_RESIDUAL_ORBIT_CNN", report_script_sha256=sha(Path(__file__)),
        shared_report_helper_sha256=sha(HELPER), trial_count=len(trials), completed_trials=len(complete),
        failed_trials=len(failures), pending_trials=len(pending), new_head_fits=fits,
        actual_completed_fits=fits + local_control_fits, completed_head_updates=updates,
        prior_unique_completed_fits=prior_fits, extra_control_fits_outside_prior_report=len(extra_control_checkpoints),
        local_extra_control_fits=local_control_fits, linked_stage_unique_completed_fits=unique_fits,
        evaluation_rows=len(rows), reused_controls_recounted=False, matching_unit=["source_lr", "budget", "seed"],
        scientific_inputs_sha256={rel(path, ROOT): sha(path) for path in inputs},
        outputs_sha256={rel(path, ROOT): sha(path) for path in outputs})
    (ROOT / "REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
