"""Append-only241-parameter residual-module development on old TRAIN/VAL.

The previous stage's fitted controls are immutable comparison artifacts. New
heads start fresh, receive500updates, and never access fresh confirmation data.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import time
import traceback

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "0"
import numpy as np
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits
from model import (EVALUATION_ARMS, FITTED_ARMS, VARIANTS, VIEW_FIELDS,
                   architecture_spec, make_model, prior, slice_cache, state_digest)

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PREVIOUS = ROOT.parent / "sem_arch_learned_orbit_20261102"
FAMILIES = ["high_lr", "low_lr"]
CONTROL_ARMS = ["uniform_frozen", "uniform_adapted", "single_adapted", "learned_plain", "learned_joint"]
START = None


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


old_binding = sys.modules.get("model")
sys.modules["model"] = prior
try:
    r = module("residual_prior_readonly_utilities", PREVIOUS / "runner.py")
finally:
    if old_binding is None:
        del sys.modules["model"]
    else:
        sys.modules["model"] = old_binding


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    r.save(path, value)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def resolve(path):
    path = Path(path)
    return path if path.is_absolute() else REPO / path


def configuration(path):
    c = json.loads(path.read_text())
    assert c["candidate"] == "orbit_pointwise_residual"
    assert c["fitted_arms"] == FITTED_ARMS and c["evaluation_arms"] == EVALUATION_ARMS
    assert c["budgets"] == [18, 27] and c["screen_seeds"] == [5501]
    assert c["replication_seeds"] == [5501, 5521, 5557] and c["subset_seed"] == 5303
    assert c["steps"] == 500 and c["batch_size"] == 8 and c["head_learning_rate"] == .0005
    assert c["weight_decay"] == .0001 and c["physics_weight"] == 1.
    assert c["epsilon"] == .001 and c["normalization_scale"] == 100. and c["normalization_variance_floor"] == 1e-6
    assert c["equivariance_tolerance"] == 1e-6
    assert c["thresholds"] == [round(.10 + .01 * i, 2) for i in range(81)]
    assert c["gates"] == dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025, minimum_mean_IoU_delta=-.002)
    assert c["prior_head_control_by_arm"] == dict(residual_plain="learned_plain", residual_joint="learned_joint", residual_only="learned_joint")
    assert c["protocol_sha256"] == sha(ROOT / "PROTOCOL.md")
    return c


def source_hashes():
    result = {"model.py": sha(ROOT / "model.py"), "runner.py": sha(ROOT / "runner.py")}
    for name, value in r.source_hashes().items():
        path = (PREVIOUS / name).resolve()
        result[os.path.relpath(path, ROOT)] = value
    return result


def append_ledger(event):
    with (ROOT / ".ledger.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        path = ROOT / "LEDGER.json"
        ledger = json.loads(path.read_text()) if path.exists() else dict(version=1, scope="ADAPTIVE_OLD_TRAIN_VAL_ONLY", events=[])
        ledger["events"].append(dict(event, index=len(ledger["events"]), UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        save(path, ledger); fcntl.flock(lock, fcntl.LOCK_UN)


def make(c, arm, state, seed, device):
    return make_model(arm, state, head_seed=seed + 100003, epsilon=c["epsilon"],
        scale=c["normalization_scale"], norm_floor=c["normalization_variance_floor"]).to(device)


def controls(c, seeds, refs):
    rows, source_files = [], []
    for name in c["prior_stage7_results"] + c.get("prior_stage7_additional_results", []):
        path = resolve(name); result = json.loads(path.read_text())
        assert result["status"] == "COMPLETE_DEVELOPMENT_TRIAL"
        audit_path = path.parent / "AUDIT.json"
        assert json.loads(audit_path.read_text())["status"] == "PASS_AUDIT"
        config_path = path.parent / "CONFIG_SNAPSHOT.json"
        old = json.loads(config_path.read_text())
        for key in ["steps", "batch_size", "head_learning_rate", "weight_decay", "physics_weight", "thresholds", "subset_seed", "budgets"]:
            assert old[key] == c[key], key
        assert old["backbone_learning_rate"] == .0001
        for row in result["rows"]:
            if row["seed"] not in seeds or row["arm"] not in CONTROL_ARMS:
                continue
            ref = next(ref for ref in refs if (ref["source_lr"], ref["budget"], ref["seed"]) ==
                       (row["source_lr"], row["budget"], row["seed"]))
            assert row["source"] == ref
            filename = f'{row["source_lr"]}_b{row["budget"]}_s{row["seed"]}_{row["arm"]}'
            probability_path = path.parent / "val_probs" / f"{filename}.npz"
            control_ref = dict(result_file=str(path.relative_to(REPO)), result_sha256=sha(path),
                audit_file=str(audit_path.relative_to(REPO)), audit_sha256=sha(audit_path),
                config_file=str(config_path.relative_to(REPO)), config_sha256=sha(config_path),
                val_probability_file=str(probability_path.relative_to(REPO)), val_probability_sha256=sha(probability_path))
            if row["fit_count"]:
                checkpoint = path.parent / "models" / f"{filename}.pt"
                assert sha(checkpoint) == result["checkpoint_hashes"][checkpoint.name]
                assert row["steps"] == 500 and row["batch_sequence_sha256"] == ref["source_batch_sequence_sha256"]
                control_ref.update(checkpoint_file=str(checkpoint.relative_to(REPO)), checkpoint_sha256=sha(checkpoint))
            rows.append(dict(row, control_ref=control_ref, reused=True))
        source_files.append(dict(result_file=str(path.relative_to(REPO)), result_sha256=sha(path),
                                 audit_file=str(audit_path.relative_to(REPO)), audit_sha256=sha(audit_path)))
    expected = {(ref["source_lr"], ref["budget"], ref["seed"], arm) for ref in refs for arm in CONTROL_ARMS}
    actual = {(row["source_lr"], row["budget"], row["seed"], row["arm"]) for row in rows}
    assert len(rows) == len(actual) and actual == expected, "Missing or repeated matched prior controls; generate before replication"
    return rows, source_files


def fitted_head_digest(model):
    return state_digest({name: p for name, p in model.named_parameters() if p.requires_grad})


def fit(c, model, values, cache, reference, trial, counter):
    before = state_digest(model.backbone.state_dict()); head_before = fitted_head_digest(model)
    residual_before = state_digest(model.residual.state_dict())
    scorer_before = state_digest(model.scorer.state_dict()) if model.scorer is not None else None
    params = [p for p in model.parameters() if p.requires_grad]
    assert sum(p.numel() for p in params) == (241 if model.arm == "residual_only" else 490)
    optimizer = torch.optim.AdamW(params, lr=c["head_learning_rate"], weight_decay=c["weight_decay"])
    rng = np.random.default_rng(reference["seed"] + 1000); batches = hashlib.sha256()
    model.train(); started = time.monotonic()
    for step in range(1, c["steps"] + 1):
        ai = rng.integers(0, len(values["dense"]["x"]), c["batch_size"])
        wi = rng.integers(0, len(values["weak"]["x"]), c["batch_size"])
        batches.update(ai.astype(np.int64).tobytes()); batches.update(wi.astype(np.int64).tobytes())
        ai, wi = torch.tensor(ai, device="mps"), torch.tensor(wi, device="mps")
        optimizer.zero_grad(set_to_none=True)
        batch = r.concat_cache([slice_cache(cache["dense"], ai), slice_cache(cache["weak"], wi)])
        result = model.forward_cached(batch); dense, weak = result["logits"].split(c["batch_size"])
        bce = F.binary_cross_entropy_with_logits(dense, values["dense"]["mask"][ai])
        labels = values["weak"]["label"][wi]
        geometry = r.physics.geometry_loss(weak, torch.stack((labels // 3, labels % 3), dim=1))
        loss = bce + c["physics_weight"] * geometry
        assert torch.isfinite(loss); loss.backward()
        assert all(p.grad is None for p in model.backbone.parameters())
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in params)
        assert any(float(p.grad.abs().sum()) > 0 for p in params)
        optimizer.step(); counter[0] += 1
        if step % 100 == 0:
            row = dict(stage="ORBIT_RESIDUAL_OLD_TRAIN_VAL", trial=trial.name, source_lr=reference["source_lr"],
                budget=reference["budget"], seed=reference["seed"], arm=model.arm, step=step, target_steps=500,
                completed_updates=counter[0], dense_BCE=float(bce.detach().cpu()), geometry_loss=float(geometry.detach().cpu()),
                total_loss=float(loss.detach().cpu()), seconds=time.monotonic() - START)
            save(trial / "PROGRESS.json", row); save(ROOT / "PROGRESS.json", row)
            with (trial / "progress.jsonl").open("a") as handle: handle.write(json.dumps(row) + "\n")
            print(json.dumps(row), flush=True)
    torch.mps.synchronize()
    after = state_digest(model.backbone.state_dict()); head_after = fitted_head_digest(model)
    assert before == after and head_before != head_after
    assert state_digest(model.residual.state_dict()) != residual_before
    assert batches.hexdigest() == reference["source_batch_sequence_sha256"]
    return dict(steps=500, optimizer_updates=500, fit_count=1, trainable_parameters=sum(p.numel() for p in params),
        learning_rate=c["head_learning_rate"], weight_decay=c["weight_decay"], optimizer_group="allnewheads",
        backbone_before_sha256=before, backbone_after_sha256=after, head_initial_sha256=head_before, head_final_sha256=head_after,
        scorer_initial_sha256=scorer_before, scorer_final_sha256=state_digest(model.scorer.state_dict()) if model.scorer is not None else None,
        residual_initial_sha256=residual_before, residual_final_sha256=state_digest(model.residual.state_dict()),
        batch_sequence_sha256=batches.hexdigest(), seconds=time.monotonic() - started)


def evaluate(c, model, values, cache):
    model.eval(); outputs, logits = [], []
    with torch.no_grad():
        for variant in VARIANTS:
            ps, zs = [], []
            for start in range(0, len(values["x"]), 16):
                result = model.forward_cached(slice_cache(cache, slice(start, start + 16)), variant)
                ps.append(result["probability"].cpu().numpy()); zs.append(result["logits"].cpu().numpy())
            outputs.append(np.concatenate(ps)); logits.append(np.concatenate(zs))
    probability = np.array(outputs)
    target = dict(truth=values["label"].cpu().numpy(), target=values["mask"][:, 0].cpu().numpy().astype(bool))
    evaluations, arrays = [], []
    for p in probability:
        e, a = r.orbit.score(p, target, c["thresholds"]); evaluations.append(e); arrays.append(a)
    selected = evaluations[0]["selected"]; ti = c["thresholds"].index(selected["threshold"])
    ablations = {variant: dict(**evaluations[i]["VAL_scores_all_thresholds"][ti],
        mask_flip_fraction=float(np.mean((probability[i] >= selected["threshold"]) != (probability[0] >= selected["threshold"]))))
        for i, variant in enumerate(VARIANTS)}
    return dict(selected=selected, ablations=ablations, VAL_scores_all_thresholds={v: e["VAL_scores_all_thresholds"]
        for v, e in zip(VARIANTS, evaluations)}), dict(probability=probability, logits=np.array(logits),
        truth=target["truth"], target=target["target"], thresholds=np.array(c["thresholds"]), variants=np.array(VARIANTS),
        predictions=np.array([a["predictions"] for a in arrays]), packed_masks=np.array([a["packed_masks"] for a in arrays]),
        selected_threshold=np.array(selected["threshold"]))


def fixture(c, model, x, cache):
    arrays, technical = r.technical_fixture(c, model, x, cache)
    with torch.no_grad():
        result = model.forward_details(x)
        arrays.update({key: result[key].cpu().numpy() for key in ["mixture_logits", "residual", "correction", "residual_inputs"]})
    return arrays, technical


def comparisons(rows, control_rows, c):
    all_rows = rows + control_rows
    arms = FITTED_ARMS + CONTROL_ARMS
    means = {lr: {b: {arm: {metric: float(np.mean([row["selected"][metric] for row in all_rows
        if row["source_lr"] == lr and row["budget"] == b and row["arm"] == arm])) for metric in ["mask_F1", "IoU"]}
        for arm in arms} for b in c["budgets"]} for lr in FAMILIES}
    def compare(lr, left, right):
        f1 = [means[lr][b][left]["mask_F1"] - means[lr][b][right]["mask_F1"] for b in c["budgets"]]
        iou = float(np.mean([means[lr][b][left]["IoU"] - means[lr][b][right]["IoU"] for b in c["budgets"]]))
        gain = float(np.mean(f1)); limits = c["gates"]
        checks = dict(mean_F1_gain=gain >= limits["minimum_mean_F1_gain"], budget_F1_guard=min(f1) >= limits["minimum_budget_F1_delta"],
                      mean_IoU_guard=iou >= limits["minimum_mean_IoU_delta"])
        return dict(delta=gain, IoU_delta=iou, budget_deltas=f1, checks=checks, passed=all(checks.values()))
    architecture = {}
    for arm in FITTED_ARMS:
        family = {}
        for lr in FAMILIES:
            results = {"vs_" + control: compare(lr, arm, control) for control in ["uniform_frozen", "uniform_adapted", "single_adapted"]}
            results["vs_prior_head"] = compare(lr, arm, c["prior_head_control_by_arm"][arm])
            results["prior_head_arm"] = c["prior_head_control_by_arm"][arm]
            results["passed"] = all(value["passed"] for value in results.values() if isinstance(value, dict))
            family[lr] = results
        architecture[arm] = dict(by_source_lr=family, passed=all(value["passed"] for value in family.values()))
    physical = {}
    for lr in FAMILIES:
        result = compare(lr, "residual_joint", "residual_plain")
        result["joint_architecture_gate"] = architecture["residual_joint"]["by_source_lr"][lr]["passed"]
        result["passed"] = bool(result["passed"] and result["joint_architecture_gate"]); physical[lr] = result
    attention = {lr: compare(lr, "residual_joint", "residual_only") for lr in FAMILIES}
    return dict(A_architecture=architecture, A_any=any(value["passed"] for value in architecture.values()),
        B_physics=dict(by_source_lr=physical, passed=all(value["passed"] for value in physical.values())),
        C_attention_role=dict(by_source_lr=attention, passed=all(value["passed"] for value in attention.values())),
        interpretation="ReusedTRAIN_VAL; A needs4matched controls inbothLR; optionalC is not requiredforA"), means


def signature(c):
    return digest(dict(configuration={key: value for key, value in c.items() if key != "prior_stage7_additional_results"},
        source_sha256=source_hashes(), TRAIN_VAL_sha256=sha(r.PILOT / "TRAIN_VAL.npz")))


def previous_screen(expected):
    found = []
    for path in (ROOT / "trials").glob("*/RESULT.json"):
        result = json.loads(path.read_text())
        if result["phase"] == "screen" and result["signature"] == expected and result["status"] == "COMPLETE_DEVELOPMENT_TRIAL": found.append((path, result))
    assert len(found) == 1 and found[0][1]["gates"]["A_any"], "Replication needs exactlyone compatible passingA screen"
    return found[0]


def preflight(c):
    data, refs, states, lineage = r.inputs(c, [5501], "cpu")
    baseline, baseline_sources = controls(c, [5501], refs)
    ref = next(ref for ref in refs if ref["source_lr"] == "high_lr" and ref["budget"] == 18)
    state = states["high_lr", 18, 5501]; x = data[18]["dense"]["x"][:2]
    initial_scorers, initial_residuals, evidence = [], [], []
    for arm in FITTED_ARMS:
        model = make(c, arm, state, 5501, "cpu")
        old = prior.make_model("learned_plain" if arm == "residual_plain" else "learned_joint", state,
            head_seed=105504, epsilon=c["epsilon"], scale=c["normalization_scale"], norm_floor=c["normalization_variance_floor"])
        cache = model.precompute(x); result = model.forward_cached(cache)
        old_result = old.forward_cached(cache)
        assert torch.count_nonzero(result["residual"]) == 0
        assert torch.equal(result["logits"], old_result["logits"])
        if model.scorer is not None:
            assert state_digest(model.scorer.state_dict()) == state_digest(old.scorer.state_dict())
            initial_scorers.append(state_digest(model.scorer.state_dict()))
        initial_residuals.append(state_digest(model.residual.state_dict()))
        initial_probability_error = float((result["probability"] - cache["uniform_probability"]).abs().max().detach())
        assert initial_probability_error < 3e-7
        F.binary_cross_entropy_with_logits(result["logits"], data[18]["dense"]["mask"][:2]).backward()
        assert all(p.grad is None for p in model.backbone.parameters())
        assert float(model.residual[-1].weight.grad.abs().sum()) > 0
        assert torch.count_nonzero(model.residual[0].weight.grad) == 0
        if model.scorer is not None: assert float(model.scorer[-1].weight.grad.abs().sum()) > 0
        with torch.no_grad():
            model.residual[-1].weight.copy_(torch.linspace(-.02, .02, 8).reshape(1, 8, 1, 1))
            model.residual[-1].bias.fill_(.003)
            if model.scorer is not None: model.scorer[-1].weight.copy_(torch.linspace(-.02, .02, 8).reshape(1, 8, 1, 1))
        model.zero_grad(set_to_none=True); model.forward_cached(cache)["logits"].sum().backward()
        assert float(model.residual[0].weight.grad.abs().sum()) > 0
        arrays, technical = fixture(c, model, x, cache)
        with torch.no_grad():
            permuted_probabilities = []
            for k in range(4):
                permuted = {key: torch.roll(value, k, 0) if key in VIEW_FIELDS else value for key, value in cache.items()}
                permuted_probabilities.append(model.forward_cached(permuted)["probability"])
            permuted_probabilities = torch.stack(permuted_probabilities)
            assert float((permuted_probabilities - torch.tensor(arrays["probability"])[None]).abs().max()) <= c["equivariance_tolerance"]
        arrays["view_permuted_probability"] = permuted_probabilities.numpy()
        arrays.update({"active_parameter_" + name.replace(".", "_"): p.detach().numpy()
                       for name, p in model.named_parameters() if p.requires_grad})
        np.savez_compressed(ROOT / f"TECHNICAL_ACTIVE_{arm}.npz", **arrays)
        evidence.append(dict(arm=arm, counts=model.parameter_counts(), exact_old_mixture_logit_initialization=True,
            initial_probability_rounding_error=initial_probability_error, first_residual_output_gradient_nonzero=True,
            active_hidden_gradient_nonzero=True, **technical))
    assert len(set(initial_scorers)) == len(set(initial_residuals)) == 1
    result = dict(status="PASS_PREFLIGHT", rows=evidence, same_fresh_prior_scorer_initialization=True,
        same_residual_initialization_all3=True, source_backbone_frozen=True, conditioning_detached=True,
        active_C4_and_view_permutation_checks=True, reused_control_rows=len(baseline),
        control_sources=baseline_sources, lineage=lineage, source_sha256=source_hashes(), optimizer_updates=0)
    save(ROOT / "PREFLIGHT.json", result); print(json.dumps(result), flush=True)


def run(c, phase, config_path):
    global START
    START = time.monotonic()
    assert torch.backends.mps.is_available() and os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] == "0"
    seeds = c["screen_seeds"] if phase == "screen" else [seed for seed in c["replication_seeds"] if seed not in c["screen_seeds"]]
    expected = signature(c); inherited = previous_screen(expected) if phase == "replicate" else None
    data, refs, states, lineage = r.inputs(c, seeds, "mps")
    control_rows, control_sources = controls(c, seeds, refs)
    trial_id = f'residual_{phase}_s{"-".join(map(str,seeds))}_{digest(source_hashes())[:10]}'
    trial = ROOT / "trials" / trial_id; assert not trial.exists(), "Immutable trial exists; no overwrite or implicitresume"
    for folder in [trial, trial / "models", trial / "val_probs", trial / "fixtures", trial / "source"]: folder.mkdir(parents=True, exist_ok=False)
    hashes = source_hashes(); save(trial / "CONFIG_SNAPSHOT.json", c); shutil.copy2(ROOT / "PROTOCOL.md", trial / "PROTOCOL.md")
    for name in ["model.py", "runner.py"]: shutil.copy2(ROOT / name, trial / "source" / name)
    save(trial / "CONTROL_SNAPSHOT.json", dict(rows=control_rows, sources=control_sources))
    frozen = dict(candidate=c["candidate"], phase=phase, seeds=seeds, signature=expected, sources=refs, lineage=lineage,
        source_sha256=hashes, architecture=architecture_spec(), protocol_sha256=sha(ROOT / "PROTOCOL.md"), config_sha256=sha(config_path),
        control_sources=control_sources, prior_stage_links=c["prior_stage_links"], fitted_models=3 * len(refs),
        total_updates=1500 * len(refs), evaluation_rows=3 * len(refs), reused_control_rows=len(control_rows), fresh_confirmation_access=False)
    save(trial / "FROZEN.json", frozen); append_ledger(dict(status="RUNNING", trial=trial_id, phase=phase, signature=expected))
    rows, checkpoints, counter = [], {}, [0]
    try:
        for ref in refs:
            source_key = ref["source_lr"], ref["budget"], ref["seed"]
            values = data[ref["budget"]]
            builder = make(c, "residual_plain", states[source_key], ref["seed"], "mps")
            cache, cache_meta = r.cached_inputs(builder, values, ref, c)
            cache_meta["prior_cache_builder_model_sha256"] = cache_meta["model_sha256"]
            cache_meta["model_sha256"] = sha(ROOT / "model.py")
            del builder
            paired = []
            for arm in FITTED_ARMS:
                net = make(c, arm, states[source_key], ref["seed"], "mps")
                timing = fit(c, net, values, cache, ref, trial, counter)
                evaluation, arrays = evaluate(c, net, values["val"], cache["val"])
                fixture_arrays, technical = fixture(c, net, values["val"]["x"][:16], slice_cache(cache["val"], slice(0, 16)))
                row = dict(source_lr=ref["source_lr"], budget=ref["budget"], seed=ref["seed"], arm=arm, source=ref,
                    **timing, **evaluation, **technical, parameters=net.parameter_counts(), cache=cache_meta, CNN_passes_per_image=4)
                name = f'{ref["source_lr"]}_b{ref["budget"]}_s{ref["seed"]}_{arm}'
                path = trial / "models" / f"{name}.pt"; temporary = path.with_suffix(".pt.partial")
                torch.save(dict(model={key: value.detach().cpu() for key, value in net.state_dict().items()}, settings=row), temporary)
                temporary.replace(path); checkpoints[path.name] = sha(path)
                np.savez_compressed(trial / "val_probs" / f"{name}.npz", **arrays)
                np.savez_compressed(trial / "fixtures" / f"{name}.npz", **fixture_arrays)
                rows.append(row); paired.append(row); save(trial / "PARTIAL_RESULTS.json", rows); save(trial / "CHECKPOINT_HASHES.json", checkpoints)
                del net
            assert len({row["batch_sequence_sha256"] for row in paired}) == 1
            assert len({row["residual_initial_sha256"] for row in paired}) == 1
            assert len({row["scorer_initial_sha256"] for row in paired if row["arm"] != "residual_only"}) == 1
            del cache
        assert counter[0] == 1500 * len(refs)
        assert all(sha(ROOT / name) == value for name, value in hashes.items())
        assert sha(config_path) == frozen["config_sha256"] and sha(ROOT / "PROTOCOL.md") == frozen["protocol_sha256"]
        for control in control_rows:
            for key, value in control["control_ref"].items():
                if key.endswith("_file"): assert sha(REPO / value) == control["control_ref"][key[:-5] + "_sha256"]
        gates, means = comparisons(rows, control_rows, c)
        result = dict(status="COMPLETE_DEVELOPMENT_TRIAL", candidate=c["candidate"], phase=phase, seeds=seeds, signature=expected,
            rows=rows, controls=control_rows, control_sources=control_sources, gates=gates, means=means, fitted_models=3 * len(refs),
            updates=counter[0], evaluation_rows=len(rows), reused_control_rows=len(control_rows), checkpoint_hashes=checkpoints,
            frozen_sha256=sha(trial / "FROZEN.json"), seconds=time.monotonic() - START, scope="OldTRAIN_VALonly; nofreshTESTorlossinnovation")
        save(trial / "RESULT.json", result)
        aggregate = None
        if inherited is not None:
            old_path, old = inherited; all_rows, all_controls = old["rows"] + rows, old["controls"] + control_rows
            assert len({(row["source_lr"], row["budget"], row["seed"], row["arm"]) for row in all_rows}) == len(all_rows)
            ag, am = comparisons(all_rows, all_controls, c)
            robust = {arm: bool(ag["A_architecture"][arm]["passed"] and gates["A_architecture"][arm]["passed"]) for arm in FITTED_ARMS}
            aggregate = dict(status="COMPLETE_REUSED_VAL_REPLICATION", rows=all_rows, controls=all_controls, gates=ag, means=am,
                new_seed_gates=gates, robust_architecture_by_arm=robust, robust_architecture_pass=any(robust.values()),
                seeds=c["replication_seeds"], source_trials=[str(old_path.parent.relative_to(ROOT)), str(trial.relative_to(ROOT))])
            save(trial / "AGGREGATE_RESULT.json", aggregate)
        summary = dict(status=result["status"], trial=str(trial.relative_to(ROOT)), phase=phase, result_sha256=sha(trial / "RESULT.json"),
                       gates=aggregate["gates"] if aggregate else gates, means=aggregate["means"] if aggregate else means)
        append_ledger(summary); save(ROOT / "LATEST_RESULT.json", summary); print(json.dumps(summary), flush=True)
    except BaseException as error:
        failure = dict(status="FAILED", trial=trial_id, phase=phase, error=str(error), error_type=type(error).__name__, traceback=traceback.format_exc())
        save(trial / "FAILURE.json", failure); append_ledger(failure); raise


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--phase", choices=["screen", "replicate"], default="screen")
    parser.add_argument("--config", type=Path, default=ROOT / "CONFIG.json"); parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args(); c = configuration(args.config); torch.set_num_threads(2)
    if args.preflight: preflight(c)
    else: run(c, args.phase, args.config)


if __name__ == "__main__":
    with threadpool_limits(limits=2): main()
