"""Pointwise C4-equivariant logit residual on top of learned orbit fusion.

The frozen source CNN and fresh249-parameter scorer follow stage7 exactly.
The additional241-parameter branch can change consensus predictions. Its zero
output preserves the previous stable mixture logits exactly at initialization.
"""
from pathlib import Path
import importlib.util

import torch
from torch import nn
from torch.nn import functional as F

PRIOR = Path(__file__).resolve().parents[1] / "sem_arch_learned_orbit_20261102"
spec = importlib.util.spec_from_file_location("residual_prior_orbit_model", PRIOR / "model.py")
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
state_digest = prior.state_digest
slice_cache = prior.slice_cache
VIEW_FIELDS = prior.VIEW_FIELDS
VARIANTS = prior.VARIANTS
FITTED_ARMS = ["residual_plain", "residual_joint", "residual_only"]
EVALUATION_ARMS = FITTED_ARMS


class OrbitResidualSegmenter(prior.LearnedOrbitSegmenter):
    def __init__(self, arm, backbone_state, **kwargs):
        assert arm in FITTED_ARMS
        # Always construct the prior scorer first, including in its ablation.
        # This preserves both the249 scorer initialization and the RNG state
        # used for ψ, so ψ has identical initial tensors in all three arms.
        super().__init__("learned_plain" if arm == "residual_plain" else "learned_joint",
                         backbone_state, **kwargs)
        self.arm = arm
        if arm == "residual_only":
            self.scorer = None
        self.residual = nn.Sequential(nn.Conv2d(28, 8, 1), nn.GELU(), nn.Conv2d(8, 1, 1))
        nn.init.zeros_(self.residual[-1].weight)
        nn.init.zeros_(self.residual[-1].bias)
        self.backbone.requires_grad_(False)
        assert self.parameter_counts()["residual"] == 241
        assert self.parameter_counts()["trainable"] == (241 if arm == "residual_only" else 490)

    def parameter_counts(self):
        counts = super().parameter_counts()
        counts["residual"] = (sum(p.numel() for p in self.residual.parameters())
                              if hasattr(self, "residual") else 0)
        return counts

    def fuse(self, inputs, intervention="actual"):
        assert intervention in VARIANTS
        z = inputs["view_logits"]
        view_probability = z.sigmoid()
        mu = inputs["uniform_probability"]
        mode = "plain" if self.arm == "residual_plain" else "joint"
        maps = inputs["maps_" + mode]
        assert not maps.requires_grad
        if intervention == "zero":
            maps = torch.zeros_like(maps)
        elif intervention == "roll":
            maps = torch.roll(maps, (5, 5), (-2, -1))
        if self.scorer is None:
            scores = torch.zeros_like(z)
        else:
            n = z.shape[1]
            repeat = lambda value: value.unsqueeze(0).expand(4, -1, -1, -1, -1)
            values = torch.cat((inputs["view_features"], view_probability,
                repeat(mu), repeat(inputs["x"]), repeat(maps)), dim=2)
            scores = self.scorer(values.reshape(4 * n, 29, 12, 12)).reshape(4, n, 1, 12, 12)
        log_weights = scores.log_softmax(0)
        weights = log_weights.exp()
        mixture_logits = (torch.logsumexp(log_weights + F.logsigmoid(z), dim=0)
                          - torch.logsumexp(log_weights + F.logsigmoid(-z), dim=0))
        residual_inputs = torch.cat((inputs["view_features"].mean(0), mu, inputs["x"], maps), dim=1)
        assert residual_inputs.shape[1] == 28
        psi = self.residual(residual_inputs)
        correction = 4 * psi  # Deliberately unbounded: no tanh or extra loss.
        logits = mixture_logits + correction
        return dict(logits=logits, probability=logits.sigmoid(), uniform_probability=mu,
            weights=weights, scores=scores, maps_normalized=maps, mixture_logits=mixture_logits,
            residual=psi, correction=correction, residual_inputs=residual_inputs)

    def forward_details(self, x, intervention="actual"):
        inputs = self.current_orbit(x)
        mode = "plain" if self.arm == "residual_plain" else "joint"
        inputs["raw_" + mode], inputs["maps_" + mode] = self.conditioning_maps(inputs["uniform_probability"], mode)
        return self.fuse(inputs, intervention)


def make_model(arm, backbone_state, **kwargs):
    return OrbitResidualSegmenter(arm, backbone_state, **kwargs)


def architecture_spec():
    return dict(candidate="orbit_pointwise_residual", fitted_arms=FITTED_ARMS, group="C4",
        scorer="unchanged fresh shared29to8to1pointwise scorer249 fromstage7",
        residual="shared Conv1x1(28to8),GELU,Conv1x1(8to1)", residual_parameters=241,
        residual_inputs=["orbit_meanF24", "uniform_probability1", "SEM1", "maps2"],
        head_parameters=dict(residual_plain=490, residual_joint=490, residual_only=241),
        correction="stable_attention_mixture_logit+4*psi; no bounding nonlinearity",
        initialization="exact prior scorer tensors; zero residual final layer; samepsi tensors allarms",
        backbone_frozen=True, conditioning_detached=True,
        ablation="residual_only uses jointmaps and uniformviewweights, no249scorerparameters",
        cache="same stage7 image-only ephemeral bounded120MiB sourcecache",
        scope="oldTRAIN_VAL development only; no newloss, confirmationdata or noveltyclaim")
