"""Expand control weights using inherited DEV evidence; TRAIN/VAL only.

Only main() launches training. Importing helpers is safe for the evaluator and
the technical smoke checks. All weight selection uses the fixed VAL split.
"""
from pathlib import Path
import hashlib
import itertools
import json
import os
import sys
import time

# This must be configured before importing torch. An unsupported operation
# should fail explicitly rather than change the planned device silently.
os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '0'

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
OLD = G / 'sem_cldice_confirmation_20261030'
from physics_adapter import make_segmenter, geometry_loss
from vendor.cldice import soft_cldice

DEV_SEEDS = [3011, 3041]
SEEDS = [4111, 4157, 4211, 4253, 4297]
ARMS = ['head9', 'cldice_head9', 'soft']
OLD_WEIGHTS = [.1, .4, 1.]
HEAD_NEW_WEIGHTS = [2., 4.]
CLDICE_EXPANDED_WEIGHTS = [1., 2., 4.]
PHYSICS_WEIGHT = .4
BASE_STEPS = 400
DEV_STEPS = 1000
FINAL_STEPS = 2000
HEAD_WARM_STEPS = 200
BATCH_SIZE = 16
CLDICE_ITERATIONS = 24
TOTAL = 52800
TOTAL_HEAD = 6000
START = None
COMPLETED = 0
HEAD_COMPLETED = 0
CLASS_CACHE = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.partial')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def progress(**details):
    record = dict(seconds=None if START is None else time.monotonic() - START,
                  completed_backbone_steps=COMPLETED, total_backbone_steps=TOTAL,
                  completed_head_only_steps=HEAD_COMPLETED,
                  total_head_only_steps=TOTAL_HEAD, **details)
    save(ROOT / 'PROGRESS.json', record)
    with (ROOT / 'progress.jsonl').open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + '\n')
    print(json.dumps(record, ensure_ascii=False), flush=True)


def hard_classes(masks):
    """Cache exact historical binary-grid classes; never use soft conductance."""
    from prepare import class_labels
    masks = np.asarray(masks, dtype=bool).reshape(-1, 12, 12)
    keys = [row.tobytes() for row in np.packbits(masks.reshape(len(masks), -1), axis=1)]
    missing = sorted(set(keys) - CLASS_CACHE.keys())
    if missing:
        values = np.array([np.unpackbits(np.frombuffer(key, dtype=np.uint8)).reshape(12, 12)
                           for key in missing], dtype=bool)
        CLASS_CACHE.update(zip(missing, class_labels(values).tolist()))
    return np.array([CLASS_CACHE[key] for key in keys], dtype=np.int64)


def make_head(family='head9'):
    assert family in ['head9', 'cldice_head9'], family
    return nn.Sequential(nn.Linear(3456, 64), nn.GELU(), nn.Linear(64, 9))


def head_classes(logits, family='head9'):
    assert family in ['head9', 'cldice_head9'], family
    return logits.argmax(1)


def head_loss(logits, targets, family='head9'):
    assert family in ['head9', 'cldice_head9'], family
    return F.cross_entropy(logits, targets)


def make_cldice():
    """Configure the unchanged author implementation with the frozen depth.

    The author's constructor hard-codes 10 iterations regardless of iter_.
    TRAIN-only technical checks require 24 here; set the public submodule
    property explicitly instead of changing the vendored source files.
    """
    loss = soft_cldice()
    loss.soft_skeletonize.num_iter = CLDICE_ITERATIONS
    return loss


def configuration(family, weight, cldice_weight=0.):
    weight = float(weight); cldice_weight = float(cldice_weight)
    assert family in ARMS
    assert weight > 0 and cldice_weight >= 0
    assert family == 'cldice_head9' or cldice_weight == 0
    head_weight = 0. if family == 'soft' else weight
    physics_weight = weight if family == 'soft' else 0.
    token = lambda v: f'{v:g}'.replace('.', 'p')
    name = f'{family}_w{token(weight)}_c{token(cldice_weight)}'
    return {'family': family, 'weight': weight, 'head_weight': head_weight,
            'cldice_weight': cldice_weight, 'physics_weight': physics_weight,
            'config_id': name}


def configurations():
    """Only new settings to fit; historical points are never retrained here."""
    out = [configuration('head9', w) for w in HEAD_NEW_WEIGHTS]
    out += [configuration('cldice_head9', w, c)
            for w, c in itertools.product(CLDICE_EXPANDED_WEIGHTS, CLDICE_EXPANDED_WEIGHTS)
            if (w, c) != (1., 1.)]
    assert len(out) == 10
    return out


def selection_candidates():
    """Union of all prespecified control settings, plus one fixed soft setting."""
    out = [configuration('head9', w) for w in OLD_WEIGHTS + HEAD_NEW_WEIGHTS]
    out += [configuration('cldice_head9', w, c) for w, c in itertools.product(OLD_WEIGHTS, OLD_WEIGHTS)]
    out += [s for s in configurations() if s['family'] == 'cldice_head9']
    out += [configuration('soft', PHYSICS_WEIGHT)]
    assert len(out) == 23 and len({s['config_id'] for s in out}) == 23
    return out


def selection_rank(row):
    return row['mask_F1'], row['IoU'], -row['weight'], -row['cldice_weight']


def load_training():
    """This function never opens DATA.npz or TEST.npz.

    The separate archive has no test tensors. Weak examples have no mask key
    in the data object returned to the optimizers.
    """
    with np.load(ROOT / 'TRAIN_VAL.npz', allow_pickle=False) as z:
        roles = z['role']
        assert set(roles.tolist()) == {'dense', 'weak', 'val'}
        assert {role: int((roles == role).sum()) for role in set(roles)} == {
            'dense': 54, 'weak': 1152, 'val': 695}
        data = {}
        for role in ['dense', 'weak', 'val']:
            ids = np.flatnonzero(roles == role)
            data[role] = {
                'x': torch.tensor(5 * (z['X'][ids] - .2), device='mps'),
                'label': torch.tensor(z['label'][ids], device='mps'),
            }
            if role != 'weak':
                data[role]['mask'] = torch.tensor(z['Y'][ids].astype(np.float32), device='mps')
    assert set(data['weak']) == {'x', 'label'}
    return data


def evaluate(net, head, data, family):
    net.eval()
    if head is not None:
        head.eval()
    masks = []; direct = []
    with torch.inference_mode():
        for x in data['x'].split(256):
            if head is None:
                logits = net(x)
            else:
                features = net[:-1](x)
                logits = net[-1](features)
                direct.append(head_classes(head(features.flatten(1)), family).cpu().numpy())
            masks.append((logits[:, 0] >= 0).cpu().numpy())
    masks = np.concatenate(masks)
    truth = data['label'].cpu().numpy()
    target = data['mask'][:, 0].cpu().numpy().astype(bool)
    prediction = hard_classes(masks)
    union = (masks | target).sum((1, 2))
    iou = np.divide((masks & target).sum((1, 2)), union,
                    out=np.ones(len(union), dtype=float), where=union > 0)
    result = {
        'mask_F1': float(f1_score(truth, prediction, labels=range(9), average='macro', zero_division=0)),
        'IoU': float(iou.mean()),
        'direct_head_F1': None if head is None else float(f1_score(
            truth, np.concatenate(direct), labels=range(9), average='macro', zero_division=0)),
    }
    assert np.isfinite(result['mask_F1']) and np.isfinite(result['IoU'])
    net.train()
    if head is not None:
        head.train()
    return result


def base_model(seed, data):
    global COMPLETED
    torch.manual_seed(seed)
    net = make_segmenter().to('mps')
    assert sum(p.numel() for p in net.parameters()) == 10681
    opt = torch.optim.AdamW(net.parameters(), lr=.003, weight_decay=.0001)
    rng = np.random.default_rng(seed)
    started = time.monotonic()
    for step in range(1, BASE_STEPS + 1):
        ids = torch.tensor(rng.integers(0, len(data['x']), BATCH_SIZE), device='mps')
        opt.zero_grad(set_to_none=True)
        loss = F.binary_cross_entropy_with_logits(net(data['x'][ids]), data['mask'][ids])
        assert torch.isfinite(loss), (seed, 'base', step)
        loss.backward(); opt.step(); COMPLETED += 1
        if step % 100 == 0:
            progress(stage='base', seed=seed, step=step, target_steps=BASE_STEPS,
                     method_seconds=time.monotonic()-started)
    return {key: value.detach().cpu().clone() for key, value in net.state_dict().items()}


def train_method(seed, settings, steps, initial, data):
    global COMPLETED, HEAD_COMPLETED
    family = settings['family']
    setup_started = time.monotonic()
    # make_segmenter consumes random numbers, but all its weights are replaced.
    # Reset the generator AFTER creation to obtain identical head initialization
    # for head9 and cldice_head9 of every setting of the same seed.
    net = make_segmenter().to('mps')
    net.load_state_dict(initial)
    torch.manual_seed(seed + 3)
    head = None if family == 'soft' else make_head(family).to('mps')
    dense, weak = data['dense'], data['weak']
    head_initial_sha = None
    if head is not None:
        head_initial_sha = state_digest(head.state_dict())
        with torch.inference_mode():
            features = torch.cat([net[:-1](x).flatten(1) for x in weak['x'].split(128)]).clone()
        # Clone outside inference_mode to permit gradients for head parameters.
        features = features.clone()
        opt_head = torch.optim.AdamW(head.parameters(), lr=.003, weight_decay=.0001)
        rng_head = np.random.default_rng(seed + 700)
        for step in range(1, HEAD_WARM_STEPS + 1):
            wi = torch.tensor(rng_head.integers(0, len(weak['x']), BATCH_SIZE), device='mps')
            opt_head.zero_grad(set_to_none=True)
            loss = head_loss(head(features[wi]), weak['label'][wi], family)
            assert torch.isfinite(loss), (seed, family, 'head', step)
            loss.backward(); opt_head.step(); HEAD_COMPLETED += 1
        del features, opt_head
    head_after_warm_sha = None if head is None else state_digest(head.state_dict())
    setup_seconds = time.monotonic() - setup_started
    params = list(net.parameters()) + ([] if head is None else list(head.parameters()))
    opt = torch.optim.AdamW(params, lr=.001, weight_decay=.0001)
    rng = np.random.default_rng(seed + 10)
    loss_cldice = make_cldice()
    assert loss_cldice.soft_skeletonize.num_iter == CLDICE_ITERATIONS == 24
    started = time.monotonic()
    for step in range(1, steps + 1):
        # Both arrays are drawn for all arms, including soft, in the same order.
        ai = torch.tensor(rng.integers(0, len(dense['x']), BATCH_SIZE), device='mps')
        wi = torch.tensor(rng.integers(0, len(weak['x']), BATCH_SIZE), device='mps')
        opt.zero_grad(set_to_none=True)
        dense_logits = net(dense['x'][ai])
        loss = F.binary_cross_entropy_with_logits(dense_logits, dense['mask'][ai])
        if family == 'soft':
            labels = weak['label'][wi]
            direction = torch.stack((labels // 3, labels % 3), 1)
            loss = loss + settings['physics_weight'] * geometry_loss(net(weak['x'][wi]), direction)
        else:
            weak_features = net[:-1](weak['x'][wi])
            loss = loss + settings['head_weight'] * head_loss(
                head(weak_features.flatten(1)), weak['label'][wi], family)
            # Zero weight deliberately takes exactly the baseline code path.
            if settings['cldice_weight'] != 0:
                loss = loss + settings['cldice_weight'] * loss_cldice(
                    dense['mask'][ai], dense_logits.sigmoid())
        assert torch.isfinite(loss), (seed, settings, step)
        loss.backward(); opt.step(); COMPLETED += 1
        if step % 100 == 0:
            elapsed = time.monotonic() - started
            progress(stage='train', seed=seed, **settings, step=step,
                     target_steps=steps, method_seconds=elapsed,
                     method_steps_per_second=step / elapsed)
    timing = {'seconds': time.monotonic() - started, 'setup_seconds': setup_seconds,
              'head_initial_sha256': head_initial_sha,
              'head_after_warm_sha256': head_after_warm_sha}
    return net, head, timing


def state_digest(state):
    digest = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        digest.update(key.encode()); digest.update(str(value.dtype).encode())
        digest.update(str(value.shape).encode()); digest.update(value.tobytes())
    return digest.hexdigest()


def checkpoint(path, net, head, **settings):
    payload = {
        'segmenter': {key: value.detach().cpu() for key, value in net.state_dict().items()},
        'head': None if head is None else {key: value.detach().cpu() for key, value in head.state_dict().items()},
        'settings': settings,
    }
    temporary = path.with_suffix(path.suffix + '.partial')
    torch.save(payload, temporary)
    temporary.replace(path)
    return sha(path)


NUMERICAL_CORE = [
    'hard_classes', 'make_head', 'head_classes', 'head_loss', 'make_cldice',
    'configuration', 'selection_rank', 'load_training', 'evaluate',
    'base_model', 'train_method', 'state_digest', 'checkpoint',
]


def numerical_core_hashes(path):
    import ast
    nodes = {node.name: node for node in ast.parse(Path(path).read_text()).body
             if isinstance(node, ast.FunctionDef)}
    return {name: hashlib.sha256(ast.dump(nodes[name], include_attributes=False).encode()).hexdigest()
            for name in NUMERICAL_CORE}


def prepare_inherited_evidence():
    """Validate and freeze immutable old DEV observations, without TEST reads.

    May be called by preflight before main(). Existing outputs must match
    byte-for-byte; no inherited result or model is silently replaced.
    """
    old_frozen = json.loads((OLD / 'FROZEN.json').read_text())
    old_complete = json.loads((OLD / 'TRAINING_COMPLETE.json').read_text())
    old_audit = json.loads((OLD / 'AUDIT.json').read_text())
    old_hashes = json.loads((OLD / 'CHECKPOINT_HASHES.json').read_text())
    raw = (OLD / 'DEV_RESULTS.json').read_bytes()
    rows = json.loads(raw)
    assert old_audit['status'] == 'PASS_AUDIT' and all(old_audit['checks'].values())
    assert sha(OLD / 'train.py') == old_frozen['script_sha256']
    assert sha(OLD / 'FROZEN.json') == old_complete['frozen_sha256']
    assert old_frozen['DEV_SEEDS'] == DEV_SEEDS and old_frozen['cldice_iterations'] == CLDICE_ITERATIONS
    assert torch.__version__ == old_frozen['torch'], 'Changed torch version: inherited DEV reuse requires new validation'
    assert all(sha(OLD / name) == value for name, value in old_frozen['source_sha256'].items())
    assert len(rows) == 30
    assert numerical_core_hashes(Path(__file__)) == numerical_core_hashes(OLD / 'train.py'), \
        'The numerical training core must remain identical when inheriting DEV results'
    expected_configs = [configuration('head9', w) for w in OLD_WEIGHTS]
    expected_configs += [configuration('cldice_head9', w, c) for w, c in itertools.product(OLD_WEIGHTS, OLD_WEIGHTS)]
    expected_configs += [configuration('soft', w) for w in OLD_WEIGHTS]
    assert {(row['seed'], row['config_id']) for row in rows} == {
        (seed, setting['config_id']) for seed in DEV_SEEDS for setting in expected_configs}
    assert all(np.isfinite(row['mask_F1']) and np.isfinite(row['IoU']) for row in rows)
    models = {}
    for row in rows:
        name = f'dev_{row["config_id"]}_{row["seed"]}.pt'
        expected = old_complete['checkpoint_hashes'][name]
        assert old_hashes[name] == expected and sha(OLD / 'models' / name) == expected
        payload = torch.load(OLD / 'models' / name, map_location='cpu', weights_only=True)
        assert payload['settings'] == row, ('Inherited checkpoint metadata differs', name)
        models[name] = expected
    head_init = {}; head_warm = {}
    for seed in DEV_SEEDS:
        selected = [row for row in rows if row['seed'] == seed and row['family'] != 'soft']
        assert len(selected) == 12
        assert len({row['head_initial_sha256'] for row in selected}) == 1
        assert len({row['head_after_warm_sha256'] for row in selected}) == 1
        head_init[str(seed)] = selected[0]['head_initial_sha256']
        head_warm[str(seed)] = selected[0]['head_after_warm_sha256']
    files = ['DEV_RESULTS.json', 'FROZEN.json', 'TRAINING_COMPLETE.json',
             'CHECKPOINT_HASHES.json', 'CONFIG.json', 'PROTOCOL.md', 'TRAIN_VAL.npz',
             'train.py', 'AUDIT.json', 'physics_adapter.py',
             'vendor/cldice.py', 'vendor/soft_skeleton.py', 'VENDOR.json']
    lineage = {
        'status': 'FROZEN_INHERITED_DEV', 'source_root': '../sem_cldice_confirmation_20261030',
        'source_DEV_RESULTS_sha256': sha(OLD / 'DEV_RESULTS.json'),
        'files_sha256': {name: sha(OLD / name) for name in files},
        'dev_models_sha256': models,
        'expected_head_initialization_by_seed': head_init,
        'expected_head_after_warm_by_seed': head_warm,
        'numerical_core_AST_sha256': numerical_core_hashes(Path(__file__)),
        'torch_version': torch.__version__, 'numpy_version_current': np.__version__,
        'inherited_rows': len(rows), 'inherited_DEV_seeds': DEV_SEEDS,
        'inherited_models': len(models), 'retraining_old_configurations': False,
        'physics_weight_fixed': PHYSICS_WEIGHT,
        'scope': 'Only historical TRAIN/VAL development results inherited. Previous TEST arrays/predictions are not read by trainer.'}
    result_path = ROOT / 'INHERITED_DEV_RESULTS.json'
    if result_path.exists():
        assert result_path.read_bytes() == raw
    else:
        result_path.write_bytes(raw)
    line_path = ROOT / 'INHERITED_DEV_LINEAGE.json'
    if line_path.exists():
        assert json.loads(line_path.read_text()) == lineage
    else:
        save(line_path, lineage)
    return rows, lineage


def verify_preconditions():
    assert torch.backends.mps.is_available(), 'Explicit MPS required, no CPU fallback'
    assert os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] == '0'
    assert not (ROOT / 'FROZEN.json').exists(), 'Refuse to overwrite a frozen training attempt'
    assert not (ROOT / 'TRAINING_COMPLETE.json').exists()
    assert not (ROOT / 'RESULT.json').exists(), 'TEST evaluation must follow training'
    config = json.loads((ROOT / 'CONFIG.json').read_text())
    expected = {
        'dev_seeds': DEV_SEEDS, 'final_seeds': SEEDS,
        'head_new_weights': HEAD_NEW_WEIGHTS, 'cldice_expanded_weights': CLDICE_EXPANDED_WEIGHTS,
        'physics_weight': PHYSICS_WEIGHT,
        'base_steps': BASE_STEPS, 'dev_steps': DEV_STEPS, 'final_steps': FINAL_STEPS,
        'head_warm_steps': HEAD_WARM_STEPS, 'batch_size': BATCH_SIZE,
        'cldice_iterations': CLDICE_ITERATIONS,
        'total_backbone_updates': TOTAL, 'total_head_updates': TOTAL_HEAD,
    }
    assert all(config[key] == value for key, value in expected.items()), (config, expected)
    assert config['protocol_sha256'] == sha(ROOT / 'PROTOCOL.md')
    smoke = json.loads((ROOT / 'SMOKE_CHECK.json').read_text())
    assert smoke['status'] == 'PASS_SMOKE_CHECK', smoke.get('status')
    for name, value in smoke['source_sha256'].items():
        assert sha(ROOT / name) == value, ('Smoke input changed', name)
    manifest = json.loads((ROOT / 'DATA_MANIFEST.json').read_text())
    assert manifest['status'] == 'PASS_DATA_GATE'
    assert manifest['protocol_sha256'] == sha(ROOT / 'PROTOCOL.md')
    assert manifest['TRAIN_VAL_sha256'] == sha(ROOT / 'TRAIN_VAL.npz')
    assert sha(ROOT / 'TRAIN_VAL.npz') == sha(OLD / 'TRAIN_VAL.npz'), \
        'Inherited results require the exact same TRAIN/VAL archive'
    assert (ROOT / 'INHERITED_DEV_RESULTS.json').exists() and (ROOT / 'INHERITED_DEV_LINEAGE.json').exists(), \
        'Freeze inherited evidence before smoke checks'
    inherited, lineage = prepare_inherited_evidence()
    # Ensure the numerical dependencies really are the old version.
    for name in ['physics_adapter.py', 'vendor/cldice.py', 'vendor/soft_skeleton.py', 'VENDOR.json']:
        assert sha(ROOT / name) == lineage['files_sha256'][name], name
    return config, smoke, manifest, inherited, lineage


def aggregate_candidates(rows):
    aggregated = []
    for settings in selection_candidates():
        selected = [row for row in rows if row['config_id'] == settings['config_id']]
        assert len(selected) == len(DEV_SEEDS)
        assert sorted(row['seed'] for row in selected) == DEV_SEEDS
        aggregated.append(dict(settings,
            mask_F1=float(np.mean([row['mask_F1'] for row in selected])),
            IoU=float(np.mean([row['IoU'] for row in selected]))))
    return aggregated


def main():
    global START, COMPLETED, HEAD_COMPLETED
    START = time.monotonic(); COMPLETED = 0; HEAD_COMPLETED = 0
    torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        config, smoke, manifest, inherited, lineage = verify_preconditions()
        dependencies = ['train.py', 'physics_adapter.py', 'prepare.py',
                        'vendor/cldice.py', 'vendor/soft_skeleton.py', 'VENDOR.json',
                        '../sem_physics_materials/physics_loss_example.py']
        source_sha = {name: sha(ROOT / name) for name in dependencies}
        frozen = {
            'protocol_sha256': sha(ROOT / 'PROTOCOL.md'),
            'config_sha256': sha(ROOT / 'CONFIG.json'),
            'train_val_sha256': sha(ROOT / 'TRAIN_VAL.npz'),
            'data_sha256': manifest['DATA_sha256'],
            'manifest_sha256': sha(ROOT / 'DATA_MANIFEST.json'),
            'script_sha256': sha(Path(__file__)), 'source_sha256': source_sha,
            'smoke_sha256': sha(ROOT / 'SMOKE_CHECK.json'),
            'inherited_results_sha256': sha(ROOT / 'INHERITED_DEV_RESULTS.json'),
            'inherited_lineage_sha256': sha(ROOT / 'INHERITED_DEV_LINEAGE.json'),
            'inherited_source_root': lineage['source_root'],
            'inherited_source_files_sha256': lineage['files_sha256'],
            'inherited_DEV_models_sha256': lineage['dev_models_sha256'],
            'torch': torch.__version__, 'numpy': np.__version__, 'MPS_available': True,
            'MPS_fallback': os.environ['PYTORCH_ENABLE_MPS_FALLBACK'],
            'DEV_SEEDS': DEV_SEEDS, 'FINAL_SEEDS': SEEDS, 'ARMS': ARMS,
            'new_configurations': configurations(), 'selection_candidates': selection_candidates(),
            'cldice_iterations': CLDICE_ITERATIONS,
            'physics_weight_fixed': PHYSICS_WEIGHT,
            'training_has_no_TEST_tensors': True, 'training_archive': 'TRAIN_VAL.npz',
            'weak_data_has_no_mask_key': True,
            'selection_rule': '(mask_F1, IoU, -weight, -cldice_weight), controls union; soft fixed .4',
        }
        save(ROOT / 'FROZEN.json', frozen)
        (ROOT / 'models').mkdir(exist_ok=True)
        data = load_training()
        progress(stage='START_EXPANDED_DEV_NO_TEST_OPENED')
        rows = []; hashes = {}
        head_init_by_seed = {}; head_warm_by_seed = {}
        for seed in DEV_SEEDS:
            initial = base_model(seed, data['dense'])
            for settings in configurations():
                net, head, timing = train_method(seed, settings, DEV_STEPS, initial, data)
                # These checks are essential to safely reuse the old DEV points.
                assert timing['head_initial_sha256'] == lineage['expected_head_initialization_by_seed'][str(seed)], \
                    ('Inherited head initialization mismatch', seed)
                assert timing['head_after_warm_sha256'] == lineage['expected_head_after_warm_by_seed'][str(seed)], \
                    ('Inherited warm head mismatch: do not combine results', seed)
                head_init_by_seed.setdefault(seed, timing['head_initial_sha256'])
                head_warm_by_seed.setdefault(seed, timing['head_after_warm_sha256'])
                row = dict(seed=seed, **settings, **timing, **evaluate(net, head, data['val'], settings['family']))
                rows.append(row)
                name = f'dev_{settings["config_id"]}_{seed}.pt'
                hashes[name] = checkpoint(ROOT / 'models' / name, net, head, **row)
                save(ROOT / 'DEV_RESULTS.json', rows)
                save(ROOT / 'ALL_DEV_RESULTS.json', inherited + rows)
                save(ROOT / 'CHECKPOINT_HASHES.json', hashes)
                print(json.dumps({'stage': 'VAL', **row}), flush=True)
                del net, head
        assert len(rows) == 20
        combined_rows = inherited + rows
        assert len(combined_rows) == 50
        aggregated = aggregate_candidates(combined_rows)
        chosen = {arm: max([row for row in aggregated if row['family'] == arm], key=selection_rank)
                  for arm in ['head9', 'cldice_head9']}
        fixed_soft = [row for row in aggregated if row['family'] == 'soft']
        assert len(fixed_soft) == 1 and fixed_soft[0]['physics_weight'] == PHYSICS_WEIGHT
        chosen['soft'] = fixed_soft[0]
        assert all(np.isfinite(row['mask_F1']) and np.isfinite(row['IoU']) for row in aggregated)
        assert all(row['mask_F1'] >= .45 for row in chosen.values()), \
            'VAL learning gate failed (best family F1 < .45); do not open TEST'
        selection = {
            'status': 'FROZEN_BEFORE_TEST', 'chosen': chosen,
            'primary_controls': ['head9', 'cldice_head9'],
            'all_VAL_configurations': aggregated,
            'candidate_counts': {'head9': 5, 'cldice_head9': 17, 'soft': 1},
            'old_DEV_rows': len(inherited), 'new_DEV_rows': len(rows),
            'used_DEV_rows': 46, 'all_DEV_rows': len(combined_rows),
            'inherited_results_sha256': sha(ROOT / 'INHERITED_DEV_RESULTS.json'),
            'inherited_lineage_sha256': sha(ROOT / 'INHERITED_DEV_LINEAGE.json'),
            'physics_fixed_before_new_DEV': True,
            'rule': '(mask_F1, IoU, -weight, -cldice_weight) on controls; soft fixed .4',
            'selection_uses_TEST': False,
        }
        save(ROOT / 'SELECTION.json', selection)
        print(json.dumps({'stage': 'SELECTION', **selection}), flush=True)
        final_rows = []
        for seed in SEEDS:
            initial = base_model(seed, data['dense'])
            base = make_segmenter(); base.load_state_dict(initial)
            name = f'final_base_{seed}.pt'
            hashes[name] = checkpoint(ROOT / 'models' / name, base, None, seed=seed, family='base')
            del base
            for family in ARMS:
                settings = {key: chosen[family][key] for key in
                            ['family', 'weight', 'head_weight', 'cldice_weight', 'physics_weight', 'config_id']}
                net, head, timing = train_method(seed, settings, FINAL_STEPS, initial, data)
                if head is not None:
                    head_init_by_seed.setdefault(seed, timing['head_initial_sha256'])
                    head_warm_by_seed.setdefault(seed, timing['head_after_warm_sha256'])
                    assert timing['head_initial_sha256'] == head_init_by_seed[seed]
                    assert timing['head_after_warm_sha256'] == head_warm_by_seed[seed]
                row = dict(seed=seed, **settings, **timing, **evaluate(net, head, data['val'], family))
                final_rows.append(row)
                name = f'final_{family}_{seed}.pt'
                hashes[name] = checkpoint(ROOT / 'models' / name, net, head, **row)
                save(ROOT / 'FINAL_VAL_RESULTS.json', final_rows)
                save(ROOT / 'CHECKPOINT_HASHES.json', hashes)
                print(json.dumps({'stage': 'FINAL_VAL', **row}), flush=True)
                del net, head
        assert COMPLETED == TOTAL, (COMPLETED, TOTAL)
        assert HEAD_COMPLETED == TOTAL_HEAD, (HEAD_COMPLETED, TOTAL_HEAD)
        assert len(hashes) == 40, len(hashes)
        assert sha(ROOT / 'TRAIN_VAL.npz') == frozen['train_val_sha256']
        assert sha(ROOT / 'PROTOCOL.md') == frozen['protocol_sha256']
        assert sha(ROOT / 'CONFIG.json') == frozen['config_sha256']
        assert sha(ROOT / 'INHERITED_DEV_RESULTS.json') == frozen['inherited_results_sha256']
        assert sha(ROOT / 'INHERITED_DEV_LINEAGE.json') == frozen['inherited_lineage_sha256']
        assert all(sha(ROOT / name) == value for name, value in source_sha.items())
        assert all(sha(OLD / name) == value for name, value in lineage['files_sha256'].items())
        assert all(sha(OLD / 'models' / name) == value for name, value in lineage['dev_models_sha256'].items())
        complete = {
            'status': 'COMPLETE_TRAINING_NO_TEST_OPENED',
            'seconds': time.monotonic() - START,
            'backbone_steps': COMPLETED, 'head_only_steps': HEAD_COMPLETED,
            'total_weights': len(hashes), 'checkpoint_hashes': hashes,
            'new_DEV_models': 20, 'inherited_DEV_models': 30,
            'inherited_DEV_models_sha256': lineage['dev_models_sha256'],
            'inherited_results_sha256': sha(ROOT / 'INHERITED_DEV_RESULTS.json'),
            'inherited_lineage_sha256': sha(ROOT / 'INHERITED_DEV_LINEAGE.json'),
            'selection_sha256': sha(ROOT / 'SELECTION.json'),
            'frozen_sha256': sha(ROOT / 'FROZEN.json'),
            'head_initialization_equal_by_seed': head_init_by_seed,
            'head_after_warm_equal_by_seed': head_warm_by_seed,
            'DEV_head_initialization_matches_inherited': True,
            'DEV_head_after_warm_matches_inherited': True,
            'physics_weight_fixed': PHYSICS_WEIGHT,
            'last_weights_only': True, 'TEST_opened': False,
        }
        save(ROOT / 'TRAINING_COMPLETE.json', complete)
        progress(stage='COMPLETE_TRAINING_NO_TEST_OPENED')


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if START is not None:
            save(ROOT / 'TRAINING_FAILURE.json', {
                'status': 'STOPPED_TRAINING', 'error_type': type(error).__name__,
                'error': str(error), 'completed_backbone_steps': COMPLETED,
                'completed_head_only_steps': HEAD_COMPLETED,
                'seconds': time.monotonic() - START,
                'TEST_opened_by_trainer': False,
            })
        raise
