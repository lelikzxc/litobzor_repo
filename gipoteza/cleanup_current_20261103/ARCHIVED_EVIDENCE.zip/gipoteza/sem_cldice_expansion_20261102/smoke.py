"""TRAIN-only technical checks of the fixed clDice implementation on MPS."""
from pathlib import Path
import json
import os
import time
os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '0'
import numpy as np
import torch
from threadpoolctl import threadpool_limits
import train
from vendor.soft_skeleton import SoftSkeletonize
from physics_adapter import smoke_check as physics_check

ROOT = Path(__file__).resolve().parent


def main():
    start = time.monotonic()
    assert not (ROOT / 'FROZEN.json').exists(), 'Technical checks precede experimental training'
    assert torch.backends.mps.is_available()
    torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        # Exact unchanged TRAIN masks; no new TEST arrays are opened here.
        inherited, lineage = train.prepare_inherited_evidence()
        old = ROOT.parent / 'sem_cldice_confirmation_20261030/TRAIN_VAL.npz'
        with np.load(old, allow_pickle=False) as z:
            data = {}
            for role in ['dense', 'weak']:
                ids = np.flatnonzero(z['role'] == role)
                data[role] = {'x': torch.tensor(5*(z['X'][ids]-.2), device='mps'),
                              'label': torch.tensor(z['label'][ids], device='mps')}
                if role == 'dense':
                    cpu_gt = torch.tensor(z['Y'][ids].astype(np.float32))
                    data[role]['mask'] = cpu_gt.to('mps')
        assert set(data['weak']) == {'x', 'label'}
        sk10 = SoftSkeletonize(10)(cpu_gt)
        sk24 = SoftSkeletonize(24)(cpu_gt)
        sk32 = SoftSkeletonize(32)(cpu_gt)
        changed = int((sk10-sk24).abs().flatten(1).sum(1).gt(0).sum())
        assert changed == 7
        assert torch.equal(sk24, sk32), '24 iterations must stabilise every dense TRAIN skeleton'
        assert (sk24.flatten(1).sum(1) > 0).all()
        masks = np.zeros((8, 1, 12, 12), dtype=np.float32)
        masks[1] = 1
        masks[2, 0, 5:7] = 1  # thin track crossing left/right borders
        masks[3, 0, :2] = 1   # top-border track
        masks[4, 0, :, 4:8] = 1
        masks[5, 0, [3, 8], :] = 1
        masks[6, 0, 3:9, 3:9] = 1; masks[6, 0, 4:8, 4:8] = 0
        masks[7, 0, 2:10, 2:10] = 1
        fixtures = torch.tensor(masks)
        loss_fn = train.make_cldice()
        fixture_identity = []
        for i in range(len(fixtures)):
            loss = loss_fn(fixtures[i:i+1], fixtures[i:i+1])
            assert torch.isfinite(loss) and abs(float(loss)) < 1e-6
            fixture_identity.append(float(loss))
        # Technical sensitivity, not a claim that clDice perfectly captures paths.
        broken = fixtures[2:3].clone(); broken[:, :, :, 6] = 0
        bridge = fixtures[5:6].clone(); bridge[:, :, 3:9, 6] = 1
        break_loss = float(loss_fn(fixtures[2:3], broken))
        bridge_loss = float(loss_fn(fixtures[5:6], bridge))
        assert break_loss > 0 and bridge_loss > 0
        empty_loss = loss_fn(fixtures[2:3], torch.zeros_like(fixtures[2:3]))
        assert torch.isfinite(empty_loss)
        # Full targets have no skeleton under author padding; excluded from TRAIN.
        full_skeleton_sum = float(SoftSkeletonize(24)(fixtures[1:2]).sum())
        assert full_skeleton_sum == 0
        logits = torch.linspace(-3, 3, len(fixtures)*144).reshape(len(fixtures), 1, 12, 12).requires_grad_()
        cpu_loss = loss_fn(fixtures, logits.sigmoid())
        cpu_grad = torch.autograd.grad(cpu_loss, logits)[0]
        ml = logits.detach().to('mps').requires_grad_()
        mps_loss = loss_fn(fixtures.to('mps'), ml.sigmoid())
        mps_grad = torch.autograd.grad(mps_loss, ml)[0]
        assert torch.isfinite(mps_loss) and torch.isfinite(mps_grad).all() and mps_grad.abs().sum() > 0
        le = abs(float(cpu_loss.detach())-float(mps_loss.detach().cpu()))
        ge = float((cpu_grad-mps_grad.cpu()).abs().max())
        assert le < 1e-5 and ge < 1e-5
        # Use the REAL training implementation for equivalence at c=0.
        technical_progress = []
        train.progress = lambda **kwargs: technical_progress.append(kwargs)
        reproduction = {}
        for dev_seed in train.DEV_SEEDS:
            dev_initial = train.base_model(dev_seed, data['dense'])
            dn, dh, dt = train.train_method(dev_seed, train.configuration('head9', .4), 1, dev_initial, data)
            assert dt['head_initial_sha256'] == lineage['expected_head_initialization_by_seed'][str(dev_seed)]
            assert dt['head_after_warm_sha256'] == lineage['expected_head_after_warm_by_seed'][str(dev_seed)]
            reproduction[str(dev_seed)] = {'head_initial_sha256':dt['head_initial_sha256'],
                'head_after_warm_sha256':dt['head_after_warm_sha256'], 'matches_historical':True}
            del dn, dh
        torch.manual_seed(301030)
        net = train.make_segmenter()
        initial = {k:v.detach().clone() for k,v in net.state_dict().items()}
        a, ah, at = train.train_method(301030, train.configuration('head9', .4), 8, initial, data)
        b, bh, bt = train.train_method(301030, train.configuration('cldice_head9', .4, 0.), 8, initial, data)
        ne = max(float((a.state_dict()[k]-b.state_dict()[k]).abs().max().cpu()) for k in a.state_dict())
        he = max(float((ah.state_dict()[k]-bh.state_dict()[k]).abs().max().cpu()) for k in ah.state_dict())
        assert ne == he == 0
        assert at['head_initial_sha256'] == bt['head_initial_sha256']
        assert at['head_after_warm_sha256'] == bt['head_after_warm_sha256']
        del a, ah, b, bh, net
        c, ch, ct = train.train_method(301030, train.configuration('cldice_head9', 4., 4.), 200, initial, data)
        torch.mps.synchronize()
        assert all(torch.isfinite(v).all() for v in c.state_dict().values())
        seconds_per_step = ct['seconds']/200
        del c, ch
        physics = physics_check()
        names = ['smoke.py','train.py','CONFIG.json','PROTOCOL.md','physics_adapter.py',
                 'vendor/cldice.py','vendor/soft_skeleton.py','VENDOR.json',
                 'INHERITED_DEV_RESULTS.json','INHERITED_DEV_LINEAGE.json']
        result = {'status': 'PASS_SMOKE_CHECK', 'MPS_available': True, 'fallback': '0',
            'training_ARCHIVE_used': str(old), 'no_new_TEST_opened': True,
            'experimental_training_started': False,
            'TRAIN_skeletons_changed_10_to24': changed,
            'all54_TRAIN_skeletons_stable_24_vs32': True,
            'all54_TRAIN_skeletons_nonempty': True,
            'actual_skeleton_iterations': train.make_cldice().soft_skeletonize.num_iter,
            'identity_fixture_losses': fixture_identity, 'false_break_fixture_loss': break_loss,
            'false_bridge_fixture_loss': bridge_loss, 'empty_prediction_loss': float(empty_loss),
            'full_target_skeleton_sum': full_skeleton_sum,
            'full_target_limitation': 'Author skeleton of all-full mask is empty; fully empty/full TRAIN targets are excluded by unchanged preprocessing.',
            'CPU_MPS_loss_max_error': le, 'CPU_MPS_gradient_max_error': ge,
            'zero_cldice_weight_segmenter_max_error': ne, 'zero_cldice_weight_head_max_error': he,
            'same_head_init_and_warm_at_zero_weight': True,
            'DEV_reproduction':reproduction, 'all_DEV_warm_states_match_historical':True,
            'expanded_weight_4_finite_training_checked':True,
            'physics_checks': physics,
            'timing_cldice24_200steps_seconds': ct['seconds'],
            'timing_cldice24_seconds_per_step': seconds_per_step,
            'projection_cldice26000steps_seconds': seconds_per_step*26000,
            'script_sha256': train.sha(Path(__file__)),
            'source_sha256': {n:train.sha(ROOT/n) for n in names},
            'input_old_DATA_sha256': train.sha(old), 'seconds': time.monotonic()-start}
        train.save(ROOT/'SMOKE_CHECK.json', result)
        print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        train.save(ROOT/'SMOKE_FAILURE.json', {'status':'FAIL_SMOKE_CHECK','error':str(error),'error_type':type(error).__name__,'experimental_training_started':False})
        raise
