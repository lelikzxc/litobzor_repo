"""Publish expanded-control comparison only after evaluation and audit.

CPU-only: this script neither fits models nor changes scientific inputs. The
same report structure is generated for PASS_PILOT and FAIL_PILOT.
"""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import os
import re
import time
from zoneinfo import ZoneInfo

os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/sem_cldice_expansion_mpl_20261102')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'sem_cldice_confirmation_20261030'
ARMS = ['head9', 'cldice_head9', 'soft']
NAMES = {'head9': 'Голова: 9 классов', 'cldice_head9': 'clDice + голова 9',
         'soft': 'Непрерывная регуляризация'}
COLORS = {'head9': '#8064A2', 'cldice_head9': '#C18A36', 'soft': '#087F8C'}
GEOMETRY_LABELS = {
    'false_break_rate': ('Потерянный путь', '% эталонных направлений с путём', 100),
    'false_connection_rate': ('Ложный путь', '% эталонных направлений без пути', 100),
    'grade_error_per_true_connected': ('Неверная ненулевая градация', '% эталонных направлений с путём', 100),
    'joint_connection_error_rate': ('Ошибка наличия пути на фрагменте', '% фрагментов', 100),
    'component_count_mae': ('Ошибка числа связных компонент', 'Средняя абсолютная ошибка, компонент/фрагмент', 1),
    'hole_count_mae': ('Ошибка числа отверстий', 'Средняя абсолютная ошибка, отверстий/фрагмент', 1),
    'component_count_exact_rate': ('Точное число связных компонент', '% фрагментов', 100),
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def save_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.partial')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def fmt(value, factor=100, places=3, signed=False):
    spec = f'+.{places}f' if signed else f'.{places}f'
    return format(factor * value, spec).replace('.', ',')


def interval(values, factor=100, places=3):
    return '[' + '; '.join(fmt(v, factor, places, signed=True) for v in values) + ']'


def write_csv(name, rows):
    assert rows
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with (ROOT / name).open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader(); writer.writerows(rows)


def save_figure(fig, name):
    for suffix in ['png', 'svg']:
        fig.savefig(ROOT / 'figures' / f'{name}.{suffix}', dpi=220, bbox_inches='tight')
    plt.close(fig)


def figures(result, geometry_per_seed, geometry_names):
    (ROOT / 'figures').mkdir(exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
        'axes.spines.top': False, 'axes.spines.right': False, 'svg.fonttype': 'none'})
    ns = len(result['seeds'])
    jitter = np.linspace(-.09, .09, ns)
    fig, axes = plt.subplots(1, 2, figsize=(12.4, 4.4), sharey=True)
    for j, family in enumerate(ARMS):
        metric = result['metrics'][family]
        for ax, key, per_key in zip(axes, ['mask_F1', 'IoU'], ['per_seed_mask_F1', 'per_seed_IoU']):
            values = np.array(metric[per_key]) * 100
            ax.scatter(values, j+jitter, color=COLORS[family], alpha=.52, s=30, zorder=2)
            ax.scatter([100*metric[key]], [j], marker='D', color=COLORS[family], s=65, zorder=3)
            ax.annotate(fmt(metric[key]), (100*metric[key], j), xytext=(7, 8),
                        textcoords='offset points', color=COLORS[family], fontsize=10)
    for ax, title in zip(axes, ['Класс из бинарной маски: Macro-F1, %', 'Сегментация металла: средний IoU, %']):
        ax.set_yticks(range(3), [NAMES[family] for family in ARMS])
        ax.set_title(title, loc='left', fontsize=11, pad=14)
        ax.grid(axis='x', alpha=.16); ax.set_axisbelow(True); ax.margins(x=.28)
    axes[0].set_ylim(2.5, -.5)
    fig.suptitle('Расширенный подбор контролей: новые кадры и инициализации', x=.03, ha='left', fontsize=14, weight='bold')
    fig.text(.03, .02, f"{result['test_examples']:,} фрагментов; 8 новых кадров одного чипа; 5 запусков. Точки — запуски, ромбы — средние.".replace(',', ' '),
             fontsize=9, color='#52606D')
    fig.tight_layout(rect=(0, .08, 1, .91), w_pad=3)
    save_figure(fig, 'comparison')

    fig, ax = plt.subplots(figsize=(11.3, 3.8))
    all_endpoints = [0., 1.]
    for j, family in enumerate(['head9', 'cldice_head9']):
        comparison = result['soft_minus_control'][family]
        point = comparison['delta'] * 100
        lo, hi = np.array(comparison['CI95']) * 100
        passed = all(comparison['gates'].values())
        color = '#087F8C' if passed else '#A85C38'
        ax.plot([lo, hi], [j, j], color=color, linewidth=2.4)
        ax.scatter([point], [j], s=50, color=color, zorder=3)
        gates = comparison['gates']
        yes = lambda value: 'да' if value else 'нет'
        status = ('PASS' if passed else 'FAIL') + ' — ' + '; '.join([
            'F1 ≥1 п.п.: '+yes(gates['gain_at_least_one_pp']),
            'CI >0: '+yes(gates['positive_CI_lower']),
            'IoU: '+yes(gates['IoU_guard'])])
        ax.annotate(f'{fmt(comparison["delta"],signed=True)} п.п.\n{status}', (hi, j),
                    xytext=(9, 8), textcoords='offset points', fontsize=9, color=color)
        all_endpoints += [lo, hi, point]
    ax.axvline(0, color='#8993A0', linestyle='--', linewidth=1)
    ax.axvline(1, color='#C18A36', linestyle=':', linewidth=1.2, label='Заранее заданный минимум: 1 п.п.')
    span = max(all_endpoints) - min(all_endpoints)
    span = max(span, 1.)
    ax.set_xlim(min(all_endpoints)-.12*span, max(all_endpoints)+.85*span)
    ax.set_yticks([0, 1], [NAMES['head9'], NAMES['cldice_head9']]); ax.set_ylim(1.55, -.55)
    ax.set_xlabel('Наш метод − контроль, п.п. Macro-F1 класса из маски')
    ax.set_title('Парные сравнения: 95%-интервалы по кадрам и запускам', loc='left', fontsize=12, pad=16)
    ax.grid(axis='x', alpha=.15); ax.legend(frameon=False, fontsize=9, loc='lower right')
    fig.text(.03, .02, 'Оба контроля зафиксированы до TEST. Все три условия должны выполняться против каждого контроля.',
             fontsize=9, color='#52606D')
    fig.tight_layout(rect=(0, .08, 1, 1))
    save_figure(fig, 'paired_comparisons')

    chosen = ['false_break_rate', 'false_connection_rate', 'grade_error_per_true_connected',
              'joint_connection_error_rate', 'component_count_mae', 'hole_count_mae']
    fig, axes = plt.subplots(2, 3, figsize=(13.2, 8.3))
    for ax, name in zip(axes.flat, chosen):
        title, ylabel, scale = GEOMETRY_LABELS[name]
        k = geometry_names.index(name)
        for j, family in enumerate(ARMS):
            point = result['metrics'][family]['geometry'][name]
            values = geometry_per_seed[:, j, k] * scale
            ax.bar(j, scale*point, color=COLORS[family], width=.62, alpha=.72)
            ax.scatter(j+jitter, values, color=COLORS[family], edgecolor='white', linewidth=.5, s=26, zorder=3)
            places = 2 if scale == 100 else 4
            ax.annotate(fmt(point, factor=scale, places=places), (j, float(values.max())),
                        xytext=(0, 6), textcoords='offset points', ha='center', fontsize=9)
        ax.set_xticks(range(3), ['Голова 9', 'clDice + голова', 'Наш метод'], rotation=12, ha='right')
        ax.set_title(title, loc='left', fontsize=10, pad=12)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.grid(axis='y', alpha=.14); ax.set_axisbelow(True)
        top = max(ax.get_ylim()[1], .001)
        ax.set_ylim(0, top * 1.18)
    fig.suptitle('Вторичные геометрические показатели', x=.03, ha='left', fontsize=14, weight='bold')
    fig.text(.03, .015, 'Столбцы — средние, точки — 5 запусков. Эти показатели не меняют основной критерий PASS/FAIL.',
             fontsize=9, color='#52606D')
    fig.tight_layout(rect=(0, .05, 1, .94), w_pad=2.4, h_pad=2.2)
    save_figure(fig, 'geometry_errors')


def execution_timing(name):
    path = ROOT / f'{name.upper()}_EXECUTION.json'
    if not path.exists():
        return None
    row = load(path.name)
    if row.get('status') != 'COMPLETE' or 'ended_UTC' not in row:
        return None
    start = datetime.datetime.fromisoformat(row['started_UTC'])
    end = datetime.datetime.fromisoformat(row['ended_UTC'])
    return {'seconds': (end-start).total_seconds(),
            'start_Moscow': start.astimezone(ZoneInfo('Europe/Moscow')).isoformat(),
            'end_Moscow': end.astimezone(ZoneInfo('Europe/Moscow')).isoformat()}


def clean_spacing(text):
    return re.sub(r'(?<=[А-Яа-яёЁ])(?=\d)|(?<=\d)(?=[А-Яа-яёЁ])', ' ', text)


def setting_text(row):
    if row['family'] == 'soft': return f"p={row['physics_weight']:g}"
    if row['family'] == 'head9': return f"h={row['head_weight']:g}"
    return f"h={row['head_weight']:g}; c={row['cldice_weight']:g}"


def main():
    started = time.monotonic()
    required = ['RESULT.json','AUDIT.json','DEV_RESULTS.json','ALL_DEV_RESULTS.json',
        'INHERITED_DEV_RESULTS.json','INHERITED_DEV_LINEAGE.json','SELECTION.json',
        'FINAL_VAL_RESULTS.json','TRAINING_COMPLETE.json','SMOKE_CHECK.json',
        'DATA_MANIFEST.json','FROZEN.json','CONFIG.json','BOOTSTRAP.npz','PREDICTIONS.npz']
    before = {name: sha(ROOT/name) for name in required}
    result = load('RESULT.json'); audit = load('AUDIT.json'); dev = load('DEV_RESULTS.json')
    inherited = load('INHERITED_DEV_RESULTS.json'); all_dev = load('ALL_DEV_RESULTS.json')
    lineage = load('INHERITED_DEV_LINEAGE.json'); selection = load('SELECTION.json')
    final_val = load('FINAL_VAL_RESULTS.json'); training = load('TRAINING_COMPLETE.json')
    smoke = load('SMOKE_CHECK.json'); data = load('DATA_MANIFEST.json')
    frozen = load('FROZEN.json'); config = load('CONFIG.json')
    assert audit['status'] == 'PASS_AUDIT' and all(audit['checks'].values())
    assert result['status'] in ['PASS_PILOT','FAIL_PILOT']
    assert result['arms'] == ARMS and result['seeds'] == config['final_seeds']
    assert result['primary_controls'] == config['primary_controls'] == ['head9','cldice_head9']
    assert len(dev)==20 and len(inherited)==30 and all_dev==inherited+dev
    assert len(all_dev)==50 and len(final_val)==15
    assert len(selection['all_VAL_configurations'])==23
    assert selection['candidate_counts']=={'head9':5,'cldice_head9':17,'soft':1}
    assert selection['physics_fixed_before_new_DEV'] is True
    assert selection['chosen']['soft']['physics_weight']==config['physics_weight']==.4
    assert training['backbone_steps']==52800 and training['head_only_steps']==6000
    assert training['total_weights']==len(training['checkpoint_hashes'])==40
    assert training['new_DEV_models']==20 and training['inherited_DEV_models']==30
    assert training['DEV_head_initialization_matches_inherited'] is True
    assert training['DEV_head_after_warm_matches_inherited'] is True
    assert smoke['status']=='PASS_SMOKE_CHECK'
    assert smoke['actual_skeleton_iterations']==config['cldice_iterations']==24
    assert smoke['all_DEV_warm_states_match_historical'] is True
    hash_pairs = [('SELECTION.json',training['selection_sha256']),('FROZEN.json',training['frozen_sha256']),
        ('PROTOCOL.md',frozen['protocol_sha256']),('CONFIG.json',frozen['config_sha256']),
        ('DATA_MANIFEST.json',frozen['manifest_sha256']),('PREDICTIONS.npz',result['predictions_sha256']),
        ('BOOTSTRAP.npz',result['bootstrap_sha256']),('INHERITED_DEV_RESULTS.json',frozen['inherited_results_sha256']),
        ('INHERITED_DEV_LINEAGE.json',frozen['inherited_lineage_sha256'])]
    assert all(sha(ROOT/name)==expected for name,expected in hash_pairs)
    assert all(sha(ROOT/name)==value for name,value in frozen['source_sha256'].items())
    assert (ROOT/'INHERITED_DEV_RESULTS.json').read_bytes()==(OLD/'DEV_RESULTS.json').read_bytes()
    assert all(sha(OLD/name)==value for name,value in lineage['files_sha256'].items())
    assert all(sha(OLD/'models'/name)==value for name,value in lineage['dev_models_sha256'].items())
    assert len(lineage['dev_models_sha256'])==30 and len(lineage['numerical_core_AST_sha256'])==13
    for family in ['head9','cldice_head9']:
        value=result['soft_minus_control'][family]
        expected={'gain_at_least_one_pp':value['delta']>=config['minimum_F1_gain'],
            'positive_CI_lower':value['CI95'][0]>0,'IoU_guard':value['IoU_delta']>=-config['maximum_IoU_drop']}
        assert expected==value['gates']
    passed=all(all(value['gates'].values()) for value in result['soft_minus_control'].values())
    assert passed==(result['status']=='PASS_PILOT')
    with np.load(ROOT/'BOOTSTRAP.npz',allow_pickle=False) as z:
        geometry_names=z['geometry_metric_names'].tolist()
        geometry_per_seed=z['geometry_numerators'].sum(2)/z['geometry_denominators'].sum(2)
    figures(result,geometry_per_seed,geometry_names)
    for name,rows in [('inherited_dev_results.csv',inherited),('new_dev_results.csv',dev),
        ('all_dev_results.csv',all_dev),('val_configurations.csv',selection['all_VAL_configurations']),
        ('final_val_results.csv',final_val)]: write_csv(name,rows)
    test_rows=[]; geometry_rows=[]
    for a,family in enumerate(ARMS):
        metric=result['metrics'][family]
        for s,seed in enumerate(result['seeds']):
            test_rows.append({'seed':seed,'family':family,'mask_F1':metric['per_seed_mask_F1'][s],
                'IoU':metric['per_seed_IoU'][s],'direct_head_F1':metric.get('per_seed_direct_head_F1',[None]*5)[s]})
            geometry_rows.extend({'seed':seed,'family':family,'metric':name,
                'value':float(geometry_per_seed[s,a,k]),'scope':'secondary_descriptive'} for k,name in enumerate(geometry_names))
        geometry_rows.extend({'seed':'mean','family':family,'metric':name,
            'value':metric['geometry'][name],'scope':'secondary_descriptive'} for name in geometry_names)
    write_csv('final_test_results.csv',test_rows);write_csv('secondary_geometry.csv',geometry_rows)
    write_csv('secondary_geometry_comparisons.csv',[
        {'control':family,'metric':name,'improvement':value['improvement'],'CI95_lower':value['CI95'][0],
         'CI95_upper':value['CI95'][1],'scope':value['status']}
        for family,values in result['secondary_geometry'].items() for name,value in values.items()])
    results_table=['| Метод | Macro-F1 класса из маски, % | IoU, % | Прямая голова: F1, % |','|---|---:|---:|---:|']
    selection_table=['| Метод | Вес головы h | Вес clDice c | Вес физики p | VAL F1, % | VAL IoU, % |','|---|---:|---:|---:|---:|---:|']
    for family in ARMS:
        metric=result['metrics'][family];chosen=selection['chosen'][family]
        direct=fmt(metric['direct_head_F1']) if 'direct_head_F1' in metric else '—'
        results_table.append(f'| {NAMES[family]} | {fmt(metric["mask_F1"])} | {fmt(metric["IoU"])} | {direct} |')
        selection_table.append(f'| {NAMES[family]} | {chosen["head_weight"]:g} | {chosen["cldice_weight"]:g} | '
            f'{chosen["physics_weight"]:g} | {fmt(chosen["mask_F1"])} | {fmt(chosen["IoU"])} |')
    comparisons_table=['| Контроль | Наш метод − контроль, п.п. F1 | 95%-интервал, п.п. | Разность IoU, п.п. | ≥1 п.п. F1 | Нижняя CI >0 | IoU ≥−2 п.п. |','|---|---:|---|---:|---|---|---|']
    failed=[]
    labels={'gain_at_least_one_pp':'выигрыш среднего F1 минимум1п.п.',
        'positive_CI_lower':'положительная нижняя граница интервала','IoU_guard':'ограничение ухудшения IoU'}
    for family in ['head9','cldice_head9']:
        value=result['soft_minus_control'][family];gates=value['gates']
        comparisons_table.append(f'| {NAMES[family]} | {fmt(value["delta"],signed=True)} | '
            f'{interval(value["CI95"])} | {fmt(value["IoU_delta"],signed=True)} | '+' | '.join('PASS' if gates[k] else 'FAIL' for k in labels)+' |')
        failed.extend(f'{NAMES[family]}: {label}' for key,label in labels.items() if not gates[key])
    seed_table=['| Seed | Голова 9: F1, % | clDice + голова: F1, % | Наш метод: F1, % | Δ к голове 9, п.п. | Δ к clDice, п.п. |','|---:|---:|---:|---:|---:|---:|']
    for s,seed in enumerate(result['seeds']):
        m=result['metrics']
        seed_table.append(f'| {seed} | {fmt(m["head9"]["per_seed_mask_F1"][s])} | {fmt(m["cldice_head9"]["per_seed_mask_F1"][s])} | '
            f'{fmt(m["soft"]["per_seed_mask_F1"][s])} | {fmt(result["soft_minus_control"]["head9"]["per_seed_deltas"][s],signed=True)} | '
            f'{fmt(result["soft_minus_control"]["cldice_head9"]["per_seed_deltas"][s],signed=True)} |')
    inherited_ids={row['config_id'] for row in inherited}
    rank=lambda row:(row['mask_F1'],row['IoU'],-row['weight'],-row['cldice_weight'])
    old_best={family:max([row for row in selection['all_VAL_configurations'] if row['family']==family
        and row['config_id'] in inherited_ids],key=rank) for family in ['head9','cldice_head9']}
    improvement_rows=[]
    old_new_table=['| Контроль | Прежняя настройка | Прежний VAL F1, % | Выбранная настройка | Новый VAL F1, % | Разность VAL, п.п. |','|---|---|---:|---|---:|---:|']
    for family in ['head9','cldice_head9']:
        old=old_best[family];new=selection['chosen'][family];delta=new['mask_F1']-old['mask_F1']
        assert delta>=0
        old_new_table.append(f'| {NAMES[family]} | {setting_text(old)} | {fmt(old["mask_F1"])} | {setting_text(new)} | {fmt(new["mask_F1"])} | {fmt(delta,signed=True)} |')
        improvement_rows.append({'family':family,'old_setting':setting_text(old),'old_mask_F1':old['mask_F1'],
            'new_setting':setting_text(new),'new_mask_F1':new['mask_F1'],'VAL_gain':delta})
    write_csv('old_vs_expanded_VAL.csv',improvement_rows)
    boundary=[];h=selection['chosen']['head9'];cl=selection['chosen']['cldice_head9']
    if h['head_weight']==4:boundary.append('обычная голова h=4')
    if cl['head_weight']==4:boundary.append('голова при clDice h=4')
    if cl['cldice_weight']==4:boundary.append('clDice c=4')
    boundary_note=('Выбранные параметры на верхней границе нового диапазона: '+', '.join(boundary)+'. '
        if boundary else 'Выбранные веса не находятся на новой верхней границе4. ')
    boundary_note+='Конечный поиск до4 не гарантирует глобальный оптимум всех контрольных моделей и настроек.'
    geometry_table=['| Вторичный показатель | Голова 9 | clDice + голова | Наш метод |','|---|---:|---:|---:|']
    geometry_ci_table=['| Контроль | Показатель | Улучшение | Номинальный 95%-интервал |','|---|---|---:|---|']
    for name in geometry_names:
        label,unit,factor=GEOMETRY_LABELS[name]
        geometry_table.append('| '+label+' ('+unit+') | '+' | '.join(fmt(result['metrics'][family]['geometry'][name],factor,3 if factor==100 else 5) for family in ARMS)+' |')
    for family in ['head9','cldice_head9']:
        for name in geometry_names:
            label,unit,factor=GEOMETRY_LABELS[name];value=result['secondary_geometry'][family][name]
            geometry_ci_table.append(f'| {NAMES[family]} | {label} | {fmt(value["improvement"],factor,3 if factor==100 else 5,signed=True)} | {interval(value["CI95"],factor,3 if factor==100 else 5)} |')
    if passed:
        verdict=('Заранее заданный критерий выполнен против обоих расширенно настроенных контролей. '
            'На новых кадрах этого чипа опыт поддерживает пользу фиксированной резисторной регуляризации '
            'относительно головы и проверенного варианта clDice.')
        reasons='Невыполненных обязательных условий нет.'
        inference_note=''
    else:
        verdict=('Заранее заданный критерий преимущества фиксированной резисторной регуляризации против обоих '
            'расширенно настроенных контролей не выполнен. Текущий опыт не подтверждает более сильное '
            'утверждение; прежний PASS сохраняется отдельно как результат своего протокола.')
        reasons='Не выполнены условия:\n\n'+'\n'.join('- '+item+'.' for item in failed)
        both_include_zero=all(value['CI95'][0]<=0<=value['CI95'][1]
                              for value in result['soft_minus_control'].values())
        inference_note=('Невыполнение критерия превосходства не устанавливает эквивалентность методов. '
            + ('Оба доверительных интервала разностей F1 включают ноль: этот опыт также не '
               'установил статистически убедительного ухудшения нашей регуляризации. '
               if both_include_zero else
               'Направление и неопределённость различий нужно оценивать по приведённым интервалам. '))
        if all(result['metrics']['soft']['IoU']>result['metrics'][family]['IoU']
               for family in ['head9','cldice_head9']):
            inference_note+=('Средний IoU нашей модели выше обоих контролей, но это вторичный результат: '
                'он не отменяет невыполнение первичного критерия Macro-F1 и не переводит опыт в PASS.')
    counts_table=['| Класс (LR, TB) | Фрагментов TEST |','|---|---:|']
    counts_table += [f'| {k} ({k//3}, {k%3}) | {count} |' for k,count in enumerate(result['test_class_counts'])]
    download=load('DOWNLOAD.json');timing={name:execution_timing(name) for name in ['train','evaluate','audit']}
    time_rows=['| Этап | Новое измеренное время, с | Источник |','|---|---:|---|',
        f'| Загрузка новых8кадров | {download["seconds"]:.2f} | DOWNLOAD.json |',
        f'| Подготовка данных | {data["seconds"]:.2f} | DATA_MANIFEST.json |',
        f'| Проверки и воспроизведение прогрева | {smoke["seconds"]:.2f} | SMOKE_CHECK.json |',
        f'| Новое обучение, включая подбор | {training["seconds"]:.2f} | TRAINING_COMPLETE.json |',
        f'| TEST, геометрия и bootstrap | {result["seconds"]:.2f} | RESULT.json |',
        f'| Независимый аудит | {audit["seconds"]:.2f} | AUDIT.json |']
    for name,value in timing.items():
        if value:time_rows.append(f'| Полный процесс {name} | {value["seconds"]:.2f} | {name.upper()}_EXECUTION.json |')
    chronology=''
    if timing['train'] and timing['audit']:
        begin=datetime.datetime.fromisoformat(timing['train']['start_Moscow']);end=datetime.datetime.fromisoformat(timing['audit']['end_Moscow'])
        chronology=f'Начало обучения {begin:%H:%M:%S}, окончание аудита {end:%H:%M:%S} по Москве; между ними {(end-begin).total_seconds()/60:.2f}мин, включая паузы между этапами.'
    holes=result['truth_hole_histogram']
    holes_note=('Во всех эталонах нет отверстий: показатель измеряет лишь их ложное появление, а не сохранение настоящих отверстий.'
        if set(holes)=={'0'} else 'Распределение отверстий эталона: '+json.dumps(holes,ensure_ascii=False)+'.')
    positives={family:sum(v>0 for v in result['soft_minus_control'][family]['per_seed_deltas']) for family in ['head9','cldice_head9']}
    report=f'''# Расширенный подбор контролей: проверка SEM-гипотезы

2 ноября 2026 года. **{result['status']}**. Технический аудит: **{audit['status']}**.

{verdict}

## Постановка и данные

В опыте30октября лучшие веса контролей были равны1 — верхней границе сетки.
Новый опыт расширяет диапазон до4 и проверяет результат на других кадрах и seed.
Общий сегментатор, **54 плотные маски**, **1152 слабых примера** и **695 VAL**.
TRAIN/VAL переиспользованы точно; тренер читает отдельный архив без TEST.
Маски слабых примеров не передаются оптимизаторам. Метки рассчитаны по SVG;
стоимость производственной разметки не измерена.

Маршрут: SEM → бинарная маска материала → прежняя резисторная модель →
девять модельных геометрических классов. Это не экспертные производственные
дефекты и не измеренная проводимость изделия.

TEST: **{result['test_examples']} фрагментов** восьми новых кадров
{', '.join(map(str,result['test_frames']))}; новые seed {', '.join(map(str,result['seeds']))}.
Один физический чип; новые кадры не означают внешнюю межчиповую репликацию.

## Результаты и установленное решение

{chr(10).join(results_table)}

![Основные результаты и пять запусков](figures/comparison.png)

Прямые выходы голов вторичны: параметры выбирались для класса из маски,
поэтому это не отдельно оптимизированные прямые классификаторы.

PASS требует против ОБОИХ контролей средний выигрыш≥1п.п. Macro-F1,
нижнюю границу каждого парного95%-интервала>0 и ухудшение IoU не более2п.п.
Решение без округления. Минимум1п.п. относится к среднему, не к каждому seed
и не к нижней границе интервала.

{chr(10).join(comparisons_table)}

{reasons}

{inference_note}

![Парные сравнения с обоими контролями](figures/paired_comparisons.png)

Интервалы:4000парных пересэмплирований исходных кадров и seed. Матрицы ошибок
сначала суммируются по выбранным кадрам, затем усредняется F1 выбранных seed.
Фрагменты и повторные обучения не объявляются независимыми чипами.

{chr(10).join(seed_table)}

Положительная разность к голове9 в{positives['head9']}из5запусков, к clDice —
в{positives['cldice_head9']}из5. Все запуски опубликованы, включая ухудшения.
Последние веса; итоговый VAL не менял настройки или срок обучения.

## Выбор расширенных контролей

{chr(10).join(old_new_table)}

Это сравнение VAL, а не перенос прежних TEST-чисел. Старые лучшие настройки
входят в новый пул; более слабый по VAL контроль не выбирается вместо них.
По сравнению с опытом30октября одновременно изменились настройки контролей,
тестовые кадры и итоговые seed. Поэтому изменение наблюдаемого выигрыша нельзя
приписывать только расширению подбора весов. Текущий опыт проверяет устойчивость
утверждения о превосходстве в новой заранее заданной проверке; причинный вклад
одного изменения HPO отдельно не измерялся.

{chr(10).join(selection_table)}

{boundary_note}

DEV seed3011и3041, по1000шагов. Новые точки: head h∈{{2,4}}; clDice(h,c)∈{{1,2,4}}²,
кроме прежней пары(1,1): всего20 новых обучений. Пул выбора —5 вариантов головы,
17clDice и **единственная фиксированная soft p=0.4**, всего23 настройки.
Физика повторно не подбирается. Выбор контроля: средние VAL F1, затем IoU,
затем меньшие h и c. У clDice больший бюджет поиска. Допуск VAL≥0.45 выполнен.

## Наследование и равноправность

Все30 прежних DEV-оценок скопированы побайтно. SHA30исходных DEV-весов и
их метаданные проверены, файлы остаются в прежней папке. Новых строк20,
ALL_DEV_RESULTS содержит50. Для выбора нужны46строк (23настройки×2seed);
4прежние строки других весов физики сохранены, но не участвуют в выборе.

Все13численно значимых функций AST-идентичны старому коду, torch2.10.0
сохранён. Восстановлены общие400-шаговые BCE-прогревы DEV. SHA инициализации
голов и состояния после200head-only шагов совпали с историческими точно.
При несовпадении смешение старых/новых оценок запрещено; проверки прошли.

Каждый новый FINAL seed: общий400-шаговый прогрев, затем три метода по2000шагов.
Одинаковые начальные веса сегментатора и индексы батчей. Две головы одинаково
инициализированы и прогреты200шагами на замороженных признаках; у soft головы
нет. Равенство полной ёмкости и полного времени вычислений не заявляется.
AdamW lr0.001,wd0.0001; batch16плотных+16слабых. Новая работа:52800обновлений
сегментатора и6000head-only. Сохранены40новых весов:20DEV+15FINAL+5FINAL-base.
30старых DEV-весов входят в проверяемую цепочку, не в новое время обучения.

clDice использует только54плотные маски;1152классовые метки доступны обеим
головам и физике без плотных масок. Авторские исходники неизменны, commit
47d31a6cc4a8101b1ffe8052994821961e57af9f. Фабрика задаёт24итерации, smooth1,
один канал металла, exclude_background=False; отдельная Dice loss не добавлена.
24итерации стабильны на54TRAIN-масках; CPU/MPS, градиенты, нулевая ветвьclDice
и исторические головы повторно проверены. Новых поправок в протокол нет.
Поправка10→24относится к прежнему опыту30октября.

## Вторичные геометрические показатели

{chr(10).join(geometry_table)}

Разрыв — потеря эталонного четырёхсвязного граничного пути; знаменатель — все
эталонные направления с путём. Ложное соединение делится на направления без
пути. Ненулевая градация делится на эталонные направления с путём. На фрагменте
ошибка наличия пути означает хотя бы одно ошибочное направление. Число
компонент не зависит от порога проводимости, но не определяет всю топологию.
Это ошибки геометрии маски, не установленные физические отказы.

![Вторичные показатели всех запусков](figures/geometry_errors.png)

{chr(10).join(geometry_ci_table)}

Для ошибок улучшение=контроль−soft, для точного совпадения=soft−контроль.
Разности долей — в процентных пунктах. Интервалы вторичные номинальные,
без поправки на множественные показатели; они не меняют PASS/FAIL и не
доказывают причинный механизм. {holes_note}

## Разбиение, время, аудит

{chr(10).join(counts_table)}

Новые кадры выбраны по SHA до загрузки, исключены62прежних кадра. Прежняя
предобработка:512-пиксельная граница, усреднение4×4, маска по большинству,
12×12шаг6, исключение пустых/полных масок. D4-мотивы и полутоновые ключи
исключены относительно объединения манифестов28и30октября и новых кадров.
Близкие мотивы и пространственная зависимость одного чипа остаются.

{chr(10).join(time_rows)}

{chronology}

Внутренний таймер и полный процесс стадии не складываются. Загрузка относится
к успешной попытке; сетевые неудачи сохранены отдельно. Подготовка кода и паузы
не входят в таймер обучения. Это не время обработки одного изображения.

Аудит независимо проверил источники, SHA, изоляцию TRAIN/VAL, старые и новые
DEV, прогрев, выбор23кандидатов с фиксированной физикой, F1/IoU, все bootstrap
другим способом, геометрию и сохранённый MPS-вывод против CPU. Ошибка F1
{audit['independent_sklearn_F1_max_error']:.3g}, IoU{audit['independent_IoU_max_error']:.3g},
bootstrap{audit['independent_bootstrap_max_error']:.3g}, CPU/MPS-вероятности
{audit['CPU_MPS_max_probability_error']:.3g}. Технический PASS_AUDIT не заменяет
научный PASS_PILOT/FAIL_PILOT.

Ограничения: один чип, CNN10681параметр,12×12, модельные классы по SVG.
Реальные отказы, измеренная проводимость, стоимость разметки, межчиповый
перенос и мировая/публикационная новизна не проверялись. Конечное расширение
весов не устанавливает превосходство над всеми clDice и классификаторами.

## Материалы

- [Протокол](PROTOCOL.md), [параметры](CONFIG.json), [данные](DATA_MANIFEST.json),
  [технические проверки](SMOKE_CHECK.json), [зафиксированные входы](FROZEN.json).
- [Результат](RESULT.json), [аудит](AUDIT.json), [выбор по VAL](SELECTION.json),
  [завершение обучения](TRAINING_COMPLETE.json).
- [30прежнихDEV](inherited_dev_results.csv), [20новыхDEV](new_dev_results.csv),
  [все50строк](all_dev_results.csv), [23настройкиVAL](val_configurations.csv),
  [прежние/новые контроли по VAL](old_vs_expanded_VAL.csv).
- [Итоговый VAL](final_val_results.csv), [15итоговыхTEST](final_test_results.csv),
  [геометрия](secondary_geometry.csv), [геометрические сравнения](secondary_geometry_comparisons.csv).
- [Наследованные оценки](INHERITED_DEV_RESULTS.json), [их SHA-цепочка](INHERITED_DEV_LINEAGE.json),
  [новые веса](CHECKPOINT_HASHES.json).
- [Подготовка](prepare.py), [обучение](train.py), [оценка](evaluate.py),
  [независимый аудит](audit.py), [графики и отчёт](report.py).

Сохранены исходные PNG/SVG, архивы данных,40новых весов, все классы,
упакованные маски, выходы голов, геометрия и индексы bootstrap.
'''
    (ROOT/'REPORT.md').write_text(clean_spacing(report),encoding='utf-8')
    readme=f'''# Расширение контрольных методов SEM, 2 ноября 2026

**{result['status']}**; независимый аудит **{audit['status']}**.

{verdict}

[Полный отчёт с числами, графиками и ограничениями](REPORT.md).

20новых DEV-обучений дополнены30прежними оценками с проверенной SHA-цепочкой.
Контроли выбраны из5вариантов головы и17clDice; физика0.4зафиксирована.
Три метода проверены на{result['test_examples']}новых фрагментах восьми кадров
одного чипа и пяти новых инициализациях. Сохранены40новых весов и все прогнозы;
30прежних DEV-весов остаются в исходном каталоге и доступны по манифесту.
Классы модельные геометрические; физические производственные отказы и
межчиповый перенос этим опытом не проверялись. Старые результаты неизменны.

Код лежит рядом. Для нового научного опыта нужен новый каталог с протоколом.

```bash
cat gipoteza/sem_cldice_expansion_20261102/PROGRESS.json
tail -n 20 gipoteza/sem_cldice_expansion_20261102/progress.jsonl
```
'''
    (ROOT/'README.md').write_text(clean_spacing(readme),encoding='utf-8')
    assert before=={name:sha(ROOT/name) for name in required}
    manifest={'status':'REPORT_COMPLETE','scientific_status':result['status'],
        'report_sha256':sha(ROOT/'REPORT.md'),'result_sha256':sha(ROOT/'RESULT.json'),
        'audit_sha256':sha(ROOT/'AUDIT.json'),'code_sha256':sha(Path(__file__)),
        'figures_sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'figures').iterdir())},
        'csv_sha256':{p.name:sha(p) for p in sorted(ROOT.glob('*.csv'))},
        'input_sha256':before,'scientific_inputs_unchanged':True,'seconds':time.monotonic()-started}
    save_json(ROOT/'REPORT_MANIFEST.json',manifest)
    print(json.dumps({'status':manifest['status'],'scientific_status':result['status'],'audit':audit['status'],
        'report':str(ROOT/'REPORT.md'),'figures':len(manifest['figures_sha256']),'seconds':manifest['seconds']},ensure_ascii=False))


if __name__=='__main__':main()
