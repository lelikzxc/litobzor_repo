"""Independent CPU arithmetic/provenance audit of the control expansion.

This audit does not train, run new MPS inference, alter selection or redefine
the scientific PASS gate. CPU replay is compared with saved MPS fixtures.
"""
from pathlib import Path
import ast
import hashlib
import json
import re
import sys
import time

import numpy as np
from scipy import ndimage, sparse
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import spsolve
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits
import torch

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'sem_cldice_confirmation_20261030'
ORIGINAL = ROOT.parent / 'sem_confirmation_20261028'
sys.path.insert(0, str(ROOT))
from train import make_segmenter, make_head, make_cldice

ARMS = ['head9', 'cldice_head9', 'soft']
SEEDS = [4111, 4157, 4211, 4253, 4297]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(value):
    path = ROOT / 'AUDIT.json'
    temporary = path.with_suffix('.json.partial')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def independent_direction(mask):
    """Sparse Kirchhoff solution restricted to components joining electrodes."""
    a = np.asarray(mask, dtype=bool); size = a.shape[0]
    assert a.shape == (12, 12)
    edges = [(y * size + x, yy * size + xx)
             for y in range(size) for x in range(size)
             for yy, xx in [(y + 1, x), (y, x + 1)]
             if yy < size and xx < size and a[y, x] and a[yy, xx]]
    if not edges:
        return 0
    u = np.array([p[0] for p in edges]); v = np.array([p[1] for p in edges])
    graph = sparse.csr_matrix((np.ones(2 * len(u)), (np.r_[u, v], np.r_[v, u])), shape=(144, 144))
    _, membership = connected_components(graph, directed=False)
    left = np.arange(0, 144, 12); right = np.arange(11, 144, 12)
    common = np.intersect1d(membership[left[a[:, 0]]], membership[right[a[:, -1]]])
    if not len(common):
        return 0
    active = np.isin(membership, common)
    graph = graph.multiply(active[:, None] * active[None, :]).tocsr()
    lap = sparse.diags(np.asarray(graph.sum(1)).ravel()) - graph
    free = np.array([12 * y + x for y in range(12) for x in range(1, 11) if active[12 * y + x]])
    matrix = lap[free][:, free]
    rhs = -np.asarray(lap[free][:, right].sum(1)).ravel()
    potential = spsolve(matrix.tocsc(), rhs)
    response = float(lap[right][:, right].sum() - rhs @ potential) / (12 / 11)
    return 0 if response < 1e-8 else 1 if response < .5 - 1e-8 else 2


def characteristics(mask):
    """Independent per-image 2D labels: beta0,beta1,LR,TB."""
    m = np.asarray(mask, dtype=bool)
    fg, count = ndimage.label(m, structure=ndimage.generate_binary_structure(2, 1))
    lr = bool((set(fg[:, 0]) & set(fg[:, -1])) - {0})
    tb = bool((set(fg[0]) & set(fg[-1])) - {0})
    bg, nb = ndimage.label(~m, structure=np.ones((3, 3), dtype=bool))
    border = set(np.concatenate((bg[0], bg[-1], bg[:, 0], bg[:, -1]))) - {0}
    return int(count), int(nb - len(border)), lr, tb


def canonical_keys(masks, raw=False):
    """Independent minimum among rotations and reflected rotations."""
    m = np.asarray(masks)
    variants = []
    for mirrored in [False, True]:
        source = m[:, :, ::-1] if mirrored else m
        variants.extend(np.rot90(source, k, axes=(1, 2)) for k in range(4))
    if raw:
        encoded = [v.astype('<u2') for v in variants]
        return [hashlib.sha256(min(v[i].tobytes() for v in encoded)).hexdigest() for i in range(len(m))]
    encoded = [np.packbits(v.reshape(len(m), -1), axis=1) for v in variants]
    return [min(v[i].tobytes() for v in encoded).hex() for i in range(len(m))]


def macro_from_confusion(c):
    denominator = c.sum(-1) + c.sum(-2)
    diagonal = np.diagonal(c, axis1=-2, axis2=-1)
    return np.divide(2 * diagonal, denominator, out=np.zeros_like(diagonal, dtype=float),
                     where=denominator > 0).mean(-1)


def static_training_input_check(frozen):
    text = (ROOT / 'train.py').read_text()
    tree = ast.parse(text)
    calls = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name) and node.func.value.id == 'np' and node.func.attr == 'load':
                calls.append(ast.get_source_segment(text, node.args[0]))
    return (calls == ["ROOT / 'TRAIN_VAL.npz'"]
            and frozen['training_archive'] == 'TRAIN_VAL.npz'
            and frozen['training_has_no_TEST_tensors'] is True
            and frozen['weak_data_has_no_mask_key'] is True), calls


def independent_selection(config, selection):
    new_rows = json.loads((ROOT / 'DEV_RESULTS.json').read_text())
    inherited = json.loads((ROOT / 'INHERITED_DEV_RESULTS.json').read_text())
    rows = inherited + new_rows
    all_rows = json.loads((ROOT / 'ALL_DEV_RESULTS.json').read_text())
    assert rows == all_rows and len(inherited) == 30 and len(new_rows) == 20
    old_weights = [.1, .4, 1.]
    head_weights = old_weights + [2., 4.]
    old_cl = {(h, c) for h in old_weights for c in old_weights}
    expanded_cl = {(h, c) for h in [1., 2., 4.] for c in [1., 2., 4.]}
    pools = {
        'head9': [(h, 0.) for h in head_weights],
        'cldice_head9': sorted(old_cl | expanded_cl),
        'soft': [(.4, 0.)],
    }
    expected_new = {('head9', h, 0.) for h in [2., 4.]}
    expected_new |= {('cldice_head9', h, c) for h, c in expanded_cl if (h, c) != (1., 1.)}
    assert len(expected_new) == 10
    assert {(r['family'], r['weight'], r['cldice_weight']) for r in new_rows} == expected_new
    assert all(sorted(r['seed'] for r in new_rows
                      if (r['family'], r['weight'], r['cldice_weight']) == key) == config['dev_seeds']
               for key in expected_new)
    settings = []
    for arm in ARMS:
        for weight, cl_weight in pools[arm]:
            chosen_rows = [r for r in rows if r['family'] == arm
                           and r['weight'] == weight and r['cldice_weight'] == cl_weight]
            assert len(chosen_rows) == len(config['dev_seeds'])
            assert sorted(r['seed'] for r in chosen_rows) == sorted(config['dev_seeds'])
            assert len({r['config_id'] for r in chosen_rows}) == 1
            settings.append({
                'family': arm, 'weight': float(weight),
                'head_weight': 0. if arm == 'soft' else float(weight),
                'physics_weight': float(weight) if arm == 'soft' else 0.,
                'cldice_weight': float(cl_weight), 'config_id': chosen_rows[0]['config_id'],
                'mask_F1': float(np.mean([r['mask_F1'] for r in chosen_rows])),
                'IoU': float(np.mean([r['IoU'] for r in chosen_rows])),
            })
    rank = lambda r: (r['mask_F1'], r['IoU'], -r['weight'], -r['cldice_weight'])
    chosen = {arm: max([r for r in settings if r['family'] == arm], key=rank)
              for arm in ['head9', 'cldice_head9']}
    chosen['soft'] = next(r for r in settings if r['family'] == 'soft')
    match = (len(rows) == 50 and len(settings) == 23 and chosen == selection['chosen']
             and {r['config_id']: r for r in settings}
             == {r['config_id']: r for r in selection['all_VAL_configurations']}
             and all(r['mask_F1'] >= .45 for r in chosen.values())
             and selection['selection_uses_TEST'] is False
             and selection['physics_fixed_before_new_DEV'] is True
             and config['physics_weight'] == chosen['soft']['physics_weight'] == .4
             and selection['primary_controls'] == ['head9', 'cldice_head9'])
    # Parameter metadata in every saved final checkpoint must match frozen VAL.
    final_rows = json.loads((ROOT / 'FINAL_VAL_RESULTS.json').read_text())
    for row in final_rows:
        for key in ['weight', 'head_weight', 'cldice_weight', 'physics_weight', 'config_id']:
            match &= row[key] == chosen[row['family']][key]
    match &= len(final_rows) == 15
    return bool(match), chosen


def inherited_dev_check(frozen, complete):
    """Check inherited points and exact warm starts without trusting new ranks."""
    lineage = json.loads((ROOT / 'INHERITED_DEV_LINEAGE.json').read_text())
    source = (ROOT / lineage['source_root']).resolve()
    assert source == OLD.resolve()
    inherited = json.loads((ROOT / 'INHERITED_DEV_RESULTS.json').read_text())
    new_rows = json.loads((ROOT / 'DEV_RESULTS.json').read_text())
    old_complete = json.loads((source / 'TRAINING_COMPLETE.json').read_text())
    checks = {
        'inherited_lineage_frozen': sha(ROOT / 'INHERITED_DEV_LINEAGE.json') == frozen['inherited_lineage_sha256'],
        'inherited_results_frozen': sha(ROOT / 'INHERITED_DEV_RESULTS.json') == frozen['inherited_results_sha256'],
        'inherited_results_exact_bytes': (ROOT / 'INHERITED_DEV_RESULTS.json').read_bytes() == (source / 'DEV_RESULTS.json').read_bytes(),
        'inherited_DEV_source_hash': sha(source / 'DEV_RESULTS.json') == lineage['source_DEV_RESULTS_sha256'],
        'inherited_source_files_unchanged': all(sha(source / name) == h for name, h in lineage['files_sha256'].items()),
        'inherited_DEV_model_count': len(lineage['dev_models_sha256']) == 30,
        'inherited_DEV_model_hashes': all(
            name.startswith('dev_') and sha(source / 'models' / name) == h == old_complete['checkpoint_hashes'][name]
            for name, h in lineage['dev_models_sha256'].items()),
    }
    warm_matches = True
    for seed in [3011, 3041]:
        old = [r for r in inherited if r['seed'] == seed and r['family'] != 'soft']
        current = [r for r in new_rows if r['seed'] == seed]
        init = {r['head_initial_sha256'] for r in old}
        warm = {r['head_after_warm_sha256'] for r in old}
        warm_matches &= len(init) == len(warm) == 1
        warm_matches &= all(r['head_initial_sha256'] in init and r['head_after_warm_sha256'] in warm for r in current)
        warm_matches &= lineage['expected_head_initialization_by_seed'][str(seed)] in init
        warm_matches &= lineage['expected_head_after_warm_by_seed'][str(seed)] in warm
        warm_matches &= complete['head_initialization_equal_by_seed'][str(seed)] in init
        warm_matches &= complete['head_after_warm_equal_by_seed'][str(seed)] in warm
    checks['inherited_DEV_warm_starts_exactly_reproduced'] = bool(warm_matches)
    # Core training routines must be unchanged; global budgets and candidate
    # construction differ, but the numerical update used for old points does not.
    old_ast = ast.parse((source / 'train.py').read_text())
    new_ast = ast.parse((ROOT / 'train.py').read_text())
    names = ['hard_classes', 'make_head', 'head_classes', 'head_loss', 'make_cldice',
             'configuration', 'selection_rank', 'load_training', 'evaluate',
             'base_model', 'train_method', 'state_digest', 'checkpoint']
    old_funcs = {n.name: ast.dump(n, include_attributes=False) for n in old_ast.body
                 if isinstance(n, ast.FunctionDef)}
    new_funcs = {n.name: ast.dump(n, include_attributes=False) for n in new_ast.body
                 if isinstance(n, ast.FunctionDef)}
    checks['inherited_numerical_training_core_unchanged'] = all(old_funcs[n] == new_funcs[n] for n in names)
    return checks


def main():
    start = time.monotonic(); torch.set_num_threads(2)
    result = json.loads((ROOT / 'RESULT.json').read_text())
    frozen = json.loads((ROOT / 'FROZEN.json').read_text())
    complete = json.loads((ROOT / 'TRAINING_COMPLETE.json').read_text())
    selection = json.loads((ROOT / 'SELECTION.json').read_text())
    manifest = json.loads((ROOT / 'DATA_MANIFEST.json').read_text())
    config = json.loads((ROOT / 'CONFIG.json').read_text())
    evaluation_frozen = json.loads((ROOT / 'EVALUATION_FROZEN.json').read_text())
    smoke = json.loads((ROOT / 'SMOKE_CHECK.json').read_text())
    vendor = json.loads((ROOT / 'VENDOR.json').read_text())
    fixed_names = ['DATA.npz', 'TRAIN_VAL.npz', 'TEST.npz', 'DATA_MANIFEST.json',
                   'PROTOCOL.md', 'CONFIG.json', 'train.py', 'prepare.py',
                   'PREDICTIONS.npz', 'BOOTSTRAP.npz', 'RESULT.json',
                   'SELECTION.json', 'TRAINING_COMPLETE.json', 'FROZEN.json',
                   'INHERITED_DEV_RESULTS.json', 'INHERITED_DEV_LINEAGE.json',
                   'ALL_DEV_RESULTS.json', 'DEV_RESULTS.json']
    before = {p: sha(ROOT / p) for p in fixed_names}
    checks = {}
    checks['frozen_inputs'] = bool(
        before['DATA.npz'] == frozen['data_sha256'] == manifest['DATA_sha256']
        and before['TRAIN_VAL.npz'] == frozen['train_val_sha256'] == manifest['TRAIN_VAL_sha256']
        and before['TEST.npz'] == manifest['TEST_sha256']
        and before['DATA_MANIFEST.json'] == frozen['manifest_sha256']
        and before['PROTOCOL.md'] == frozen['protocol_sha256'] == config['protocol_sha256'] == manifest['protocol_sha256']
        and before['CONFIG.json'] == frozen['config_sha256']
        and before['train.py'] == frozen['script_sha256']
        and before['prepare.py'] == manifest['prepare_script_sha256']
        and before['SELECTION.json'] == complete['selection_sha256'] == evaluation_frozen['selection_sha256']
        and before['FROZEN.json'] == complete['frozen_sha256']
        and before['TRAINING_COMPLETE.json'] == evaluation_frozen['training_complete_sha256']
        and sha(ROOT / 'evaluate.py') == result['analysis_sha256'] == evaluation_frozen['script_sha256']
        and sha(ROOT / 'EVALUATION_FROZEN.json') == result['evaluation_frozen_sha256']
        and before['PREDICTIONS.npz'] == result['predictions_sha256']
        and before['BOOTSTRAP.npz'] == result['bootstrap_sha256'])
    checks['code_source_hashes'] = all(sha(ROOT / p) == h for p, h in frozen['source_sha256'].items())
    checks['source_image_hashes'] = all(sha(ROOT / p) == h for p, h in manifest['sources_sha256'].items())
    checks['inherited_source_image_hashes'] = (
        Path(manifest['inherited_source_root']).resolve() == ORIGINAL.resolve()
        and all(sha(ORIGINAL / p) == h for p, h in manifest['inherited_source_files_sha256'].items()))
    checks['inherited_data_lineage'] = (sha(OLD / 'DATA.npz') == manifest['inherited_data_sha256']
                                        and sha(OLD / 'DATA_MANIFEST.json') == manifest['inherited_manifest_sha256'])
    checks['both_prior_data_sources_unchanged'] = (
        set(manifest['prior_data_sha256']) == {
            '../sem_confirmation_20261028/DATA.npz', '../sem_cldice_confirmation_20261030/DATA.npz'}
        and all(sha(ROOT / p) == h for p, h in manifest['prior_data_sha256'].items())
        and all(sha(ROOT / p) == h for p, h in manifest['prior_manifests_sha256'].items()))
    checks['vendor_unmodified'] = (vendor['source_modifications'] is False
        and vendor['commit'] == '47d31a6cc4a8101b1ffe8052994821961e57af9f'
        and all(sha(ROOT / 'vendor' / p) == row['sha256'] for p, row in vendor['files'].items()))
    checks['cldice_iterations_fixed_before_training'] = (
        config['cldice_iterations'] == frozen['cldice_iterations'] == 24
        and make_cldice().soft_skeletonize.num_iter == 24)
    plan = json.loads((ROOT / 'SOURCE_PLAN.json').read_text())
    shared = ROOT.parent / 'shared_data/ic_sem_m2'
    historical = json.loads((shared / 'SOURCE_MEMBERS.json').read_text())
    excluded = {int(re.search(r'sem(\d+)\.png', row['path']).group(1))
                for row in historical['png_original_sources']}
    excluded |= set(json.loads((ORIGINAL / 'RESULT.json').read_text())['test_frames'])
    excluded |= set(json.loads((OLD / 'RESULT.json').read_text())['test_frames'])
    listing = json.loads((shared / 'sem_zip_listing.json').read_text())
    available = [int(m.group(1)) for row in listing
                 if (m := re.fullmatch(r'dataset/sems/m2/sem(\d+)\.png', row['name']))
                 and int(m.group(1)) not in excluded]
    available.sort(key=lambda i: hashlib.sha256(('SEM-CLDICE-EXPAND-20261102/' + str(i)).encode()).hexdigest())
    checks['source_plan_frozen_and_selection_recomputed'] = (
        sha(ROOT / 'SOURCE_PLAN.json') == manifest['source_plan_sha256']
        and plan['protocol_sha256'] == before['PROTOCOL.md']
        and plan['prepare_script_sha256'] == before['prepare.py']
        and plan['test'] == config['test_frames'] == available[:8]
        and plan['selection_prefix'] == 'SEM-CLDICE-EXPAND-20261102/'
        and len(excluded) == 62 and plan['excluded_previous_frames'] == sorted(excluded)
        and all(sha(shared / p) == h for p, h in plan['shared_sha256'].items()))
    checks['smoke_hashes'] = (sha(ROOT / 'SMOKE_CHECK.json') == frozen['smoke_sha256']
        and smoke['status'] == 'PASS_SMOKE_CHECK'
        and all(sha(ROOT / p) == h for p, h in smoke['source_sha256'].items()))
    checks['checkpoint_hashes'] = (complete['total_weights'] == 40 and len(complete['checkpoint_hashes']) == 40
        and all(sha(ROOT / 'models' / p) == h for p, h in complete['checkpoint_hashes'].items()))
    checks['training_counts'] = (complete['backbone_steps'] == 52800 and complete['head_only_steps'] == 6000
        and complete['last_weights_only'] is True and complete['TEST_opened'] is False)
    checks['physics_fixed_before_new_DEV'] = (
        frozen['physics_weight_fixed'] == complete['physics_weight_fixed'] == config['physics_weight'] == .4
        and selection['physics_fixed_before_new_DEV'] is True
        and complete['DEV_head_initialization_matches_inherited'] is True
        and complete['DEV_head_after_warm_matches_inherited'] is True)
    checks.update(inherited_dev_check(frozen, complete))
    checks['trainer_separate_input'], np_load_calls = static_training_input_check(frozen)
    checks['VAL_selection_recomputed'], chosen = independent_selection(config, selection)
    # Preserve exact inherited TRAIN/VAL, including dtype and ordering.
    with np.load(ROOT / 'DATA.npz', allow_pickle=False) as z:
        data = {k: z[k] for k in z.files}
    with np.load(ROOT / 'TRAIN_VAL.npz', allow_pickle=False) as z:
        tv = {k: z[k] for k in z.files}
    with np.load(ROOT / 'TEST.npz', allow_pickle=False) as z:
        test = {k: z[k] for k in z.files}
    with np.load(OLD / 'DATA.npz', allow_pickle=False) as z:
        old = {k: z[k] for k in z.files}
    with np.load(ORIGINAL / 'DATA.npz', allow_pickle=False) as z:
        older = {k: z[k] for k in z.files}
    inherited_ids = np.flatnonzero(old['role'] != 'test')
    checks['TRAIN_VAL_exactly_inherited'] = (len(inherited_ids) == 1901
        and manifest['inherited_record_indices'] == inherited_ids.tolist()
        and set(tv) == {'X', 'Y', 'label', 'role', 'frame'}
        and all(tv[k].dtype == old[k].dtype and np.array_equal(tv[k], old[k][inherited_ids]) for k in tv)
        and all(np.array_equal(data[k][:1901], tv[k]) and np.array_equal(data[k][1901:], test[k]) for k in tv)
        and set(tv['role'].tolist()) == {'dense', 'weak', 'val'})
    indices = np.flatnonzero(data['role'] == 'test')
    target = data['Y'][indices, 0].astype(bool)
    truth = data['label'][indices]; frames = data['frame'][indices]
    test_frames = set(frames.tolist())
    checks['frame_split_disjoint'] = (not set(tv['frame']) & test_frames
        and not set(old['frame']) & test_frames
        and not set(older['frame']) & test_frames
        and test_frames == set(config['test_frames']) == {170, 253, 270, 102, 260, 204, 244, 122})
    records = manifest['records']
    checks['manifest_row_metadata'] = (len(records) == len(data['role'])
        and [r['role'] for r in records] == data['role'].tolist()
        and [r['frame'] for r in records] == data['frame'].tolist()
        and [r['label'] for r in records] == data['label'].tolist())
    mask_keys = canonical_keys(data['Y'][:, 0].astype(bool))
    raw_values = np.rint(data['X'][:, 0].astype(float) * (16 * 255)).astype(np.uint16)
    raw_keys = canonical_keys(raw_values, raw=True)
    old_mask_keys = canonical_keys(old['Y'][:, 0].astype(bool))
    old_raw_values = np.rint(old['X'][:, 0].astype(float) * (16 * 255)).astype(np.uint16)
    old_raw_keys = canonical_keys(old_raw_values, raw=True)
    older_mask_keys = canonical_keys(older['Y'][:, 0].astype(bool))
    older_raw_values = np.rint(older['X'][:, 0].astype(float) * (16 * 255)).astype(np.uint16)
    older_raw_keys = canonical_keys(older_raw_values, raw=True)
    checks['D4_keys_recomputed'] = (mask_keys == [r['canonical_D4'] for r in records]
                                   and raw_keys == [r['raw_D4_sha256'] for r in records])
    checks['D4_all_new_unique'] = len(set(mask_keys)) == len(mask_keys) and len(set(raw_keys)) == len(raw_keys)
    checks['new_TEST_excludes_ALL_old_motifs'] = (
        not set(mask_keys[1901:]) & (set(old_mask_keys) | set(older_mask_keys))
        and not set(raw_keys[1901:]) & (set(old_raw_keys) | set(older_raw_keys)))
    checks['test_data_gate'] = (min(np.bincount(truth, minlength=9)) >= 16
        and all(len(set(frames[truth == c])) >= 4 for c in range(9)))
    checks['result_test_metadata'] = (result['test_examples'] == len(truth)
        and result['test_frames'] == sorted(test_frames)
        and result['test_class_counts'] == np.bincount(truth, minlength=9).tolist())
    with np.load(ROOT / 'PREDICTIONS.npz', allow_pickle=False) as z:
        pred = z['mask_predictions']; packed = z['packed_masks']; stored_iou = z['IoU']
        fixtures = z['fixture_probabilities']; saved_truth_topology = z['truth_topology']
        saved_pred_topology = z['predicted_topology']; saved_direction_events = z['directional_events']
        saved_joint_events = z['joint_events']
        direct = {family: z[f'direct_{family}'] for family in ['head9', 'cldice_head9']}
        logits = {family: z[f'logits_{family}'] for family in direct}
        checks['prediction_alignment'] = (np.array_equal(indices, z['source_indices'])
            and np.array_equal(truth, z['truth']) and np.array_equal(frames, z['frames'])
            and z['seeds'].tolist() == SEEDS == result['seeds']
            and z['arms'].tolist() == ARMS == result['arms'])
    with np.load(ROOT / 'BOOTSTRAP.npz', allow_pickle=False) as z:
        stored_draws = z['scores']; seed_ids = z['seed_ids']; frame_ids = z['frame_ids']
        original_confusion = z['confusion']; geometry_stored = z['geometry_scores']
        geometry_names = z['geometry_metric_names'].tolist()
    ns = len(SEEDS); na = len(ARMS); n = len(truth)
    unique_frames, gid = np.unique(frames, return_inverse=True); nf = len(unique_frames)
    true_direction = np.column_stack((truth // 3, truth % 3))
    truth_topology = np.asarray([characteristics(m) for m in target], dtype=np.int16)
    topology_mismatches = int(np.count_nonzero(truth_topology != saved_truth_topology))
    path_mismatches = int(np.count_nonzero(truth_topology[:, 2:] != (true_direction > 0)))
    matrices = np.zeros((ns, na, nf, 9, 9), dtype=np.int64)
    geom_num = np.zeros((ns, na, nf, len(geometry_names)), dtype=float)
    geom_den = np.zeros_like(geom_num)
    f1_error = 0.; iou_error = 0.; probability_error = 0.; head_logit_error = 0.
    geometry_error = 0.; event_mismatches = 0; direct_decode_ok = True
    with threadpool_limits(limits=2):
        for s, seed in enumerate(SEEDS):
            for a, family in enumerate(ARMS):
                masks = np.unpackbits(packed[s, a], axis=1, count=144).reshape(n, 12, 12).astype(bool)
                score = f1_score(truth, pred[s, a], labels=range(9), average='macro', zero_division=0)
                f1_error = max(f1_error, abs(score - result['metrics'][family]['per_seed_mask_F1'][s]))
                intersection = (target & masks).sum((1, 2)); union = (target | masks).sum((1, 2))
                iou = np.divide(intersection, union, out=np.ones(n, dtype=float), where=union > 0)
                iou_error = max(iou_error, float(np.max(np.abs(iou - stored_iou[s, a]))),
                    abs(float(iou.mean()) - result['metrics'][family]['per_seed_IoU'][s]))
                topo = np.asarray([characteristics(m) for m in masks], dtype=np.int16)
                topology_mismatches += int(np.count_nonzero(topo != saved_pred_topology[s, a]))
                pd = np.column_stack((pred[s, a] // 3, pred[s, a] % 3))
                path_mismatches += int(np.count_nonzero(topo[:, 2:] != (pd > 0)))
                breaks = (truth_topology[:, 2:] > 0) & (topo[:, 2:] == 0)
                false_connections = (truth_topology[:, 2:] == 0) & (topo[:, 2:] > 0)
                grades = (true_direction > 0) & (pd > 0) & (true_direction != pd)
                conn_errors = (breaks | false_connections).any(1)
                grade_only = ~conn_errors & grades.any(1)
                ev = breaks.astype(np.uint8) + 2 * false_connections.astype(np.uint8) + 3 * grades.astype(np.uint8)
                je = conn_errors.astype(np.uint8) + 2 * grade_only.astype(np.uint8)
                event_mismatches += int(np.count_nonzero(ev != saved_direction_events[s, a]))
                event_mismatches += int(np.count_nonzero(je != saved_joint_events[s, a]))
                abs_c = np.abs(topo[:, 0] - truth_topology[:, 0])
                abs_h = np.abs(topo[:, 1] - truth_topology[:, 1])
                metric_values = {
                    'false_break_rate': (breaks.sum(1), (true_direction > 0).sum(1)),
                    'false_connection_rate': (false_connections.sum(1), (true_direction == 0).sum(1)),
                    'grade_error_per_true_connected': (grades.sum(1), (true_direction > 0).sum(1)),
                    'joint_connection_error_rate': (conn_errors, np.ones(n)),
                    'component_count_mae': (abs_c, np.ones(n)),
                    'hole_count_mae': (abs_h, np.ones(n)),
                    'component_count_exact_rate': (abs_c == 0, np.ones(n)),
                }
                for g in range(nf):
                    keep = gid == g
                    matrices[s, a, g] = np.bincount(9 * truth[keep] + pred[s, a, keep], minlength=81).reshape(9, 9)
                    for k, metric in enumerate(geometry_names):
                        numerator, denominator = metric_values[metric]
                        geom_num[s, a, g, k] = numerator[keep].sum()
                        geom_den[s, a, g, k] = denominator[keep].sum()
                checkpoint = torch.load(ROOT / 'models' / f'final_{family}_{seed}.pt', map_location='cpu', weights_only=True)
                settings = checkpoint['settings']
                for key in ['weight', 'head_weight', 'cldice_weight', 'physics_weight', 'config_id']:
                    assert settings[key] == chosen[family][key], (family, seed, key)
                net = make_segmenter(); net.load_state_dict(checkpoint['segmenter']); net.eval()
                x = torch.tensor(5 * (data['X'][indices[:24]] - .2))
                with torch.inference_mode():
                    features = net[:-1](x)
                    out = net[-1](features).sigmoid().numpy()
                    probability_error = max(probability_error, float(np.max(np.abs(out - fixtures[s, a]))))
                    if family != 'soft':
                        head = make_head(family); head.load_state_dict(checkpoint['head']); head.eval()
                        h = head(features.flatten(1)).numpy()
                        head_logit_error = max(head_logit_error, float(np.max(np.abs(h - logits[family][s, :24]))))
                if family in direct:
                    direct_decode_ok &= np.array_equal(logits[family][s].argmax(-1), direct[family][s])
                    direct_score = f1_score(truth, direct[family][s], labels=range(9), average='macro', zero_division=0)
                    f1_error = max(f1_error, abs(direct_score - result['metrics'][family]['per_seed_direct_head_F1'][s]))
                print(json.dumps({'stage': 'AUDIT_MASKS', 'seed': seed, 'family': family}), flush=True)
    checks['full_confusion_recomputed'] = np.array_equal(matrices, original_confusion)
    for a, family in enumerate(ARMS):
        f1_error = max(f1_error, abs(float(macro_from_confusion(matrices[:, a].sum(1)).mean())
                                    - result['metrics'][family]['mask_F1']))
        iou_error = max(iou_error, abs(float(stored_iou[:, a].mean()) - result['metrics'][family]['IoU']))
        if family in direct:
            independent_direct = np.mean([f1_score(truth, y, labels=range(9), average='macro', zero_division=0)
                                          for y in direct[family]])
            f1_error = max(f1_error, abs(float(independent_direct) - result['metrics'][family]['direct_head_F1']))
    # Recompute bootstrap indices too; avoid assuming the saved RNG seed.
    rng = np.random.default_rng(211102)
    checks['bootstrap_indices_recomputed'] = (np.array_equal(seed_ids, rng.integers(0, ns, (4000, ns)))
        and np.array_equal(frame_ids, rng.integers(0, nf, (4000, nf))))
    seed_weights = np.array([np.bincount(draw, minlength=ns) for draw in seed_ids])
    frame_weights = np.array([np.bincount(draw, minlength=nf) for draw in frame_ids])
    weighted_matrices = np.einsum('bf,safij->bsaij', frame_weights.astype(float), matrices.astype(float))
    seed_scores = macro_from_confusion(weighted_matrices)
    independent_draws = (np.einsum('bs,bsa->ba', seed_weights, seed_scores) / ns).T
    bootstrap_error = float(np.max(np.abs(independent_draws - stored_draws)))
    gnum = np.einsum('bf,safk->bsak', frame_weights, geom_num)
    gden = np.einsum('bf,safk->bsak', frame_weights, geom_den)
    geometry_draws = np.einsum('bs,bsak->bak', seed_weights, gnum / gden) / ns
    geometry_bootstrap_error = float(np.max(np.abs(geometry_draws - geometry_stored)))
    gpoint = (geom_num.sum(2) / geom_den.sum(2)).mean(0)
    for a, family in enumerate(ARMS):
        for k, metric in enumerate(geometry_names):
            geometry_error = max(geometry_error, abs(gpoint[a, k] - result['metrics'][family]['geometry'][metric]))
    soft = ARMS.index('soft'); point = macro_from_confusion(matrices.sum(2)).mean(0)
    primary_gates = {}; gate_value_error = 0.; secondary_ci_error = 0.
    for family in ['head9', 'cldice_head9']:
        a = ARMS.index(family)
        delta = point[soft] - point[a]
        ci = np.quantile(independent_draws[soft] - independent_draws[a], [.025, .975])
        iou_delta = stored_iou[:, soft].mean() - stored_iou[:, a].mean()
        own_gates = {'gain_at_least_one_pp': bool(delta >= .01), 'positive_CI_lower': bool(ci[0] > 0),
                     'IoU_guard': bool(iou_delta >= -.02)}
        saved = result['soft_minus_control'][family]
        primary_gates[family] = own_gates
        gate_value_error = max(gate_value_error, abs(delta - saved['delta']),
            float(np.max(np.abs(ci - saved['CI95']))), abs(iou_delta - saved['IoU_delta']))
        assert own_gates == saved['gates']
        for k, metric in enumerate(geometry_names):
            sign = 1 if metric == 'component_count_exact_rate' else -1
            gi = sign * (gpoint[soft, k] - gpoint[a, k])
            gci = np.quantile(sign * (geometry_draws[:, soft, k] - geometry_draws[:, a, k]), [.025, .975])
            saved_secondary = result['secondary_geometry'][family][metric]
            secondary_ci_error = max(secondary_ci_error, abs(gi - saved_secondary['improvement']),
                                     float(np.max(np.abs(gci - saved_secondary['CI95']))))
    should_pass = all(all(v.values()) for v in primary_gates.values())
    checks['scientific_gate_consistent'] = ((result['status'] == 'PASS_PILOT') == should_pass
        and result['status'] in ['PASS_PILOT', 'FAIL_PILOT']
        and result['primary_controls'] == ['head9', 'cldice_head9'])
    # Balanced truth plus sixteen masks from each of fifteen trained outputs.
    selected_truth = np.concatenate([np.flatnonzero(truth == c)[:16] for c in range(9)])
    kirchhoff_checks = [(target[i], int(truth[i])) for i in selected_truth]
    rng = np.random.default_rng(811102)
    for s in range(ns):
        for a in range(na):
            selected = rng.choice(n, 16, replace=False)
            masks = np.unpackbits(packed[s, a, selected], axis=1, count=144).reshape(-1, 12, 12).astype(bool)
            kirchhoff_checks.extend((m, int(y)) for m, y in zip(masks, pred[s, a, selected]))
    with threadpool_limits(limits=2):
        checks['independent_sparse_classes_match'] = all(
            3 * independent_direction(m) + independent_direction(m.T) == y for m, y in kirchhoff_checks)
    checks['independent_sparse_class_count'] = len(kirchhoff_checks) == 384
    checks['all_topology_arrays_match'] = topology_mismatches == 0
    checks['all_paths_match_saved_classes'] = path_mismatches == 0
    checks['all_error_event_arrays_match'] = event_mismatches == 0
    checks['independent_F1_matches'] = f1_error < 1e-12
    checks['independent_IoU_matches'] = iou_error < 1e-12
    checks['direct_head_decode_matches'] = bool(direct_decode_ok)
    checks['CPU_MPS_probability_fixtures'] = probability_error < 1e-4
    checks['CPU_MPS_head_logit_fixtures'] = head_logit_error < 1e-3
    checks['independent_bootstrap_matches'] = bootstrap_error < 1e-12
    checks['independent_geometry_matches'] = geometry_error < 1e-12
    checks['independent_geometry_bootstrap_matches'] = geometry_bootstrap_error < 1e-12
    checks['primary_gate_values_match'] = gate_value_error < 1e-12
    checks['secondary_intervals_match'] = secondary_ci_error < 1e-12
    checks['all_audit_inputs_unchanged'] = before == {p: sha(ROOT / p) for p in fixed_names}
    protected_path = ROOT / 'PROTECTED_BEFORE.json'
    protected_count = 0
    if protected_path.exists():
        protected = json.loads(protected_path.read_text())
        protected_count = len(protected)
        checks['protected_old_files_unchanged'] = all(sha(ROOT.parent / p) == h for p, h in protected.items())
    audit = {
        'status': 'PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT',
        'checks': checks, 'np_load_training_arguments': np_load_calls,
        'input_sha256': before, 'script_sha256': sha(Path(__file__)),
        'independent_sklearn_F1_max_error': f1_error,
        'independent_IoU_max_error': iou_error,
        'CPU_MPS_max_probability_error': probability_error,
        'CPU_MPS_max_head_logit_error': head_logit_error,
        'independent_bootstrap_max_error': bootstrap_error,
        'independent_geometry_max_error': geometry_error,
        'independent_geometry_bootstrap_max_error': geometry_bootstrap_error,
        'primary_gate_value_max_error': gate_value_error,
        'secondary_CI_max_error': secondary_ci_error,
        'topology_value_mismatches': topology_mismatches, 'path_class_mismatches': path_mismatches,
        'error_event_mismatches': event_mismatches,
        'independent_sparse_class_cases': len(kirchhoff_checks),
        'protected_existing_files': protected_count, 'seconds': time.monotonic() - start,
        'scope': 'Technical audit of provenance, separate TRAIN/VAL, selection, masks, all bootstrap draws, geometric metrics and saved MPS/CPU fixtures. PASS_AUDIT is independent of PASS_PILOT/FAIL_PILOT.',
    }
    save(audit)
    print(json.dumps(audit, ensure_ascii=False), flush=True)
    assert audit['status'] == 'PASS_AUDIT', {k: v for k, v in checks.items() if not v}


if __name__ == '__main__':
    main()
