"""Evaluate frozen expanded-control comparison once on new fixed TEST frames.

MPS is required for model inference. Geometry, hard classes and paired
frame/seed bootstrap use CPU. No training or model/threshold selection occurs.
"""
from pathlib import Path
import hashlib
import json
import sys
import time

import numpy as np
from scipy import ndimage
from sklearn.metrics import f1_score
from threadpoolctl import threadpool_limits
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from train import make_segmenter, make_head, hard_classes, head_classes

ARMS = ['head9', 'cldice_head9', 'soft']
SEEDS = [4111, 4157, 4211, 4253, 4297]
BOOTSTRAP_REPETITIONS = 4000
BOOTSTRAP_SEED = 211102
GEOMETRY_METRICS = [
    'false_break_rate', 'false_connection_rate',
    'grade_error_per_true_connected', 'joint_connection_error_rate',
    'component_count_mae', 'hole_count_mae', 'component_count_exact_rate',
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    path = ROOT / name
    temporary = path.with_suffix(path.suffix + '.partial')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def topology(masks):
    """Vectorised isolated image planes: beta0, beta1, LR path, TB path."""
    masks = np.asarray(masks, dtype=bool)
    n = len(masks)
    s4 = np.zeros((3, 3, 3), dtype=bool)
    s4[1] = ndimage.generate_binary_structure(2, 1)
    foreground, count = ndimage.label(masks, structure=s4)
    owner = np.zeros(count + 1, dtype=np.int32)
    owner[foreground] = np.arange(n, dtype=np.int32)[:, None, None]
    components = np.bincount(owner[1:], minlength=n)
    lr_ids = np.intersect1d(np.unique(foreground[:, :, 0]), np.unique(foreground[:, :, -1]))
    tb_ids = np.intersect1d(np.unique(foreground[:, 0, :]), np.unique(foreground[:, -1, :]))
    lr = np.zeros(n, dtype=bool); tb = lr.copy()
    lr[owner[lr_ids[lr_ids != 0]]] = True
    tb[owner[tb_ids[tb_ids != 0]]] = True
    s8 = np.zeros((3, 3, 3), dtype=bool); s8[1] = True
    background, bg_count = ndimage.label(~masks, structure=s8)
    bg_owner = np.zeros(bg_count + 1, dtype=np.int32)
    bg_owner[background] = np.arange(n, dtype=np.int32)[:, None, None]
    border = np.concatenate((background[:, 0, :].ravel(), background[:, -1, :].ravel(),
                             background[:, :, 0].ravel(), background[:, :, -1].ravel()))
    touches = np.zeros(bg_count + 1, dtype=bool); touches[border] = True
    holes = np.flatnonzero(~touches); holes = holes[holes != 0]
    holes = np.bincount(bg_owner[holes], minlength=n)
    return np.stack((components, holes, lr, tb), axis=1).astype(np.int16)


def macro_from_confusion(confusion):
    den = confusion.sum(-1) + confusion.sum(-2)
    num = 2 * np.diagonal(confusion, axis1=-2, axis2=-1)
    return np.divide(num, den, out=np.zeros_like(num, dtype=float), where=den > 0).mean(-1)


def verify_frozen_inputs(frozen, complete, manifest):
    checks = {
        'protocol': sha(ROOT / 'PROTOCOL.md') == frozen['protocol_sha256'] == manifest['protocol_sha256'],
        'training_script': sha(ROOT / 'train.py') == frozen['script_sha256'],
        'training_arrays': sha(ROOT / 'TRAIN_VAL.npz') == frozen['train_val_sha256'],
        'data': sha(ROOT / 'DATA.npz') == frozen['data_sha256'] == manifest['DATA_sha256'],
        'manifest': sha(ROOT / 'DATA_MANIFEST.json') == frozen['manifest_sha256'],
        'config': sha(ROOT / 'CONFIG.json') == frozen['config_sha256'],
        'selection': sha(ROOT / 'SELECTION.json') == complete['selection_sha256'],
        'frozen': sha(ROOT / 'FROZEN.json') == complete['frozen_sha256'],
        'code_sources': all(sha(ROOT / p) == h for p, h in frozen['source_sha256'].items()),
        'checkpoints': all(sha(ROOT / 'models' / p) == h for p, h in complete['checkpoint_hashes'].items()),
        'inherited_dev_results': sha(ROOT / 'INHERITED_DEV_RESULTS.json') == frozen['inherited_results_sha256'],
        'inherited_dev_lineage': sha(ROOT / 'INHERITED_DEV_LINEAGE.json') == frozen['inherited_lineage_sha256'],
        'fixed_physics': frozen['physics_weight_fixed'] == complete['physics_weight_fixed'] == .4,
    }
    assert all(checks.values()), checks
    return checks


def main():
    started = time.monotonic()
    assert torch.backends.mps.is_available(), 'Explicit MPS inference; no silent fallback'
    assert not (ROOT / 'RESULT.json').exists(), 'Do not overwrite the single frozen TEST result'
    assert not (ROOT / 'PREDICTIONS.npz').exists(), 'Do not overwrite frozen TEST predictions'
    complete = json.loads((ROOT / 'TRAINING_COMPLETE.json').read_text())
    assert complete['status'] == 'COMPLETE_TRAINING_NO_TEST_OPENED'
    frozen = json.loads((ROOT / 'FROZEN.json').read_text())
    manifest = json.loads((ROOT / 'DATA_MANIFEST.json').read_text())
    selection = json.loads((ROOT / 'SELECTION.json').read_text())
    assert selection['status'] == 'FROZEN_BEFORE_TEST'
    checks = verify_frozen_inputs(frozen, complete, manifest)
    assert set(selection['chosen']) == set(ARMS)
    assert selection['physics_fixed_before_new_DEV'] is True
    assert selection['chosen']['soft']['physics_weight'] == .4
    evaluation_frozen = {
        'script_sha256': sha(Path(__file__)), 'selection_sha256': sha(ROOT / 'SELECTION.json'),
        'training_complete_sha256': sha(ROOT / 'TRAINING_COMPLETE.json'),
        'data_sha256': sha(ROOT / 'DATA.npz'), 'bootstrap_repetitions': BOOTSTRAP_REPETITIONS,
        'bootstrap_seed': BOOTSTRAP_SEED, 'arms': ARMS, 'seeds': SEEDS,
        'primary_controls': ['head9', 'cldice_head9'], 'input_checks': checks,
        'geometry_metrics_status': 'Secondary descriptive measurements; no separate PASS gate',
    }
    save('EVALUATION_FROZEN.json', evaluation_frozen)
    torch.set_num_threads(2)
    with threadpool_limits(limits=2), np.load(ROOT / 'DATA.npz', allow_pickle=False) as data:
        source_indices = np.flatnonzero(data['role'] == 'test')
        x = data['X'][source_indices]
        target = data['Y'][source_indices, 0].astype(bool)
        truth = data['label'][source_indices]
        frames = data['frame'][source_indices]
    assert len(source_indices) > 0
    assert set(frames.tolist()) == {170, 253, 270, 102, 260, 204, 244, 122}
    n = len(truth); ns = len(SEEDS); na = len(ARMS)
    frame_values, gid = np.unique(frames, return_inverse=True)
    nf = len(frame_values)
    truth_direction = np.column_stack((truth // 3, truth % 3))
    truth_topology = topology(target)
    assert np.array_equal(truth_topology[:, 2:], truth_direction > 0)
    predictions = np.empty((ns, na, n), dtype=np.int64)
    packed_masks = np.empty((ns, na, n, 18), dtype=np.uint8)
    ious = np.empty((ns, na, n), dtype=float)
    predicted_topology = np.empty((ns, na, n, 4), dtype=np.int16)
    directional_events = np.empty((ns, na, n, 2), dtype=np.uint8)
    joint_events = np.empty((ns, na, n), dtype=np.uint8)
    fixtures = np.empty((ns, na, min(24, n), 1, 12, 12), dtype=np.float32)
    direct = {family: [] for family in ['head9', 'cldice_head9']}
    logits_all = {family: [] for family in direct}
    confusion = np.zeros((ns, na, nf, 9, 9), dtype=np.int32)
    geometry_num = np.zeros((ns, na, nf, len(GEOMETRY_METRICS)), dtype=float)
    geometry_den = np.zeros_like(geometry_num)
    rows = []
    with threadpool_limits(limits=2):
        for s, seed in enumerate(SEEDS):
            for a, family in enumerate(ARMS):
                payload = torch.load(ROOT / 'models' / f'final_{family}_{seed}.pt',
                                     map_location='cpu', weights_only=True)
                net = make_segmenter().to('mps'); net.load_state_dict(payload['segmenter']); net.eval()
                head = None if payload['head'] is None else make_head(family).to('mps')
                if head is not None:
                    head.load_state_dict(payload['head']); head.eval()
                assert (head is None) == (family == 'soft')
                mask_parts = []; head_pred_parts = []; head_logit_parts = []
                with torch.inference_mode():
                    for offset in range(0, n, 256):
                        batch = torch.tensor(5 * (x[offset:offset + 256] - .2), device='mps')
                        if head is None:
                            logits = net(batch)
                        else:
                            features = net[:-1](batch); logits = net[-1](features)
                            h = head(features.flatten(1))
                            head_pred_parts.append(head_classes(h, family).cpu().numpy())
                            head_logit_parts.append(h.cpu().numpy())
                        mask_parts.append((logits[:, 0] >= 0).cpu().numpy())
                        if offset == 0:
                            fixtures[s, a] = logits[:min(24, n)].sigmoid().cpu().numpy()
                mask = np.concatenate(mask_parts)
                pred = hard_classes(mask)
                union = (mask | target).sum((1, 2))
                intersection = (mask & target).sum((1, 2))
                iou = np.divide(intersection, union, out=np.ones(n, dtype=float), where=union > 0)
                predictions[s, a] = pred
                packed_masks[s, a] = np.packbits(mask.reshape(n, -1), axis=1)
                ious[s, a] = iou
                tp = topology(mask); predicted_topology[s, a] = tp
                pd = np.column_stack((pred // 3, pred % 3))
                assert np.array_equal(tp[:, 2:], pd > 0)
                broken = (truth_direction > 0) & (pd == 0)
                joined = (truth_direction == 0) & (pd > 0)
                grade = (truth_direction > 0) & (pd > 0) & (truth_direction != pd)
                event = broken.astype(np.uint8) + 2 * joined.astype(np.uint8) + 3 * grade.astype(np.uint8)
                assert np.all((truth_direction == pd).astype(int) + broken + joined + grade == 1)
                directional_events[s, a] = event
                conn_error = (broken | joined).any(1)
                grade_only = ~conn_error & grade.any(1)
                joint_events[s, a] = conn_error.astype(np.uint8) + 2 * grade_only.astype(np.uint8)
                abs_component = np.abs(tp[:, 0] - truth_topology[:, 0])
                abs_hole = np.abs(tp[:, 1] - truth_topology[:, 1])
                geometry_values = [
                    (broken.sum(1), (truth_direction > 0).sum(1)),
                    (joined.sum(1), (truth_direction == 0).sum(1)),
                    (grade.sum(1), (truth_direction > 0).sum(1)),
                    (conn_error, np.ones(n)), (abs_component, np.ones(n)),
                    (abs_hole, np.ones(n)), (abs_component == 0, np.ones(n)),
                ]
                for k, (numerator, denominator) in enumerate(geometry_values):
                    geometry_num[s, a, :, k] = np.bincount(gid, weights=numerator, minlength=nf)
                    geometry_den[s, a, :, k] = np.bincount(gid, weights=denominator, minlength=nf)
                np.add.at(confusion[s, a], (gid, truth, pred), 1)
                row = {'seed': seed, 'family': family,
                       'mask_F1': float(f1_score(truth, pred, labels=range(9), average='macro', zero_division=0)),
                       'IoU': float(iou.mean())}
                if head is not None:
                    hp = np.concatenate(head_pred_parts)
                    direct[family].append(hp); logits_all[family].append(np.concatenate(head_logit_parts))
                    row['direct_head_F1'] = float(f1_score(truth, hp, labels=range(9), average='macro', zero_division=0))
                rows.append(row)
                save('EVALUATION_PROGRESS.json', {'completed': len(rows), 'total': ns * na, 'rows': rows,
                                                'seconds': time.monotonic() - started})
                print(json.dumps({'stage': 'TEST_EVALUATION', **row}), flush=True)
                del net, head
    np.savez_compressed(ROOT / 'PREDICTIONS.npz', mask_predictions=predictions,
        packed_masks=packed_masks, IoU=ious, fixture_probabilities=fixtures,
        source_indices=source_indices, truth=truth, frames=frames,
        seeds=np.array(SEEDS), arms=np.array(ARMS),
        direct_head9=np.array(direct['head9']), direct_cldice_head9=np.array(direct['cldice_head9']),
        logits_head9=np.array(logits_all['head9']), logits_cldice_head9=np.array(logits_all['cldice_head9']),
        truth_topology=truth_topology, predicted_topology=predicted_topology,
        directional_events=directional_events, joint_events=joint_events)
    point_per_seed = macro_from_confusion(confusion.sum(2))
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    seed_ids = rng.integers(0, ns, (BOOTSTRAP_REPETITIONS, ns))
    frame_ids = rng.integers(0, nf, (BOOTSTRAP_REPETITIONS, nf))
    draws = []
    for a in range(na):
        sampled = confusion[seed_ids[:, :, None], a, frame_ids[:, None, :]].sum(2)
        draws.append(macro_from_confusion(sampled).mean(1))
    draws = np.array(draws)
    sampled_num = geometry_num[seed_ids[:, :, None], :, frame_ids[:, None, :], :].sum(2)
    sampled_den = geometry_den[seed_ids[:, :, None], :, frame_ids[:, None, :], :].sum(2)
    assert (sampled_den > 0).all()
    geometry_scores = (sampled_num / sampled_den).mean(1)
    geometry_points = (geometry_num.sum(2) / geometry_den.sum(2)).mean(0)
    metrics = {}
    for a, family in enumerate(ARMS):
        metrics[family] = {'mask_F1': float(point_per_seed[:, a].mean()),
                          'per_seed_mask_F1': point_per_seed[:, a].tolist(),
                          'IoU': float(ious[:, a].mean()),
                          'per_seed_IoU': ious[:, a].mean(1).tolist(),
                          'geometry': dict(zip(GEOMETRY_METRICS, map(float, geometry_points[a])))}
        if family in direct:
            ds = [float(f1_score(truth, hp, labels=range(9), average='macro', zero_division=0))
                  for hp in direct[family]]
            metrics[family].update(direct_head_F1=float(np.mean(ds)), per_seed_direct_head_F1=ds)
    soft = ARMS.index('soft'); comparisons = {}; geometry_comparisons = {}
    for family in ['head9', 'cldice_head9']:
        a = ARMS.index(family)
        ci = np.quantile(draws[soft] - draws[a], [.025, .975])
        delta = metrics['soft']['mask_F1'] - metrics[family]['mask_F1']
        iou_delta = metrics['soft']['IoU'] - metrics[family]['IoU']
        comparisons[family] = {'delta': float(delta), 'CI95': ci.tolist(), 'IoU_delta': float(iou_delta),
            'per_seed_deltas': (point_per_seed[:, soft] - point_per_seed[:, a]).tolist(),
            'gates': {'gain_at_least_one_pp': bool(delta >= .01), 'positive_CI_lower': bool(ci[0] > 0),
                      'IoU_guard': bool(iou_delta >= -.02)}}
        geometry_comparisons[family] = {}
        for k, name in enumerate(GEOMETRY_METRICS):
            sign = 1 if name == 'component_count_exact_rate' else -1
            distribution = sign * (geometry_scores[:, soft, k] - geometry_scores[:, a, k])
            geometry_comparisons[family][name] = {
                'improvement': float(sign * (geometry_points[soft, k] - geometry_points[a, k])),
                'CI95': np.quantile(distribution, [.025, .975]).tolist(),
                'status': 'Secondary exploratory; nominal interval, no multiplicity correction or PASS gate',
            }
    passed = all(all(v['gates'].values()) for v in comparisons.values())
    np.savez_compressed(ROOT / 'BOOTSTRAP.npz', scores=draws, seed_ids=seed_ids, frame_ids=frame_ids,
        confusion=confusion, geometry_scores=geometry_scores,
        geometry_numerators=geometry_num, geometry_denominators=geometry_den,
        geometry_metric_names=np.array(GEOMETRY_METRICS))
    result = {
        'status': 'PASS_PILOT' if passed else 'FAIL_PILOT',
        'primary_controls': ['head9', 'cldice_head9'], 'test_examples': n,
        'test_frames': frame_values.tolist(), 'test_class_counts': np.bincount(truth, minlength=9).tolist(),
        'seeds': SEEDS, 'arms': ARMS, 'metrics': metrics,
        'soft_minus_control': comparisons, 'secondary_geometry': geometry_comparisons,
        'selection': selection, 'seconds': time.monotonic() - started,
        'predictions_sha256': sha(ROOT / 'PREDICTIONS.npz'),
        'bootstrap_sha256': sha(ROOT / 'BOOTSTRAP.npz'),
        'analysis_sha256': sha(Path(__file__)), 'evaluation_frozen_sha256': sha(ROOT / 'EVALUATION_FROZEN.json'),
        'truth_component_histogram': {str(k): int(v) for k, v in zip(*np.unique(truth_topology[:, 0], return_counts=True))},
        'truth_hole_histogram': {str(k): int(v) for k, v in zip(*np.unique(truth_topology[:, 1], return_counts=True))},
        'scope': 'Expanded head/clDice controls, physics weight fixed at0.4 before new DEV. Fixed fresh frames of one IC and five new seeds, matched weak images/class labels. Primary class derived from binary masks. Direct heads and geometry secondary. No external chip replication or publication novelty claim.',
    }
    save('RESULT.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
