"""Direct nine-class C4-covariant readouts of a frozen segmentation CNN.

Class probabilities are a separate output from the unchanged segmentation
mask. Context accepts only uniform-C4 predicted probabilities, never targets.
"""
from pathlib import Path
import importlib.util
import math

import torch
from torch import nn
from torch.nn import functional as F

PILOT = Path(__file__).resolve().parents[1] / "sem_architecture_pilot_20261102"


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, PILOT / filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


original = module("class_readout_source_CNN", "model.py")
physics = module("class_readout_old_physics", "physics_adapter.py")
soft_conductance = physics._scope["soft_conductance"]
state_digest = original.state_digest
ARMS = ["visual_cnn", "physics_cnn", "physics_mlp"]
CLASS_SWAP = [0, 3, 6, 1, 4, 7, 2, 5, 8]
CONTEXT_SWAP = [2, 3, 0, 1]
VIEW_FIELDS = ["view_features", "view_logits", "physical_context", "visual_context"]
G0 = .5 / ((12 * 12 - 1) * (12 / 11))


def slice_cache(cache, ids):
    return {key: value[:, ids] if key in VIEW_FIELDS else value[ids] for key, value in cache.items()}


@torch.no_grad()
def context_from_mu(mu):
    """Fixed old ordinal features from prediction-only soft conductances."""
    fourth = mu.pow(4)
    p4 = fourth / (fourth + (1 - mu).pow(4))
    g = torch.stack((soft_conductance(p4), soft_conductance(p4.transpose(-1, -2))), dim=1)
    ordinal = torch.stack((4 * (g.log() - math.log(G0)), 40 * (g - .5)), dim=-1).flatten(1)
    return dict(conductance=g, ordinal_logits=ordinal,
                canonical_physical_context=torch.tanh(ordinal / 4), p4=p4)


@torch.no_grad()
def visual_context(mu):
    left_right = torch.cat((mu[:, :, :, 0], mu[:, :, :, -1]), dim=-1).mean((1, 2))
    top_bottom = torch.cat((mu[:, :, 0, :], mu[:, :, -1, :]), dim=-1).mean((1, 2))
    statistics = torch.stack((left_right, top_bottom, mu.mean((1, 2, 3)),
                               (4 * mu * (1 - mu)).mean((1, 2, 3))), dim=1)
    return 2 * statistics - 1


class SpatialClassHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(26, 16, 3, padding=1)
        self.film = nn.Linear(4, 32)
        self.conv2 = nn.Conv2d(16, 8, 3, padding=1)
        self.classifier = nn.Linear(72, 9)

    def forward(self, images, context):
        features = F.gelu(self.conv1(images))
        gamma, beta = self.film(context).chunk(2, dim=1)
        features = features * (1 + .5 * gamma.tanh()[:, :, None, None]) + .5 * beta.tanh()[:, :, None, None]
        features = F.gelu(self.conv2(features))
        return self.classifier(F.adaptive_avg_pool2d(features, (3, 3)).flatten(1))


class ClassificationReadout(nn.Module):
    def __init__(self, arm, backbone_state, *, head_seed):
        super().__init__()
        assert arm in ARMS
        self.arm = arm
        torch.manual_seed(int(head_seed))
        self.backbone = original.make_backbone()
        self.head = (nn.Sequential(nn.Linear(4, 32), nn.GELU(), nn.Linear(32, 9))
                     if arm == "physics_mlp" else SpatialClassHead())
        self.backbone.load_state_dict(backbone_state, strict=True)
        self.backbone.requires_grad_(False)
        assert self.parameter_counts()["head"] == (457 if arm == "physics_mlp" else 5737)

    def parameter_counts(self):
        return dict(backbone=sum(p.numel() for p in self.backbone.parameters()),
            head=sum(p.numel() for p in self.head.parameters()),
            trainable=sum(p.numel() for p in self.parameters() if p.requires_grad),
            total=sum(p.numel() for p in self.parameters()))

    @torch.no_grad()
    def precompute(self, x):
        """Raw rotated-coordinate features; all context remains label-free."""
        features, logits = [], []
        for k in range(4):
            transformed = torch.rot90(x, k, (-2, -1)).contiguous()
            f = self.backbone[:-1](transformed)
            z = self.backbone[-1](f)
            features.append(f); logits.append(z)
        # Preserve stage7's exact floating-point expression and tensor shape:
        # inverse-align logits, stack, sigmoid, then mean across the4views.
        aligned_logits = torch.stack([torch.rot90(z, -k, (-2, -1)) for k, z in enumerate(logits)])
        mu = aligned_logits.sigmoid().mean(0)
        contexts = context_from_mu(mu)
        physical = contexts.pop("canonical_physical_context")
        contexts.update(physical_context=torch.stack([physical[:, CONTEXT_SWAP] if k % 2 else physical for k in range(4)]),
            visual_context=torch.stack([visual_context(torch.rot90(mu, k, (-2, -1))) for k in range(4)]))
        return dict(x=x.detach().clone(), view_features=torch.stack(features).detach(),
            view_logits=torch.stack(logits).detach(), uniform_probability=mu.detach(), **contexts)

    def forward_cached(self, cache):
        mu, x = cache["uniform_probability"], cache["x"]
        context = cache["visual_context"] if self.arm == "visual_cnn" else cache["physical_context"]
        assert not context.requires_grad
        n = len(x)
        if self.arm == "physics_mlp":
            logits = self.head(context.reshape(4 * n, 4)).reshape(4, n, 9)
        else:
            inputs = torch.stack([torch.cat((cache["view_features"][k], torch.rot90(mu, k, (-2, -1)),
                torch.rot90(x, k, (-2, -1))), dim=1) for k in range(4)])
            logits = self.head(inputs.reshape(4 * n, 26, 12, 12), context.reshape(4 * n, 4)).reshape(4, n, 9)
        per_view_log_probability = logits.log_softmax(-1)
        aligned = torch.stack([value[:, CLASS_SWAP] if k % 2 else value for k, value in enumerate(per_view_log_probability)])
        log_probability = torch.logsumexp(aligned, dim=0) - math.log(4)
        return dict(log_probability=log_probability, probability=log_probability.exp(),
            per_view_logits=logits, per_view_log_probability=per_view_log_probability,
            aligned_log_probability=aligned, prediction=log_probability.argmax(-1),
            uniform_probability=mu, context=context)

    def forward_details(self, x):
        return self.forward_cached(self.precompute(x))

    def forward(self, x):
        return self.forward_details(x)["log_probability"]


def make_model(arm, backbone_state, *, head_seed):
    return ClassificationReadout(arm, backbone_state, head_seed=head_seed)


def architecture_spec():
    return dict(candidate="C4_classification_readout", arms=ARMS, backbone_frozen=True,
        head_parameters=dict(visual_cnn=5737, physics_cnn=5737, physics_mlp=457),
        CNN="Conv26to16k3,GELU,FiLMLinear4to32,Conv16to8k3,GELU,Pool3x3,Linear72to9",
        MLP="Linear4to32,GELU,Linear32to9", FiLM="1+.5*tanhgamma,offset.5*tanhbeta",
        input_coordinates="F24 in original rotated-view coordinates plus rotatedmu andSEM",
        physical_context="tanh(oldordinal_logits(gLR,gTB)/4),p4=mu^4/(mu^4+(1-mu)^4)",
        visual_context="2*[LRboundarymean,TBboundarymean,meanmu,mean4mu(1-mu)]-1",
        class_rotation_odd=CLASS_SWAP, context_rotation_odd=CONTEXT_SWAP,
        aggregation="inverse-class-permuted perviewsoftmax mean; stablelogsumexp",
        output="direct learned9class probability; unchangedfrozenmask is a separatediagnostic",
        objective="standard classCE only; sourceCNN retains its historical mask/geometry training",
        scope="OldTRAIN_VAL classifierdevelopment only; no newlossinnovation or maskqualitygain")
