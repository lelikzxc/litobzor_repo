"""Report direct classification heads separately from frozen segmentation."""
from pathlib import Path
import datetime
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PRIOR = ROOT.parent / "sem_arch_orbit_residual_20261102"
HELPER = ROOT.parent / "sem_arch_joint_adaptation_20261102" / "report.py"
spec = importlib.util.spec_from_file_location("classification_report_helpers", HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
read, sha, rel = helpers.read, helpers.sha, helpers.rel
discover, actual_rows, views = helpers.discover, helpers.actual_rows, helpers.views
pct, pp, passed = helpers.percent, helpers.pp, helpers.passed
plt, np = helpers.plt, helpers.np
ARMS = ["visual_cnn", "physics_cnn", "physics_mlp"]
CONTROLS = ["uniform_frozen", "uniform_adapted", "single_adapted", "fixed_softordinal"]
FAMILIES = ["high_lr", "low_lr"]


def avg(rows, arm, field="class_F1"):
    return float(np.mean([row[field] for row in rows if row["arm"] == arm]))


def verify(result):
    units = {(row["source_lr"], row["budget"], row["seed"]) for row in result["rows"]}
    rows = {(row["source_lr"], row["budget"], row["seed"], row["arm"]): row for row in result["rows"]}
    controls = {(row["source_lr"], row["budget"], row["seed"], row["arm"]): row for row in result["controls"]}
    assert len(rows) == len(result["rows"]) == 3 * len(units)
    assert len(controls) == len(result["controls"]) == 4 * len(units)
    for key in units:
        heads = [rows[key + (arm,)] for arm in ARMS]
        old = [controls[key + (arm,)] for arm in CONTROLS]
        source = heads[0]["source"]
        assert all(row["source"] == source for row in heads + old)
        assert len({row["batch_sequence_sha256"] for row in heads}) == 1
        assert heads[0]["head_initial_sha256"] == heads[1]["head_initial_sha256"]
        assert len({row["frozen_mask_IoU"] for row in heads}) == 1
        for row in heads:
            size = 457 if row["arm"] == "physics_mlp" else 5737
            assert row["fit_count"] == 1 and row["steps"] == row["optimizer_updates"] == 1000
            assert row["trainable_parameters"] == row["parameters"]["trainable"] == size
            assert row["parameters"]["total"] == 10681 + size
            assert row["backbone_before_sha256"] == row["backbone_after_sha256"] == source["backbone_state_sha256"]
            assert row["head_initial_sha256"] != row["head_final_sha256"]
            assert row["training_masks_used"] is False and sum(row["training_class_counts"]) == row["training_examples"]
            assert row["mask_output_unchanged"] and row["frozen_mask_probability_bit_exact"]
            assert row["prediction_pipeline"] == "direct_learned_class_probability_argmax"
            assert row["no_class_threshold"] and row["CNN_passes_per_image"] == 4
            assert abs(row["frozen_mask_IoU"] - controls[key + ("uniform_frozen",)]["frozen_mask_IoU"]) < 2e-7
        for row in old:
            if row["arm"] == "fixed_softordinal":
                assert row["fit_count"] == row["optimizer_updates"] == 0
            else:
                assert row["reused"] is True
                for field, path in row["control_ref"].items():
                    if field.endswith("_file"):
                        assert sha(REPO / path) == row["control_ref"][field[:-5] + "_sha256"]


def figure(result_views):
    if not result_views:
        return None
    path = ROOT / "figures" / "classification_and_frozen_mask.png"
    path.parent.mkdir(exist_ok=True)
    points = [(label, family, result) for label, result in result_views for family in FAMILIES]
    x = np.arange(len(points));fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    colors = ["#777777", "#90734e", "#8d6cab", "#aaaaaa", "#3c78a8", "#b25a43", "#4d8d63"]
    for offset, arm, color in zip(np.arange(7) - 3, CONTROLS + ARMS, colors):
        values = [100 * avg([row for row in result["rows"] + result["controls"] if row["source_lr"] == family], arm)
                  for _, family, result in points]
        axes[0, 0].bar(x + offset * .095, values, .09, label=arm, color=color)
    axes[0, 0].set_ylim(0, 100);axes[0, 0].set_ylabel("Classification Macro-F1, %")
    axes[0, 0].set_title("Direct class output versus fixed readouts")
    axes[0, 0].legend(fontsize=7, loc="lower left", ncol=2)
    for offset, arm, color in [(-.16, "visual_cnn", "#3c78a8"), (0, "physics_cnn", "#b25a43"), (.16, "physics_mlp", "#4d8d63")]:
        values = [100 * min(result["gates"]["A_pipeline"][arm]["by_source_lr"][family][f"vs_{control}"]["delta"]
                           for control in CONTROLS) for _, family, result in points]
        axes[0, 1].scatter(x + offset, values, color=color, s=45, label=arm)
        mask_delta = [100 * (avg([row for row in result["rows"] if row["source_lr"] == family], arm, "frozen_mask_IoU") -
                            avg([row for row in result["controls"] if row["source_lr"] == family], "uniform_frozen", "frozen_mask_IoU"))
                      for _, family, result in points]
        axes[1, 1].scatter(x + offset, mask_delta, color=color, s=45, label=arm)
    axes[0, 1].set_title("A_pipeline: minimum mean gain over four controls")
    axes[0, 1].set_ylabel("Classification F1 gain, percentage points")
    axes[0, 1].legend(fontsize=8)
    for offset, key, label, color, marker in [(-.1, "B_physics", "B physics CNN − visual CNN", "#b25a43", "o"),
                                             (.1, "C_fusion", "C physics CNN − physics MLP", "#4d8d63", "D")]:
        values = [100 * result["gates"][key]["by_source_lr"][family]["delta"] for _, family, result in points]
        axes[1, 0].scatter(x + offset, values, color=color, marker=marker, s=45, label=label)
    axes[1, 0].set_title("Common CE supervision; B uses matched CNN capacity")
    axes[1, 0].set_ylabel("Classification F1 difference, percentage points")
    axes[1, 0].legend(fontsize=8)
    axes[1, 1].set_title("Segmentation frozen: no IoU improvement")
    axes[1, 1].set_ylabel("Δ segmentation IoU versus frozen C4, pp")
    axes[1, 1].set_ylim(-.05, .05)
    for axis in axes.flat:
        axis.set_xticks(x, [f"{label}\n{family}" for label, family, _ in points])
        axis.set_xlim(-.6, len(points) - .4)
    for axis in [axes[0, 1], axes[1, 0]]:
        axis.axhline(0, color="black", lw=.8)
        axis.axhline(.5, color="gray", ls="--", lw=.8)
    axes[1, 1].axhline(0, color="black", lw=.8)
    fig.suptitle("Learned classification heads on reused VAL; masks remain unchanged", fontsize=11)
    fig.tight_layout();fig.savefig(path, dpi=180, bbox_inches="tight");plt.close(fig)
    return path


def build():
    config = read(ROOT / "CONFIG.json");trials = discover(ROOT)
    complete = [trial for trial in trials if trial["result"]]
    failures = [trial for trial in trials if trial["failure"]]
    pending = [trial for trial in trials if not trial["result"] and not trial["failure"]]
    rows = actual_rows(trials);fits = sum(row["fit_count"] for row in rows);updates = sum(row["optimizer_updates"] for row in rows)
    prior_manifest = read(PRIOR / "REPORT_MANIFEST.json");prior_fits = prior_manifest["linked_stage_unique_completed_fits"]
    # The previous report's hash manifest fixes which reused control fits were
    # already counted, including controls held outside the new model folder.
    known_checkpoints = {(PRIOR / name).resolve() for name in prior_manifest["scientific_inputs_sha256"]
                         if name.endswith(".pt")}
    reused_checkpoints = {(REPO / row["control_ref"]["checkpoint_file"]).resolve()
                         for trial in complete for row in trial["result"]["controls"]
                         if "control_ref" in row and "checkpoint_file" in row["control_ref"]}
    extras = reused_checkpoints - known_checkpoints
    unique_fits = prior_fits + fits + len(extras)
    result_views = [("screen" if result.get("phase") == "screen" else label, result) for label, result in views(trials)]
    for trial in complete:
        assert trial["result"]["frozen_sha256"] == sha(trial["path"] / "FROZEN.json")
        assert trial["frozen"]["masks_used_for_head_training"] is False and trial["frozen"]["fresh_confirmation_access"] is False
        verify(trial["result"])
        assert trial["result"]["fitted_models"] == len(trial["result"]["rows"])
        if trial["aggregate"]:
            verify(trial["aggregate"])
    output_figure = figure(result_views)
    text = ["# Прямая классификационная CNN-ветвь при замороженной сегментации", "",
            "**Изменился смысл классового выхода:** новая голова предсказывает девять вероятностей, "
            "итог — `argmax`, а не класс, вычисленный только из пороговой маски. "
            "Сегментационная C4-карта исходной CNN заморожена и проверяется побайтно; "
            "рост классификационного F1 не является ростом IoU или улучшением маски. "
            "Класс головы может не совпадать с геометрическим классом её маски; это измеряется отдельно.", "",
            "Visual_cnn и physics_cnn имеют одинаковые **5 737** обучаемых параметров: "
            "Conv3×3(26→16), GELU; FiLM(4→32); Conv3×3(16→8), GELU; AvgPool3×3; Linear(72→9). "
            "С замороженной CNN 10 681 это 16 418 параметров. Вход26 — признаки24, C4-вероятность и SEM. "
            "Общие веса головы обрабатывают четыре вида. При поворотах 90/270 градусов классовые "
            "вероятности переставляются `[0,3,6,1,4,7,2,5,8]`, меняя LR/TB; затем усредняются "
            "вероятности, не номера классов. Проверяется C4-ковариантность с перестановкой меток.", "",
            "Physics_cnn получает четыре tanh(ordinal_logits/4) от предсказанных непрерывных gLR/gTB "
            "по заострённой C4-карте μ⁴/(μ⁴+(1−μ)⁴). Visual_cnn получает четыре визуальные статистики "
            "в сопоставимом диапазоне: LR/TB-границы, среднюю вероятность и неопределённость. "
            "Physics_mlp — Linear(4→32), GELU, Linear(32→9), **457** параметров, всего 11 138; "
            "он получает тот же физический контекст. C сравнивает CNN со значительно меньшим MLP "
            "и изменяет также доступ к пространственным признакам.", "",
            "## Надзор, лосс и границы сравнения", "",
            "Для всех трёх голов используется одна **стандартная CE** канонического девятиклассового "
            "распределения, 1 000 шагов AdamW, lr=0,001, weight_decay=0,0001, batch32. "
            "Совокупный TRAIN — dense18/27 и 1152 weak, 1170/1179 примеров; одинаковые классы "
            "и батчи доступны всем головам. Пиксельные маски ни dense, ни weak не передаются оптимизатору. "
            "Encoder заморожен; его прежние веса обучены с BCE+geometry_loss. "
            "Это исследование классификационной архитектуры под общей CE, без новой предлагаемой функции потерь.", "",
            "A_pipeline против фиксированного readout включает также дополнительное обучение головы "
            "по классам. Он не изолирует чистую замену одного слоя. B сравнивает две одинаковые CNN "
            "под одинаковой CE и проверяет физический контекст. C сравнивает physics_cnn с physics_mlp "
            "при той же CE; ёмкость и пространственный вход этих моделей различаются.", "",
            f"Начато попыток {len(trials)}, завершено {len(complete)}, технических ошибок {len(failures)}, "
            f"незавершённых {len(pending)}. Новых обучений голов **{fits}**, обновлений {updates:,}. "
            f"С прежними {prior_fits} и дополнительными внешними контролями {len(extras)} "
            f"уникальных обучений **{unique_fits}**. Сводные результаты и сохранённые контроли повторно не считаются.", "",
            "## Критерии классификационного тракта", "",
            "A_pipeline требует ΔMacro-F1 ≥0,5 п.п. в среднем и ΔF1 каждого бюджета ≥−0,25 п.п. "
            "против каждого из четырёх readout: uniform_frozen, uniform_adapted, single_adapted "
            "и fixed_softordinal(g0,0,5), отдельно в high_lr/low_lr. Старые масочные readout сохраняют "
            "свои выбранные по 81-точечной VAL-сетке пороги. У новых классовых голов порога нет: argmax9. "
            "IoU не включён как мнимый новый выигрыш; маска обязана остаться неизменной. "
            "B: physics_cnn против visual_cnn и A physics_cnn. C: physics_cnn против physics_mlp "
            "и A physics_cnn. A для MLP не устанавливает пользу пространственной CNN. "
            "При расширении отдельно нужны условия на всех трёх и новых двух seed.", ""]
    if result_views:
        for label, result in result_views:
            text += [f"## {label}: seed {result['seeds']}", "",
                     "| Семья | Visual CNN F1, % | Physics CNN F1, % | Physics MLP F1, % | A visual / physics / MLP | B | C |",
                     "|---|---:|---:|---:|---|---|---|"]
            for family in FAMILIES:
                selected = [row for row in result["rows"] if row["source_lr"] == family];gates = result["gates"]
                values = " | ".join(pct(avg(selected, arm)) for arm in ARMS)
                outcomes = " / ".join(passed(gates["A_pipeline"][arm]["by_source_lr"][family]["passed"]) for arm in ARMS)
                text.append(f"| {family} | {values} | {outcomes} | {passed(gates['B_physics']['by_source_lr'][family]['passed'])} | "
                            f"{passed(gates['C_fusion']['by_source_lr'][family]['passed'])} |")
            text += ["", "Обе семьи: " + "; ".join(f"A {arm} **{passed(result['gates']['A_pipeline'][arm]['passed'])}**" for arm in ARMS) +
                     f"; B **{passed(result['gates']['B_physics']['passed'])}**; C **{passed(result['gates']['C_fusion']['passed'])}**.", "",
                     "| Семья | Frozen mask-readout F1, % | C4-adapted mask-readout F1, % | Single-adapted mask-readout F1, % | Fixed softordinal F1, % |",
                     "|---|---:|---:|---:|---:|"]
            for family in FAMILIES:
                selected = [row for row in result["controls"] if row["source_lr"] == family]
                text.append(f"| {family} | " + " | ".join(pct(avg(selected, arm)) for arm in CONTROLS) + " |")
            text += ["", "| Семья | Голова | Неизменный IoU маски, % | Несогласие class-argmax / class-of-mask, % |",
                     "|---|---|---:|---:|"]
            for family in FAMILIES:
                selected = [row for row in result["rows"] if row["source_lr"] == family]
                for arm in ARMS:
                    text.append(f"| {family} | {arm} | {pct(avg(selected, arm, 'frozen_mask_IoU'))} | "
                                f"{pct(avg(selected, arm, 'class_mask_disagreement_fraction'))} |")
            text.append("")
            for family in FAMILIES:
                gate = result["gates"]["B_physics"]["by_source_lr"][family]
                if all(gate["checks"].values()) and not gate["physics_cnn_pipeline_gate"]:
                    text += [f"{family}: численные условия сравнения physics_cnn с visual_cnn "
                             f"пройдены (ΔF1 {pp(gate['delta'])} п.п.), но полный B остаётся FAIL, "
                             "поскольку обязательный A_pipeline physics_cnn не пройден. "
                             "Разница внутри пары CNN и выигрыш над сильными readout — разные сравнения.", ""]
    else:
        text += ["Завершённого результата пока нет; вывод о прохождении A/B/C не сделан.", ""]
    if output_figure:
        text += ["![Классификационный результат и отдельно неизменная сегментация](figures/classification_and_frozen_mask.png)", "",
                 "Слева/сверху — классификационные метрики; IoU показан отдельно. Минимальный прирост "
                 "A берётся по четырём контролям. Пунктир +0,5 п.п. относится к среднему F1, "
                 "бюджетные ограничения приведены ниже. Это повторная VAL без независимых интервалов подтверждения.", ""]
    text += ["## Все сохранённые попытки", ""]
    for trial in trials:
        path = trial["path"]
        text += [f"### {path.name}", "", f"[FROZEN.json]({rel(path / 'FROZEN.json', ROOT)}).", ""]
        if not trial["result"]:
            if trial["failure"]:
                error = trial["failure"]
                text += [f"Техническая ошибка `{error.get('error_type', 'см. файл')}`: "
                         f"{str(error.get('error', '')).replace(chr(10), ' ')}. "
                         f"[FAILURE.json]({rel(path / 'FAILURE.json', ROOT)}). "
                         "Это технический исход, отдельный от отрицательного критерия модели.", ""]
            else:
                text += ["Попытка начата; итогового результата ещё нет.", ""]
            text += [f"Сохранённых обучений {len(trial['partial'])}.", ""];continue
        result = trial["result"]
        text += [f"`{result['status']}`; {result['phase']}; seed {result['seeds']}; "
                 f"обучений {result['fitted_models']}, обновлений {result['updates']:,}; новых оценок {result['evaluation_rows']}; "
                 f"старых масочных контролей {result['reused_mask_control_rows']}, фиксированных softordinal "
                 f"{result['fixed_softordinal_rows']}; {result['seconds']:.2f} с. "
                 f"[RESULT.json]({rel(path / 'RESULT.json', ROOT)}), SHA-256 `{sha(path / 'RESULT.json')}`.", "",
                 "| Семья | Бюджет | Seed | Голова | Параметров головы | Class F1, % | Accuracy, % | Неизменный mask IoU, % | Class/mask несогласие, % |",
                 "|---|---:|---:|---|---:|---:|---:|---:|---:|"]
        for row in result["rows"]:
            text.append(f"| {row['source_lr']} | {row['budget']} | {row['seed']} | {row['arm']} | {row['trainable_parameters']} | "
                        f"{pct(row['class_F1'])} | {pct(row['accuracy'])} | {pct(row['frozen_mask_IoU'])} | {pct(row['class_mask_disagreement_fraction'])} |")
        text.append("")
        gate_results = [("только эта попытка", result)]
        if trial["aggregate"]:
            gate_results.append(("все три seed", trial["aggregate"]))
            text += [f"[AGGREGATE_RESULT.json]({rel(path / 'AGGREGATE_RESULT.json', ROOT)}) объединяет "
                     "исходный скрининг и новые seed без повторного учёта обучений.", ""]
        for label, item in gate_results:
            text += [f"**{label}: {item['seeds']}**", "",
                     "| Семья | Сравнение классификации | ΔF1, п.п. | ΔF1 бюджеты 18 / 27, п.п. | Критерий |",
                     "|---|---|---:|---|---|"]
            for family in FAMILIES:
                comparisons = [(f"A_pipeline {arm} − {control}", item["gates"]["A_pipeline"][arm]["by_source_lr"][family][f"vs_{control}"])
                               for arm in ARMS for control in CONTROLS]
                comparisons += [("B physics_cnn − visual_cnn, с A", item["gates"]["B_physics"]["by_source_lr"][family]),
                                ("C physics_cnn − physics_mlp, с A", item["gates"]["C_fusion"]["by_source_lr"][family])]
                for name, gate in comparisons:
                    text.append(f"| {family} | {name} | {pp(gate['delta'])} | "
                                f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
            text.append("")
        if trial["aggregate"]:
            aggregate = trial["aggregate"]
            robust = {arm: aggregate["gates"]["A_pipeline"][arm]["passed"] and result["gates"]["A_pipeline"][arm]["passed"] for arm in ARMS}
            text += ["Одновременно все три и новые два seed: " + "; ".join(f"A {arm} {passed(robust[arm])}" for arm in ARMS) + "; " +
                     "; ".join(f"{name} {passed(aggregate['gates'][key]['passed'] and result['gates'][key]['passed'])}"
                               for name, key in [("B", "B_physics"), ("C", "C_fusion")]) + ".", ""]
        audit = trial["audit"]
        text += [(f"Независимый CPU-аудит: `{audit.get('status', 'см. файл')}`, "
                  f"{audit.get('checks_passed', 'см. файл')} / {audit.get('checks_total', 'см. файл')}. "
                  f"[AUDIT.json]({rel(path / 'AUDIT.json', ROOT)})." if audit else "Итоговый аудит ещё не сохранён."), ""]
        if audit and audit.get("numerical_note"):
            text += [f"Примечание технического аудита: {audit['numerical_note']}", ""]
        for old_path in sorted(path.glob("AUDIT_PREVIOUS_*.json")):
            text += [f"Предыдущая техническая проверка [{old_path.name}]({rel(old_path, ROOT)}): "
                     f"`{read(old_path).get('status', 'см. файл')}`. Исходные обучения сохранены.", ""]
    text += ["## Пределы вывода и прежний поиск", "",
             "Истинные девять классов прежние и производны от SVG-масок; они не являются экспертными "
             "типами дефектов или измеренным электрическим состоянием. Непрерывные физические признаки "
             "получены из предсказания и не назначают истинные метки. Выигрыш class-argmax может происходить "
             "при неизменной ошибочной маске; это не улучшение сегментации. B — matched-CNN сравнение "
             "физического и визуального контекстов, C меняет также параметры/пространственный вход. "
             "Технический PASS подтверждает воспроизведение чисел и неизменность маски, "
             "а критерии A/B/C отдельно проверяют качество классификации.", "",
             f"[Предыдущие попытки, 84 обучения и ссылки на сохранённый C4 FAIL_PILOT]({rel(PRIOR / 'REPORT.md', ROOT)}). "
             "Эта серия использует только старые TRAIN/VAL. Независимого подтверждения новой классификационной "
             "головы ещё нет; прежний закрытый исход другой модели не переопределяется. "
             "Для нового выбранного тракта требуется отдельная закрытая проверка. "
             "Перенос между изделиями, новизна и готовность для Q1 не установлены.", "",
             "[PROTOCOL.md](PROTOCOL.md) · [CONFIG.json](CONFIG.json) · [LEDGER.json](LEDGER.json) · "
             "[model.py](model.py) · [runner.py](runner.py) · [audit.py](audit.py).", ""]
    (ROOT / "REPORT.md").write_text("\n".join(text))
    (ROOT / "README.md").write_text(
        "# Прямая классификационная CNN-ветвь\n\n"
        "Класс теперь argmax9 обученной головы, маска/IoU заморожены. Две matchedCNN5737 сравнивают "
        "visual/physics контекст; physicsMLP457 — малый контроль. У всех стандартнаяCE и одинаковые классы/батчи. "
        "A_pipeline против фиксированных правил включает дополнительное обучение readout, "
        "а не чистый эффект слоя. Рост классификации не является ростом сегментации.\n\n"
        f"Завершено попыток {len(complete)}, технических ошибок {len(failures)}, новых обучений {fits}, "
        f"обновлений {updates}; уникальных обучений с прежними {unique_fits}.\n\n"
        "[Отчёт](REPORT.md) · [Протокол](PROTOCOL.md) · [Конфигурация](CONFIG.json) · [Журнал](LEDGER.json). "
        "Только прежняяTRAIN/VAL, независимой проверки новой головы ещё нет.\n\n"
        "```bash\n.venv/bin/python -B gipoteza/sem_arch_classification_readout_20261102/report.py\n```\n")
    inputs = [HELPER, PRIOR / "REPORT_MANIFEST.json", PRIOR / "REPORT.md"]
    inputs += [ROOT / name for name in ["CONFIG.json", "PROTOCOL.md", "LEDGER.json"] if (ROOT / name).exists()]
    for trial in trials:
        inputs += [trial["path"] / name for name in ["FROZEN.json", "RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json",
                   "PARTIAL_RESULTS.json", "AUDIT.json", "CONFIG_SNAPSHOT.json", "REUSED_CONTROLS.json", "CONTROL_RESULTS.json"] if (trial["path"] / name).exists()]
        inputs += sorted(trial["path"].glob("AUDIT_PREVIOUS_*.json"))
    for trial in complete:
        for row in trial["result"]["controls"]:
            if "control_ref" in row:
                inputs += [REPO / path for name, path in row["control_ref"].items() if name.endswith("_file")]
    outputs = [ROOT / "REPORT.md", ROOT / "README.md"] + ([output_figure] if output_figure else [])
    manifest = dict(status="REPORT_GENERATED", UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope="ADAPTIVE_OLD_TRAIN_VAL_DIRECT_CLASSIFICATION_FROZEN_SEGMENTATION", report_script_sha256=sha(Path(__file__)),
        shared_report_helper_sha256=sha(HELPER), trial_count=len(trials), completed_trials=len(complete), failed_trials=len(failures),
        pending_trials=len(pending), actual_completed_fits=fits, completed_head_updates=updates,
        prior_unique_completed_fits=prior_fits, extra_control_fits=len(extras), linked_stage_unique_completed_fits=unique_fits,
        evaluation_rows=len(rows), classification_output="direct_argmax9", segmentation_unchanged=True,
        head_objective="Standard shared cross-entropy; source CNN pretraining BCE+geometry_loss",
        scientific_inputs_sha256={rel(path, ROOT): sha(path) for path in inputs}, outputs_sha256={rel(path, ROOT): sha(path) for path in outputs})
    (ROOT / "REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
