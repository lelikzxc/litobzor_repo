"""C4-equivariant, pointwise learned fusion of immutable CNN orbit views.

Learned arms use249 scoring parameters and a frozen source CNN. The matched
uniform-adapted control updates only its10681 CNN parameters. Prediction maps
are label-free and detached. This module defines no loss and reads no data.
"""
from pathlib import Path
import importlib.util

import torch
from torch import nn
from torch.nn import functional as F

PILOT = Path(__file__).resolve().parents[1] / "sem_architecture_pilot_20261102"


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, PILOT / filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


original = module("learned_orbit_source_CNN", "model.py")
circuit_source = module("learned_orbit_source_circuit", "circuit.py")
state_digest = original.state_digest
FITTED_ARMS = ["learned_plain", "learned_joint", "uniform_adapted", "single_adapted"]
EVALUATION_ARMS = ["source_identity", "uniform_frozen", *FITTED_ARMS]
VARIANTS = ["actual", "zero", "roll"]
VIEW_FIELDS = ["view_features", "view_logits"]


def normalize_maps(raw, scale=100., floor=1e-6):
    transformed = torch.log1p(float(scale) * raw)
    centered = transformed - transformed.mean((-2, -1), keepdim=True)
    return centered / torch.sqrt(centered.square().mean((-2, -1), keepdim=True) + float(floor))


def slice_cache(cache, indices):
    return {key: value[:, indices] if key in VIEW_FIELDS else value[indices]
            for key, value in cache.items()}


class LearnedOrbitSegmenter(nn.Module):
    def __init__(self, arm, backbone_state, *, head_seed=105504,
                 epsilon=.001, scale=100., norm_floor=1e-6):
        super().__init__()
        assert arm in EVALUATION_ARMS, arm
        self.arm = arm
        self.epsilon, self.scale, self.norm_floor = float(epsilon), float(scale), float(norm_floor)
        torch.manual_seed(int(head_seed))
        self.backbone = original.make_backbone()
        self.scorer = None
        if arm.startswith("learned_"):
            self.scorer = nn.Sequential(nn.Conv2d(29, 8, 1), nn.GELU(), nn.Conv2d(8, 1, 1))
            nn.init.zeros_(self.scorer[-1].weight)
            nn.init.zeros_(self.scorer[-1].bias)
        self.backbone.load_state_dict(backbone_state, strict=True)
        self.backbone.requires_grad_(arm in ["uniform_adapted", "single_adapted"])
        self.circuit = circuit_source.CircuitMaps(epsilon=self.epsilon)
        assert self.parameter_counts()["backbone"] == 10681
        assert self.parameter_counts()["scorer"] == (249 if self.scorer is not None else 0)

    def parameter_counts(self):
        return dict(backbone=sum(p.numel() for p in self.backbone.parameters()),
            scorer=0 if self.scorer is None else sum(p.numel() for p in self.scorer.parameters()),
            trainable=sum(p.numel() for p in self.parameters() if p.requires_grad),
            total=sum(p.numel() for p in self.parameters()))

    def current_orbit(self, x):
        assert x.ndim == 4 and x.shape[1:] == (1, 12, 12), x.shape
        features, logits = [], []
        for k in range(4):
            transformed = torch.rot90(x, k, (-2, -1)).contiguous()
            f = self.backbone[:-1](transformed)
            z = self.backbone[-1](f)
            features.append(torch.rot90(f, -k, (-2, -1)))
            logits.append(torch.rot90(z, -k, (-2, -1)))
        return dict(view_features=torch.stack(features), view_logits=torch.stack(logits),
                    x=x, uniform_probability=torch.stack(logits).sigmoid().mean(0))

    @torch.no_grad()
    def conditioning_maps(self, mean_probability, mode):
        assert mode in ["plain", "joint"]
        mu = mean_probability.detach()
        if mode == "plain":
            raw = torch.cat((mu, 4 * mu * (1 - mu)), dim=1)
        else:
            z = torch.logit(mu.clamp(self.epsilon, 1 - self.epsilon))
            raw = self.circuit(z, mode="joint")
        maps = normalize_maps(raw, self.scale, self.norm_floor)
        assert not raw.requires_grad and not maps.requires_grad
        return raw, maps

    @torch.no_grad()
    def precompute(self, x):
        """Image-only ephemeral cache for frozen source models, never persisted."""
        assert self.arm not in ["uniform_adapted", "single_adapted"], "An adapting CNN must recompute its live prediction"
        inputs = self.current_orbit(x)
        for mode in ["plain", "joint"]:
            raw, maps = self.conditioning_maps(inputs["uniform_probability"], mode)
            inputs["raw_" + mode], inputs["maps_" + mode] = raw, maps
        return {key: value.detach().clone() for key, value in inputs.items()}

    def fuse(self, inputs, intervention="actual"):
        assert intervention in VARIANTS, intervention
        z = inputs["view_logits"]
        if self.arm == "source_identity":
            return dict(logits=z[0], probability=z[0].sigmoid(),
                        uniform_probability=inputs["uniform_probability"], weights=None, scores=None)
        view_probability = z.sigmoid()
        mu = inputs["uniform_probability"]
        maps = None
        if self.scorer is None:
            scores = torch.zeros_like(z)
        else:
            mode = "joint" if self.arm == "learned_joint" else "plain"
            maps = inputs["maps_" + mode]
            assert not maps.requires_grad
            if intervention == "zero":
                maps = torch.zeros_like(maps)
            elif intervention == "roll":
                maps = torch.roll(maps, (5, 5), (-2, -1))
            n = z.shape[1]
            repeat = lambda value: value.unsqueeze(0).expand(4, -1, -1, -1, -1)
            values = torch.cat((inputs["view_features"], view_probability,
                repeat(mu), repeat(inputs["x"]), repeat(maps)), dim=2)
            assert values.shape == (4, n, 29, 12, 12)
            scores = self.scorer(values.reshape(4 * n, 29, 12, 12)).reshape(4, n, 1, 12, 12)
        log_weights = scores.log_softmax(0)
        weights = log_weights.exp()
        # Stable exact mathematical logit of the probability mixture; neither
        # probability clipping nor a replacement training loss is introduced.
        log_p = torch.logsumexp(log_weights + F.logsigmoid(z), dim=0)
        log_not_p = torch.logsumexp(log_weights + F.logsigmoid(-z), dim=0)
        logits = log_p - log_not_p
        # This equivalent expression preserves the old uniform mean bit-for-bit
        # at zero scores: weights=.25 and the entire correction is exactly0.
        probability = mu + ((weights - .25) * view_probability).sum(0)
        return dict(logits=logits, probability=probability, uniform_probability=mu,
                    weights=weights, scores=scores, maps_normalized=maps)

    def forward_cached(self, cache, intervention="actual"):
        assert self.arm not in ["uniform_adapted", "single_adapted"], "No stale cache during CNN adaptation"
        return self.fuse(cache, intervention)

    def forward_details(self, x, intervention="actual"):
        if self.arm == "source_identity" or (self.arm == "single_adapted" and self.training):
            z = self.backbone(x)
            return dict(logits=z, probability=z.sigmoid(), uniform_probability=None,
                        weights=None, scores=None)
        inputs = self.current_orbit(x)
        if self.scorer is not None:
            mode = "joint" if self.arm == "learned_joint" else "plain"
            raw, maps = self.conditioning_maps(inputs["uniform_probability"], mode)
            inputs["raw_" + mode], inputs["maps_" + mode] = raw, maps
        return self.fuse(inputs, intervention)

    def forward(self, x):
        return self.forward_details(x)["logits"]


def make_model(arm, backbone_state, **kwargs):
    return LearnedOrbitSegmenter(arm, backbone_state, **kwargs)


def architecture_spec():
    return dict(candidate="learned_orbit_attention", fitted_arms=FITTED_ARMS,
        evaluation_arms=EVALUATION_ARMS, group="C4", aligned_features=24,
        scorer_inputs=["alignedF24", "view_probability1", "uniform_mean1", "SEM1", "maps2"],
        scorer="shared Conv1x1(29to8),GELU,Conv1x1(8to1)", scorer_parameters=249,
        identity_initialization="zero finalscore convolution gives exact uniformC4 probabilities",
        aggregation="view-softmax pointwise weights; stable probability-mixture logit",
        learned_backbone_frozen=True, conditioning_detached=True,
        physical_maps="jointDtN from detached uniformC4 mean, old log1p100 center/RMS",
        adapted_control="uniformC4,CNN10681 receives500updates under same pooled old loss",
        extra_adaptation_control="single_adapted CNN10681 trains500single-view updates then evaluatesuniformC4",
        training_cache="ephemeral image-only tensors, bounded120MiB/source; no archive persistence",
        scope="TRAIN/VAL development only; standard attention pooling, no novelty claim")
