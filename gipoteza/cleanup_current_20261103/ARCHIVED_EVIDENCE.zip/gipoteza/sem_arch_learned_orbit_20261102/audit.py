"""Independent CPU audit of learned shared C4 view attention.

TRAIN/VAL development only. No fitting or fresh confirmation data access.
"""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import time

import numpy as np
from scipy import linalg, ndimage
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
G = ROOT.parent
REPO = G.parent
PILOT = G / 'sem_architecture_pilot_20261102'
_DIRECTION_CACHE = {}
_CLASS_CACHE = {}
ARMS = ['source_identity', 'uniform_frozen', 'learned_plain', 'learned_joint', 'uniform_adapted', 'single_adapted']
VARIANTS = ['actual', 'zero', 'roll']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def digest(state):
    h = hashlib.sha256()
    for key in sorted(state):
        value = state[key].detach().cpu().contiguous().numpy()
        h.update(key.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()

def macro_f1(truth, prediction):
    confusion = np.bincount(9 * truth + prediction, minlength=81).reshape(9, 9)
    denominator = confusion.sum(0) + confusion.sum(1)
    return float(np.divide(2 * np.diag(confusion), denominator,
                           out=np.zeros(9, float), where=denominator > 0).mean())

def mean_iou(masks, target):
    union = (masks | target).sum((-2, -1))
    intersection = (masks & target).sum((-2, -1))
    return float(np.divide(intersection, union, out=np.ones(len(union)),
                           where=union > 0).mean())

def direction_class(mask):
    """Independent active-node Cholesky solve of the binary unit-edge graph."""
    mask = np.ascontiguousarray(mask, dtype=bool)
    key = np.packbits(mask).tobytes()
    if key in _DIRECTION_CACHE:
        return _DIRECTION_CACHE[key]
    components, _ = ndimage.label(mask, ndimage.generate_binary_structure(2, 1))
    spanning = np.intersect1d(components[:, 0], components[:, -1])
    spanning = spanning[spanning > 0]
    if not len(spanning):
        answer = 0
    else:
        active = np.isin(components, spanning)
        vertices = np.flatnonzero(active.ravel())
        lookup = np.full(144, -1, dtype=int)
        lookup[vertices] = np.arange(len(vertices))
        laplacian = np.zeros((len(vertices), len(vertices)), dtype=np.float64)
        for vertex in vertices:
            y, x = divmod(int(vertex), 12)
            for yy, xx in [(y + 1, x), (y, x + 1)]:
                if yy < 12 and xx < 12 and active[yy, xx]:
                    a, b = lookup[vertex], lookup[yy * 12 + xx]
                    laplacian[a, a] += 1; laplacian[b, b] += 1
                    laplacian[a, b] -= 1; laplacian[b, a] -= 1
        left = np.flatnonzero(vertices % 12 == 0)
        right = np.flatnonzero(vertices % 12 == 11)
        free = np.setdiff1d(np.arange(len(vertices)), np.r_[left, right])
        potential = np.zeros(len(vertices)); potential[right] = 1
        if len(free):
            potential[free] = linalg.solve(
                laplacian[np.ix_(free, free)],
                -laplacian[np.ix_(free, right)].sum(1), assume_a='pos',
                check_finite=False)
        conductance = float((laplacian[right] @ potential).sum()) / (12 / 11)
        answer = 0 if conductance < 1e-8 else (1 if conductance < .5 - 1e-8 else 2)
    _DIRECTION_CACHE[key] = answer
    return answer

def classify(masks):
    result = []
    for mask in np.asarray(masks, dtype=bool).reshape(-1, 12, 12):
        key = np.packbits(mask).tobytes()
        if key not in _CLASS_CACHE:
            _CLASS_CACHE[key] = 3 * direction_class(mask) + direction_class(mask.T)
        result.append(_CLASS_CACHE[key])
    return np.asarray(result, dtype=np.int64)

def conv(x, state, prefix, padding=0, dilation=1):
    return F.conv2d(x, state[prefix + '.weight'], state[prefix + '.bias'],
                    padding=padding, dilation=dilation)

def independent_backbone(x, state):
    features = x
    for index, dilation in [(0, 1), (2, 2), (4, 4)]:
        features = F.gelu(conv(features, state, str(index), dilation, dilation))
    coarse = conv(features, state, '6')
    return torch.cat((features, coarse, x), 1), coarse

def selected(scores):
    return max(scores, key=lambda row: (row['mask_F1'], row['IoU'],
                -abs(row['threshold'] - .5), -row['threshold']))

def gate(delta_f1, delta_iou, config):
    checks = {
        'mean_F1_gain': float(np.mean(delta_f1)) >= config['minimum_mean_F1_gain'],
        'each_budget_guard': min(delta_f1) >= config['minimum_budget_F1_delta'],
        'mean_IoU_guard': float(np.mean(delta_iou)) >= config['minimum_mean_IoU_delta'],
    }
    return {'passed': all(checks.values()), 'checks': checks,
            'mean_F1_delta': float(np.mean(delta_f1)),
            'budget_F1_deltas': list(map(float, delta_f1)),
            'mean_IoU_delta': float(np.mean(delta_iou))}

def compare_stored_gates(computed, stored):
    """Compare semantic gate outcomes, permitting only historical key spelling."""
    def canonical(value):
        if isinstance(value, dict):
            names = {'delta': 'mean_F1_delta', 'IoU_delta': 'mean_IoU_delta',
                     'budget_deltas': 'budget_F1_deltas', 'budget_F1_guard': 'each_budget_guard'}
            return {names.get(key, key): canonical(item) for key, item in value.items()
                    if key != 'interpretation'}
        if isinstance(value, list):
            return [canonical(item) for item in value]
        return value
    actual, observed = canonical(computed), canonical(stored)
    def compare(left, right):
        if isinstance(left, dict):
            assert set(left) == set(right), (set(left), set(right))
            return max([compare(left[key], right[key]) for key in left] + [0.])
        if isinstance(left, list):
            assert len(left) == len(right)
            return max([compare(a, b) for a, b in zip(left, right)] + [0.])
        if isinstance(left, bool):
            assert left == right, (left, right)
            return 0.
        return abs(float(left) - float(right))
    return compare(actual, observed)

def normalize_reference(raw):
    value = np.log1p(100 * np.asarray(raw, dtype=np.float64))
    centered = value - value.mean((-2, -1), keepdims=True)
    return centered / np.sqrt((centered * centered).mean((-2, -1), keepdims=True) + 1e-6)


def independent_views(x, backbone):
    features, logits = [], []
    for rotation in range(4):
        transformed = torch.rot90(x, rotation, (-2, -1)).contiguous()
        visual, coarse = independent_backbone(transformed, backbone)
        features.append(torch.rot90(visual[:, :24], -rotation, (-2, -1)))
        logits.append(torch.rot90(coarse, -rotation, (-2, -1)))
    aligned_features = torch.stack(features, 1)
    aligned_logits = torch.stack(logits, 1)
    probabilities = aligned_logits.sigmoid()
    return aligned_features, aligned_logits, probabilities, probabilities.mean(1)


def independent_mixture(aligned_logits, scores=None):
    if scores is None:
        log_weights = torch.full_like(aligned_logits, -np.log(4.))
    else:
        log_weights = scores.log_softmax(1)
    log_probability = torch.logsumexp(log_weights + F.logsigmoid(aligned_logits), 1)
    log_complement = torch.logsumexp(log_weights + F.logsigmoid(-aligned_logits), 1)
    return log_probability - log_complement, log_weights.exp()


def functional_attention(features, logits, mean_probability, sem, maps, head, intervention='actual'):
    if intervention == 'zero':
        maps = torch.zeros_like(maps)
    elif intervention == 'roll':
        maps = torch.roll(maps, (5, 5), (-2, -1))
    batch, views = logits.shape[:2]
    expanded = lambda value: value[:, None].expand(-1, views, -1, -1, -1)
    inputs = torch.cat((features, logits.sigmoid(), expanded(mean_probability), expanded(sem), expanded(maps)), 2)
    flat = inputs.reshape(batch * views, 29, 12, 12)
    score = F.conv2d(F.gelu(F.conv2d(flat, head['0.weight'], head['0.bias'])), head['2.weight'], head['2.bias'])
    score = score.reshape(batch, views, 1, 12, 12)
    output, weights = independent_mixture(logits, score)
    return output, weights, score


def batch_sequence(budget, seed):
    rng = np.random.default_rng(seed + 1000); value = hashlib.sha256()
    for _ in range(500):
        value.update(rng.integers(0, budget, 8).astype(np.int64).tobytes())
        value.update(rng.integers(0, 1152, 8).astype(np.int64).tobytes())
    return value.hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module
def recompute_gates(rows, config):
    def mean(family, budget, arm, metric):
        return float(np.mean([row['selected'][metric] for row in rows if row['source_lr'] == family and
                              row['budget'] == budget and row['arm'] == arm]))
    def compare(family, left, right):
        return gate([mean(family, budget, left, 'mask_F1') - mean(family, budget, right, 'mask_F1') for budget in [18, 27]],
                    [mean(family, budget, left, 'IoU') - mean(family, budget, right, 'IoU') for budget in [18, 27]], config['gates'])
    architecture = {}
    for arm in ['learned_plain', 'learned_joint']:
        families = {}
        for family in ['high_lr', 'low_lr']:
            frozen = compare(family, arm, 'uniform_frozen'); adapted = compare(family, arm, 'uniform_adapted')
            single = compare(family, arm, 'single_adapted')
            families[family] = dict(vs_uniform_frozen=frozen, vs_uniform_adapted=adapted, vs_single_adapted=single,
                                    passed=bool(frozen['passed'] and adapted['passed'] and single['passed']))
        architecture[arm] = dict(by_source_lr=families, passed=all(item['passed'] for item in families.values()))
    physics = {}
    for family in ['high_lr', 'low_lr']:
        item = compare(family, 'learned_joint', 'learned_plain')
        item['joint_architecture_gate'] = architecture['learned_joint']['by_source_lr'][family]['passed']
        item['passed'] &= item['joint_architecture_gate']
        physics[family] = item
    training = {}
    for family in ['high_lr', 'low_lr']:
        frozen = compare(family, 'uniform_adapted', 'uniform_frozen'); single = compare(family, 'uniform_adapted', 'single_adapted')
        training[family] = dict(vs_uniform_frozen=frozen, vs_single_adapted=single, passed=bool(frozen['passed'] and single['passed']))
    return dict(A_architecture=architecture, A_any=any(item['passed'] for item in architecture.values()),
        B_physics=dict(by_source_lr=physics, passed=bool(all(item['passed'] for item in physics.values()) and architecture['learned_joint']['passed'])),
        D_uniform_training=dict(by_source_lr=training, passed=all(item['passed'] for item in training.values())))
def reference_cache(images, backbone, circuit):
    result = {key: [] for key in ['view_features', 'view_logits', 'uniform_probability', 'x', 'raw_plain', 'maps_plain', 'raw_joint', 'maps_joint']}
    with torch.inference_mode():
        for x in images.split(16):
            features, logits, _, mu = independent_views(x, backbone)
            raw_plain = torch.cat((mu, 4 * mu * (1 - mu)), 1)
            raw_joint = circuit(torch.logit(mu.clamp(.001, .999)), mode='joint')
            values = dict(view_features=features, view_logits=logits, uniform_probability=mu, x=x,
                raw_plain=raw_plain, maps_plain=torch.tensor(normalize_reference(raw_plain.numpy()), dtype=torch.float32),
                raw_joint=raw_joint, maps_joint=torch.tensor(normalize_reference(raw_joint.numpy()), dtype=torch.float32))
            for key, value in values.items():
                result[key].append(value)
    return {key: torch.cat(value) for key, value in result.items()}


def reference_forward(cache, arm, head=None, intervention='actual'):
    logits = cache['view_logits']; mu = cache['uniform_probability']
    if arm == 'source_identity':
        return logits[:, 0], logits[:, 0].sigmoid(), None, None
    if head is None:
        value, weights = independent_mixture(logits)
        return value, mu, weights, torch.zeros_like(logits)
    mode = 'joint' if arm == 'learned_joint' else 'plain'
    value, weights, scores = functional_attention(cache['view_features'], logits, mu, cache['x'], cache['maps_' + mode], head, intervention)
    probability = mu + ((weights - .25) * logits.sigmoid()).sum(1)
    return value, probability, weights, scores


def audit_active_probe(config, model_module, circuit, backbone):
    preflight = json.loads((ROOT / 'PREFLIGHT.json').read_text())
    checks = {}
    checks['preflight_frozen_sources_and249_parameter_count'] = (
        preflight['status'] == 'PASS_PREFLIGHT' and all(sha(ROOT / key) == value for key, value in preflight['source_sha256'].items()) and
        preflight['counts'] == dict(backbone=10681, scorer=249, trainable=249, total=10930) and preflight['no_optimizer_steps'])
    generator = torch.Generator().manual_seed(7503)
    x = torch.randn((2, 1, 12, 12), generator=generator)
    errors = dict(logits=0., probability=0., weights=0., permutation=0., raw_map_rotation=0., normalized_map_rotation=0., float64_mixture_identity=0.)
    active_ok = True; gradient_ok = True; control_ok = True
    for arm in ['learned_plain', 'learned_joint']:
        with np.load(ROOT / f'TECHNICAL_ACTIVE_{arm}.npz', allow_pickle=False) as archive:
            fixture = {key: archive[key] for key in archive.files}
        active_ok &= np.array_equal(fixture['x'], x.numpy())
        head = {key: torch.tensor(fixture['active_scorer_' + key.replace('.', '_')]) for key in ['0.weight', '0.bias', '2.weight', '2.bias']}
        net = model_module.make_model(arm, backbone, head_seed=105504)
        initial_head = net.scorer.state_dict()
        active_ok &= (digest(initial_head) == preflight['initial_head_sha256'] and
            all(torch.equal(head[key], value) for key, value in initial_head.items() if key != '2.weight') and
            torch.equal(head['2.weight'], torch.linspace(-.02, .02, 8).reshape(1, 8, 1, 1)))
        initial_cache = net.precompute(x)
        initial = net.forward_cached(initial_cache)
        active_ok &= torch.equal(initial['probability'], initial_cache['uniform_probability'])
        initial['logits'].sum().backward()
        gradient_ok &= (all(value.grad is None for value in net.backbone.parameters()) and
            bool(net.scorer[-1].weight.grad.abs().sum() > 0) and
            all(value.grad is not None and bool(torch.count_nonzero(value.grad) == 0) for value in net.scorer[0].parameters()))
        net.scorer.load_state_dict(head); net.zero_grad(set_to_none=True)
        active = net.forward_cached(initial_cache); active['logits'].sum().backward()
        gradient_ok &= bool(net.scorer[0].weight.grad.abs().sum() > 0)
        active_ok &= float((active['weights'].detach() - .25).abs().max()) > 1e-6
        cache = reference_cache(x, backbone, circuit)
        with torch.inference_mode():
            logits, probability, weights, _ = reference_forward(cache, arm, head)
        errors['logits'] = max(errors['logits'], float(np.max(np.abs(logits.numpy() - fixture['logits']))))
        errors['probability'] = max(errors['probability'], float(np.max(np.abs(probability.numpy() - fixture['probability']))))
        errors['weights'] = max(errors['weights'], float(np.max(np.abs(weights.permute(1, 0, 2, 3, 4).numpy() - fixture['weights']))))
        z64 = torch.tensor(fixture['view_logits'], dtype=torch.float64).permute(1, 0, 2, 3, 4)
        s64 = torch.tensor(fixture['scores'], dtype=torch.float64).permute(1, 0, 2, 3, 4)
        l64, w64 = independent_mixture(z64, s64)
        errors['float64_mixture_identity'] = max(errors['float64_mixture_identity'], float((l64.sigmoid() - (w64 * z64.sigmoid()).sum(1)).abs().max()))
        for rotation in range(4):
            shifted = {key: value.roll(rotation, 1) if key in ['view_features', 'view_logits'] else value for key, value in cache.items()}
            with torch.inference_mode():
                p = reference_forward(shifted, arm, head)[1]
            errors['permutation'] = max(errors['permutation'], float((p - probability).abs().max()),
                float(np.max(np.abs(p.numpy() - fixture['view_permuted_probability'][rotation]))))
        for mode in ['plain', 'joint']:
            base_raw, base_maps = net.conditioning_maps(initial_cache['uniform_probability'], mode)
            for rotation in range(4):
                raw, maps = net.conditioning_maps(torch.rot90(initial_cache['uniform_probability'], rotation, (-2, -1)), mode)
                errors['raw_map_rotation'] = max(errors['raw_map_rotation'], float((torch.rot90(raw, -rotation, (-2, -1)) - base_raw).abs().max()))
                errors['normalized_map_rotation'] = max(errors['normalized_map_rotation'], float((torch.rot90(maps, -rotation, (-2, -1)) - base_maps).abs().max()))
            gradient_ok &= not base_raw.requires_grad and not base_maps.requires_grad
        restored = fixture['restored_probability']
        active_ok &= float(np.max(np.abs(restored - fixture['probability'][None]))) <= 1e-6
    for arm, expected_passes in [('uniform_adapted', 4), ('single_adapted', 1)]:
        net = model_module.make_model(arm, backbone, head_seed=105504).train()
        counter = [0]
        hook = net.backbone[0].register_forward_hook(lambda *args: counter.__setitem__(0, counter[0] + 1))
        value = net(x); hook.remove(); value.sum().backward()
        control_ok &= counter[0] == expected_passes and all(value.grad is not None and torch.isfinite(value.grad).all().item() for value in net.backbone.parameters())
        net.eval()
        with torch.no_grad():
            output = net.forward_details(x)
        control_ok &= torch.equal(output['probability'], output['uniform_probability'])
        try:
            net.forward_cached(initial_cache)
        except AssertionError:
            pass
        else:
            control_ok = False
    checks['active249_scorer_independent_forward_permutation_and_C4_fixtures'] = (
        bool(active_ok) and errors['logits'] < 1e-5 and errors['probability'] < 1e-6 and errors['weights'] < 1e-6 and errors['permutation'] < 1e-6)
    checks['identity_first_hidden_zero_then_active_hidden_nonzero_frozen_CNN_gradients'] = bool(gradient_ok)
    checks['raw_and_normalized_map_rotation_closure_separate_declared_bounds'] = (
        errors['raw_map_rotation'] < preflight['raw_map_rotation_tolerance'] == 1e-6 and
        errors['normalized_map_rotation'] < preflight['normalized_map_rotation_tolerance'] == 1e-4)
    checks['matched_single_vs_four_view_training_live_CNN_and_four_view_eval_no_cache'] = bool(control_ok)
    return checks, errors
def audit_trial(folder):
    started = time.monotonic()
    read = lambda name: json.loads((folder / name).read_text())
    result, frozen, config = (read(name) for name in ['RESULT.json', 'FROZEN.json', 'CONFIG_SNAPSHOT.json'])
    before = {str(path): sha(path) for path in [folder / 'RESULT.json', folder / 'FROZEN.json', folder / 'CONFIG_SNAPSHOT.json',
        folder / 'PROTOCOL.md', ROOT / 'model.py', ROOT / 'runner.py', PILOT / 'TRAIN_VAL.npz']}
    checks = {}
    checks['explicit_TRAIN_VAL_only_frozen_sources_protocol_and_no_fresh_confirmation_access'] = (
        result['status'] == 'COMPLETE_DEVELOPMENT_TRIAL' and frozen['fresh_confirmation_access'] is False and
        'no confirmation data' in result['scope'] and sha(folder / 'FROZEN.json') == result['frozen_sha256'] and
        sha(folder / 'PROTOCOL.md') == config['protocol_sha256'] == frozen['protocol_sha256'] and
        sha(folder / 'CONFIG_SNAPSHOT.json') == frozen['config_sha256'] and
        all(sha(ROOT / key) == value for key, value in frozen['source_sha256'].items()) and
        all(sha(folder / 'source' / key) == frozen['source_sha256'][key] for key in ['model.py', 'runner.py']))
    fitted_arms = ['learned_plain', 'learned_joint', 'uniform_adapted', 'single_adapted']
    checks['fixed_four_fitted_arms_all81_grid_hyperparameters_and_strict_gates'] = (
        config['candidate'] == 'learned_orbit_attention' and config['evaluation_arms'] == ARMS and config['fitted_arms'] == fitted_arms and
        config['source_lr'] == ['high_lr', 'low_lr'] and config['budgets'] == [18, 27] and config['subset_seed'] == 5303 and
        config['screen_seeds'] == [5501] and config['replication_seeds'] == [5501, 5521, 5557] and
        config['thresholds'] == [round(.1 + .01 * i, 2) for i in range(81)] and config['steps'] == 500 and config['batch_size'] == 8 and
        config['head_learning_rate'] == .0005 and config['backbone_learning_rate'] == .0001 and config['weight_decay'] == .0001 and
        config['physics_weight'] == 1 and config['epsilon'] == .001 and config['normalization_scale'] == 100 and
        config['normalization_variance_floor'] == 1e-6 and config['technical_seed'] == 7503 and config['equivariance_tolerance'] == 1e-6 and
        config['gates'] == dict(minimum_mean_F1_gain=.005, minimum_budget_F1_delta=-.0025, minimum_mean_IoU_delta=-.002))
    tree = ast.parse((folder / 'source' / 'runner.py').read_text())
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    reads = [(name, ast.unparse(node)) for name, function in functions.items() for node in ast.walk(function) if
        isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and
        node.func.value.id == 'np' and node.func.attr == 'load']
    fit_source = ast.unparse(functions['fit']); input_source = ast.unparse(functions['inputs'])
    checks['source_only_TRAIN_VAL_npz_and_no_weak_masks'] = (len(reads) == 1 and reads[0][0] == 'inputs' and
        "PILOT / 'TRAIN_VAL.npz'" in reads[0][1] and "if role != 'weak':" in input_source)
    checks['exact_old_BCE_plus_geometry_loss_and_distinct_head_or_CNN_optimizer'] = (
        "dense_loss = F.binary_cross_entropy_with_logits(dense, values['dense']['mask'][ai])" in fit_source and
        'geometry_loss = physics.geometry_loss(weak, torch.stack((y // 3, y % 3), dim=1))' in fit_source and
        "loss = dense_loss + c['physics_weight'] * geometry_loss" in fit_source and
        'params = list(model.scorer.parameters()) if learned else list(model.backbone.parameters())' in fit_source and
        "rate = c['head_learning_rate'] if learned else c['backbone_learning_rate']" in fit_source and
        'logits = model.forward_cached(batch)' in fit_source and
        "logits = model(torch.cat((values['dense']['x'][ai], values['weak']['x'][wi])))" in fit_source)
    model_tree = ast.parse((folder / 'source' / 'model.py').read_text())
    precompute = next(node for node in ast.walk(model_tree) if isinstance(node, ast.FunctionDef) and node.name == 'precompute')
    model_source = ast.unparse(model_tree)
    checks['source_label_free_cache_detached_maps_shared1x1_scorer_stable_logsumexp_mixture'] = (
        [arg.arg for arg in precompute.args.args] == ['self', 'x'] and
        'nn.Conv2d(29, 8, 1)' in model_source and 'nn.Conv2d(8, 1, 1)' in model_source and
        'log_weights = scores.log_softmax(0)' in model_source and
        'log_p = torch.logsumexp(log_weights + F.logsigmoid(z), dim=0)' in model_source and
        'log_not_p = torch.logsumexp(log_weights + F.logsigmoid(-z), dim=0)' in model_source and
        'mu = mean_probability.detach()' in model_source)
    lineage = frozen['lineage']; subsets = json.loads((PILOT / 'SUBSETS.json').read_text())
    with np.load(PILOT / 'TRAIN_VAL.npz', allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    val = np.flatnonzero(data['role'] == 'val'); images = torch.tensor(5 * (data['X'][val] - .2))
    truth, target = data['label'][val], data['Y'][val, 0].astype(bool)
    checks['unchanged_data_subsets_roles_and_independent_VAL_truth'] = (
        sha(PILOT / 'TRAIN_VAL.npz') == lineage['TRAIN_VAL_sha256'] == subsets['train_val_sha256'] and
        sha(PILOT / 'SUBSETS.json') == lineage['subsets_sha256'] and sha(PILOT / 'INITIAL_LINEAGE.json') == lineage['initial_lineage_sha256'] and
        {role: int(np.sum(data['role'] == role)) for role in set(data['role'])} == {'dense': 54, 'weak': 1152, 'val': 695} and
        set(data['frame'][val]) == {6, 7} and set(data['frame'][data['role'] != 'val']) == set(range(6)) and
        set(subsets['dense_indices']['18']).issubset(subsets['dense_indices']['27']) and
        all(np.array_equal(np.bincount(data['label'][subsets['dense_indices'][str(b)]], minlength=9), np.full(9, b // 9)) for b in [18, 27]) and
        np.array_equal(classify(target), truth))
    seeds = [5501] if result['phase'] == 'screen' else [5521, 5557]
    refs, rows = result['sources'], result['rows']
    units = {(family, budget, seed) for family in ['high_lr', 'low_lr'] for budget in [18, 27] for seed in seeds}
    checks['exact_source_evaluation_and_fit_grids_no_seed_double_count'] = (
        seeds == result['seeds'] == frozen['seeds'] and refs == frozen['sources'] and
        len(refs) == len(units) and {(r['source_lr'], r['budget'], r['seed']) for r in refs} == units and
        len(rows) == result['evaluation_rows'] == frozen['evaluation_rows'] == 6 * len(units) and
        {(r['source_lr'], r['budget'], r['seed'], r['arm']) for r in rows} == {(*u, arm) for u in units for arm in ARMS} and
        result['fitted_models'] == frozen['fitted_models'] == 4 * len(units) and result['updates'] == frozen['total_updates'] == 2000 * len(units))
    checks['all_fitted_checkpoint_file_hashes'] = len(result['checkpoint_hashes']) == 4 * len(units) and all(
        sha(folder / 'models' / name) == value for name, value in result['checkpoint_hashes'].items())
    states = {}; source_ok = True; probe_state = None
    for ref in refs:
        key = ref['source_lr'], ref['budget'], ref['seed']
        for file_key, hash_key in [('checkpoint_file', 'checkpoint_sha256'), ('control_result_file', 'control_result_sha256'),
                                  ('source_audit_file', 'source_audit_sha256'), ('config_snapshot_file', 'config_snapshot_sha256')]:
            source_ok &= sha(REPO / ref[file_key]) == ref[hash_key]
        payload = torch.load(REPO / ref['checkpoint_file'], map_location='cpu', weights_only=True)
        states[key] = payload['model']
        old_audit = json.loads((REPO / ref['source_audit_file']).read_text())
        source_ok &= digest(states[key]) == ref['backbone_state_sha256'] and old_audit['status'] == 'PASS_AUDIT'
        if probe_state is None and ref['source_lr'] == 'high_lr':
            old_result = json.loads((REPO / ref['control_result_file']).read_text())
            probe_file = REPO / ref['control_result_file']; probe_file = probe_file.parent / 'models/base_b18_s5501.pt'
            source_ok &= sha(probe_file) == old_result['checkpoint_hashes'][probe_file.name]
            probe_state = torch.load(probe_file, map_location='cpu', weights_only=True)['model']
    checks['all_immutable_source_control_checkpoints_and_audits_match'] = bool(source_ok)
    circuit = load_module('learned_attention_audit_circuit', PILOT / 'circuit.py').CircuitMaps(epsilon=.001)
    model_module = load_module('learned_attention_audit_model', ROOT / 'model.py')
    probe_checks, probe_errors = audit_active_probe(config, model_module, circuit, probe_state)
    checks.update(probe_checks)
    errors = dict(logits=0., probability=0., weights=0., cache_features=0., raw_maps=0., normalization=0.,
                  mixture_probability=0., probability_range_excess=0., metrics=0., fixtures=0., equivariance=0.)
    metadata_ok = counts_ok = state_ok = initialization_ok = batches_ok = cache_ok = predictions_ok = selections_ok = convex_ok = technical_ok = True
    recomputed = []
    for ref in refs:
        family, budget, seed = ref['source_lr'], ref['budget'], ref['seed']; state = states[family, budget, seed]
        cache = reference_cache(images, state, circuit)
        for arm in ARMS:
            row = next(r for r in rows if (r['source_lr'], r['budget'], r['seed'], r['arm']) == (family, budget, seed, arm))
            learned = arm.startswith('learned_'); fitted = arm in fitted_arms
            stem = f'{family}_b{budget}_s{seed}_{arm}'
            metadata_ok &= row['source'] == ref and row['CNN_passes_per_image'] == (1 if arm == 'source_identity' else 4)
            head = None; backbone = state
            if fitted:
                payload = torch.load(folder / 'models' / f'{stem}.pt', map_location='cpu', weights_only=True)
                weights = payload['model']; metadata_ok &= payload['settings'] == row
                backbone = {key[len('backbone.'):]: value for key, value in weights.items() if key.startswith('backbone.')}
                head = {key[len('scorer.'):]: value for key, value in weights.items() if key.startswith('scorer.')} if learned else None
                state_ok &= row['backbone_before_sha256'] == ref['backbone_state_sha256'] and digest(backbone) == row['backbone_after_sha256']
                state_ok &= (all(torch.equal(backbone[key], value) for key, value in state.items()) if learned else row['backbone_after_sha256'] != row['backbone_before_sha256'])
                counts_ok &= sum(value.numel() for value in weights.values()) == (10930 if learned else 10681) and all(torch.isfinite(value).all().item() for value in weights.values())
                metadata_ok &= (row['fit_count'] == 1 and row['steps'] == row['optimizer_updates'] == 500 and
                    row['learning_rate'] == (.0005 if learned else .0001) and row['weight_decay'] == .0001 and
                    row['optimizer_group'] == ('scorer' if learned else 'backbone') and
                    row['trainable_parameters'] == (249 if learned else 10681) and
                    row['training_CNN_passes_per_image'] == (0 if learned else (1 if arm == 'single_adapted' else 4)))
                batches_ok &= row['batch_sequence_sha256'] == batch_sequence(budget, seed) == ref['source_batch_sequence_sha256']
                if learned:
                    initial = model_module.make_model(arm, state, head_seed=seed + 100003)
                    initialization_ok &= (digest(initial.scorer.state_dict()) == row['head_initial_sha256'] and
                        digest(head) == row['head_final_sha256'] != row['head_initial_sha256'] and sum(v.numel() for v in head.values()) == 249)
                else:
                    initialization_ok &= row['head_initial_sha256'] is None and row['head_final_sha256'] is None
            else:
                metadata_ok &= row['fit_count'] == row['steps'] == row['optimizer_updates'] == row['trainable_parameters'] == 0
                state_ok &= row['backbone_before_sha256'] == row['backbone_after_sha256'] == ref['backbone_state_sha256']
            counts_ok &= row['parameters'] == dict(backbone=10681, scorer=249 if learned else 0,
                trainable=249 if learned else (10681 if arm in ['uniform_adapted', 'single_adapted'] else 0), total=10930 if learned else 10681)
            current_cache = reference_cache(images, backbone, circuit) if arm in ['uniform_adapted', 'single_adapted'] else cache
            if row['cache'] is not None:
                meta = row['cache']; indices = dict(dense=subsets['dense_indices'][str(budget)],
                    weak=np.flatnonzero(data['role'] == 'weak').tolist(), val=val.tolist())
                cache_ok &= (meta['ephemeral'] and not meta['persisted'] and meta['image_only'] and meta['bytes'] == 63360 * (budget + 1152 + 695) and
                    meta['bytes'] <= meta['maximum_bytes'] == 120 * 1024 ** 2 and meta['indices'] == indices and
                    meta['backbone_state_sha256'] == ref['backbone_state_sha256'] and meta['TRAIN_VAL_sha256'] == sha(PILOT / 'TRAIN_VAL.npz') and
                    meta['model_sha256'] == sha(ROOT / 'model.py') and set(meta['keys']) == set(cache))
            else:
                cache_ok &= arm in ['uniform_adapted', 'single_adapted']
            variants = VARIANTS if learned else ['actual']
            with np.load(folder / 'val_probs' / f'{stem}.npz', allow_pickle=False) as archive:
                arrays = {key: archive[key] for key in archive.files}
            metadata_ok &= (arrays['variants'].tolist() == variants and arrays['thresholds'].tolist() == config['thresholds'] and
                np.array_equal(arrays['truth'], truth) and np.array_equal(arrays['target'], target) and
                arrays['probability'].shape == arrays['logits'].shape == (len(variants), 695, 1, 12, 12) and
                np.isfinite(arrays['probability']).all() and np.isfinite(arrays['logits']).all())
            errors['probability_range_excess'] = max(errors['probability_range_excess'], float(max(0., arrays['probability'].max() - 1., -arrays['probability'].min())))
            for index, variant in enumerate(variants):
                with torch.inference_mode():
                    logits, probability, weights, scores = reference_forward(current_cache, arm, head, variant)
                errors['logits'] = max(errors['logits'], float(np.max(np.abs(logits.numpy() - arrays['logits'][index]))))
                errors['probability'] = max(errors['probability'], float(np.max(np.abs(probability.numpy() - arrays['probability'][index]))))
                errors['mixture_probability'] = max(errors['mixture_probability'], float(np.max(np.abs(
                    torch.tensor(arrays['logits'][index]).sigmoid().numpy() - arrays['probability'][index]))))
                if weights is not None:
                    views = current_cache['view_logits'].sigmoid()
                    convex_ok &= (bool(weights.min() >= 0) and float((weights.sum(1) - 1).abs().max()) < 3e-7 and
                        bool((probability >= views.min(1).values - 3e-7).all()) and bool((probability <= views.max(1).values + 3e-7).all()))
                metric_rows = []
                for ti, threshold in enumerate(config['thresholds']):
                    masks = arrays['probability'][index, :, 0] >= threshold; prediction = classify(masks)
                    predictions_ok &= np.array_equal(prediction, arrays['predictions'][index, ti])
                    predictions_ok &= np.array_equal(np.packbits(masks.reshape(695, 144), axis=1), arrays['packed_masks'][index, ti])
                    observation = dict(threshold=threshold, mask_F1=macro_f1(truth, prediction), IoU=mean_iou(masks, target)); metric_rows.append(observation)
                    for name, value in observation.items():
                        errors['metrics'] = max(errors['metrics'], abs(value - row['VAL_scores_all_thresholds'][variant][ti][name]))
                if variant == 'actual':
                    chosen = selected(metric_rows); selections_ok &= chosen['threshold'] == float(arrays['selected_threshold'])
                    for name, value in chosen.items():
                        errors['metrics'] = max(errors['metrics'], abs(value - row['selected'][name]))
                    selected_index = config['thresholds'].index(chosen['threshold'])
                ablation = dict(**metric_rows[selected_index], mask_flip_fraction=float(np.mean(
                    (arrays['probability'][index] >= chosen['threshold']) != (arrays['probability'][0] >= chosen['threshold']))))
                for name, value in ablation.items():
                    errors['metrics'] = max(errors['metrics'], abs(value - row['ablations'][variant][name]))
            with np.load(folder / 'fixtures' / f'{stem}.npz', allow_pickle=False) as archive:
                fixture = {key: archive[key] for key in archive.files}
            technical_ok &= np.array_equal(fixture['x'], images[:16].numpy())
            errors['fixtures'] = max(errors['fixtures'], float(np.max(np.abs(fixture['probability'] - arrays['probability'][0, :16]))))
            restored = np.stack([np.rot90(fixture['transformed_probability'][k], -k, (-2, -1)) for k in range(4)])
            errors['fixtures'] = max(errors['fixtures'], float(np.max(np.abs(restored - fixture['restored_probability']))))
            eq = float(np.max(np.abs(restored - fixture['probability'][None])))
            errors['equivariance'] = max(errors['equivariance'], abs(eq - row['C4_equivariance_max_error']))
            technical_ok &= row['C4_equivariance_required'] == (arm != 'source_identity')
            if arm != 'source_identity':
                technical_ok &= eq <= 1e-6
            if row['cache'] is not None:
                for key in ['view_features', 'view_logits', 'uniform_probability']:
                    expected = current_cache[key][:16]
                    if key in ['view_features', 'view_logits']:
                        expected = expected.permute(1, 0, 2, 3, 4)
                    errors['cache_features'] = max(errors['cache_features'], float(np.max(np.abs(expected.numpy() - fixture[key]))))
                for mode in ['plain', 'joint']:
                    errors['raw_maps'] = max(errors['raw_maps'], float(np.max(np.abs(current_cache['raw_' + mode][:16].numpy() - fixture['raw_' + mode]))))
                    errors['normalization'] = max(errors['normalization'], float(np.max(np.abs(normalize_reference(fixture['raw_' + mode]) - fixture['maps_' + mode]))))
            recomputed.append(dict(source_lr=family, budget=budget, seed=seed, arm=arm, selected=chosen))
    checks.update(all_saved_model_metadata_parameters_and_optimizer_rates=bool(metadata_ok and counts_ok),
        exactly_frozen_learned_backbones_and_adapted_CNN_changed=bool(state_ok),
        all249_head_initializations_and_final_digests=bool(initialization_ok),
        all500_minibatch_sequences_exact_and_control_paired=bool(batches_ok),
        ephemeral_label_free_cache_indices_size_and_source_provenance=bool(cache_ok),
        independent_full_forward_logits_and_probabilities=errors['logits'] < 1e-4 and errors['probability'] < 1e-5,
        stable_logit_probability_identity_and_convex_mixture=bool(convex_ok) and errors['mixture_probability'] < 8 * np.finfo(np.float32).eps and errors['probability_range_excess'] < 8 * np.finfo(np.float32).eps and probe_errors['float64_mixture_identity'] < 1e-12,
        independent_cached_source_features_maps_and_normalization=errors['cache_features'] < 1e-4 and errors['raw_maps'] < 1e-4 and errors['normalization'] < 1e-5,
        all81_thresholds_masks_classes_metrics_and_fixed_interventions=bool(predictions_ok and selections_ok) and errors['metrics'] < 2e-7,
        all_C4_fixtures_and_source_identity_exemption=bool(technical_ok) and errors['fixtures'] < 1e-5 and errors['equivariance'] < 1e-10)
    paired = True
    for unit in units:
        group = [row for row in rows if (row['source_lr'], row['budget'], row['seed']) == unit]
        heads = [row for row in group if row['arm'].startswith('learned_')]
        fitted = [row for row in group if row['arm'] in fitted_arms]
        paired &= len({r['head_initial_sha256'] for r in heads}) == 1 and len({r['batch_sequence_sha256'] for r in fitted}) == 1
    checks['plain_joint_initializations_and_allfour_fit_batches_matched'] = bool(paired)
    gates = recompute_gates(recomputed, config)
    checks['strict_three_control_A_physics_B_and_two_control_D_independently_recomputed'] = compare_stored_gates(gates, result['gates']) < 2e-7
    replication = {}
    if result['phase'] == 'replicate':
        aggregate = read('AGGREGATE_RESULT.json'); old_folder = ROOT / aggregate['source_trials'][0]
        old = json.loads((old_folder / 'RESULT.json').read_text()); old_audit = json.loads((old_folder / 'AUDIT.json').read_text())
        checks['exact_new_two_seed_and_all_three_seed_aggregation'] = (
            old_audit['status'] == 'PASS_AUDIT' and old_audit['result_sha256'] == sha(old_folder / 'RESULT.json') and
            old['seeds'] == [5501] and (old['gates']['A_any'] or old['gates']['D_uniform_training']['passed']) and
            aggregate['rows'] == old['rows'] + rows and aggregate['seeds'] == [5501, 5521, 5557] and
            len({(r['source_lr'], r['budget'], r['seed'], r['arm']) for r in aggregate['rows']}) == 72)
        all_gates = recompute_gates(old['rows'] + recomputed, config)
        robust = {arm: gates['A_architecture'][arm]['passed'] and all_gates['A_architecture'][arm]['passed'] for arm in ['learned_plain', 'learned_joint']}
        checks['all_three_new_two_and_robust_A_B_D_gates_recomputed'] = (
            compare_stored_gates(all_gates, aggregate['gates']) < 2e-7 and compare_stored_gates(gates, aggregate['new_seed_gates']) < 2e-7 and
            aggregate['robust_architecture_by_arm'] == robust and aggregate['robust_architecture_pass'] == any(robust.values()) and
            aggregate['robust_uniform_training_pass'] == (gates['D_uniform_training']['passed'] and all_gates['D_uniform_training']['passed']))
        replication = dict(new_two_seeds=gates, all_three_seeds=all_gates)
    checks['all_audited_inputs_unchanged'] = all(sha(path) == value for path, value in before.items())
    return dict(status='PASS_AUDIT' if all(checks.values()) else 'FAIL_AUDIT', scope='INDEPENDENT_CPU_LEARNED_C4_TRAIN_VAL_DEVELOPMENT_ONLY',
        trial=str(folder.relative_to(ROOT)), phase=result['phase'], audit_source_sha256=sha(__file__), result_sha256=sha(folder / 'RESULT.json'),
        checks=checks, checks_passed=sum(bool(value) for value in checks.values()), checks_total=len(checks), maximum_errors=errors,
        active_probe_errors=probe_errors, independent_gates=gates, replication=replication, seconds=time.monotonic() - started,
        numerical_tolerances=dict(logits=1e-4, probabilities=1e-5, mixture_probability=8 * float(np.finfo(np.float32).eps), float64_mixture_identity=1e-12),
        numerical_note='The compensated exact-uniform-initialization probability expression and stable logsumexp logit are mathematically identical. Float32 arithmetic produced a4.17e-7 parity gap and2.38e-7 range excess; an8-epsilon arithmetic budget replaces the preliminary3e-7 audit bound. Initial failed audit is preserved. Float64 identity is checked independently; no model, data, protocol, scientific threshold or gate changed.',
        caveat='Reused TRAIN/VAL only. No access to closed confirmation data; passing A/B/D does not establish fresh-test superiority or publication novelty.')


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--trial', type=Path)
    args = parser.parse_args()
    folders = [args.trial if args.trial.is_absolute() else ROOT / args.trial] if args.trial else sorted(path.parent for path in (ROOT / 'trials').glob('*/RESULT.json'))
    assert folders, 'No completed trial'
    torch.set_num_threads(2)
    with threadpool_limits(limits=2):
        for folder in folders:
            output = folder / 'AUDIT.json'
            if output.exists():
                previous = json.loads(output.read_text()); assert previous['result_sha256'] == sha(folder / 'RESULT.json')
                if previous['audit_source_sha256'] == sha(__file__):
                    outcome = previous
                else:
                    archive = folder / f"AUDIT_PREVIOUS_{previous['audit_source_sha256'][:12]}.json"
                    assert not archive.exists(); output.rename(archive); outcome = audit_trial(folder)
            else:
                outcome = audit_trial(folder)
            if not output.exists():
                output.write_text(json.dumps(outcome, indent=2, ensure_ascii=False, default=lambda value: value.item()) + '\n')
            print(json.dumps({key: outcome[key] for key in ['status', 'trial', 'checks_passed', 'checks_total', 'maximum_errors',
                  'active_probe_errors', 'independent_gates', 'replication', 'seconds']}, ensure_ascii=False, default=lambda value: value.item()), flush=True)
            assert outcome['status'] == 'PASS_AUDIT'


if __name__ == '__main__':
    main()
