"""Describe every saved learned-orbit TRAIN/VAL trial; do not run models."""
from pathlib import Path
import datetime
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
HELPER = ROOT.parent / "sem_arch_joint_adaptation_20261102" / "report.py"
spec = importlib.util.spec_from_file_location("learned_orbit_json_report_helpers", HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
read, sha, rel = helpers.read, helpers.sha, helpers.rel
discover, actual_rows, views = helpers.discover, helpers.actual_rows, helpers.views
mean, pct, pp, passed = helpers.mean, helpers.percent, helpers.pp, helpers.passed
plt, np = helpers.plt, helpers.np
FITTED = ["learned_plain", "learned_joint", "uniform_adapted", "single_adapted"]
ARMS = ["source_identity", "uniform_frozen", "learned_plain", "learned_joint", "uniform_adapted", "single_adapted"]
HEAD_CONTROLS = ["uniform_frozen", "uniform_adapted", "single_adapted"]
FAMILIES = ["high_lr", "low_lr"]
PRIOR = ROOT.parent / "sem_arch_orbit_pool_20261102"
CONFIRMATION = ROOT.parent / "sem_arch_orbit_confirmation_20261102"


def verify(result):
    units = {(row["source_lr"], row["budget"], row["seed"]) for row in result["rows"]}
    by_key = {(row["source_lr"], row["budget"], row["seed"], row["arm"]): row for row in result["rows"]}
    assert len(by_key) == len(result["rows"]) == 6 * len(units)
    for key in units:
        rows = [by_key[key + (arm,)] for arm in ARMS]
        source = rows[0]["source"]
        assert all(row["source"] == source for row in rows)
        for file_key, hash_key in [("checkpoint_file", "checkpoint_sha256"),
                                  ("control_result_file", "control_result_sha256"),
                                  ("source_audit_file", "source_audit_sha256"),
                                  ("config_snapshot_file", "config_snapshot_sha256")]:
            assert sha(REPO / source[file_key]) == source[hash_key]
        fitted = [row for row in rows if row["arm"] in FITTED]
        learned = [row for row in rows if row["arm"].startswith("learned_")]
        assert len({row["batch_sequence_sha256"] for row in fitted}) == 1
        assert fitted[0]["batch_sequence_sha256"] == source["source_batch_sequence_sha256"]
        assert len({row["head_initial_sha256"] for row in learned}) == 1
        for row in rows:
            assert row["backbone_before_sha256"] == source["backbone_state_sha256"]
            assert row["CNN_passes_per_image"] == (1 if row["arm"] == "source_identity" else 4)
            assert row["fit_count"] == (1 if row["arm"] in FITTED else 0)
            assert row["optimizer_updates"] == (500 if row["arm"] in FITTED else 0)
            if row["arm"].startswith("learned_"):
                assert row["trainable_parameters"] == row["parameters"]["scorer"] == 249
                assert row["parameters"]["total"] == 10930
                assert row["backbone_after_sha256"] == row["backbone_before_sha256"]
                assert row["head_initial_sha256"] != row["head_final_sha256"]
            elif row["arm"] in ["uniform_adapted", "single_adapted"]:
                assert row["trainable_parameters"] == row["parameters"]["total"] == 10681
                assert row["backbone_after_sha256"] != row["backbone_before_sha256"]
            else:
                assert row["trainable_parameters"] == 0


def figure(result_views):
    if not result_views:
        return None
    points = [(label, family, result) for label, result in result_views for family in FAMILIES]
    path = ROOT / "figures" / "learned_orbit_validation.png"
    path.parent.mkdir(exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(13, 6.2))
    x = np.arange(len(points));width = .12
    colors = ["#aaaaaa", "#777777", "#3c78a8", "#b25a43", "#90734e", "#8d6cab"]
    for offset, arm, color in zip([-2.5, -1.5, -.5, .5, 1.5, 2.5], ARMS, colors):
        values = [100 * mean([row for row in result["rows"] if row["source_lr"] == family], arm)
                  for _, family, result in points]
        bars = axes[0].bar(x + offset * width, values, width, label=arm, color=color)
        axes[0].bar_label(bars, fmt="%.2f", fontsize=7, padding=3, rotation=90 if len(points) > 2 else 0)
    axes[0].set_ylim(0, min(100, max(bar.get_height() for bar in axes[0].patches) + (14 if len(points) > 2 else 9)))
    axes[0].set_ylabel("Validation Macro-F1, %")
    axes[0].set_title("Shared 81-threshold grid for every output")
    axes[0].legend(fontsize=8, loc="lower left")
    series = [(-.3, "learned_plain", "vs_uniform_frozen", "plain − frozen uniform", "#3c78a8", "o"),
              (-.2, "learned_plain", "vs_uniform_adapted", "plain − C4-adapted", "#3c78a8", "x"),
              (-.1, "learned_plain", "vs_single_adapted", "plain − single-adapted", "#3c78a8", "+"),
              (0, "learned_joint", "vs_uniform_frozen", "joint − frozen uniform", "#b25a43", "o"),
              (.1, "learned_joint", "vs_uniform_adapted", "joint − C4-adapted", "#b25a43", "x"),
              (.2, "learned_joint", "vs_single_adapted", "joint − single-adapted", "#b25a43", "+"),
              (.3, None, None, "joint − plain (B)", "#4d8d63", "D")]
    for offset, arm, control, label, color, marker in series:
        values = [100 * (result["gates"]["A_architecture"][arm]["by_source_lr"][family][control]["delta"] if arm else
                        result["gates"]["B_physics"]["by_source_lr"][family]["delta"]) for _, family, result in points]
        axes[1].scatter(x + offset, values, color=color, marker=marker, label=label, s=50)
    axes[1].axhline(0, color="black", lw=.8)
    axes[1].axhline(.5, color="gray", ls="--", lw=.8, label="Mean-gain gate: +0.5 pp")
    axes[1].set_ylabel("Macro-F1 difference, percentage points")
    axes[1].set_title("A requires all three controls in both families")
    axes[1].legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.17), ncol=2)
    for axis in axes:
        axis.set_xticks(x, [f"{label}\n{family}" for label, family, _ in points])
        axis.set_xlim(-.6, len(points) - .4)
    fig.suptitle("Learned 249-parameter CNN view weights on reused development VAL", fontsize=11)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def training_figure(result_views):
    if not result_views:
        return None
    points = [(label, family, result) for label, result in result_views for family in FAMILIES]
    path = ROOT / "figures" / "uniform_training_validation.png"
    x = np.arange(len(points));fig, axis = plt.subplots(figsize=(9, 4.5))
    for offset, control, label, color, marker in [(-.08, "uniform_frozen", "C4-adapted − frozen C4", "#90734e", "o"),
                                                  (.08, "single_adapted", "C4-adapted − single-adapted", "#8d6cab", "D")]:
        values = [100 * result["gates"]["D_uniform_training"]["by_source_lr"][family][f"vs_{control}"]["delta"]
                  for _, family, result in points]
        axis.scatter(x + offset, values, color=color, marker=marker, s=55, label=label)
    axis.axhline(0, color="black", lw=.8)
    axis.axhline(.5, color="gray", ls="--", lw=.8, label="Mean-gain gate: +0.5 pp")
    axis.set_xticks(x, [f"{label}\n{family}" for label, family, _ in points])
    axis.set_ylabel("Macro-F1 difference, percentage points")
    axis.set_title("D: train CNN through C4 versus matched single-view training")
    axis.legend(fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.17), ncol=2)
    fig.tight_layout();fig.savefig(path, dpi=180, bbox_inches="tight");plt.close(fig)
    return path


def build():
    config = read(ROOT / "CONFIG.json")
    trials = discover(ROOT)
    complete = [trial for trial in trials if trial["result"]]
    failures = [trial for trial in trials if trial["failure"]]
    pending = [trial for trial in trials if not trial["result"] and not trial["failure"]]
    rows = actual_rows(trials)
    fits = sum(row["fit_count"] for row in rows)
    updates = sum(row["optimizer_updates"] for row in rows)
    prior_manifest = read(PRIOR / "REPORT_MANIFEST.json")
    prior_fits = prior_manifest["linked_stage_unique_completed_fits"]
    confirmation = read(CONFIRMATION / "RESULT.json")
    result_views = [("screen" if result.get("phase") == "screen" else label, result)
                    for label, result in views(trials)]
    for trial in complete:
        assert trial["result"]["frozen_sha256"] == sha(trial["path"] / "FROZEN.json")
        assert trial["frozen"]["fresh_confirmation_access"] is False
        verify(trial["result"])
        assert trial["result"]["fitted_models"] == sum(row["fit_count"] for row in trial["result"]["rows"])
        assert trial["result"]["updates"] == sum(row["optimizer_updates"] for row in trial["result"]["rows"])
        if trial["aggregate"]:
            verify(trial["aggregate"])
    output_figure = figure(result_views)
    output_training_figure = training_figure(result_views)
    text = ["# Обучаемый CNN-блок объединения четырёх видов", "",
            "Новая обучаемая часть модели — общий для четырёх видов CNN-блок "
            "`Conv1×1(29→8), GELU, Conv1×1(8→1)` с **249 параметрами**. Он вычисляет пространственные "
            "score; softmax по видам задаёт веса выпуклой суммы вероятностей. Исходная CNN с 10 681 "
            "параметром заморожена; всего у learned-модели 10 930 параметров. Нулевой последний слой "
            "даёт точное начальное совпадение с равномерным C4. На предсказании нужны четыре прохода "
            "исходной CNN и малый общий scorer. C4 и обучаемое объединение видов — известные общие принципы; "
            "новизна предметной конструкции здесь не объявляется доказанной.", "",
            "29 входов scorer: 24 согласованных признака вида, его вероятность, равномерное среднее, SEM "
            "и две условные карты. Learned_plain получает вероятность/неопределённость; learned_joint — "
            "совместные DtN-карты из равномерного C4. Карты отделены от градиента; нормировка log1p100, "
            "центрирование/RMS, стабилизатор 1e−6. Внутри источника plain/joint имеют одинаковые начальные "
            "параметры и батчи. Общие 1×1-операции сохраняют согласованность перестановки видов; "
            "C4-эквивариантность проверяется отдельно от качества.", "",
            "## Поиск и учёт обучений", "",
            f"Локальных попыток {len(trials)}; завершено {len(complete)}; технических ошибок {len(failures)}; "
            f"незавершённых {len(pending)}. Сохранённых оценочных строк {len(rows)}; новых обучений **{fits}**, "
            f"обновлений {updates:,}. Два замороженных выхода не считаются обучениями. "
            "Строки сводного расширения повторно не считаются.", "",
            f"Предыдущий поиск и контроли содержат {prior_fits} уникальных обучений; вместе с этим этапом "
            f"**{prior_fits + fits}**. Старые источники и результаты сохраняются: "
            f"[полный журнал прежних архитектурных попыток]({rel(PRIOR / 'REPORT.md', ROOT)}).", "",
            "## Общее обучение и сильные контроли", "",
            "Прежний лосс: BCE итоговой плотной маски и geometry_loss с весом 1 на слабых метках. "
            "500 шагов AdamW, batch 8 dense + 8 weak, weight_decay 0,0001. У learned обучаются только "
            "249 параметров с lr=0,0005. Uniform_adapted обучает все 10 681 параметр CNN 500 шагов "
            "с lr=0,0001 через равномерный C4 и тот же лосс. Stable logsumexp-логит смеси — численная "
            "реализация прежнего лосса. Плотные бюджеты 18/27, розыгрыш 5303, 1152 weak и 695 VAL прежние; "
            "weak-маски оптимизатору не передаются. Кеш допустим только для замороженных CNN; "
            "адаптируемые контроли пересчитывают проход. Single_adapted получает те же 500 шагов "
            "с lr=0,0001 и теми же батчами через один вид; оценивается также через C4. "
            "Uniform_adapted использует 4 CNN-прохода на обучающее изображение, single_adapted — 1; "
            "число шагов одинаково, вычислительная стоимость обучения различается. "
            "Этот контроль отделяет обучение через C4 от одного дополнительного дообучения CNN.", "",
            "A проверяется отдельно для каждого learned-варианта против **всех трёх** uniform_frozen, "
            "uniform_adapted и single_adapted, отдельно в high_lr и low_lr. Все шесть сравнений должны пройти: "
            "средний ΔF1 ≥0,5 п.п.; ΔF1 каждого бюджета ≥−0,25 п.п.; средний ΔIoU ≥−0,2 п.п. "
            "B — learned_joint против learned_plain в обеих семьях, с требованием A joint. "
            "Source_identity публикуется как дополнительный исход, а не достаточный контроль для A. "
            "Все шесть выходов используют одну сетку 81 порога 0,10…0,90 с шагом 0,01: "
            "F1, IoU, близость к 0,5, меньший порог. Бюджеты равновесны. При расширении нужны "
            "одновременно все три и новые два seed отдельно.", "",
            "**D, отдельная проверка обучения CNN:** uniform_adapted против обоих uniform_frozen "
            "и single_adapted, с теми же условиями, в обеих семьях. D относится к изменённым весам CNN "
            "при обучении через C4; его прохождение не подтверждает пользу scorer с 249 параметрами "
            "и не изменяет A/B. Критерий D и single-view контроль записаны до первого обучения.", ""]
    if result_views:
        text += ["| Набор seed | Семья | Identity F1, % | Frozen C4 F1, % | Learned plain F1, % | Learned joint F1, % | Adapted C4 F1, % | Single-adapted F1, % | A plain / joint | B | D |",
                 "|---|---|---:|---:|---:|---:|---:|---:|---|---|---|"]
        for label, result in result_views:
            for family in FAMILIES:
                family_rows = [row for row in result["rows"] if row["source_lr"] == family]
                a = result["gates"]["A_architecture"];b = result["gates"]["B_physics"]
                values = " | ".join(pct(mean(family_rows, arm)) for arm in ARMS)
                text.append(f"| {label}: {result['seeds']} | {family} | {values} | "
                            f"{passed(a['learned_plain']['by_source_lr'][family]['passed'])} / "
                            f"{passed(a['learned_joint']['by_source_lr'][family]['passed'])} | "
                            f"{passed(b['by_source_lr'][family]['passed'])} | "
                            f"{passed(result['gates']['D_uniform_training']['by_source_lr'][family]['passed'])} |")
            text += ["", f"Совместно обе семьи: A plain "
                     f"**{passed(result['gates']['A_architecture']['learned_plain']['passed'])}**, A joint "
                     f"**{passed(result['gates']['A_architecture']['learned_joint']['passed'])}**, B "
                     f"**{passed(result['gates']['B_physics']['passed'])}**; отдельно D "
                     f"**{passed(result['gates']['D_uniform_training']['passed'])}**.", ""]
    else:
        text += ["Завершённого результата пока нет. Вывод о прохождении A/B/D не сделан.", ""]
    if output_figure:
        text += ["![Все выходы и раздельные сравнения с сильными контролями](figures/learned_orbit_validation.png)", "",
                 "Это точечные средние адаптивной разработки на повторно используемой VAL. "
                 "Независимые интервалы подтверждения не рассчитываются; средние всех трёх и новых двух "
                 "seed при расширении перекрываются по данным.", ""]
    if output_training_figure:
        text += ["![D: обучение CNN через C4 и matched single-view контроль](figures/uniform_training_validation.png)", "",
                 "D публикуется отдельно от A/B обучаемого scorer. На рисунке средние ΔF1; "
                 "ограничения по бюджетам и IoU приведены ниже.", ""]
    text += ["## Все сохранённые попытки", ""]
    for trial in trials:
        path = trial["path"]
        text += [f"### {path.name}", "", f"[FROZEN.json]({rel(path / 'FROZEN.json', ROOT)}).", ""]
        if not trial["result"]:
            if trial["failure"]:
                item = trial["failure"]
                text += [f"Техническая ошибка `{item.get('error_type', 'см. файл')}`: "
                         f"{str(item.get('error', '')).replace(chr(10), ' ')}. "
                         f"[FAILURE.json]({rel(path / 'FAILURE.json', ROOT)}). Она не считается "
                         "отрицательным научным исходом архитектуры.", ""]
            else:
                text += ["Попытка начата, итоговый RESULT.json ещё не сохранён.", ""]
            text += [f"Сохранено оценок {len(trial['partial'])}; обучений "
                     f"{sum(row['fit_count'] for row in trial['partial'])}.", ""]
            continue
        result = trial["result"]
        text += [f"`{result['status']}`; {result['phase']}; seed {result['seeds']}; обучений "
                 f"{result['fitted_models']}, оценочных строк {result['evaluation_rows']}, обновлений "
                 f"{result['updates']:,}; полное время {result['seconds']:.2f} с. "
                 f"[RESULT.json]({rel(path / 'RESULT.json', ROOT)}), SHA-256 `{sha(path / 'RESULT.json')}`.", "",
                 "| Семья | Бюджет | Seed | Вариант | Обучаемых параметров | Шагов | Порог | F1, % | IoU, % | Zero ΔF1, п.п. | Roll ΔF1, п.п. |",
                 "|---|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|"]
        for row in result["rows"]:
            chosen = row["selected"];ablations = row["ablations"]
            zero = pp(ablations["zero"]["mask_F1"] - chosen["mask_F1"]) if "zero" in ablations else "—"
            roll = pp(ablations["roll"]["mask_F1"] - chosen["mask_F1"]) if "roll" in ablations else "—"
            text.append(f"| {row['source_lr']} | {row['budget']} | {row['seed']} | {row['arm']} | "
                        f"{row['trainable_parameters']} | {row['steps']} | {chosen['threshold']:.2f} | "
                        f"{pct(chosen['mask_F1'])} | {pct(chosen['IoU'])} | {zero} | {roll} |")
        text.append("")
        gate_results = [("только эта попытка", result)]
        if trial["aggregate"]:
            gate_results.append(("все три seed", trial["aggregate"]))
            text += [f"[AGGREGATE_RESULT.json]({rel(path / 'AGGREGATE_RESULT.json', ROOT)}) "
                     "объединяет исходный скрининг и новые seed; новых обучений не добавляет.", ""]
        for label, item in gate_results:
            text += [f"**{label}: {item['seeds']}**", "",
                     "| Семья | Сравнение | ΔF1, п.п. | ΔIoU, п.п. | ΔF1 бюджеты 18 / 27, п.п. | Критерий |",
                     "|---|---|---:|---:|---|---|"]
            for family in FAMILIES:
                comparisons = []
                for arm in ["learned_plain", "learned_joint"]:
                    comparisons += [(f"A {arm} − {control}", item["gates"]["A_architecture"][arm]["by_source_lr"][family][f"vs_{control}"])
                                    for control in HEAD_CONTROLS]
                comparisons.append(("B learned_joint − learned_plain, с A joint", item["gates"]["B_physics"]["by_source_lr"][family]))
                comparisons += [(f"D uniform_adapted − {control}", item["gates"]["D_uniform_training"]["by_source_lr"][family][f"vs_{control}"])
                                for control in ["uniform_frozen", "single_adapted"]]
                for name, gate in comparisons:
                    text.append(f"| {family} | {name} | {pp(gate['delta'])} | {pp(gate['IoU_delta'])} | "
                                f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
            text.append("")
        if trial["aggregate"]:
            aggregate = trial["aggregate"]
            robust = {arm: aggregate["gates"]["A_architecture"][arm]["passed"] and
                      result["gates"]["A_architecture"][arm]["passed"] for arm in ["learned_plain", "learned_joint"]}
            robust_b = aggregate["gates"]["B_physics"]["passed"] and result["gates"]["B_physics"]["passed"]
            robust_d = aggregate["gates"]["D_uniform_training"]["passed"] and result["gates"]["D_uniform_training"]["passed"]
            text += [f"Одновременно все три и новые два seed: A plain {passed(robust['learned_plain'])}; "
                     f"A joint {passed(robust['learned_joint'])}; B {passed(robust_b)}; отдельно D {passed(robust_d)}.", ""]
        audit = trial["audit"]
        text += [(f"Независимый CPU-аудит: `{audit.get('status', 'см. файл')}`, "
                  f"{audit.get('checks_passed', 'см. файл')} / {audit.get('checks_total', 'см. файл')}. "
                  f"[AUDIT.json]({rel(path / 'AUDIT.json', ROOT)})." if audit else
                  "Итоговый независимый аудит пока не сохранён."), ""]
        if audit and audit.get("numerical_note"):
            text += [f"Примечание технического аудита: {audit['numerical_note']}", ""]
        for old_path in sorted(path.glob("AUDIT_PREVIOUS_*.json")):
            text += [f"Предыдущая техническая проверка: [{old_path.name}]({rel(old_path, ROOT)}), "
                     f"`{read(old_path).get('status', 'см. файл')}`. Результаты обучения сохранены.", ""]
    text += ["## Границы вывода", "",
             "В этом этапе используются только прежние TRAIN/VAL. Он не добавляет независимой проверки "
             "learned-модели. Прохождение A без B не позволяет приписывать выигрыш физическим картам; "
             "вмешательства Zero/roll используют выбранный actual-порог и проверяют чувствительность, "
             "которая сама по себе не доказывает пользу.", "",
             "Технический PASS относится к воспроизведению реализации и чисел; "
             "критерии A/B/D отдельно проверяют пользу соответствующих изменений.", "",
             f"Предыдущая отложенная проверка **равномерного C4**: "
             f"`{confirmation['status']}`; [неизменный отчёт]({rel(CONFIRMATION / 'REPORT.md', ROOT)}). "
             "Это отдельная уже завершённая проверка на восьми полях той же ИС; её исход не переименовывается "
             "в результат нового scorer. Для нового обучаемого блока потребуется отдельное закрытое подтверждение. "
             "Перенос между изделиями, экспертная типология дефектов и новизна требуют отдельных оснований.", "",
             "[PROTOCOL.md](PROTOCOL.md) · [CONFIG.json](CONFIG.json) · [LEDGER.json](LEDGER.json) · "
             "[model.py](model.py) · [runner.py](runner.py) · [audit.py](audit.py).", ""]
    (ROOT / "REPORT.md").write_text("\n".join(text))
    (ROOT / "README.md").write_text(
        "# Обучаемые CNN-веса четырёх видов\n\n"
        "249-параметровый общий scorer задаёт softmax-веса C4-видов. Исходная CNN заморожена; "
        "у plain/joint общий прежний лосс. A требует выигрыша над frozen C4, C4-adapted и single-adapted "
        "в обеих LR-семьях; B проверяет физические карты. Отдельный D проверяет C4-обучение CNN "
        "против frozen/single-adapted, без подмены A/B scorer. Все6 выходов калибруются по общей81-точечной VAL-сетке.\n\n"
        f"Завершено попыток {len(complete)}, технических ошибок {len(failures)}, новых обучений {fits}; "
        f"уникальных обучений вместе с прежними {prior_fits + fits}. Только прежняя TRAIN/VAL; "
        "нового независимого подтверждения этого блока нет.\n\n"
        "[Полный отчёт](REPORT.md) · [Протокол](PROTOCOL.md) · [Конфигурация](CONFIG.json) · [Журнал](LEDGER.json).\n\n"
        "Пересоздать только отчёт/рисунок:\n\n"
        "```bash\n.venv/bin/python -B gipoteza/sem_arch_learned_orbit_20261102/report.py\n```\n")
    inputs = [HELPER, PRIOR / "REPORT_MANIFEST.json", CONFIRMATION / "RESULT.json", CONFIRMATION / "REPORT.md"]
    inputs += [ROOT / name for name in ["CONFIG.json", "PROTOCOL.md", "LEDGER.json"] if (ROOT / name).exists()]
    for trial in trials:
        inputs += [trial["path"] / name for name in ["FROZEN.json", "RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json",
                   "PARTIAL_RESULTS.json", "AUDIT.json", "CONFIG_SNAPSHOT.json"] if (trial["path"] / name).exists()]
        inputs += sorted(trial["path"].glob("AUDIT_PREVIOUS_*.json"))
    for trial in complete:
        for source in trial["result"]["sources"]:
            inputs += [REPO / source[name] for name in ["checkpoint_file", "control_result_file", "source_audit_file", "config_snapshot_file"]]
    outputs = [ROOT / "REPORT.md", ROOT / "README.md"] + ([output_figure] if output_figure else [])
    if output_training_figure:
        outputs.append(output_training_figure)
    manifest = dict(status="REPORT_GENERATED", UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope="ADAPTIVE_OLD_TRAIN_VAL_LEARNED_ORBIT_CNN", report_script_sha256=sha(Path(__file__)),
        shared_report_helper_sha256=sha(HELPER), trial_count=len(trials), completed_trials=len(complete),
        failed_trials=len(failures), pending_trials=len(pending), actual_completed_fits=fits,
        evaluation_rows=len(rows), completed_updates=updates, prior_unique_completed_fits=prior_fits,
        linked_stage_unique_completed_fits=prior_fits + fits, prior_fresh_uniform_C4_status=confirmation["status"],
        matching_unit=["source_lr", "budget", "seed"], shared_source_fits_recounted=False,
        scientific_inputs_sha256={rel(path, ROOT): sha(path) for path in inputs},
        outputs_sha256={rel(path, ROOT): sha(path) for path in outputs})
    (ROOT / "REPORT_MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
