"""Append-only learned C4 fusion development on TRAIN/VAL only.

No fresh confirmation files, TEST/EVAL data or old test metrics are read.
Caches are image-only, ephemeral and bounded; adapted CNNs never use them.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import time
import traceback

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "0"
import numpy as np
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits
from model import (EVALUATION_ARMS, FITTED_ARMS, VARIANTS, VIEW_FIELDS,
                   architecture_spec, make_model, slice_cache, state_digest)

ROOT = Path(__file__).resolve().parent
G, REPO = ROOT.parent, ROOT.parents[1]
PILOT = G / "sem_architecture_pilot_20261102"
ORBIT = G / "sem_arch_orbit_pool_20261102"
FAMILIES = ["high_lr", "low_lr"]
START = None


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


# Reuse read-only source/provenance and hard-class utilities, binding their
# own original model during import. No old runner mutator is called.
previous_model = sys.modules.get("model")
sys.modules["model"] = module("fusion_source_orbit_model", ORBIT / "model.py")
try:
    orbit = module("fusion_source_orbit_utilities", ORBIT / "runner.py")
finally:
    if previous_model is None:
        del sys.modules["model"]
    else:
        sys.modules["model"] = previous_model
physics = module("fusion_unchanged_old_physics", PILOT / "physics_adapter.py")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def save(path, value):
    orbit.save(path, value)


def configuration(path):
    c = json.loads(path.read_text())
    assert c["candidate"] == "learned_orbit_attention"
    assert c["fitted_arms"] == FITTED_ARMS and c["evaluation_arms"] == EVALUATION_ARMS
    assert c["budgets"] == [18, 27] and c["screen_seeds"] == [5501]
    assert c["replication_seeds"] == [5501, 5521, 5557] and c["subset_seed"] == 5303
    assert c["steps"] == 500 and c["batch_size"] == 8
    assert c["head_learning_rate"] == .0005 and c["backbone_learning_rate"] == .0001
    assert c["weight_decay"] == .0001 and c["physics_weight"] == 1.
    assert c["epsilon"] == .001 and c["normalization_scale"] == 100.
    assert c["normalization_variance_floor"] == 1e-6
    assert c["technical_seed"] == 7503 and c["equivariance_tolerance"] == 1e-6
    assert c["thresholds"] == [round(.10 + .01 * i, 2) for i in range(81)]
    assert c["gates"] == dict(minimum_mean_F1_gain=.005,
        minimum_budget_F1_delta=-.0025, minimum_mean_IoU_delta=-.002)
    assert c["protocol_sha256"] == sha(ROOT / "PROTOCOL.md")
    return c


def source_hashes():
    names = ["model.py", "runner.py", "../sem_arch_orbit_pool_20261102/model.py",
        "../sem_arch_orbit_pool_20261102/runner.py", "../sem_architecture_pilot_20261102/model.py",
        "../sem_architecture_pilot_20261102/circuit.py", "../sem_architecture_pilot_20261102/physics_adapter.py",
        "../sem_architecture_pilot_20261102/prepare.py", "../sem_confirmation_20261028/prepare.py",
        "../sem_physics_materials/physics_loss_example.py", "../retained_evidence_20261027/SELECTED_SOURCES.zip"]
    return {name: sha(ROOT / name) for name in names}


def append_ledger(event):
    with (ROOT / ".ledger.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        path = ROOT / "LEDGER.json"
        ledger = json.loads(path.read_text()) if path.exists() else dict(version=1,
            scope="ADAPTIVE_TRAIN_VAL_ONLY_LEARNED_C4_FUSION", events=[])
        ledger["events"].append(dict(event, index=len(ledger["events"]),
            UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        save(path, ledger)
        fcntl.flock(lock, fcntl.LOCK_UN)


def inputs(c, seeds, device):
    subsets = json.loads((PILOT / "SUBSETS.json").read_text())
    initial = json.loads((PILOT / "INITIAL_LINEAGE.json").read_text())
    assert sha(PILOT / "TRAIN_VAL.npz") == subsets["train_val_sha256"] == initial["TRAIN_VAL_sha256"]
    with np.load(PILOT / "TRAIN_VAL.npz", allow_pickle=False) as z:
        assert set(z["role"]) == {"dense", "weak", "val"}
        arrays = {key: z[key].copy() for key in z.files}
    data = {}
    for budget in c["budgets"]:
        data[budget] = {}
        for role in ["dense", "weak", "val"]:
            ids = np.array(subsets["dense_indices"][str(budget)]) if role == "dense" else np.flatnonzero(arrays["role"] == role)
            values = dict(x=torch.tensor(5 * (arrays["X"][ids] - .2), device=device),
                label=torch.tensor(arrays["label"][ids], device=device), indices=ids.tolist())
            if role != "weak":
                values["mask"] = torch.tensor(arrays["Y"][ids].astype(np.float32), device=device)
            data[budget][role] = values
        assert len(data[budget]["dense"]["x"]) == budget
        assert len(data[budget]["weak"]["x"]) == 1152 and len(data[budget]["val"]["x"]) == 695
        assert np.array_equal(np.bincount(data[budget]["dense"]["label"].cpu().numpy(), minlength=9), np.full(9, budget // 9))
    # Source controls were originally recorded on the old seven-point grid.
    # Their frozen weights are independent of recalibration; validate their
    # provenance with that original grid, then score every new arm on c's81.
    source_grid = json.loads((ORBIT / "CONFIG.json").read_text())["thresholds"]
    refs, states = orbit.sources(dict(c, thresholds=source_grid), seeds)
    return data, refs, states, dict(TRAIN_VAL_sha256=sha(PILOT / "TRAIN_VAL.npz"),
        subsets_sha256=sha(PILOT / "SUBSETS.json"), initial_lineage_sha256=sha(PILOT / "INITIAL_LINEAGE.json"),
        original_source_control_thresholds=source_grid, evaluation_thresholds=c["thresholds"])


def make(c, arm, state, seed, device):
    return make_model(arm, state, head_seed=seed + 100003, epsilon=c["epsilon"],
        scale=c["normalization_scale"], norm_floor=c["normalization_variance_floor"]).to(device)


@torch.no_grad()
def cached_inputs(model, values, reference, c):
    cache = {}
    total_bytes = 0
    for role, data in values.items():
        output = {}
        for start in range(0, len(data["x"]), 16):
            part = model.precompute(data["x"][start:start + 16])
            if not output:
                for key, tensor in part.items():
                    shape = list(tensor.shape)
                    shape[1 if key in VIEW_FIELDS else 0] = len(data["x"])
                    output[key] = torch.empty(shape, dtype=tensor.dtype, device=tensor.device)
            for key, tensor in part.items():
                if key in VIEW_FIELDS:
                    output[key][:, start:start + len(data["x"][start:start + 16])].copy_(tensor)
                else:
                    output[key][start:start + len(tensor)].copy_(tensor)
        assert all(not tensor.requires_grad and torch.isfinite(tensor).all() for tensor in output.values())
        cache[role] = output
        total_bytes += sum(t.numel() * t.element_size() for t in output.values())
    assert total_bytes <= 120 * 1024 ** 2, total_bytes
    return cache, dict(ephemeral=True, persisted=False, image_only=True, bytes=total_bytes,
        maximum_bytes=120 * 1024 ** 2, backbone_state_sha256=reference["backbone_state_sha256"],
        indices={role: data["indices"] for role, data in values.items()},
        model_sha256=sha(ROOT / "model.py"), TRAIN_VAL_sha256=sha(PILOT / "TRAIN_VAL.npz"),
        keys=list(next(iter(cache.values()))))


def concat_cache(parts):
    return {key: torch.cat([part[key] for part in parts], dim=1 if key in VIEW_FIELDS else 0)
            for key in parts[0]}


def fit(c, model, values, cache, reference, trial, counter):
    learned = model.scorer is not None
    before = state_digest(model.backbone.state_dict())
    head_before = state_digest(model.scorer.state_dict()) if learned else None
    params = list(model.scorer.parameters()) if learned else list(model.backbone.parameters())
    rate = c["head_learning_rate"] if learned else c["backbone_learning_rate"]
    optimizer = torch.optim.AdamW(params, lr=rate, weight_decay=c["weight_decay"])
    rng = np.random.default_rng(reference["seed"] + 1000)
    batches = hashlib.sha256()
    model.train()
    started = time.monotonic()
    for step in range(1, c["steps"] + 1):
        ai = rng.integers(0, len(values["dense"]["x"]), c["batch_size"])
        wi = rng.integers(0, len(values["weak"]["x"]), c["batch_size"])
        batches.update(ai.astype(np.int64).tobytes()); batches.update(wi.astype(np.int64).tobytes())
        ai, wi = torch.tensor(ai, device="mps"), torch.tensor(wi, device="mps")
        optimizer.zero_grad(set_to_none=True)
        if learned:
            batch = concat_cache([slice_cache(cache["dense"], ai), slice_cache(cache["weak"], wi)])
            logits = model.forward_cached(batch)["logits"]
        else:
            logits = model(torch.cat((values["dense"]["x"][ai], values["weak"]["x"][wi])))
        dense, weak = logits.split(c["batch_size"])
        dense_loss = F.binary_cross_entropy_with_logits(dense, values["dense"]["mask"][ai])
        y = values["weak"]["label"][wi]
        geometry_loss = physics.geometry_loss(weak, torch.stack((y // 3, y % 3), dim=1))
        loss = dense_loss + c["physics_weight"] * geometry_loss
        assert torch.isfinite(loss)
        loss.backward()
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in params)
        assert any(float(p.grad.abs().sum()) > 0 for p in params)
        if learned:
            assert all(p.grad is None for p in model.backbone.parameters())
        optimizer.step(); counter[0] += 1
        if step % 100 == 0:
            progress = dict(stage="LEARNED_C4_TRAIN_VAL", trial=trial.name,
                source_lr=reference["source_lr"], budget=reference["budget"], seed=reference["seed"],
                arm=model.arm, step=step, target_steps=c["steps"], completed_updates=counter[0],
                dense_BCE=float(dense_loss.detach().cpu()), geometry_loss=float(geometry_loss.detach().cpu()),
                total_loss=float(loss.detach().cpu()), seconds=time.monotonic() - START)
            save(trial / "PROGRESS.json", progress); save(ROOT / "PROGRESS.json", progress)
            with (trial / "progress.jsonl").open("a") as handle:
                handle.write(json.dumps(progress) + "\n")
            print(json.dumps(progress), flush=True)
    torch.mps.synchronize()
    after = state_digest(model.backbone.state_dict())
    assert (before == after) if learned else (before != after)
    head_after = state_digest(model.scorer.state_dict()) if learned else None
    if learned:
        assert head_before != head_after
    assert batches.hexdigest() == reference["source_batch_sequence_sha256"]
    return dict(steps=c["steps"], optimizer_updates=c["steps"], fit_count=1,
        training_CNN_passes_per_image=0 if learned else (1 if model.arm == "single_adapted" else 4),
        trainable_parameters=sum(p.numel() for p in params), learning_rate=rate,
        optimizer_group="scorer" if learned else "backbone", weight_decay=c["weight_decay"],
        backbone_before_sha256=before, backbone_after_sha256=after,
        head_initial_sha256=head_before, head_final_sha256=head_after,
        batch_sequence_sha256=batches.hexdigest(), seconds=time.monotonic() - started)


def evaluate(c, model, values, cache):
    model.eval()
    variants = VARIANTS if model.scorer is not None else ["actual"]
    outputs, logits = [], []
    with torch.no_grad():
        for variant in variants:
            ps, zs = [], []
            for start in range(0, len(values["x"]), 16):
                result = (model.forward_details(values["x"][start:start + 16], variant) if cache is None
                          else model.forward_cached(slice_cache(cache, slice(start, start + 16)), variant))
                ps.append(result["probability"].cpu().numpy()); zs.append(result["logits"].cpu().numpy())
            outputs.append(np.concatenate(ps)); logits.append(np.concatenate(zs))
    probability = np.array(outputs)
    targets = dict(truth=values["label"].cpu().numpy(), target=values["mask"][:, 0].cpu().numpy().astype(bool))
    evaluations, arrays = [], []
    for p in probability:
        e, a = orbit.score(p, targets, c["thresholds"]); evaluations.append(e); arrays.append(a)
    chosen = evaluations[0]["selected"]; ti = c["thresholds"].index(chosen["threshold"])
    actual = probability[0] >= chosen["threshold"]
    ablations = {variant: dict(**evaluations[i]["VAL_scores_all_thresholds"][ti],
        mask_flip_fraction=float(np.mean((probability[i] >= chosen["threshold"]) != actual)))
        for i, variant in enumerate(variants)}
    return dict(selected=chosen, ablations=ablations,
        VAL_scores_all_thresholds={name: value["VAL_scores_all_thresholds"] for name, value in zip(variants, evaluations)}), dict(
        probability=probability, logits=np.array(logits), truth=targets["truth"], target=targets["target"],
        thresholds=np.array(c["thresholds"]), variants=np.array(variants),
        predictions=np.array([a["predictions"] for a in arrays]), packed_masks=np.array([a["packed_masks"] for a in arrays]),
        selected_threshold=np.array(chosen["threshold"]))


@torch.no_grad()
def technical_fixture(c, model, x, cache=None):
    model.eval()
    actual = model.forward_details(x)
    transformed = [model.forward_details(torch.rot90(x, k, (-2, -1))) for k in range(4)]
    restored = torch.stack([torch.rot90(r["probability"], -k, (-2, -1)) for k, r in enumerate(transformed)])
    error = float((restored - actual["probability"][None]).abs().max().cpu())
    equivariance_required = model.arm != "source_identity"
    if equivariance_required:
        assert error <= c["equivariance_tolerance"], (model.arm, error)
    fixture = dict(x=x.cpu().numpy(), probability=actual["probability"].cpu().numpy(),
        logits=actual["logits"].cpu().numpy(), restored_probability=restored.cpu().numpy(),
        transformed_probability=torch.stack([r["probability"] for r in transformed]).cpu().numpy())
    if actual["weights"] is not None:
        fixture.update(weights=actual["weights"].cpu().numpy(), scores=actual["scores"].cpu().numpy())
    parity = 0.
    if cache is not None:
        observed = model.forward_cached(cache)
        parity = float((observed["probability"] - actual["probability"]).abs().max().cpu())
        assert parity < 1e-5
        fixture.update({key: tensor.cpu().numpy() for key, tensor in cache.items() if key != "x"})
    return fixture, dict(C4_equivariance_max_error=error,
        C4_equivariance_required=equivariance_required, cache_full_max_error=parity)


def comparisons(rows, c):
    means = {lr: {b: {arm: {metric: float(np.mean([r["selected"][metric] for r in rows
        if r["source_lr"] == lr and r["budget"] == b and r["arm"] == arm])) for metric in ["mask_F1", "IoU"]}
        for arm in EVALUATION_ARMS} for b in c["budgets"]} for lr in FAMILIES}
    def compare(lr, left, right):
        f1 = [means[lr][b][left]["mask_F1"] - means[lr][b][right]["mask_F1"] for b in c["budgets"]]
        iou = float(np.mean([means[lr][b][left]["IoU"] - means[lr][b][right]["IoU"] for b in c["budgets"]]))
        gain = float(np.mean(f1)); limits = c["gates"]
        checks = dict(mean_F1_gain=gain >= limits["minimum_mean_F1_gain"],
            budget_F1_guard=min(f1) >= limits["minimum_budget_F1_delta"], mean_IoU_guard=iou >= limits["minimum_mean_IoU_delta"])
        return dict(delta=gain, IoU_delta=iou, budget_deltas=f1, checks=checks, passed=all(checks.values()))
    architecture = {}
    for arm in ["learned_plain", "learned_joint"]:
        family = {}
        for lr in FAMILIES:
            frozen, adapted = compare(lr, arm, "uniform_frozen"), compare(lr, arm, "uniform_adapted")
            single = compare(lr, arm, "single_adapted")
            family[lr] = dict(vs_uniform_frozen=frozen, vs_uniform_adapted=adapted,
                              vs_single_adapted=single,
                              passed=bool(frozen["passed"] and adapted["passed"] and single["passed"]))
        architecture[arm] = dict(by_source_lr=family, passed=all(v["passed"] for v in family.values()))
    physical = {}
    for lr in FAMILIES:
        row = compare(lr, "learned_joint", "learned_plain")
        row["joint_architecture_gate"] = architecture["learned_joint"]["by_source_lr"][lr]["passed"]
        row["passed"] = bool(row["passed"] and row["joint_architecture_gate"])
        physical[lr] = row
    uniform_training = {}
    for lr in FAMILIES:
        frozen = compare(lr, "uniform_adapted", "uniform_frozen")
        single = compare(lr, "uniform_adapted", "single_adapted")
        uniform_training[lr] = dict(vs_uniform_frozen=frozen, vs_single_adapted=single,
            passed=bool(frozen["passed"] and single["passed"]))
    return dict(A_architecture=architecture, A_any=any(v["passed"] for v in architecture.values()),
        B_physics=dict(by_source_lr=physical, passed=all(v["passed"] for v in physical.values())),
        D_uniform_training=dict(by_source_lr=uniform_training,
            passed=all(v["passed"] for v in uniform_training.values())),
        interpretation="Reused TRAIN/VAL only; learned A must exceed all3 controls in bothsourcefamilies; D is separate"), means


def signature(c):
    return digest(dict(configuration=c, source_sha256=source_hashes(), TRAIN_VAL_sha256=sha(PILOT / "TRAIN_VAL.npz")))


def previous_screen(expected):
    found = []
    for path in (ROOT / "trials").glob("*/RESULT.json"):
        row = json.loads(path.read_text())
        if row["phase"] == "screen" and row["signature"] == expected and row["status"] == "COMPLETE_DEVELOPMENT_TRIAL":
            found.append((path, row))
    assert len(found) == 1, "Replication requires exactlyone compatible screen"
    gates = found[0][1]["gates"]
    assert gates["A_any"] or gates["D_uniform_training"]["passed"], "Replication requires a passing preregistered A or secondaryD screen"
    return found[0]


def preflight(c):
    data, refs, states, lineage = inputs(c, [5501], "cpu")
    ref = next(r for r in refs if r["source_lr"] == "high_lr" and r["budget"] == 18)
    state = states[ref["source_lr"], 18, 5501]
    x = data[18]["dense"]["x"][:2]
    initial, counts, map_errors = [], [], {}
    generator = torch.Generator().manual_seed(c["technical_seed"])
    random_x = torch.randn((2, 1, 12, 12), generator=generator)
    for arm in ["learned_plain", "learned_joint"]:
        net = make(c, arm, state, 5501, "cpu")
        initial.append(state_digest(net.scorer.state_dict())); counts.append(net.parameter_counts())
        cache = net.precompute(x)
        result = net.forward_cached(cache)
        assert torch.equal(result["probability"], cache["uniform_probability"])
        assert float((result["logits"].sigmoid() - result["probability"]).abs().max().detach()) < 3e-7
        loss = F.binary_cross_entropy_with_logits(result["logits"], data[18]["dense"]["mask"][:2])
        loss.backward()
        assert all(p.grad is None for p in net.backbone.parameters())
        assert float(net.scorer[-1].weight.grad.abs().sum()) > 0
        assert all(p.grad is not None and torch.count_nonzero(p.grad) == 0 for p in net.scorer[0].parameters())
        # The nonzero probe is separate from scientific initialization and
        # tests the learned route rather than only reproducing uniform C4.
        with torch.no_grad():
            net.scorer[-1].weight.copy_(torch.linspace(-.02, .02, 8).reshape(1, 8, 1, 1))
        net.zero_grad(set_to_none=True)
        active_cache = net.precompute(random_x)
        active = net.forward_cached(active_cache)
        assert float((active["weights"] - .25).abs().max().detach()) > 1e-6
        active["logits"].sum().backward()
        assert float(net.scorer[0].weight.grad.abs().sum()) > 0
        fixture, errors = technical_fixture(c, net, random_x, active_cache)
        permutation_probabilities = []
        for k in range(4):
            permuted = {key: torch.roll(value, k, 0) if key in VIEW_FIELDS else value
                        for key, value in active_cache.items()}
            with torch.no_grad():
                permutation_probabilities.append(net.forward_cached(permuted)["probability"])
        permutation_probabilities = torch.stack(permutation_probabilities)
        permutation_error = float((permutation_probabilities - active["probability"].detach()[None]).abs().max())
        assert permutation_error <= c["equivariance_tolerance"]
        fixture["view_permuted_probability"] = permutation_probabilities.detach().numpy()
        for mode in ["plain", "joint"]:
            base_raw, base_maps = net.conditioning_maps(active_cache["uniform_probability"], mode)
            raw_error, map_error = 0., 0.
            for k in range(4):
                raw, maps = net.conditioning_maps(torch.rot90(active_cache["uniform_probability"], k, (-2, -1)), mode)
                raw_error = max(raw_error, float((torch.rot90(raw, -k, (-2, -1)) - base_raw).abs().max()))
                map_error = max(map_error, float((torch.rot90(maps, -k, (-2, -1)) - base_maps).abs().max()))
            assert raw_error < 1e-6 and map_error < 1e-4
            map_errors[mode] = dict(raw=raw_error, normalized=map_error)
        np.savez_compressed(ROOT / f"TECHNICAL_ACTIVE_{arm}.npz", **fixture,
            **{"active_scorer_" + k.replace(".", "_"): v.detach().numpy() for k, v in net.scorer.state_dict().items()})
    assert len(set(initial)) == 1 and counts[0] == counts[1]
    for control_arm in ["uniform_adapted", "single_adapted"]:
        adapted = make(c, control_arm, state, 5501, "cpu")
        passes = [0]
        hook = adapted.backbone[0].register_forward_hook(lambda module, args, output: passes.__setitem__(0, passes[0] + 1))
        adapted.train(); adapted(x).sum().backward(); hook.remove()
        assert passes[0] == (1 if control_arm == "single_adapted" else 4)
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in adapted.backbone.parameters())
        adapted.eval()
        reference_uniform = make(c, "uniform_frozen", state, 5501, "cpu").eval()
        with torch.no_grad():
            assert torch.equal(adapted.forward_details(x)["probability"], reference_uniform.forward_details(x)["probability"])
    result = dict(status="PASS_PREFLIGHT", matched_initialization=True, uniform_initialization_exact=True,
        first_score_output_gradient_nonzero=True, first_hidden_gradient_zero=True,
        active_hidden_gradient_nonzero=True, backbone_frozen_gradient_absent=True,
        uniform_adapted_CNN_gradient_present=True, active_C4_equivariance=True,
        single_adapted_training_single_view=True, single_adapted_evaluation_C4=True,
        active_view_permutation_invariant=True, raw_map_rotation_tolerance=1e-6,
        normalized_map_rotation_tolerance=1e-4, final_probability_equivariance_tolerance=1e-6,
        map_rotation_closure=map_errors, conditioning_detached=True, source_sha256=source_hashes(),
        counts=counts[0], initial_head_sha256=initial[0], lineage=lineage, no_optimizer_steps=True)
    save(ROOT / "PREFLIGHT.json", result); print(json.dumps(result), flush=True)


def run(c, phase, config_path):
    global START
    START = time.monotonic()
    assert torch.backends.mps.is_available() and os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] == "0"
    seeds = c["screen_seeds"] if phase == "screen" else [s for s in c["replication_seeds"] if s not in c["screen_seeds"]]
    expected = signature(c)
    inherited = previous_screen(expected) if phase == "replicate" else None
    data, refs, states, lineage = inputs(c, seeds, "mps")
    trial_id = f'fusion_{phase}_s{"-".join(map(str, seeds))}_{digest(source_hashes())[:10]}'
    trial = ROOT / "trials" / trial_id
    assert not trial.exists(), "Immutable trial exists; never overwrite or implicitly resume"
    for folder in [trial, trial / "models", trial / "val_probs", trial / "fixtures", trial / "source"]:
        folder.mkdir(parents=True, exist_ok=False)
    hashes = source_hashes()
    save(trial / "CONFIG_SNAPSHOT.json", c); shutil.copy2(ROOT / "PROTOCOL.md", trial / "PROTOCOL.md")
    for name in ["model.py", "runner.py"]:
        shutil.copy2(ROOT / name, trial / "source" / name)
    frozen = dict(candidate=c["candidate"], phase=phase, seeds=seeds, signature=expected,
        source_sha256=hashes, sources=refs, lineage=lineage, architecture=architecture_spec(),
        protocol_sha256=sha(ROOT / "PROTOCOL.md"), config_sha256=sha(config_path),
        prior_stage_links=c["prior_stage_links"], fitted_models=4 * len(refs),
        total_updates=2000 * len(refs), evaluation_rows=6 * len(refs),
        fresh_confirmation_access=False, scope="Adaptive TRAIN_VAL only; no TEST/EVAL or confirmation results")
    save(trial / "FROZEN.json", frozen)
    append_ledger(dict(status="RUNNING", trial=trial_id, phase=phase, signature=expected))
    rows, checkpoints, counter = [], {}, [0]
    try:
        for reference in refs:
            key = reference["source_lr"], reference["budget"], reference["seed"]
            values = data[reference["budget"]]
            source = make(c, "learned_plain", states[key], reference["seed"], "mps")
            cache, cache_meta = cached_inputs(source, values, reference, c)
            del source
            paired = []
            for arm in EVALUATION_ARMS:
                net = make(c, arm, states[key], reference["seed"], "mps")
                fitting = arm in FITTED_ARMS
                if fitting:
                    timing = fit(c, net, values, cache if net.scorer is not None else None, reference, trial, counter)
                else:
                    timing = dict(steps=0, optimizer_updates=0, fit_count=0, trainable_parameters=0,
                        backbone_before_sha256=reference["backbone_state_sha256"],
                        backbone_after_sha256=reference["backbone_state_sha256"], head_initial_sha256=None, head_final_sha256=None)
                val_cache = None if arm in ["uniform_adapted", "single_adapted"] else cache["val"]
                evaluation, arrays = evaluate(c, net, values["val"], val_cache)
                fixture_cache = None if val_cache is None else slice_cache(val_cache, slice(0, 16))
                fixture, technical = technical_fixture(c, net, values["val"]["x"][:16], fixture_cache)
                row = dict(source_lr=reference["source_lr"], budget=reference["budget"], seed=reference["seed"],
                    arm=arm, source=reference, **timing, **evaluation, **technical,
                    parameters=net.parameter_counts(), cache=cache_meta if val_cache is not None else None,
                    CNN_passes_per_image=1 if arm == "source_identity" else 4)
                name = f'{reference["source_lr"]}_b{reference["budget"]}_s{reference["seed"]}_{arm}'
                if fitting:
                    path = trial / "models" / f"{name}.pt"; temporary = path.with_suffix(".pt.partial")
                    torch.save(dict(model={k: v.detach().cpu() for k, v in net.state_dict().items()}, settings=row), temporary)
                    temporary.replace(path); checkpoints[path.name] = sha(path)
                np.savez_compressed(trial / "val_probs" / f"{name}.npz", **arrays)
                np.savez_compressed(trial / "fixtures" / f"{name}.npz", **fixture)
                rows.append(row); paired.append(row); save(trial / "PARTIAL_RESULTS.json", rows)
                save(trial / "CHECKPOINT_HASHES.json", checkpoints)
                del net
            fitted = [r for r in paired if r["fit_count"]]
            learned = [r for r in paired if r["arm"].startswith("learned_")]
            assert len({r["batch_sequence_sha256"] for r in fitted}) == 1
            assert len({r["head_initial_sha256"] for r in learned}) == 1
            del cache
        assert counter[0] == 2000 * len(refs)
        assert all(sha(ROOT / name) == value for name, value in hashes.items())
        assert sha(config_path) == frozen["config_sha256"] and sha(ROOT / "PROTOCOL.md") == frozen["protocol_sha256"]
        for ref in refs:
            assert sha(REPO / ref["checkpoint_file"]) == ref["checkpoint_sha256"]
        development, means = comparisons(rows, c)
        result = dict(status="COMPLETE_DEVELOPMENT_TRIAL", candidate=c["candidate"], phase=phase,
            seeds=seeds, signature=expected, rows=rows, sources=refs, gates=development, means=means,
            fitted_models=4 * len(refs), updates=counter[0], evaluation_rows=len(rows),
            checkpoint_hashes=checkpoints, seconds=time.monotonic() - START,
            frozen_sha256=sha(trial / "FROZEN.json"), scope="Adaptive reused-VAL architecture development only; no confirmation data")
        save(trial / "RESULT.json", result)
        aggregate = None
        if inherited is not None:
            old_path, old = inherited; all_rows = old["rows"] + rows
            assert len({(r["source_lr"], r["budget"], r["seed"], r["arm"]) for r in all_rows}) == len(all_rows)
            ag, am = comparisons(all_rows, c)
            robust = {arm: bool(ag["A_architecture"][arm]["passed"] and development["A_architecture"][arm]["passed"])
                      for arm in ["learned_plain", "learned_joint"]}
            aggregate = dict(status="COMPLETE_REUSED_VAL_REPLICATION", rows=all_rows, gates=ag, means=am,
                new_seed_gates=development, robust_architecture_by_arm=robust, robust_architecture_pass=any(robust.values()),
                robust_uniform_training_pass=bool(ag["D_uniform_training"]["passed"] and
                    development["D_uniform_training"]["passed"]),
                seeds=c["replication_seeds"], source_trials=[str(old_path.parent.relative_to(ROOT)), str(trial.relative_to(ROOT))])
            save(trial / "AGGREGATE_RESULT.json", aggregate)
        summary = dict(status=result["status"], trial=str(trial.relative_to(ROOT)), phase=phase,
            result_sha256=sha(trial / "RESULT.json"), gates=aggregate["gates"] if aggregate else development,
            means=aggregate["means"] if aggregate else means)
        append_ledger(summary); save(ROOT / "LATEST_RESULT.json", summary); print(json.dumps(summary), flush=True)
    except BaseException as error:
        failed = dict(status="FAILED", trial=trial_id, phase=phase, error=str(error),
                      error_type=type(error).__name__, traceback=traceback.format_exc())
        save(trial / "FAILURE.json", failed); append_ledger(failed); raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["screen", "replicate"], default="screen")
    parser.add_argument("--config", type=Path, default=ROOT / "CONFIG.json")
    parser.add_argument("--preflight", action="store_true")
    args = parser.parse_args(); c = configuration(args.config); torch.set_num_threads(2)
    if args.preflight:
        preflight(c)
    else:
        run(c, args.phase, args.config)


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
