"""Small, matched CNN refiners for a frozen SEM segmentation backbone.

This module starts no training and reads no datasets. Plain and physical arms
within each candidate have exactly the same parameters and initialization.
Only the two prediction-derived conditioning maps differ. The old training
loss remains the responsibility of the runner; none is introduced here.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path

import torch
from torch import nn


PILOT = Path(__file__).resolve().parents[1] / "sem_architecture_pilot_20261102"
CANDIDATES = ("direct", "split", "film", "gated")
ARMS = ("plain", "joint", "independent")
ROLL_SHIFT = (5, 5)


def _load_source(name, filename):
    spec = importlib.util.spec_from_file_location(name, PILOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_original = _load_source("iterative_sem_original_model", "model.py")
_circuit = _load_source("iterative_sem_original_circuit", "circuit.py")
state_digest = _original.state_digest


def normalize_maps(raw, scale=100.0, floor=1e-6):
    """The fixed log1p100, per-image/channel transform used in development."""
    assert raw.ndim == 4 and raw.shape[1:] == (2, 12, 12), raw.shape
    assert scale > 0 and floor > 0
    transformed = torch.log1p(float(scale) * raw)
    centered = transformed - transformed.mean((-2, -1), keepdim=True)
    return centered / torch.sqrt(
        centered.square().mean((-2, -1), keepdim=True) + float(floor)
    )


def _zero_output(layer):
    nn.init.zeros_(layer.weight)
    nn.init.zeros_(layer.bias)
    return layer


class DirectRefiner(nn.Module):
    """One signed residual instead of keep/add/remove softmax competition."""

    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv2d(28, 16, 3, padding=1), nn.GELU(),
            _zero_output(nn.Conv2d(16, 1, 1)),
        )

    def forward(self, visual, maps):
        return self.network(torch.cat((visual, maps), dim=1))


class SplitRefiner(nn.Module):
    """Allocate an explicit local feature branch to the conditioning maps."""

    def __init__(self):
        super().__init__()
        self.visual = nn.Sequential(nn.Conv2d(26, 12, 3, padding=1), nn.GELU())
        self.conditioning = nn.Sequential(nn.Conv2d(2, 12, 3, padding=1), nn.GELU())
        self.fusion = nn.Sequential(
            nn.Conv2d(24, 12, 1), nn.GELU(),
            _zero_output(nn.Conv2d(12, 1, 1)),
        )

    def forward(self, visual, maps):
        return self.fusion(torch.cat((self.visual(visual), self.conditioning(maps)), dim=1))


class FiLMRefiner(nn.Module):
    """Maps modulate visual features with bounded spatial scale and offset."""

    def __init__(self):
        super().__init__()
        self.visual = nn.Sequential(nn.Conv2d(26, 16, 3, padding=1), nn.GELU())
        self.conditioning = nn.Conv2d(2, 32, 3, padding=1)
        self.output = nn.Sequential(
            nn.Conv2d(16, 8, 3, padding=1), nn.GELU(),
            _zero_output(nn.Conv2d(8, 1, 1)),
        )

    def forward(self, visual, maps):
        features = self.visual(visual)
        gamma, beta = self.conditioning(maps).chunk(2, dim=1)
        modulated = features * (1 + 0.5 * gamma.tanh()) + 0.5 * beta.tanh()
        return self.output(modulated)


class GatedRefiner(nn.Module):
    """Maps spatially gate each visual feature channel, with a nonzero floor."""

    def __init__(self):
        super().__init__()
        self.visual = nn.Sequential(nn.Conv2d(26, 16, 3, padding=1), nn.GELU())
        self.conditioning = nn.Conv2d(2, 16, 3, padding=1)
        self.output = nn.Sequential(
            nn.Conv2d(16, 8, 3, padding=1), nn.GELU(),
            _zero_output(nn.Conv2d(8, 1, 1)),
        )

    def forward(self, visual, maps):
        gate = 1 + 0.5 * self.conditioning(maps).tanh()
        return self.output(self.visual(visual) * gate)


class FrozenResidualSegmenter(nn.Module):
    def __init__(self, candidate, arm, backbone_state=None, *, decoder_seed=None,
                 epsilon=0.001, eta=2.0, scale=100.0, norm_floor=1e-6):
        super().__init__()
        assert candidate in CANDIDATES, candidate
        assert arm in ARMS, arm
        assert 0 < epsilon < 0.5 and eta > 0
        assert scale > 0 and norm_floor > 0
        self.candidate = candidate
        self.arm = arm
        self.epsilon = float(epsilon)
        self.eta = float(eta)
        self.scale = float(scale)
        self.norm_floor = float(norm_floor)
        if decoder_seed is not None:
            torch.manual_seed(int(decoder_seed))
        self.backbone = _original.make_backbone()
        self.refiner = {
            "direct": DirectRefiner, "split": SplitRefiner,
            "film": FiLMRefiner, "gated": GatedRefiner,
        }[candidate]()
        if backbone_state is not None:
            self.backbone.load_state_dict(backbone_state, strict=True)
        for parameter in self.backbone.parameters():
            parameter.requires_grad_(False)
        self.circuit = _circuit.CircuitMaps(epsilon=self.epsilon)
        assert self.parameter_counts()["backbone"] == 10681

    def parameter_counts(self):
        return {
            "backbone": sum(p.numel() for p in self.backbone.parameters()),
            "refiner": sum(p.numel() for p in self.refiner.parameters()),
            "trainable": sum(p.numel() for p in self.parameters() if p.requires_grad),
            "total": sum(p.numel() for p in self.parameters()),
        }

    @torch.no_grad()
    def precompute(self, x, *, arm=None):
        """Return immutable-by-convention cached tensors for a frozen backbone.

        The cache depends on the backbone and arm, not on the candidate's
        refiner. It can therefore be reused across candidates. No labels or
        masks are accepted. An arm override permits one model to build the
        plain and physical caches from the same source backbone.
        """
        assert x.ndim == 4 and x.shape[1:] == (1, 12, 12), x.shape
        mode = self.arm if arm is None else arm
        assert mode in ARMS, mode
        features = self.backbone[:-1](x)
        coarse = self.backbone[-1](features)
        if mode == "plain":
            p = coarse.sigmoid()
            raw = torch.cat((p, 4 * p * (1 - p)), dim=1)
        else:
            raw = self.circuit(coarse, mode=mode)
        maps = normalize_maps(raw, self.scale, self.norm_floor)
        return {
            "visual": torch.cat((features, coarse, x), dim=1).detach().clone(),
            "coarse": coarse.detach().clone(),
            "maps": maps.detach().clone(),
            "maps_raw": raw.detach().clone(),
        }

    def forward_cached(self, cache, intervention="actual"):
        assert intervention in ("actual", "zero", "roll"), intervention
        visual, coarse, maps = (cache[key] for key in ("visual", "coarse", "maps"))
        assert visual.ndim == 4 and visual.shape[1:] == (26, 12, 12), visual.shape
        assert coarse.shape == (len(visual), 1, 12, 12), coarse.shape
        assert maps.shape == (len(visual), 2, 12, 12), maps.shape
        if intervention == "zero":
            maps = torch.zeros_like(maps)
        elif intervention == "roll":
            maps = torch.roll(maps, shifts=ROLL_SHIFT, dims=(-2, -1))
        residual = self.refiner(visual, maps)
        correction = self.eta * residual.tanh()
        return {
            "logits": coarse + correction,
            "coarse": coarse,
            "correction": correction,
            "residual": residual,
            "maps_normalized": maps,
        }

    def forward_details(self, x, intervention="actual"):
        cache = self.precompute(x)
        result = self.forward_cached(cache, intervention=intervention)
        result["maps_raw"] = cache["maps_raw"]
        return result

    def forward(self, x):
        return self.forward_details(x)["logits"]


def make_model(candidate, arm, backbone_state=None, **kwargs):
    return FrozenResidualSegmenter(candidate, arm, backbone_state, **kwargs)


def architecture_spec():
    return {
        "candidates": list(CANDIDATES),
        "arms": list(ARMS),
        "backbone_parameters": 10681,
        "backbone": "unchanged frozen source CNN",
        "conditioning": "log1p(100*raw), per-image/channel centering and RMS normalization",
        "visual_channels": ["CNN_features24", "coarse_logit1", "SEM1"],
        "conditioning_channels": 2,
        "correction": "eta*tanh(signed_residual)",
        "identity_initialization": "zero final convolution in every refiner",
        "matching": "plain/joint/independent share exact architecture and initial weights within candidate",
        "roll_intervention": list(ROLL_SHIFT),
        "scope": "development architecture screening; no new loss or mathematical-identity novelty claim",
    }
