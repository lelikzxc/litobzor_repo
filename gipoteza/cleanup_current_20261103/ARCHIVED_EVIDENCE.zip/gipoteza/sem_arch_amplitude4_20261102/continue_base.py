"""Fair extra-adaptation control: original CNN, same500 updates and old loss.

This script reads only historical TRAIN/VAL inputs and source-backbone metadata.
It never opens a TEST/EVAL archive or old test results. All10681 CNN parameters
are trained; no refiner or conditioning maps are introduced.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import time
import traceback

os.environ['PYTORCH_ENABLE_MPS_FALLBACK']='0'
import numpy as np
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

import runner as r

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'baseline_control'
original=r.module('continued_source_CNN_unchanged',r.PILOT/'model.py')


def save(name,value):r.save(OUT/name,value)


def main():
    assert torch.backends.mps.is_available() and os.environ['PYTORCH_ENABLE_MPS_FALLBACK']=='0'
    assert not OUT.exists(), 'Immutable continued-control run already exists; no silent overwrite or resume'
    torch.set_num_threads(2)
    queue=ROOT/'QUEUE.json' if (ROOT/'QUEUE.json').exists() else ROOT/'CONFIG.json'
    c=r.configuration(queue);seeds=c['replication_seeds'];started=time.monotonic()
    assert seeds==[5501,5521,5557]
    data,states,lineage=r.inputs(c,seeds,'mps')
    OUT.mkdir();(OUT/'models').mkdir();(OUT/'val_probs').mkdir();(OUT/'fixtures').mkdir();(OUT/'source').mkdir()
    sources=dict(r.source_hashes(),**{'continue_base.py':r.sha(Path(__file__))})
    for name in ['continue_base.py','runner.py','model.py']:shutil.copy2(ROOT/name,OUT/'source'/name)
    shutil.copy2(ROOT/'PROTOCOL.md',OUT/'PROTOCOL.md');save('CONFIG_SNAPSHOT.json',c)
    frozen=dict(scope='Continued source-CNN adaptation on reused TRAIN/VAL only',source_sha256=sources,
        protocol_sha256=r.sha(ROOT/'PROTOCOL.md'),queue_sha256=r.sha(queue),lineage=lineage,
        models=6,steps_each=500,total_updates=3000,trainable_parameters=10681,
        seeds=seeds,budgets=c['budgets'],same_minibatch_rule='np.default_rng(seed+1000),dense8 then weak8 each step')
    save('FROZEN.json',frozen)
    rows=[];hashes={};completed=0
    try:
        for budget in c['budgets']:
            for seed in seeds:
                net=original.make_backbone().to('mps');net.load_state_dict(states[budget,seed],strict=True)
                assert sum(p.numel() for p in net.parameters() if p.requires_grad)==10681
                before=r.state_digest(net.state_dict());assert before==lineage['sources'][f'{budget}:{seed}']['backbone_sha256']
                optimizer=torch.optim.AdamW(net.parameters(),lr=c['learning_rate'],weight_decay=c['weight_decay'])
                rng=np.random.default_rng(seed+1000);batches=hashlib.sha256();fit_start=time.monotonic()
                for step in range(1,c['steps']+1):
                    ai=rng.integers(0,len(data[budget]['dense']['x']),c['batch_size'])
                    wi=rng.integers(0,len(data[budget]['weak']['x']),c['batch_size'])
                    batches.update(ai.astype(np.int64).tobytes());batches.update(wi.astype(np.int64).tobytes())
                    ai=torch.tensor(ai,device='mps');wi=torch.tensor(wi,device='mps');optimizer.zero_grad(set_to_none=True)
                    dense=net(data[budget]['dense']['x'][ai])
                    loss=F.binary_cross_entropy_with_logits(dense,data[budget]['dense']['mask'][ai])
                    label=data[budget]['weak']['label'][wi];directions=torch.stack((label//3,label%3),dim=1)
                    loss=loss+c['physics_weight']*r.physics.geometry_loss(net(data[budget]['weak']['x'][wi]),directions)
                    assert torch.isfinite(loss);loss.backward()
                    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in net.parameters())
                    optimizer.step();completed+=1
                    if step%100==0 or step==c['steps']:
                        progress=dict(stage='CONTINUED_BASELINE_TRAIN_VAL',budget=budget,seed=seed,
                            step=step,target_steps=c['steps'],completed_updates=completed,total_updates=3000,
                            seconds=time.monotonic()-started)
                        save('PROGRESS.json',progress)
                        with (OUT/'progress.jsonl').open('a') as h:h.write(json.dumps(progress)+'\n')
                        print(json.dumps(progress),flush=True)
                torch.mps.synchronize();seconds=time.monotonic()-fit_start
                after=r.state_digest(net.state_dict());assert before!=after
                net.eval();parts=[]
                with torch.no_grad():
                    for x in data[budget]['val']['x'].split(16):parts.append(net(x).cpu().numpy())
                logits=np.concatenate(parts);probability=1/(1+np.exp(-np.clip(logits[:,0],-80,80)))
                truth=data[budget]['val']['label'].cpu().numpy()
                target=data[budget]['val']['mask'][:,0].cpu().numpy().astype(bool)
                scores,predictions,packed=r.score_probabilities(probability,truth,target,c['thresholds'])
                selected=max(scores,key=r.rank)
                row=dict(budget=budget,seed=seed,arm='continued_base',steps=c['steps'],seconds=seconds,
                    trainable_parameters=10681,total_parameters=10681,source_initial=lineage['sources'][f'{budget}:{seed}'],
                    backbone_before_sha256=before,backbone_after_sha256=after,batch_sequence_sha256=batches.hexdigest(),
                    selected=selected,VAL_scores_all_thresholds=scores)
                name=f'base_b{budget}_s{seed}';path=OUT/'models'/f'{name}.pt';tmp=path.with_suffix('.pt.partial')
                torch.save(dict(model={k:v.detach().cpu() for k,v in net.state_dict().items()},settings=row),tmp);tmp.replace(path)
                hashes[path.name]=r.sha(path)
                np.savez_compressed(OUT/'val_probs'/f'{name}.npz',logits=logits,probability=probability,
                    truth=truth,target=target,thresholds=np.array(c['thresholds']),predictions=predictions,
                    packed_masks=packed,selected_threshold=np.array(selected['threshold']))
                np.savez_compressed(OUT/'fixtures'/f'{name}.npz',x=data[budget]['val']['x'][:16].cpu().numpy(),logits=logits[:16])
                rows.append(row);save('PARTIAL_RESULTS.json',rows);save('CHECKPOINT_HASHES.json',hashes);del net
        assert len(rows)==6 and completed==3000
        assert all(r.sha(ROOT/n)==h for n,h in sources.items())
        assert r.sha(ROOT/'PROTOCOL.md')==frozen['protocol_sha256'] and r.sha(queue)==frozen['queue_sha256']
        assert all(r.sha(r.G/v['file'])==v['sha256'] for v in lineage['sources'].values())
        result=dict(status='COMPLETE_CONTINUED_BASELINE_VAL_ONLY',rows=rows,models=6,updates=completed,
            checkpoint_hashes=hashes,seconds=time.monotonic()-started,frozen_sha256=r.sha(OUT/'FROZEN.json'),
            scope='Fair500-extra-step source-CNN control, reused development VAL. No new TEST, no independent superiority claim.')
        save('RESULT.json',result);save('PROGRESS.json',dict(stage=result['status'],models=6,updates=3000))
        print(json.dumps(result,ensure_ascii=False),flush=True)
    except BaseException as error:
        save('FAILURE.json',dict(status='FAILED_CONTINUED_BASELINE',error=str(error),error_type=type(error).__name__,traceback=traceback.format_exc()))
        raise


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
