"""Describe every saved development trial without running models or training.

Only reporting artifacts are written. Scientific inputs, trial folders,
checkpoints, the queue and the append-only ledger are read-only here.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
DESCRIPTIONS = {
    "direct": "одна знаковая остаточная свёрточная голова",
    "split": "отдельные свёрточные ветви изображения и условных карт",
    "film": "масштабирование и смещение признаков CNN по условным картам",
    "gated": "пространственное управление визуальными признаками через затвор",
}


def read(path, default=None):
    path = Path(path)
    return json.loads(path.read_text()) if path.exists() else default


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def relative(path, root):
    return Path(os.path.relpath(path, root)).as_posix()


def dump(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def pct(value):
    return f"{100 * float(value):.2f}"


def pp(value):
    return f"{100 * float(value):+.2f}"


def passed(value):
    return "PASS" if value else "FAIL"


def average(rows, key, arm=None):
    selected = [row for row in rows if arm is None or row.get("arm") == arm]
    if not selected:
        return float("nan")
    return float(np.mean([row["selected"][key] for row in selected]))


def stage_name(result):
    if result.get("status") == "COMPLETE_REUSED_VAL_REPLICATION":
        return "все три seed, включая исходный скрининг"
    if result.get("phase") == "replicate":
        return "только два дополнительных seed"
    return "первичный скрининг"


def discover(root):
    trials = []
    for path in sorted((root / "trials").glob("*")):
        if not path.is_dir():
            continue
        trials.append({
            "path": path,
            "frozen": read(path / "FROZEN.json", {}),
            "result": read(path / "RESULT.json"),
            "aggregate": read(path / "AGGREGATE_RESULT.json"),
            "failure": read(path / "FAILURE.json"),
            "partial": read(path / "PARTIAL_RESULTS.json", []),
            "audit": read(path / "AUDIT.json"),
        })
    ledger = read(root / "LEDGER.json", {"events": []})
    first_events = {}
    for event in ledger["events"]:
        if event.get("trial"):
            first_events.setdefault(Path(event["trial"]).name, event.get("index", len(first_events)))
    return sorted(trials, key=lambda trial: (first_events.get(trial["path"].name, float("inf")), trial["path"].name))


def previous_stages(root):
    """Follow explicit stage links and verify preserved trial-result hashes."""
    stages = []
    visited = {root.resolve()}
    current = root
    while (current / "STAGE_LINK.json").exists():
        link = read(current / "STAGE_LINK.json")
        previous = (current / link["previous_stage"]).resolve()
        assert previous not in visited, "Cyclic stage links"
        assert previous.parent == root.parent, "Stage link must stay in the study workspace"
        visited.add(previous)
        for trial_id, expected in link.get("previous_trials", {}).items():
            assert sha(previous / "trials" / trial_id / "RESULT.json") == expected
        stages.append({"path": previous, "trials": discover(previous), "link_path": current / "STAGE_LINK.json"})
        current = previous
    return list(reversed(stages))


def candidate_result(candidate, trials):
    relevant = [trial for trial in trials
                if (trial["result"] or trial["frozen"]).get("candidate") == candidate]
    # A replication aggregate includes its original screen exactly once.
    aggregates = [trial for trial in relevant if trial["aggregate"]]
    if aggregates:
        chosen = aggregates[-1]
        return chosen, chosen["aggregate"]
    complete = [trial for trial in relevant if trial["result"]]
    if complete:
        chosen = complete[-1]
        return chosen, chosen["result"]
    return None, None


def result_views(queue, trials):
    """Display a replication's new seeds separately from its reused-screen mean."""
    views = []
    for candidate in queue:
        trial, result = candidate_result(candidate, trials)
        if result:
            views.append((f"{candidate} (all 3 seeds)" if trial["aggregate"] else candidate, result))
            if trial["aggregate"]:
                views.append((f"{candidate} (new seeds)", trial["result"]))
    return views


def continued_control(root, history):
    """Read one control source; a linked reference never creates another fit."""
    providers = [root] + [stage["path"] for stage in reversed(history)]
    for provider in providers:
        result_path = provider / "baseline_control" / "RESULT.json"
        if result_path.exists():
            result = read(result_path)
            frozen_path = result_path.with_name("FROZEN.json")
            assert result["frozen_sha256"] == sha(frozen_path), "Control freeze hash mismatch"
            return {"path": result_path, "frozen_path": frozen_path, "result": result,
                    "local": provider == root, "sha256": sha(result_path),
                    "frozen_sha256": sha(frozen_path)}
    return None


def matched_control_rows(result, control):
    if not control:
        return []
    units = {(row["budget"], row["seed"]) for row in result["rows"]}
    selected = [row for row in control.get("rows", [])
                if (row["budget"], row["seed"]) in units]
    if {(row["budget"], row["seed"]) for row in selected} != units:
        return []
    assert len(selected) == len(units), "Duplicate continued-base units"
    source = {(row["budget"], row["seed"]): row for row in selected}
    for row in result["rows"]:
        reference = source[row["budget"], row["seed"]]
        for field in ("backbone_before_sha256", "batch_sequence_sha256", "steps"):
            assert row[field] == reference[field], f"Unmatched control {field}"
    return selected


def fair_comparison(result, control, arm):
    controls = matched_control_rows(result, control)
    if not controls:
        return None
    source = {(row["budget"], row["seed"]): row for row in controls}
    rows = [row for row in result["rows"] if row["arm"] == arm]
    assert len(rows) == len(controls), "Each arm must have one row per matched unit"
    assert len({(row["budget"], row["seed"]) for row in rows}) == len(rows)
    f1 = [row["selected"]["mask_F1"] - source[row["budget"], row["seed"]]["selected"]["mask_F1"]
          for row in rows]
    iou = [row["selected"]["IoU"] - source[row["budget"], row["seed"]]["selected"]["IoU"]
           for row in rows]
    return {"delta": float(np.mean(f1)), "IoU_delta": float(np.mean(iou)),
            "budget_deltas": [float(np.mean([delta for row, delta in zip(rows, f1) if row["budget"] == budget]))
                              for budget in (18, 27)], "matched_units": len(controls),
            "pairs": [{"budget": row["budget"], "seed": row["seed"],
                       "F1_delta": f1_delta, "IoU_delta": iou_delta}
                      for row, f1_delta, iou_delta in zip(rows, f1, iou)]}


def figure(root, queue, trials, control):
    points = result_views(queue, trials)
    if not points:
        return None
    output = root / "figures" / "architecture_validation.png"
    output.parent.mkdir(exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.2))
    x = np.arange(len(points))
    has_control = bool(control) and all(matched_control_rows(result, control) for _, result in points)
    width = 0.18 if has_control else 0.24
    series = [(-width, "base", "#777777"), (0, "plain", "#3c78a8"), (width, "joint", "#b25a43")]
    if has_control:
        series = [(-1.5 * width, "base", "#777777"), (-0.5 * width, "plain", "#3c78a8"),
                  (0.5 * width, "joint", "#b25a43"), (1.5 * width, "base+500", "#90734e")]
    for offset, arm, color in series:
        values = []
        for _, result in points:
            rows = result["baselines"] if arm == "base" else matched_control_rows(result, control) if arm == "base+500" else result["rows"]
            values.append(100 * average(rows, "mask_F1", arm if arm in ("plain", "joint") else None))
        bars = axes[0].bar(x + offset, values, width, label=arm, color=color)
        axes[0].bar_label(bars, fmt="%.2f", padding=3, fontsize=7,
                          rotation=90 if len(points) > 2 else 0)
    axes[0].set_xticks(x, [item[0] for item in points])
    axes[0].set_ylabel("Validation Macro-F1, %")
    axes[0].set_ylim(0, min(100, max(bar.get_height() for bar in axes[0].patches)
                            + (14 if len(points) > 2 else 9)))
    axes[0].set_title("Selected thresholds; mean of budgets and seeds")
    axes[0].legend(fontsize=9)
    for arm, offset, color in [("plain", -0.16, "#3c78a8"),
                               ("joint", 0, "#b25a43")]:
        values = [100 * result["gates"]["A_architecture"][arm]["delta"] for _, result in points]
        axes[1].scatter(x + offset, values, label=f"A: {arm} − frozen base", color=color, s=55)
    values = [100 * result["gates"]["B_physics"]["delta"] for _, result in points]
    axes[1].scatter(x + 0.16, values, label="B: joint − plain", color="#4d8d63", marker="D", s=45)
    if has_control:
        values = [100 * fair_comparison(result, control, "joint")["delta"] for _, result in points]
        axes[1].scatter(x + 0.28, values, label="joint − base+500", color="#90734e", marker="x", s=55)
    axes[1].axhline(0, color="black", lw=0.8)
    axes[1].axhline(0.5, color="gray", lw=0.8, ls="--", label="Mean-gain gate: +0.5 pp")
    axes[1].set_xticks(x, [item[0] for item in points])
    axes[1].set_xlim(-0.6, len(points) - 0.4)
    axes[1].set_ylabel("Macro-F1 difference, percentage points")
    axes[1].set_title("Development point estimates; no independent TEST")
    axes[1].legend(fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=2)
    fig.suptitle("Adaptive architecture development on reused validation data", fontsize=11)
    fig.tight_layout()
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return output


def build(root):
    config = read(root / "QUEUE.json", {})
    queue = config.get("queue", list(DESCRIPTIONS))
    eta = float(config.get("eta", 2.0))
    trials = discover(root)
    history = previous_stages(root)
    ledger = read(root / "LEDGER.json", {"events": []})
    control_source = continued_control(root, history)
    control = control_source["result"] if control_source else None
    local_control_fits = len(control["rows"]) if control_source and control_source["local"] else 0
    local_control_updates = int(control.get("updates", 0)) if local_control_fits else 0
    completed = [trial for trial in trials if trial["result"]]
    failures = [trial for trial in trials if trial["failure"]]
    pending = [trial for trial in trials if not trial["result"] and not trial["failure"]]
    # Aggregated replication rows are deliberately excluded from these counts.
    actual_rows = [row for trial in trials
                   for row in (trial["result"]["rows"] if trial["result"] else trial["partial"])]
    fit_count = len(actual_rows)
    updates = sum(int(row.get("steps", config.get("steps", 0))) for row in actual_rows)
    seconds = sum(float(trial["result"].get("seconds", 0)) for trial in completed)
    screening_count = sum(trial["result"].get("phase") == "screen" for trial in completed)
    replication_count = sum(trial["result"].get("phase") == "replicate" for trial in completed)
    screens = [trial["result"] for trial in completed if trial["result"].get("phase") == "screen"]
    screen_a_pass = sum(bool(result["gates"]["A_any"]) for result in screens)
    screen_b_pass = sum(bool(result["gates"]["B_physics"]["passed"]) for result in screens)
    all_trials = [trial for stage in history for trial in stage["trials"]] + trials
    all_completed = [trial for trial in all_trials if trial["result"]]
    all_actual_rows = [row for trial in all_trials
                       for row in (trial["result"]["rows"] if trial["result"] else trial["partial"])]
    all_screens = [trial["result"] for trial in all_completed if trial["result"].get("phase") == "screen"]
    tried = sorted({trial["frozen"].get("candidate", (trial["result"] or {}).get("candidate"))
                    for trial in trials} - {None})
    audit = read(root / "AUDIT.json")
    output_figure = figure(root, queue, trials, control)
    text = [
        "# Последовательная разработка CNN-уточнителя",
        "",
        "Эта серия проверяет изменения **модели**, работающие при предсказании. "
        "Прежняя функция потерь одинакова у всех вариантов: плотная BCE и "
        "геометрический член с весом 1 по слабым меткам. Новая функция потерь не вводится.",
        "",
        "Все результаты ниже относятся к последовательной разработке на уже используемой "
        "TRAIN/VAL. **Независимая тестовая проверка не проводится.** Прохождение критерия "
        "разработки не доказывает статистическое превосходство, новизну или пригодность для Q1.",
        "",
        "## Объём поиска и результаты критериев",
        "",
        f"Архитектур в очереди: {len(queue)}; начатых архитектур: {len(tried)}. "
        f"Отдельных попыток: {len(trials)}; завершённых: {len(completed)} "
        f"(скрининг: {screening_count}, расширение по seed: {replication_count}); "
        f"технических ошибок: {len(failures)}; незавершённых: {len(pending)}. "
        f"Сохранённых обучений уточнителей: {fit_count}; обновлений: {updates:,}. "
        "Строки сводного результата повторно не считаются.",
        "",
        f"Суммарное время завершённых попыток, включая подготовку и оценку: {seconds:.2f} с. "
        "Это время отдельных записанных попыток; подготовительные технические проверки учитываются отдельно.",
        "",
        f"Результаты завершённых первичных скринингов: критерий A пройден — {screen_a_pass}, "
        f"не пройден — {len(screens) - screen_a_pass}; критерий B пройден — {screen_b_pass}, "
        f"не пройден — {len(screens) - screen_b_pass}. Отрицательный критерий "
        "разработки и техническая ошибка — разные исходы.",
        "",
        "Два вопроса оцениваются раздельно:",
        "",
        "- **A, польза уточняющей архитектуры:** plain или joint против замороженной исходной CNN.",
        "- **B, польза физических карт:** joint против такого же по архитектуре и числу параметров plain; "
        "дополнительно joint обязан пройти A.",
        "",
        "Для каждого сравнения: средний прирост Macro-F1 не меньше 0,5 п.п., "
        "прирост каждого бюджета не ниже −0,25 п.п., средняя потеря IoU не больше 0,2 п.п. "
        "Бюджеты 18 и 27 имеют равный вес. При расширении отдельно проверяются новые "
        "seed 5521/5557 и общее среднее с исходным seed 5501.",
        "",
        "| Архитектура | Состояние / seed | Base F1, % | Plain F1, % | Joint F1, % | A plain | A joint | B joint |",
        "|---|---|---:|---:|---:|---|---|---|",
    ]
    if history:
        insertion = [
            "## Предыдущие этапы того же поиска", "",
            f"Текущий предел поправки — **{eta:g}·tanh(residual)**. "
            f"С учётом связанных предыдущих этапов сохранено попыток: {len(all_trials)}; "
            f"завершено: {len(all_completed)}. Среди всех завершённых скринингов "
            f"A пройден: {sum(bool(result['gates']['A_any']) for result in all_screens)} / {len(all_screens)}; "
            f"B пройден: {sum(bool(result['gates']['B_physics']['passed']) for result in all_screens)} / {len(all_screens)}. "
            f"Уникальных обучений уточнителей по связанным этапам: {len(all_actual_rows)}. "
            "Одна и та же VAL используется повторно; этапы не считаются независимыми экспериментами. "
            "SHA предыдущих результатов проверены по STAGE_LINK.json.", "",
            "| Предыдущий этап / кандидат | Seed | Base F1, % | Plain F1, % | Joint F1, % | A plain | A joint | B |",
            "|---|---|---:|---:|---:|---|---|---|",
        ]
        for stage in history:
            previous = stage["path"]
            previous_queue = read(previous / "QUEUE.json", {}).get("queue", list(DESCRIPTIONS))
            for candidate in previous_queue:
                trial, result = candidate_result(candidate, stage["trials"])
                if not result:
                    continue
                link = relative(trial["path"] / "RESULT.json", root)
                gates = result["gates"]
                insertion.append(f"| [{previous.name} / {candidate}]({link}) | {result['seeds']} | "
                                 f"{pct(average(result['baselines'], 'mask_F1'))} | "
                                 f"{pct(average(result['rows'], 'mask_F1', 'plain'))} | "
                                 f"{pct(average(result['rows'], 'mask_F1', 'joint'))} | "
                                 f"{passed(gates['A_architecture']['plain']['passed'])} | "
                                 f"{passed(gates['A_architecture']['joint']['passed'])} | "
                                 f"{passed(gates['B_physics']['passed'])} |")
        insertion += ["", "[Связь этапов и SHA результатов](STAGE_LINK.json). "
                      "Неудачные предыдущие варианты остаются частью журнала поиска.", ""]
        text[6:6] = insertion
    for candidate in queue:
        trial, result = candidate_result(candidate, trials)
        if result:
            gates = result["gates"]
            text.append(f"| {candidate} | {stage_name(result)}; {result['seeds']} | "
                        f"{pct(average(result['baselines'], 'mask_F1'))} | "
                        f"{pct(average(result['rows'], 'mask_F1', 'plain'))} | "
                        f"{pct(average(result['rows'], 'mask_F1', 'joint'))} | "
                        f"{passed(gates['A_architecture']['plain']['passed'])} | "
                        f"{passed(gates['A_architecture']['joint']['passed'])} | "
                        f"{passed(gates['B_physics']['passed'])} |")
        else:
            related = [t for t in trials if t["frozen"].get("candidate") == candidate]
            status = "техническая ошибка" if any(t["failure"] for t in related) else "начато" if related else "не запускалась"
            text.append(f"| {candidate} | {status} | — | — | — | — | — | — |")
    text += [
        "",
        "Здесь base **заморожена**, а уточнитель получает дополнительные 500 шагов. "
        "Поэтому A не отделяет пользу новых параметров от дополнительной адаптации. "
        "Перед утверждением об архитектурном преимуществе необходим контроль: исходная CNN "
        "также дообучается 500 шагов на тех же примерах с тем же лоссом и выбором порога. "
        "Если A пройден, а B нет, эффект нельзя приписывать физическим картам. "
        "Если B пройден, особую пользу совместного оператора ещё нужно сравнить с independent.",
        "",
    ]
    for trial in completed:
        if trial["aggregate"]:
            old = trial["aggregate"];new = trial["result"]
            ag = old["gates"];ng = new["gates"]
            robust_a = {arm: ag["A_architecture"][arm]["passed"] and ng["A_architecture"][arm]["passed"]
                        for arm in ("plain", "joint")}
            robust_b = ag["B_physics"]["passed"] and ng["B_physics"]["passed"]
            text.append(f"**Расширение {old['candidate']}:** условие одновременно на общем среднем и "
                        f"новых двух seed: A plain {passed(robust_a['plain'])}, "
                        f"A joint {passed(robust_a['joint'])}, B {passed(robust_b)}. "
                        "Это устойчивость на той же VAL, не новый независимый эксперимент.")
            text.append("")
            text += [
                f"| {old['candidate']}: набор seed | Base F1, % | Plain F1, % | Joint F1, % | A plain ΔF1, п.п. | A joint ΔF1, п.п. | B ΔF1, п.п. | A plain / joint / B |",
                "|---|---:|---:|---:|---:|---:|---:|---|",
            ]
            for label, item in [("новые 5521/5557", new), ("все 5501/5521/5557", old)]:
                gates = item["gates"]
                ap = gates["A_architecture"]["plain"];aj = gates["A_architecture"]["joint"];b = gates["B_physics"]
                text.append(f"| {label} | {pct(average(item['baselines'], 'mask_F1'))} | "
                            f"{pct(average(item['rows'], 'mask_F1', 'plain'))} | "
                            f"{pct(average(item['rows'], 'mask_F1', 'joint'))} | "
                            f"{pp(ap['delta'])} | {pp(aj['delta'])} | {pp(b['delta'])} | "
                            f"{passed(ap['passed'])} / {passed(aj['passed'])} / {passed(b['passed'])} |")
            text += ["", "Общее среднее включает исходный скрининг и не является отдельной новой выборкой. "
                     "При B FAIL добавочная польза физических карт по заданному критерию не установлена.", ""]
    if control:
        control_link = relative(control_source["path"], root)
        frozen_link = relative(control_source["frozen_path"], root)
        ownership = ("Контроль обучен в этой папке; его обучения учитываются здесь один раз."
                     if control_source["local"] else
                     "Это общий контроль из связанного предыдущего этапа; копия обучений здесь не создаётся. "
                     "Его шесть обучений не добавляются к локальному числу обучений этого этапа.")
        text += [
            "## Контроль дополнительного дообучения исходной CNN", "",
            f"Отдельный контроль сохранён: `{control.get('status', 'см. файл')}`. "
            f"Обучений: {len(control.get('rows', []))}; обновлений: {control.get('updates', 'см. файл')}. "
            "Здесь все 10 681 параметр исходной CNN получают те же 500 дополнительных шагов; "
            "новый уточнитель и условные карты не добавляются. Лосс, обучающие примеры и калибровка порога общие. "
            f"[Результат контроля]({control_link}); [замороженная запись]({frozen_link}). "
            f"SHA-256 результата: `{control_source['sha256']}`. "
            f"SHA-256 замороженной записи: `{control_source['frozen_sha256']}`. {ownership}", "",
            f"Локальных обучений вместе с контролем: {fit_count + local_control_fits}; "
            f"уникальных обучений в этом и предыдущих связанных этапах, включая общий контроль один раз: "
            f"{len(all_actual_rows) + len(control['rows'])}.", "",
            "Ниже сравниваются только совпадающие пары **(бюджет, seed)**. "
            "Для одноseed-скрининга используются два соответствующих контроля, "
            "для новых двух seed — четыре, для результата трёх seed — все шесть. "
            "SHA исходных весов, последовательности батчей и число шагов в каждой паре проверяются. "
            "Это дополнительное описательное сравнение на VAL; "
            "исходные критерии A/B в таблице выше не переписываются.", "",
            "| Архитектура | Seed | Контроль F1, % | ΔF1 plain, п.п. | ΔIoU plain, п.п. | ΔF1 joint, п.п. | ΔIoU joint, п.п. |",
            "|---|---|---:|---:|---:|---:|---:|",
        ]
        for candidate, result in result_views(queue, trials):
            controls = matched_control_rows(result, control)
            plain = fair_comparison(result, control, "plain")
            joint = fair_comparison(result, control, "joint")
            if controls:
                text.append(f"| {candidate} | {result['seeds']} | {pct(average(controls, 'mask_F1'))} | "
                            f"{pp(plain['delta'])} | {pp(plain['IoU_delta'])} | "
                            f"{pp(joint['delta'])} | {pp(joint['IoU_delta'])} |")
            else:
                text.append(f"| {candidate} | {result['seeds']} | нет полного парного контроля | — | — | — | — |")
        text += ["", "Разница относительно дообученной CNN не считается доказанной статистически. "
                 "Положительная разница только против замороженной базы не устанавливает пользу архитектуры.", ""]
        text += ["| Контроль: бюджет | Seed | Порог VAL | Macro-F1, % | IoU, % |",
                 "|---:|---:|---:|---:|---:|"]
        for row in control["rows"]:
            selected = row["selected"]
            text.append(f"| {row['budget']} | {row['seed']} | {selected['threshold']:.2f} | "
                        f"{pct(selected['mask_F1'])} | {pct(selected['IoU'])} |")
        text.append("")
    if output_figure:
        text += ["![Средние результаты и раздельные сравнения A/B](figures/architecture_validation.png)",
                 "", "На рисунке точечные средние сохранённых результатов. Интервалы "
                 "независимого подтверждения не рассчитываются. При наличии расширения отдельно показаны "
                 "все три seed и новые два seed; эти средние перекрываются по данным.", ""]
    text += [
        "## Что меняется в CNN",
        "",
        "Общий источник — прежние веса CNN с 10 681 параметром. Она заморожена, "
        "а новый блок использует 24 признака, исходный logit, SEM и две условные карты. "
        "Карты получены из предсказания, без эталонной маски и класса. "
        "У plain это вероятность и неопределённость; у joint — отклики совместной пиксельной правки. "
        "Нормировка одинакова: log1p(100m), поканальное центрирование и нормировка RMS со стабилизатором 1e−6.",
        "",
        f"Все новые блоки этого этапа выдают ограниченную знаковую поправку `{eta:g}*tanh(residual)`. "
        "Нулевой последний слой даёт точное совпадение с исходной CNN при инициализации. "
        "Внутри каждой архитектуры plain/joint имеют одинаковое число параметров, начальные веса и батчи. "
        "Между разными архитектурами размер блока может различаться.",
        "",
        "| Вариант | Изменение | Обучаемых параметров | Всего параметров |",
        "|---|---|---:|---:|",
    ]
    for candidate in queue:
        rows = [row for row in actual_rows if row.get("candidate") == candidate]
        trainable = str(rows[0]["trainable_parameters"]) if rows else "не обучалась"
        total = str(rows[0]["total_parameters"]) if rows else "—"
        text.append(f"| {candidate} | {DESCRIPTIONS.get(candidate, candidate)} | {trainable} | {total} |")
    text += [
        "",
        "## Данные и одинаковые условия",
        "",
        "Только TRAIN/VAL: пул 54 плотных масок, 1152 слабых примера и 695 VAL. "
        "Плотные бюджеты 18/27 вложены и сбалансированы: 2/3 примера каждого из девяти классов. "
        "Один розыгрыш 5303, общие исходные веса для каждого бюджета/seed. "
        "Слабые маски оптимизатору не передаются. Это уже подготовленные данные одного кристалла; "
        "классы вычислены из масок условной решёткой и не являются авторскими типами дефекта.",
        "",
        "В каждой модели 500 дополнительных шагов AdamW, lr=0,0005, weight_decay=0,0001; "
        "по 8 плотных и 8 слабых примеров в шаге. MPS задан явно, fallback запрещён; "
        "малый физический решатель работает на CPU float64. Используется общий неизменный лосс.",
        "",
        "Порог каждой модели выбирается на VAL из `[0.30, 0.40, 0.45, 0.50, 0.55, 0.60, 0.70]`: "
        "Macro-F1, затем IoU, близость к 0,5 и меньший порог. При вмешательствах порог actual фиксирован. "
        "Zero обнуляет уже нормированные карты; roll сдвигает их на (5,5). "
        "Чувствительность к картам сама по себе не доказывает их полезность.",
        "",
        "## Все сохранённые попытки",
        "",
    ]
    next_stages = []
    for link_path in sorted(root.parent.glob("sem_arch_*/STAGE_LINK.json")):
        link = read(link_path, {})
        if link.get("previous_stage") and (link_path.parent / link["previous_stage"]).resolve() == root:
            next_stages.append(link_path.parent)
    if next_stages:
        text += ["## Связанные продолжения", ""]
        for next_root in next_stages:
            next_trials = discover(next_root)
            done = sum(bool(trial["result"]) for trial in next_trials)
            text.append(f"Следующий этап [{next_root.name}]({relative(next_root / 'PROTOCOL.md', root)}): "
                        f"начатых попыток {len(next_trials)}, завершённых {done}. "
                        "Его изменение и результаты учитываются отдельно, а результаты этого этапа сохраняются.")
            text.append("")
    if not trials:
        text += ["Обучающие попытки пока не сохранены.", ""]
    for trial in trials:
        rel = trial["path"].relative_to(root).as_posix()
        result = trial["result"]
        text += [f"### {trial['path'].name}", ""]
        if result:
            text += [f"Состояние: `{result['status']}`; этап: {stage_name(result)}; "
                     f"seed {result['seeds']}; {result['updates']:,} обновлений; {result['seconds']:.2f} с. "
                     f"[RESULT.json]({rel}/RESULT.json), [FROZEN.json]({rel}/FROZEN.json).", ""]
            text += ["| Бюджет | Seed | Карты | Порог | Macro-F1, % | IoU, % | Zero ΔF1, п.п. | Zero изменено, % | Roll ΔF1, п.п. | Roll изменено, % |",
                     "|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|"]
            for row in result["rows"]:
                s = row["selected"];z = row["ablations"]["zero"];r = row["ablations"]["roll"]
                text.append(f"| {row['budget']} | {row['seed']} | {row['arm']} | {s['threshold']:.2f} | "
                            f"{pct(s['mask_F1'])} | {pct(s['IoU'])} | {pp(z['mask_F1'] - s['mask_F1'])} | "
                            f"{pct(z['mask_flip_fraction'])} | {pp(r['mask_F1'] - s['mask_F1'])} | {pct(r['mask_flip_fraction'])} |")
            text += ["", "| Сравнение | ΔF1, п.п. | ΔIoU, п.п. | ΔF1 по бюджетам 18/27, п.п. | Критерий |",
                     "|---|---:|---:|---|---|"]
            for label, gate in [("A plain − base", result["gates"]["A_architecture"]["plain"]),
                                ("A joint − base", result["gates"]["A_architecture"]["joint"]),
                                ("B joint − plain", result["gates"]["B_physics"])]:
                text.append(f"| {label} | {pp(gate['delta'])} | {pp(gate['IoU_delta'])} | "
                            f"{' / '.join(pp(value) for value in gate['budget_deltas'])} | {passed(gate['passed'])} |")
            text.append("")
            if trial["aggregate"]:
                text += [f"[AGGREGATE_RESULT.json]({rel}/AGGREGATE_RESULT.json) объединяет "
                         "исходный seed 5501 с дополнительными 5521/5557; исходное обучение не дублируется.", ""]
        elif trial["failure"]:
            failure = trial["failure"]
            error = str(failure.get("error", "")).replace("\n", " ").replace("`", "'")
            text += [f"**Техническая ошибка:** `{failure.get('error_type', 'unknown')}` — {error}. "
                     f"Сохранено завершённых обучений до ошибки: {len(trial['partial'])}. "
                     f"[FAILURE.json]({rel}/FAILURE.json). Эта ошибка не считается отрицательным "
                     "научным результатом архитектуры.", ""]
        else:
            text += [f"Попытка начата; итоговый результат не сохранён. "
                     f"Завершённых обучений: {len(trial['partial'])}. [FROZEN.json]({rel}/FROZEN.json).", ""]
    text += [
        "## Техническая проверка и границы вывода",
        "",
    ]
    trial_audits = [trial for trial in completed if trial["audit"]]
    if audit:
        checks = audit.get("checks", [])
        count = len(checks) if isinstance(checks, (list, dict)) else "см. файл"
        text += [f"Сохранённый аудит: `{audit.get('status', 'см. файл')}`, "
                 f"проверок {count}. [AUDIT.json](AUDIT.json). "
                 "Технический PASS проверяет корректность реализации и сохранённых результатов; "
                 "он не заменяет критерии A/B.", ""]
    elif not trial_audits:
        text += ["Итоговый AUDIT.json на момент генерации отсутствует. "
                 "Техническая проверка не подменяет оценку пользы архитектуры.", ""]
    if trial_audits:
        text += ["Независимые CPU-аудиты сохранены для отдельных попыток:", "",
                 "| Попытка | Статус | Пройдено / всего | Максимальная ошибка полного прохода |",
                 "|---|---|---:|---:|"]
        for trial in trial_audits:
            item = trial["audit"]
            rel = trial["path"].relative_to(root).as_posix()
            error = item.get("maximum_errors", {}).get("independent_forward")
            error_text = f"{error:.3g}" if error is not None else "см. файл"
            text.append(f"| [{trial['path'].name}]({rel}/AUDIT.json) | {item['status']} | "
                        f"{item.get('checks_passed', '—')} / {item.get('checks_total', '—')} | {error_text} |")
        text += ["", "Технический PASS означает воспроизводимость реализации и результатов. "
                 "Критерии A/B проверяют другую задачу — пользу выбранного варианта.", ""]
        old_audits = sorted(path for trial in trials for path in trial["path"].glob("AUDIT_PREVIOUS_*.json"))
        if old_audits:
            text += ["Предыдущие версии технической проверки также сохранены:", ""]
            for path in old_audits:
                item = read(path, {})
                text.append(f"- [{path.relative_to(root).as_posix()}]({path.relative_to(root).as_posix()}): "
                            f"`{item.get('status', 'см. файл')}`; примечание актуального аудита описывает "
                            "изменение технической проверки. Исходные результаты обучения сохранены.")
            text.append("")
    text += [
        "Полный и кешированный проходы, неизменность исходной CNN, одинаковость батчей и инициализации "
        "plain/joint сохраняются в каждой записи обучения. Вероятности VAL и результаты вмешательств "
        "остаются в `trials/*/val_probs/`, веса — в `trials/*/models/`, снимки исходников — в `trials/*/source/`.",
        "",
        "Критерии используются для открытого поиска на повторно используемой VAL. "
        "Все попытки и их порядок должны сохраняться: случайный выигрыш после нескольких изменений "
        "нельзя выдавать за подтверждённую гипотезу. Перед независимым подтверждением "
        "выбранный вариант и критерии фиксируются; нужны равноправно дообученная CNN и новые кадры, "
        "не использованные для EDA или прежних тестов. Даже такое сравнение на одном ИС "
        "не доказывает перенос на другие изделия. Новизна рассматривается отдельно от численного выигрыша.",
        "",
        "## Файлы",
        "",
        "[model.py](model.py) · [runner.py](runner.py) · [audit.py](audit.py) · "
        "[PROTOCOL.md](PROTOCOL.md) · [QUEUE.json](QUEUE.json) · [LEDGER.json](LEDGER.json).",
        "",
    ]
    (root / "REPORT.md").write_text("\n".join(text))
    control_readme = (
        f"Равноправно дообученная CNN сохранена в [общем контроле]({relative(control_source['path'], root)}); "
        "парные сравнения по бюджету и seed приведены в отчёте. "
        + (f"Её {local_control_fits} обучений учитываются в этой папке один раз. "
           if control_source["local"] else "Её обучения учитываются в предыдущем этапе и повторно здесь не считаются. ")
        if control_source else
        "Перед архитектурным выводом требуется исходная CNN с теми же 500 дополнительными шагами. "
    )
    (root / "README.md").write_text(
        "# Разработка свёрточной модели SEM\n\n"
        "Здесь сравниваются небольшие изменения CNN-уточнителя: direct, split, film, gated. "
        "Порядок фактических попыток сохранён в LEDGER.json. "
        "Для каждого варианта plain/joint совпадают по архитектуре, параметрам, начальным весам и батчам. "
        "Прежний лосс фиксирован; основной предмет разработки — модель.\n\n"
        f"На момент генерации: {len(completed)} завершённых попыток, {len(failures)} технических ошибок, "
        f"{fit_count} сохранённых обучений уточнителей; {local_control_fits} локальных обучений контроля. "
        "Все результаты относятся к адаптивной разработке на TRAIN/VAL.\n\n"
        "- [Отчёт со всеми попытками и раздельными критериями A/B](REPORT.md).\n"
        "- [Протокол до обучения](PROTOCOL.md), [очередь](QUEUE.json), [журнал попыток](LEDGER.json).\n"
        "- [Модель](model.py), [обучение и оценки VAL](runner.py), [аудит](audit.py).\n\n"
        "A сравнивает уточнитель с замороженной CNN; B проверяет добавочную пользу физических карт "
        "относительно matched plain. "
        f"{control_readme}Нового TEST здесь нет. Для независимого подтверждения нужны заранее закрытые "
        "новые данные, не использованные в EDA, разработке или прежних тестах.\n\n"
        "Пересоздать только текст и рисунок, без обучения:\n\n"
        f"```bash\n.venv/bin/python -B gipoteza/{root.name}/report.py\n```\n"
    )
    inputs = [root / name for name in ("PROTOCOL.md", "QUEUE.json", "LEDGER.json", "AUDIT.json",
              "baseline_control/RESULT.json", "baseline_control/FROZEN.json", "STAGE_LINK.json")
              if (root / name).exists()]
    if control_source:
        inputs += [control_source["path"], control_source["frozen_path"]]
    for trial in trials:
        inputs += [trial["path"] / name for name in
                   ("FROZEN.json", "RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json", "PARTIAL_RESULTS.json", "AUDIT.json")
                   if (trial["path"] / name).exists()]
        inputs += sorted(trial["path"].glob("AUDIT_PREVIOUS_*.json"))
    for stage in history:
        inputs += [stage["link_path"]]
        for trial in stage["trials"]:
            inputs += [trial["path"] / name for name in ("RESULT.json", "AGGREGATE_RESULT.json", "FAILURE.json")
                       if (trial["path"] / name).exists()]
    for next_root in next_stages:
        inputs += [next_root / "STAGE_LINK.json"]
        inputs += sorted((next_root / "trials").glob("*/RESULT.json"))
    outputs = [root / "REPORT.md", root / "README.md"]
    if output_figure:
        outputs.append(output_figure)
    artifact = {
        "status": "REPORT_GENERATED",
        "scope": "ADAPTIVE_REUSED_TRAIN_VAL_ONLY",
        "UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "report_script_sha256": sha(Path(__file__)),
        "trial_count": len(trials), "completed_trials": len(completed), "failed_trials": len(failures),
        "pending_trials": len(pending),
        "fit_count_scope": "LOCAL_EXECUTIONS_ONLY; linked shared-control fits excluded from local totals",
        "actual_completed_fits": fit_count + local_control_fits,
        "refiner_completed_fits": fit_count,
        "control_completed_fits": local_control_fits,
        "referenced_control_fits": len(control.get("rows", [])) if control_source and not control_source["local"] else 0,
        "completed_updates": updates + local_control_updates,
        "ledger_events": len(ledger["events"]),
        "linked_stage_total_attempts": len(all_trials),
        "linked_stage_completed_attempts": len(all_completed),
        "linked_stage_refiner_completed_fits": len(all_actual_rows),
        "linked_stage_unique_completed_fits": len(all_actual_rows) + (len(control["rows"]) if control else 0),
        "continued_control_source": ({
            "result_path": relative(control_source["path"], root),
            "result_sha256": control_source["sha256"],
            "frozen_path": relative(control_source["frozen_path"], root),
            "frozen_sha256": control_source["frozen_sha256"],
            "local_execution": control_source["local"],
            "matching_unit": ["budget", "seed"],
            "matched_fields": ["backbone_before_sha256", "batch_sequence_sha256", "steps"],
            "descriptive_comparisons": {
                f"{name}:seeds={result['seeds']}": {
                    arm: fair_comparison(result, control, arm) for arm in ("plain", "joint")}
                for name, result in result_views(queue, trials)},
            "original_A_B_gates_modified": False,
        } if control_source else None),
        "scientific_inputs_sha256": {relative(path, root): sha(path) for path in inputs},
        "outputs_sha256": {str(path.relative_to(root)): sha(path) for path in outputs},
    }
    dump(root / "REPORT_MANIFEST.json", artifact)
    print(json.dumps(artifact, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    build(args.root.resolve())


if __name__ == "__main__":
    main()
